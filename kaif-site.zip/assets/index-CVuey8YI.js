(function(){const i=document.createElement("link").relList;if(i&&i.supports&&i.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))r(s);new MutationObserver(s=>{for(const c of s)if(c.type==="childList")for(const u of c.addedNodes)u.tagName==="LINK"&&u.rel==="modulepreload"&&r(u)}).observe(document,{childList:!0,subtree:!0});function a(s){const c={};return s.integrity&&(c.integrity=s.integrity),s.referrerPolicy&&(c.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?c.credentials="include":s.crossOrigin==="anonymous"?c.credentials="omit":c.credentials="same-origin",c}function r(s){if(s.ep)return;s.ep=!0;const c=a(s);fetch(s.href,c)}})();function jr(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}var rf={exports:{}},Mo={};/**
 * @license React
 * react-jsx-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Z1;function b4(){if(Z1)return Mo;Z1=1;var e=Symbol.for("react.transitional.element"),i=Symbol.for("react.fragment");function a(r,s,c){var u=null;if(c!==void 0&&(u=""+c),s.key!==void 0&&(u=""+s.key),"key"in s){c={};for(var f in s)f!=="key"&&(c[f]=s[f])}else c=s;return s=c.ref,{$$typeof:e,type:r,key:u,ref:s!==void 0?s:null,props:c}}return Mo.Fragment=i,Mo.jsx=a,Mo.jsxs=a,Mo}var Q1;function v4(){return Q1||(Q1=1,rf.exports=b4()),rf.exports}var h=v4(),of={exports:{}},me={};/**
 * @license React
 * react.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var J1;function w4(){if(J1)return me;J1=1;var e=Symbol.for("react.transitional.element"),i=Symbol.for("react.portal"),a=Symbol.for("react.fragment"),r=Symbol.for("react.strict_mode"),s=Symbol.for("react.profiler"),c=Symbol.for("react.consumer"),u=Symbol.for("react.context"),f=Symbol.for("react.forward_ref"),p=Symbol.for("react.suspense"),m=Symbol.for("react.memo"),y=Symbol.for("react.lazy"),x=Symbol.iterator;function b(z){return z===null||typeof z!="object"?null:(z=x&&z[x]||z["@@iterator"],typeof z=="function"?z:null)}var T={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},A=Object.assign,C={};function B(z,q,Q){this.props=z,this.context=q,this.refs=C,this.updater=Q||T}B.prototype.isReactComponent={},B.prototype.setState=function(z,q){if(typeof z!="object"&&typeof z!="function"&&z!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,z,q,"setState")},B.prototype.forceUpdate=function(z){this.updater.enqueueForceUpdate(this,z,"forceUpdate")};function E(){}E.prototype=B.prototype;function k(z,q,Q){this.props=z,this.context=q,this.refs=C,this.updater=Q||T}var M=k.prototype=new E;M.constructor=k,A(M,B.prototype),M.isPureReactComponent=!0;var F=Array.isArray,D={H:null,A:null,T:null,S:null,V:null},U=Object.prototype.hasOwnProperty;function G(z,q,Q,W,ae,ge){return Q=ge.ref,{$$typeof:e,type:z,key:q,ref:Q!==void 0?Q:null,props:ge}}function Z(z,q){return G(z.type,q,void 0,void 0,void 0,z.props)}function J(z){return typeof z=="object"&&z!==null&&z.$$typeof===e}function ie(z){var q={"=":"=0",":":"=2"};return"$"+z.replace(/[=:]/g,function(Q){return q[Q]})}var oe=/\/+/g;function xe(z,q){return typeof z=="object"&&z!==null&&z.key!=null?ie(""+z.key):q.toString(36)}function Le(){}function ne(z){switch(z.status){case"fulfilled":return z.value;case"rejected":throw z.reason;default:switch(typeof z.status=="string"?z.then(Le,Le):(z.status="pending",z.then(function(q){z.status==="pending"&&(z.status="fulfilled",z.value=q)},function(q){z.status==="pending"&&(z.status="rejected",z.reason=q)})),z.status){case"fulfilled":return z.value;case"rejected":throw z.reason}}throw z}function we(z,q,Q,W,ae){var ge=typeof z;(ge==="undefined"||ge==="boolean")&&(z=null);var le=!1;if(z===null)le=!0;else switch(ge){case"bigint":case"string":case"number":le=!0;break;case"object":switch(z.$$typeof){case e:case i:le=!0;break;case y:return le=z._init,we(le(z._payload),q,Q,W,ae)}}if(le)return ae=ae(z),le=W===""?"."+xe(z,0):W,F(ae)?(Q="",le!=null&&(Q=le.replace(oe,"$&/")+"/"),we(ae,q,Q,"",function(gt){return gt})):ae!=null&&(J(ae)&&(ae=Z(ae,Q+(ae.key==null||z&&z.key===ae.key?"":(""+ae.key).replace(oe,"$&/")+"/")+le)),q.push(ae)),1;le=0;var rt=W===""?".":W+":";if(F(z))for(var Oe=0;Oe<z.length;Oe++)W=z[Oe],ge=rt+xe(W,Oe),le+=we(W,q,Q,ge,ae);else if(Oe=b(z),typeof Oe=="function")for(z=Oe.call(z),Oe=0;!(W=z.next()).done;)W=W.value,ge=rt+xe(W,Oe++),le+=we(W,q,Q,ge,ae);else if(ge==="object"){if(typeof z.then=="function")return we(ne(z),q,Q,W,ae);throw q=String(z),Error("Objects are not valid as a React child (found: "+(q==="[object Object]"?"object with keys {"+Object.keys(z).join(", ")+"}":q)+"). If you meant to render a collection of children, use an array instead.")}return le}function P(z,q,Q){if(z==null)return z;var W=[],ae=0;return we(z,W,"","",function(ge){return q.call(Q,ge,ae++)}),W}function X(z){if(z._status===-1){var q=z._result;q=q(),q.then(function(Q){(z._status===0||z._status===-1)&&(z._status=1,z._result=Q)},function(Q){(z._status===0||z._status===-1)&&(z._status=2,z._result=Q)}),z._status===-1&&(z._status=0,z._result=q)}if(z._status===1)return z._result.default;throw z._result}var ee=typeof reportError=="function"?reportError:function(z){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var q=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof z=="object"&&z!==null&&typeof z.message=="string"?String(z.message):String(z),error:z});if(!window.dispatchEvent(q))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",z);return}console.error(z)};function fe(){}return me.Children={map:P,forEach:function(z,q,Q){P(z,function(){q.apply(this,arguments)},Q)},count:function(z){var q=0;return P(z,function(){q++}),q},toArray:function(z){return P(z,function(q){return q})||[]},only:function(z){if(!J(z))throw Error("React.Children.only expected to receive a single React element child.");return z}},me.Component=B,me.Fragment=a,me.Profiler=s,me.PureComponent=k,me.StrictMode=r,me.Suspense=p,me.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=D,me.__COMPILER_RUNTIME={__proto__:null,c:function(z){return D.H.useMemoCache(z)}},me.cache=function(z){return function(){return z.apply(null,arguments)}},me.cloneElement=function(z,q,Q){if(z==null)throw Error("The argument must be a React element, but you passed "+z+".");var W=A({},z.props),ae=z.key,ge=void 0;if(q!=null)for(le in q.ref!==void 0&&(ge=void 0),q.key!==void 0&&(ae=""+q.key),q)!U.call(q,le)||le==="key"||le==="__self"||le==="__source"||le==="ref"&&q.ref===void 0||(W[le]=q[le]);var le=arguments.length-2;if(le===1)W.children=Q;else if(1<le){for(var rt=Array(le),Oe=0;Oe<le;Oe++)rt[Oe]=arguments[Oe+2];W.children=rt}return G(z.type,ae,void 0,void 0,ge,W)},me.createContext=function(z){return z={$$typeof:u,_currentValue:z,_currentValue2:z,_threadCount:0,Provider:null,Consumer:null},z.Provider=z,z.Consumer={$$typeof:c,_context:z},z},me.createElement=function(z,q,Q){var W,ae={},ge=null;if(q!=null)for(W in q.key!==void 0&&(ge=""+q.key),q)U.call(q,W)&&W!=="key"&&W!=="__self"&&W!=="__source"&&(ae[W]=q[W]);var le=arguments.length-2;if(le===1)ae.children=Q;else if(1<le){for(var rt=Array(le),Oe=0;Oe<le;Oe++)rt[Oe]=arguments[Oe+2];ae.children=rt}if(z&&z.defaultProps)for(W in le=z.defaultProps,le)ae[W]===void 0&&(ae[W]=le[W]);return G(z,ge,void 0,void 0,null,ae)},me.createRef=function(){return{current:null}},me.forwardRef=function(z){return{$$typeof:f,render:z}},me.isValidElement=J,me.lazy=function(z){return{$$typeof:y,_payload:{_status:-1,_result:z},_init:X}},me.memo=function(z,q){return{$$typeof:m,type:z,compare:q===void 0?null:q}},me.startTransition=function(z){var q=D.T,Q={};D.T=Q;try{var W=z(),ae=D.S;ae!==null&&ae(Q,W),typeof W=="object"&&W!==null&&typeof W.then=="function"&&W.then(fe,ee)}catch(ge){ee(ge)}finally{D.T=q}},me.unstable_useCacheRefresh=function(){return D.H.useCacheRefresh()},me.use=function(z){return D.H.use(z)},me.useActionState=function(z,q,Q){return D.H.useActionState(z,q,Q)},me.useCallback=function(z,q){return D.H.useCallback(z,q)},me.useContext=function(z){return D.H.useContext(z)},me.useDebugValue=function(){},me.useDeferredValue=function(z,q){return D.H.useDeferredValue(z,q)},me.useEffect=function(z,q,Q){var W=D.H;if(typeof Q=="function")throw Error("useEffect CRUD overload is not enabled in this build of React.");return W.useEffect(z,q)},me.useId=function(){return D.H.useId()},me.useImperativeHandle=function(z,q,Q){return D.H.useImperativeHandle(z,q,Q)},me.useInsertionEffect=function(z,q){return D.H.useInsertionEffect(z,q)},me.useLayoutEffect=function(z,q){return D.H.useLayoutEffect(z,q)},me.useMemo=function(z,q){return D.H.useMemo(z,q)},me.useOptimistic=function(z,q){return D.H.useOptimistic(z,q)},me.useReducer=function(z,q,Q){return D.H.useReducer(z,q,Q)},me.useRef=function(z){return D.H.useRef(z)},me.useState=function(z){return D.H.useState(z)},me.useSyncExternalStore=function(z,q,Q){return D.H.useSyncExternalStore(z,q,Q)},me.useTransition=function(){return D.H.useTransition()},me.version="19.1.0",me}var W1;function Rc(){return W1||(W1=1,of.exports=w4()),of.exports}var S=Rc();const Ce=jr(S);var sf={exports:{}},Bo={},lf={exports:{}},cf={};/**
 * @license React
 * scheduler.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var ey;function S4(){return ey||(ey=1,function(e){function i(P,X){var ee=P.length;P.push(X);e:for(;0<ee;){var fe=ee-1>>>1,z=P[fe];if(0<s(z,X))P[fe]=X,P[ee]=z,ee=fe;else break e}}function a(P){return P.length===0?null:P[0]}function r(P){if(P.length===0)return null;var X=P[0],ee=P.pop();if(ee!==X){P[0]=ee;e:for(var fe=0,z=P.length,q=z>>>1;fe<q;){var Q=2*(fe+1)-1,W=P[Q],ae=Q+1,ge=P[ae];if(0>s(W,ee))ae<z&&0>s(ge,W)?(P[fe]=ge,P[ae]=ee,fe=ae):(P[fe]=W,P[Q]=ee,fe=Q);else if(ae<z&&0>s(ge,ee))P[fe]=ge,P[ae]=ee,fe=ae;else break e}}return X}function s(P,X){var ee=P.sortIndex-X.sortIndex;return ee!==0?ee:P.id-X.id}if(e.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"){var c=performance;e.unstable_now=function(){return c.now()}}else{var u=Date,f=u.now();e.unstable_now=function(){return u.now()-f}}var p=[],m=[],y=1,x=null,b=3,T=!1,A=!1,C=!1,B=!1,E=typeof setTimeout=="function"?setTimeout:null,k=typeof clearTimeout=="function"?clearTimeout:null,M=typeof setImmediate<"u"?setImmediate:null;function F(P){for(var X=a(m);X!==null;){if(X.callback===null)r(m);else if(X.startTime<=P)r(m),X.sortIndex=X.expirationTime,i(p,X);else break;X=a(m)}}function D(P){if(C=!1,F(P),!A)if(a(p)!==null)A=!0,U||(U=!0,xe());else{var X=a(m);X!==null&&we(D,X.startTime-P)}}var U=!1,G=-1,Z=5,J=-1;function ie(){return B?!0:!(e.unstable_now()-J<Z)}function oe(){if(B=!1,U){var P=e.unstable_now();J=P;var X=!0;try{e:{A=!1,C&&(C=!1,k(G),G=-1),T=!0;var ee=b;try{t:{for(F(P),x=a(p);x!==null&&!(x.expirationTime>P&&ie());){var fe=x.callback;if(typeof fe=="function"){x.callback=null,b=x.priorityLevel;var z=fe(x.expirationTime<=P);if(P=e.unstable_now(),typeof z=="function"){x.callback=z,F(P),X=!0;break t}x===a(p)&&r(p),F(P)}else r(p);x=a(p)}if(x!==null)X=!0;else{var q=a(m);q!==null&&we(D,q.startTime-P),X=!1}}break e}finally{x=null,b=ee,T=!1}X=void 0}}finally{X?xe():U=!1}}}var xe;if(typeof M=="function")xe=function(){M(oe)};else if(typeof MessageChannel<"u"){var Le=new MessageChannel,ne=Le.port2;Le.port1.onmessage=oe,xe=function(){ne.postMessage(null)}}else xe=function(){E(oe,0)};function we(P,X){G=E(function(){P(e.unstable_now())},X)}e.unstable_IdlePriority=5,e.unstable_ImmediatePriority=1,e.unstable_LowPriority=4,e.unstable_NormalPriority=3,e.unstable_Profiling=null,e.unstable_UserBlockingPriority=2,e.unstable_cancelCallback=function(P){P.callback=null},e.unstable_forceFrameRate=function(P){0>P||125<P?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):Z=0<P?Math.floor(1e3/P):5},e.unstable_getCurrentPriorityLevel=function(){return b},e.unstable_next=function(P){switch(b){case 1:case 2:case 3:var X=3;break;default:X=b}var ee=b;b=X;try{return P()}finally{b=ee}},e.unstable_requestPaint=function(){B=!0},e.unstable_runWithPriority=function(P,X){switch(P){case 1:case 2:case 3:case 4:case 5:break;default:P=3}var ee=b;b=P;try{return X()}finally{b=ee}},e.unstable_scheduleCallback=function(P,X,ee){var fe=e.unstable_now();switch(typeof ee=="object"&&ee!==null?(ee=ee.delay,ee=typeof ee=="number"&&0<ee?fe+ee:fe):ee=fe,P){case 1:var z=-1;break;case 2:z=250;break;case 5:z=1073741823;break;case 4:z=1e4;break;default:z=5e3}return z=ee+z,P={id:y++,callback:X,priorityLevel:P,startTime:ee,expirationTime:z,sortIndex:-1},ee>fe?(P.sortIndex=ee,i(m,P),a(p)===null&&P===a(m)&&(C?(k(G),G=-1):C=!0,we(D,ee-fe))):(P.sortIndex=z,i(p,P),A||T||(A=!0,U||(U=!0,xe()))),P},e.unstable_shouldYield=ie,e.unstable_wrapCallback=function(P){var X=b;return function(){var ee=b;b=X;try{return P.apply(this,arguments)}finally{b=ee}}}}(cf)),cf}var ty;function T4(){return ty||(ty=1,lf.exports=S4()),lf.exports}var uf={exports:{}},bt={};/**
 * @license React
 * react-dom.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var iy;function j4(){if(iy)return bt;iy=1;var e=Rc();function i(p){var m="https://react.dev/errors/"+p;if(1<arguments.length){m+="?args[]="+encodeURIComponent(arguments[1]);for(var y=2;y<arguments.length;y++)m+="&args[]="+encodeURIComponent(arguments[y])}return"Minified React error #"+p+"; visit "+m+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function a(){}var r={d:{f:a,r:function(){throw Error(i(522))},D:a,C:a,L:a,m:a,X:a,S:a,M:a},p:0,findDOMNode:null},s=Symbol.for("react.portal");function c(p,m,y){var x=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:s,key:x==null?null:""+x,children:p,containerInfo:m,implementation:y}}var u=e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function f(p,m){if(p==="font")return"";if(typeof m=="string")return m==="use-credentials"?m:""}return bt.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=r,bt.createPortal=function(p,m){var y=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!m||m.nodeType!==1&&m.nodeType!==9&&m.nodeType!==11)throw Error(i(299));return c(p,m,null,y)},bt.flushSync=function(p){var m=u.T,y=r.p;try{if(u.T=null,r.p=2,p)return p()}finally{u.T=m,r.p=y,r.d.f()}},bt.preconnect=function(p,m){typeof p=="string"&&(m?(m=m.crossOrigin,m=typeof m=="string"?m==="use-credentials"?m:"":void 0):m=null,r.d.C(p,m))},bt.prefetchDNS=function(p){typeof p=="string"&&r.d.D(p)},bt.preinit=function(p,m){if(typeof p=="string"&&m&&typeof m.as=="string"){var y=m.as,x=f(y,m.crossOrigin),b=typeof m.integrity=="string"?m.integrity:void 0,T=typeof m.fetchPriority=="string"?m.fetchPriority:void 0;y==="style"?r.d.S(p,typeof m.precedence=="string"?m.precedence:void 0,{crossOrigin:x,integrity:b,fetchPriority:T}):y==="script"&&r.d.X(p,{crossOrigin:x,integrity:b,fetchPriority:T,nonce:typeof m.nonce=="string"?m.nonce:void 0})}},bt.preinitModule=function(p,m){if(typeof p=="string")if(typeof m=="object"&&m!==null){if(m.as==null||m.as==="script"){var y=f(m.as,m.crossOrigin);r.d.M(p,{crossOrigin:y,integrity:typeof m.integrity=="string"?m.integrity:void 0,nonce:typeof m.nonce=="string"?m.nonce:void 0})}}else m==null&&r.d.M(p)},bt.preload=function(p,m){if(typeof p=="string"&&typeof m=="object"&&m!==null&&typeof m.as=="string"){var y=m.as,x=f(y,m.crossOrigin);r.d.L(p,y,{crossOrigin:x,integrity:typeof m.integrity=="string"?m.integrity:void 0,nonce:typeof m.nonce=="string"?m.nonce:void 0,type:typeof m.type=="string"?m.type:void 0,fetchPriority:typeof m.fetchPriority=="string"?m.fetchPriority:void 0,referrerPolicy:typeof m.referrerPolicy=="string"?m.referrerPolicy:void 0,imageSrcSet:typeof m.imageSrcSet=="string"?m.imageSrcSet:void 0,imageSizes:typeof m.imageSizes=="string"?m.imageSizes:void 0,media:typeof m.media=="string"?m.media:void 0})}},bt.preloadModule=function(p,m){if(typeof p=="string")if(m){var y=f(m.as,m.crossOrigin);r.d.m(p,{as:typeof m.as=="string"&&m.as!=="script"?m.as:void 0,crossOrigin:y,integrity:typeof m.integrity=="string"?m.integrity:void 0})}else r.d.m(p)},bt.requestFormReset=function(p){r.d.r(p)},bt.unstable_batchedUpdates=function(p,m){return p(m)},bt.useFormState=function(p,m,y){return u.H.useFormState(p,m,y)},bt.useFormStatus=function(){return u.H.useHostTransitionStatus()},bt.version="19.1.0",bt}var ny;function A4(){if(ny)return uf.exports;ny=1;function e(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(e)}catch(i){console.error(i)}}return e(),uf.exports=j4(),uf.exports}/**
 * @license React
 * react-dom-client.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var ay;function E4(){if(ay)return Bo;ay=1;var e=T4(),i=Rc(),a=A4();function r(t){var n="https://react.dev/errors/"+t;if(1<arguments.length){n+="?args[]="+encodeURIComponent(arguments[1]);for(var o=2;o<arguments.length;o++)n+="&args[]="+encodeURIComponent(arguments[o])}return"Minified React error #"+t+"; visit "+n+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function s(t){return!(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11)}function c(t){var n=t,o=t;if(t.alternate)for(;n.return;)n=n.return;else{t=n;do n=t,(n.flags&4098)!==0&&(o=n.return),t=n.return;while(t)}return n.tag===3?o:null}function u(t){if(t.tag===13){var n=t.memoizedState;if(n===null&&(t=t.alternate,t!==null&&(n=t.memoizedState)),n!==null)return n.dehydrated}return null}function f(t){if(c(t)!==t)throw Error(r(188))}function p(t){var n=t.alternate;if(!n){if(n=c(t),n===null)throw Error(r(188));return n!==t?null:t}for(var o=t,l=n;;){var d=o.return;if(d===null)break;var g=d.alternate;if(g===null){if(l=d.return,l!==null){o=l;continue}break}if(d.child===g.child){for(g=d.child;g;){if(g===o)return f(d),t;if(g===l)return f(d),n;g=g.sibling}throw Error(r(188))}if(o.return!==l.return)o=d,l=g;else{for(var v=!1,j=d.child;j;){if(j===o){v=!0,o=d,l=g;break}if(j===l){v=!0,l=d,o=g;break}j=j.sibling}if(!v){for(j=g.child;j;){if(j===o){v=!0,o=g,l=d;break}if(j===l){v=!0,l=g,o=d;break}j=j.sibling}if(!v)throw Error(r(189))}}if(o.alternate!==l)throw Error(r(190))}if(o.tag!==3)throw Error(r(188));return o.stateNode.current===o?t:n}function m(t){var n=t.tag;if(n===5||n===26||n===27||n===6)return t;for(t=t.child;t!==null;){if(n=m(t),n!==null)return n;t=t.sibling}return null}var y=Object.assign,x=Symbol.for("react.element"),b=Symbol.for("react.transitional.element"),T=Symbol.for("react.portal"),A=Symbol.for("react.fragment"),C=Symbol.for("react.strict_mode"),B=Symbol.for("react.profiler"),E=Symbol.for("react.provider"),k=Symbol.for("react.consumer"),M=Symbol.for("react.context"),F=Symbol.for("react.forward_ref"),D=Symbol.for("react.suspense"),U=Symbol.for("react.suspense_list"),G=Symbol.for("react.memo"),Z=Symbol.for("react.lazy"),J=Symbol.for("react.activity"),ie=Symbol.for("react.memo_cache_sentinel"),oe=Symbol.iterator;function xe(t){return t===null||typeof t!="object"?null:(t=oe&&t[oe]||t["@@iterator"],typeof t=="function"?t:null)}var Le=Symbol.for("react.client.reference");function ne(t){if(t==null)return null;if(typeof t=="function")return t.$$typeof===Le?null:t.displayName||t.name||null;if(typeof t=="string")return t;switch(t){case A:return"Fragment";case B:return"Profiler";case C:return"StrictMode";case D:return"Suspense";case U:return"SuspenseList";case J:return"Activity"}if(typeof t=="object")switch(t.$$typeof){case T:return"Portal";case M:return(t.displayName||"Context")+".Provider";case k:return(t._context.displayName||"Context")+".Consumer";case F:var n=t.render;return t=t.displayName,t||(t=n.displayName||n.name||"",t=t!==""?"ForwardRef("+t+")":"ForwardRef"),t;case G:return n=t.displayName||null,n!==null?n:ne(t.type)||"Memo";case Z:n=t._payload,t=t._init;try{return ne(t(n))}catch{}}return null}var we=Array.isArray,P=i.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,X=a.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,ee={pending:!1,data:null,method:null,action:null},fe=[],z=-1;function q(t){return{current:t}}function Q(t){0>z||(t.current=fe[z],fe[z]=null,z--)}function W(t,n){z++,fe[z]=t.current,t.current=n}var ae=q(null),ge=q(null),le=q(null),rt=q(null);function Oe(t,n){switch(W(le,n),W(ge,t),W(ae,null),n.nodeType){case 9:case 11:t=(t=n.documentElement)&&(t=t.namespaceURI)?j1(t):0;break;default:if(t=n.tagName,n=n.namespaceURI)n=j1(n),t=A1(n,t);else switch(t){case"svg":t=1;break;case"math":t=2;break;default:t=0}}Q(ae),W(ae,t)}function gt(){Q(ae),Q(ge),Q(le)}function Bn(t){t.memoizedState!==null&&W(rt,t);var n=ae.current,o=A1(n,t.type);n!==o&&(W(ge,t),W(ae,o))}function Ri(t){ge.current===t&&(Q(ae),Q(ge)),rt.current===t&&(Q(rt),Co._currentValue=ee)}var qt=Object.prototype.hasOwnProperty,Ic=e.unstable_scheduleCallback,Yc=e.unstable_cancelCallback,Q2=e.unstable_shouldYield,J2=e.unstable_requestPaint,pi=e.unstable_now,W2=e.unstable_getCurrentPriorityLevel,a0=e.unstable_ImmediatePriority,r0=e.unstable_UserBlockingPriority,Ts=e.unstable_NormalPriority,ew=e.unstable_LowPriority,o0=e.unstable_IdlePriority,tw=e.log,iw=e.unstable_setDisableYieldValue,zr=null,Bt=null;function en(t){if(typeof tw=="function"&&iw(t),Bt&&typeof Bt.setStrictMode=="function")try{Bt.setStrictMode(zr,t)}catch{}}var zt=Math.clz32?Math.clz32:rw,nw=Math.log,aw=Math.LN2;function rw(t){return t>>>=0,t===0?32:31-(nw(t)/aw|0)|0}var js=256,As=4194304;function zn(t){var n=t&42;if(n!==0)return n;switch(t&-t){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t&4194048;case 4194304:case 8388608:case 16777216:case 33554432:return t&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return t}}function Es(t,n,o){var l=t.pendingLanes;if(l===0)return 0;var d=0,g=t.suspendedLanes,v=t.pingedLanes;t=t.warmLanes;var j=l&134217727;return j!==0?(l=j&~g,l!==0?d=zn(l):(v&=j,v!==0?d=zn(v):o||(o=j&~t,o!==0&&(d=zn(o))))):(j=l&~g,j!==0?d=zn(j):v!==0?d=zn(v):o||(o=l&~t,o!==0&&(d=zn(o)))),d===0?0:n!==0&&n!==d&&(n&g)===0&&(g=d&-d,o=n&-n,g>=o||g===32&&(o&4194048)!==0)?n:d}function $r(t,n){return(t.pendingLanes&~(t.suspendedLanes&~t.pingedLanes)&n)===0}function ow(t,n){switch(t){case 1:case 2:case 4:case 8:case 64:return n+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return n+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function s0(){var t=js;return js<<=1,(js&4194048)===0&&(js=256),t}function l0(){var t=As;return As<<=1,(As&62914560)===0&&(As=4194304),t}function Gc(t){for(var n=[],o=0;31>o;o++)n.push(t);return n}function Nr(t,n){t.pendingLanes|=n,n!==268435456&&(t.suspendedLanes=0,t.pingedLanes=0,t.warmLanes=0)}function sw(t,n,o,l,d,g){var v=t.pendingLanes;t.pendingLanes=o,t.suspendedLanes=0,t.pingedLanes=0,t.warmLanes=0,t.expiredLanes&=o,t.entangledLanes&=o,t.errorRecoveryDisabledLanes&=o,t.shellSuspendCounter=0;var j=t.entanglements,R=t.expirationTimes,_=t.hiddenUpdates;for(o=v&~o;0<o;){var I=31-zt(o),K=1<<I;j[I]=0,R[I]=-1;var H=_[I];if(H!==null)for(_[I]=null,I=0;I<H.length;I++){var V=H[I];V!==null&&(V.lane&=-536870913)}o&=~K}l!==0&&c0(t,l,0),g!==0&&d===0&&t.tag!==0&&(t.suspendedLanes|=g&~(v&~n))}function c0(t,n,o){t.pendingLanes|=n,t.suspendedLanes&=~n;var l=31-zt(n);t.entangledLanes|=n,t.entanglements[l]=t.entanglements[l]|1073741824|o&4194090}function u0(t,n){var o=t.entangledLanes|=n;for(t=t.entanglements;o;){var l=31-zt(o),d=1<<l;d&n|t[l]&n&&(t[l]|=n),o&=~d}}function Kc(t){switch(t){case 2:t=1;break;case 8:t=4;break;case 32:t=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:t=128;break;case 268435456:t=134217728;break;default:t=0}return t}function Xc(t){return t&=-t,2<t?8<t?(t&134217727)!==0?32:268435456:8:2}function d0(){var t=X.p;return t!==0?t:(t=window.event,t===void 0?32:q1(t.type))}function lw(t,n){var o=X.p;try{return X.p=t,n()}finally{X.p=o}}var tn=Math.random().toString(36).slice(2),yt="__reactFiber$"+tn,At="__reactProps$"+tn,fa="__reactContainer$"+tn,Zc="__reactEvents$"+tn,cw="__reactListeners$"+tn,uw="__reactHandles$"+tn,f0="__reactResources$"+tn,Lr="__reactMarker$"+tn;function Qc(t){delete t[yt],delete t[At],delete t[Zc],delete t[cw],delete t[uw]}function ha(t){var n=t[yt];if(n)return n;for(var o=t.parentNode;o;){if(n=o[fa]||o[yt]){if(o=n.alternate,n.child!==null||o!==null&&o.child!==null)for(t=R1(t);t!==null;){if(o=t[yt])return o;t=R1(t)}return n}t=o,o=t.parentNode}return null}function pa(t){if(t=t[yt]||t[fa]){var n=t.tag;if(n===5||n===6||n===13||n===26||n===27||n===3)return t}return null}function _r(t){var n=t.tag;if(n===5||n===26||n===27||n===6)return t.stateNode;throw Error(r(33))}function ma(t){var n=t[f0];return n||(n=t[f0]={hoistableStyles:new Map,hoistableScripts:new Map}),n}function ot(t){t[Lr]=!0}var h0=new Set,p0={};function $n(t,n){ga(t,n),ga(t+"Capture",n)}function ga(t,n){for(p0[t]=n,t=0;t<n.length;t++)h0.add(n[t])}var dw=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),m0={},g0={};function fw(t){return qt.call(g0,t)?!0:qt.call(m0,t)?!1:dw.test(t)?g0[t]=!0:(m0[t]=!0,!1)}function Cs(t,n,o){if(fw(n))if(o===null)t.removeAttribute(n);else{switch(typeof o){case"undefined":case"function":case"symbol":t.removeAttribute(n);return;case"boolean":var l=n.toLowerCase().slice(0,5);if(l!=="data-"&&l!=="aria-"){t.removeAttribute(n);return}}t.setAttribute(n,""+o)}}function Os(t,n,o){if(o===null)t.removeAttribute(n);else{switch(typeof o){case"undefined":case"function":case"symbol":case"boolean":t.removeAttribute(n);return}t.setAttribute(n,""+o)}}function ki(t,n,o,l){if(l===null)t.removeAttribute(o);else{switch(typeof l){case"undefined":case"function":case"symbol":case"boolean":t.removeAttribute(o);return}t.setAttributeNS(n,o,""+l)}}var Jc,y0;function ya(t){if(Jc===void 0)try{throw Error()}catch(o){var n=o.stack.trim().match(/\n( *(at )?)/);Jc=n&&n[1]||"",y0=-1<o.stack.indexOf(`
    at`)?" (<anonymous>)":-1<o.stack.indexOf("@")?"@unknown:0:0":""}return`
`+Jc+t+y0}var Wc=!1;function eu(t,n){if(!t||Wc)return"";Wc=!0;var o=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var l={DetermineComponentFrameRoot:function(){try{if(n){var K=function(){throw Error()};if(Object.defineProperty(K.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(K,[])}catch(V){var H=V}Reflect.construct(t,[],K)}else{try{K.call()}catch(V){H=V}t.call(K.prototype)}}else{try{throw Error()}catch(V){H=V}(K=t())&&typeof K.catch=="function"&&K.catch(function(){})}}catch(V){if(V&&H&&typeof V.stack=="string")return[V.stack,H.stack]}return[null,null]}};l.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var d=Object.getOwnPropertyDescriptor(l.DetermineComponentFrameRoot,"name");d&&d.configurable&&Object.defineProperty(l.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var g=l.DetermineComponentFrameRoot(),v=g[0],j=g[1];if(v&&j){var R=v.split(`
`),_=j.split(`
`);for(d=l=0;l<R.length&&!R[l].includes("DetermineComponentFrameRoot");)l++;for(;d<_.length&&!_[d].includes("DetermineComponentFrameRoot");)d++;if(l===R.length||d===_.length)for(l=R.length-1,d=_.length-1;1<=l&&0<=d&&R[l]!==_[d];)d--;for(;1<=l&&0<=d;l--,d--)if(R[l]!==_[d]){if(l!==1||d!==1)do if(l--,d--,0>d||R[l]!==_[d]){var I=`
`+R[l].replace(" at new "," at ");return t.displayName&&I.includes("<anonymous>")&&(I=I.replace("<anonymous>",t.displayName)),I}while(1<=l&&0<=d);break}}}finally{Wc=!1,Error.prepareStackTrace=o}return(o=t?t.displayName||t.name:"")?ya(o):""}function hw(t){switch(t.tag){case 26:case 27:case 5:return ya(t.type);case 16:return ya("Lazy");case 13:return ya("Suspense");case 19:return ya("SuspenseList");case 0:case 15:return eu(t.type,!1);case 11:return eu(t.type.render,!1);case 1:return eu(t.type,!0);case 31:return ya("Activity");default:return""}}function x0(t){try{var n="";do n+=hw(t),t=t.return;while(t);return n}catch(o){return`
Error generating stack: `+o.message+`
`+o.stack}}function It(t){switch(typeof t){case"bigint":case"boolean":case"number":case"string":case"undefined":return t;case"object":return t;default:return""}}function b0(t){var n=t.type;return(t=t.nodeName)&&t.toLowerCase()==="input"&&(n==="checkbox"||n==="radio")}function pw(t){var n=b0(t)?"checked":"value",o=Object.getOwnPropertyDescriptor(t.constructor.prototype,n),l=""+t[n];if(!t.hasOwnProperty(n)&&typeof o<"u"&&typeof o.get=="function"&&typeof o.set=="function"){var d=o.get,g=o.set;return Object.defineProperty(t,n,{configurable:!0,get:function(){return d.call(this)},set:function(v){l=""+v,g.call(this,v)}}),Object.defineProperty(t,n,{enumerable:o.enumerable}),{getValue:function(){return l},setValue:function(v){l=""+v},stopTracking:function(){t._valueTracker=null,delete t[n]}}}}function Rs(t){t._valueTracker||(t._valueTracker=pw(t))}function v0(t){if(!t)return!1;var n=t._valueTracker;if(!n)return!0;var o=n.getValue(),l="";return t&&(l=b0(t)?t.checked?"true":"false":t.value),t=l,t!==o?(n.setValue(t),!0):!1}function ks(t){if(t=t||(typeof document<"u"?document:void 0),typeof t>"u")return null;try{return t.activeElement||t.body}catch{return t.body}}var mw=/[\n"\\]/g;function Yt(t){return t.replace(mw,function(n){return"\\"+n.charCodeAt(0).toString(16)+" "})}function tu(t,n,o,l,d,g,v,j){t.name="",v!=null&&typeof v!="function"&&typeof v!="symbol"&&typeof v!="boolean"?t.type=v:t.removeAttribute("type"),n!=null?v==="number"?(n===0&&t.value===""||t.value!=n)&&(t.value=""+It(n)):t.value!==""+It(n)&&(t.value=""+It(n)):v!=="submit"&&v!=="reset"||t.removeAttribute("value"),n!=null?iu(t,v,It(n)):o!=null?iu(t,v,It(o)):l!=null&&t.removeAttribute("value"),d==null&&g!=null&&(t.defaultChecked=!!g),d!=null&&(t.checked=d&&typeof d!="function"&&typeof d!="symbol"),j!=null&&typeof j!="function"&&typeof j!="symbol"&&typeof j!="boolean"?t.name=""+It(j):t.removeAttribute("name")}function w0(t,n,o,l,d,g,v,j){if(g!=null&&typeof g!="function"&&typeof g!="symbol"&&typeof g!="boolean"&&(t.type=g),n!=null||o!=null){if(!(g!=="submit"&&g!=="reset"||n!=null))return;o=o!=null?""+It(o):"",n=n!=null?""+It(n):o,j||n===t.value||(t.value=n),t.defaultValue=n}l=l??d,l=typeof l!="function"&&typeof l!="symbol"&&!!l,t.checked=j?t.checked:!!l,t.defaultChecked=!!l,v!=null&&typeof v!="function"&&typeof v!="symbol"&&typeof v!="boolean"&&(t.name=v)}function iu(t,n,o){n==="number"&&ks(t.ownerDocument)===t||t.defaultValue===""+o||(t.defaultValue=""+o)}function xa(t,n,o,l){if(t=t.options,n){n={};for(var d=0;d<o.length;d++)n["$"+o[d]]=!0;for(o=0;o<t.length;o++)d=n.hasOwnProperty("$"+t[o].value),t[o].selected!==d&&(t[o].selected=d),d&&l&&(t[o].defaultSelected=!0)}else{for(o=""+It(o),n=null,d=0;d<t.length;d++){if(t[d].value===o){t[d].selected=!0,l&&(t[d].defaultSelected=!0);return}n!==null||t[d].disabled||(n=t[d])}n!==null&&(n.selected=!0)}}function S0(t,n,o){if(n!=null&&(n=""+It(n),n!==t.value&&(t.value=n),o==null)){t.defaultValue!==n&&(t.defaultValue=n);return}t.defaultValue=o!=null?""+It(o):""}function T0(t,n,o,l){if(n==null){if(l!=null){if(o!=null)throw Error(r(92));if(we(l)){if(1<l.length)throw Error(r(93));l=l[0]}o=l}o==null&&(o=""),n=o}o=It(n),t.defaultValue=o,l=t.textContent,l===o&&l!==""&&l!==null&&(t.value=l)}function ba(t,n){if(n){var o=t.firstChild;if(o&&o===t.lastChild&&o.nodeType===3){o.nodeValue=n;return}}t.textContent=n}var gw=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function j0(t,n,o){var l=n.indexOf("--")===0;o==null||typeof o=="boolean"||o===""?l?t.setProperty(n,""):n==="float"?t.cssFloat="":t[n]="":l?t.setProperty(n,o):typeof o!="number"||o===0||gw.has(n)?n==="float"?t.cssFloat=o:t[n]=(""+o).trim():t[n]=o+"px"}function A0(t,n,o){if(n!=null&&typeof n!="object")throw Error(r(62));if(t=t.style,o!=null){for(var l in o)!o.hasOwnProperty(l)||n!=null&&n.hasOwnProperty(l)||(l.indexOf("--")===0?t.setProperty(l,""):l==="float"?t.cssFloat="":t[l]="");for(var d in n)l=n[d],n.hasOwnProperty(d)&&o[d]!==l&&j0(t,d,l)}else for(var g in n)n.hasOwnProperty(g)&&j0(t,g,n[g])}function nu(t){if(t.indexOf("-")===-1)return!1;switch(t){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var yw=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),xw=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function Ds(t){return xw.test(""+t)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":t}var au=null;function ru(t){return t=t.target||t.srcElement||window,t.correspondingUseElement&&(t=t.correspondingUseElement),t.nodeType===3?t.parentNode:t}var va=null,wa=null;function E0(t){var n=pa(t);if(n&&(t=n.stateNode)){var o=t[At]||null;e:switch(t=n.stateNode,n.type){case"input":if(tu(t,o.value,o.defaultValue,o.defaultValue,o.checked,o.defaultChecked,o.type,o.name),n=o.name,o.type==="radio"&&n!=null){for(o=t;o.parentNode;)o=o.parentNode;for(o=o.querySelectorAll('input[name="'+Yt(""+n)+'"][type="radio"]'),n=0;n<o.length;n++){var l=o[n];if(l!==t&&l.form===t.form){var d=l[At]||null;if(!d)throw Error(r(90));tu(l,d.value,d.defaultValue,d.defaultValue,d.checked,d.defaultChecked,d.type,d.name)}}for(n=0;n<o.length;n++)l=o[n],l.form===t.form&&v0(l)}break e;case"textarea":S0(t,o.value,o.defaultValue);break e;case"select":n=o.value,n!=null&&xa(t,!!o.multiple,n,!1)}}}var ou=!1;function C0(t,n,o){if(ou)return t(n,o);ou=!0;try{var l=t(n);return l}finally{if(ou=!1,(va!==null||wa!==null)&&(gl(),va&&(n=va,t=wa,wa=va=null,E0(n),t)))for(n=0;n<t.length;n++)E0(t[n])}}function Hr(t,n){var o=t.stateNode;if(o===null)return null;var l=o[At]||null;if(l===null)return null;o=l[n];e:switch(n){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(l=!l.disabled)||(t=t.type,l=!(t==="button"||t==="input"||t==="select"||t==="textarea")),t=!l;break e;default:t=!1}if(t)return null;if(o&&typeof o!="function")throw Error(r(231,n,typeof o));return o}var Di=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),su=!1;if(Di)try{var Vr={};Object.defineProperty(Vr,"passive",{get:function(){su=!0}}),window.addEventListener("test",Vr,Vr),window.removeEventListener("test",Vr,Vr)}catch{su=!1}var nn=null,lu=null,Ms=null;function O0(){if(Ms)return Ms;var t,n=lu,o=n.length,l,d="value"in nn?nn.value:nn.textContent,g=d.length;for(t=0;t<o&&n[t]===d[t];t++);var v=o-t;for(l=1;l<=v&&n[o-l]===d[g-l];l++);return Ms=d.slice(t,1<l?1-l:void 0)}function Bs(t){var n=t.keyCode;return"charCode"in t?(t=t.charCode,t===0&&n===13&&(t=13)):t=n,t===10&&(t=13),32<=t||t===13?t:0}function zs(){return!0}function R0(){return!1}function Et(t){function n(o,l,d,g,v){this._reactName=o,this._targetInst=d,this.type=l,this.nativeEvent=g,this.target=v,this.currentTarget=null;for(var j in t)t.hasOwnProperty(j)&&(o=t[j],this[j]=o?o(g):g[j]);return this.isDefaultPrevented=(g.defaultPrevented!=null?g.defaultPrevented:g.returnValue===!1)?zs:R0,this.isPropagationStopped=R0,this}return y(n.prototype,{preventDefault:function(){this.defaultPrevented=!0;var o=this.nativeEvent;o&&(o.preventDefault?o.preventDefault():typeof o.returnValue!="unknown"&&(o.returnValue=!1),this.isDefaultPrevented=zs)},stopPropagation:function(){var o=this.nativeEvent;o&&(o.stopPropagation?o.stopPropagation():typeof o.cancelBubble!="unknown"&&(o.cancelBubble=!0),this.isPropagationStopped=zs)},persist:function(){},isPersistent:zs}),n}var Nn={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(t){return t.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},$s=Et(Nn),Pr=y({},Nn,{view:0,detail:0}),bw=Et(Pr),cu,uu,Fr,Ns=y({},Pr,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:fu,button:0,buttons:0,relatedTarget:function(t){return t.relatedTarget===void 0?t.fromElement===t.srcElement?t.toElement:t.fromElement:t.relatedTarget},movementX:function(t){return"movementX"in t?t.movementX:(t!==Fr&&(Fr&&t.type==="mousemove"?(cu=t.screenX-Fr.screenX,uu=t.screenY-Fr.screenY):uu=cu=0,Fr=t),cu)},movementY:function(t){return"movementY"in t?t.movementY:uu}}),k0=Et(Ns),vw=y({},Ns,{dataTransfer:0}),ww=Et(vw),Sw=y({},Pr,{relatedTarget:0}),du=Et(Sw),Tw=y({},Nn,{animationName:0,elapsedTime:0,pseudoElement:0}),jw=Et(Tw),Aw=y({},Nn,{clipboardData:function(t){return"clipboardData"in t?t.clipboardData:window.clipboardData}}),Ew=Et(Aw),Cw=y({},Nn,{data:0}),D0=Et(Cw),Ow={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},Rw={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},kw={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function Dw(t){var n=this.nativeEvent;return n.getModifierState?n.getModifierState(t):(t=kw[t])?!!n[t]:!1}function fu(){return Dw}var Mw=y({},Pr,{key:function(t){if(t.key){var n=Ow[t.key]||t.key;if(n!=="Unidentified")return n}return t.type==="keypress"?(t=Bs(t),t===13?"Enter":String.fromCharCode(t)):t.type==="keydown"||t.type==="keyup"?Rw[t.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:fu,charCode:function(t){return t.type==="keypress"?Bs(t):0},keyCode:function(t){return t.type==="keydown"||t.type==="keyup"?t.keyCode:0},which:function(t){return t.type==="keypress"?Bs(t):t.type==="keydown"||t.type==="keyup"?t.keyCode:0}}),Bw=Et(Mw),zw=y({},Ns,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),M0=Et(zw),$w=y({},Pr,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:fu}),Nw=Et($w),Lw=y({},Nn,{propertyName:0,elapsedTime:0,pseudoElement:0}),_w=Et(Lw),Hw=y({},Ns,{deltaX:function(t){return"deltaX"in t?t.deltaX:"wheelDeltaX"in t?-t.wheelDeltaX:0},deltaY:function(t){return"deltaY"in t?t.deltaY:"wheelDeltaY"in t?-t.wheelDeltaY:"wheelDelta"in t?-t.wheelDelta:0},deltaZ:0,deltaMode:0}),Vw=Et(Hw),Pw=y({},Nn,{newState:0,oldState:0}),Fw=Et(Pw),Uw=[9,13,27,32],hu=Di&&"CompositionEvent"in window,Ur=null;Di&&"documentMode"in document&&(Ur=document.documentMode);var qw=Di&&"TextEvent"in window&&!Ur,B0=Di&&(!hu||Ur&&8<Ur&&11>=Ur),z0=" ",$0=!1;function N0(t,n){switch(t){case"keyup":return Uw.indexOf(n.keyCode)!==-1;case"keydown":return n.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function L0(t){return t=t.detail,typeof t=="object"&&"data"in t?t.data:null}var Sa=!1;function Iw(t,n){switch(t){case"compositionend":return L0(n);case"keypress":return n.which!==32?null:($0=!0,z0);case"textInput":return t=n.data,t===z0&&$0?null:t;default:return null}}function Yw(t,n){if(Sa)return t==="compositionend"||!hu&&N0(t,n)?(t=O0(),Ms=lu=nn=null,Sa=!1,t):null;switch(t){case"paste":return null;case"keypress":if(!(n.ctrlKey||n.altKey||n.metaKey)||n.ctrlKey&&n.altKey){if(n.char&&1<n.char.length)return n.char;if(n.which)return String.fromCharCode(n.which)}return null;case"compositionend":return B0&&n.locale!=="ko"?null:n.data;default:return null}}var Gw={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function _0(t){var n=t&&t.nodeName&&t.nodeName.toLowerCase();return n==="input"?!!Gw[t.type]:n==="textarea"}function H0(t,n,o,l){va?wa?wa.push(l):wa=[l]:va=l,n=Sl(n,"onChange"),0<n.length&&(o=new $s("onChange","change",null,o,l),t.push({event:o,listeners:n}))}var qr=null,Ir=null;function Kw(t){b1(t,0)}function Ls(t){var n=_r(t);if(v0(n))return t}function V0(t,n){if(t==="change")return n}var P0=!1;if(Di){var pu;if(Di){var mu="oninput"in document;if(!mu){var F0=document.createElement("div");F0.setAttribute("oninput","return;"),mu=typeof F0.oninput=="function"}pu=mu}else pu=!1;P0=pu&&(!document.documentMode||9<document.documentMode)}function U0(){qr&&(qr.detachEvent("onpropertychange",q0),Ir=qr=null)}function q0(t){if(t.propertyName==="value"&&Ls(Ir)){var n=[];H0(n,Ir,t,ru(t)),C0(Kw,n)}}function Xw(t,n,o){t==="focusin"?(U0(),qr=n,Ir=o,qr.attachEvent("onpropertychange",q0)):t==="focusout"&&U0()}function Zw(t){if(t==="selectionchange"||t==="keyup"||t==="keydown")return Ls(Ir)}function Qw(t,n){if(t==="click")return Ls(n)}function Jw(t,n){if(t==="input"||t==="change")return Ls(n)}function Ww(t,n){return t===n&&(t!==0||1/t===1/n)||t!==t&&n!==n}var $t=typeof Object.is=="function"?Object.is:Ww;function Yr(t,n){if($t(t,n))return!0;if(typeof t!="object"||t===null||typeof n!="object"||n===null)return!1;var o=Object.keys(t),l=Object.keys(n);if(o.length!==l.length)return!1;for(l=0;l<o.length;l++){var d=o[l];if(!qt.call(n,d)||!$t(t[d],n[d]))return!1}return!0}function I0(t){for(;t&&t.firstChild;)t=t.firstChild;return t}function Y0(t,n){var o=I0(t);t=0;for(var l;o;){if(o.nodeType===3){if(l=t+o.textContent.length,t<=n&&l>=n)return{node:o,offset:n-t};t=l}e:{for(;o;){if(o.nextSibling){o=o.nextSibling;break e}o=o.parentNode}o=void 0}o=I0(o)}}function G0(t,n){return t&&n?t===n?!0:t&&t.nodeType===3?!1:n&&n.nodeType===3?G0(t,n.parentNode):"contains"in t?t.contains(n):t.compareDocumentPosition?!!(t.compareDocumentPosition(n)&16):!1:!1}function K0(t){t=t!=null&&t.ownerDocument!=null&&t.ownerDocument.defaultView!=null?t.ownerDocument.defaultView:window;for(var n=ks(t.document);n instanceof t.HTMLIFrameElement;){try{var o=typeof n.contentWindow.location.href=="string"}catch{o=!1}if(o)t=n.contentWindow;else break;n=ks(t.document)}return n}function gu(t){var n=t&&t.nodeName&&t.nodeName.toLowerCase();return n&&(n==="input"&&(t.type==="text"||t.type==="search"||t.type==="tel"||t.type==="url"||t.type==="password")||n==="textarea"||t.contentEditable==="true")}var e3=Di&&"documentMode"in document&&11>=document.documentMode,Ta=null,yu=null,Gr=null,xu=!1;function X0(t,n,o){var l=o.window===o?o.document:o.nodeType===9?o:o.ownerDocument;xu||Ta==null||Ta!==ks(l)||(l=Ta,"selectionStart"in l&&gu(l)?l={start:l.selectionStart,end:l.selectionEnd}:(l=(l.ownerDocument&&l.ownerDocument.defaultView||window).getSelection(),l={anchorNode:l.anchorNode,anchorOffset:l.anchorOffset,focusNode:l.focusNode,focusOffset:l.focusOffset}),Gr&&Yr(Gr,l)||(Gr=l,l=Sl(yu,"onSelect"),0<l.length&&(n=new $s("onSelect","select",null,n,o),t.push({event:n,listeners:l}),n.target=Ta)))}function Ln(t,n){var o={};return o[t.toLowerCase()]=n.toLowerCase(),o["Webkit"+t]="webkit"+n,o["Moz"+t]="moz"+n,o}var ja={animationend:Ln("Animation","AnimationEnd"),animationiteration:Ln("Animation","AnimationIteration"),animationstart:Ln("Animation","AnimationStart"),transitionrun:Ln("Transition","TransitionRun"),transitionstart:Ln("Transition","TransitionStart"),transitioncancel:Ln("Transition","TransitionCancel"),transitionend:Ln("Transition","TransitionEnd")},bu={},Z0={};Di&&(Z0=document.createElement("div").style,"AnimationEvent"in window||(delete ja.animationend.animation,delete ja.animationiteration.animation,delete ja.animationstart.animation),"TransitionEvent"in window||delete ja.transitionend.transition);function _n(t){if(bu[t])return bu[t];if(!ja[t])return t;var n=ja[t],o;for(o in n)if(n.hasOwnProperty(o)&&o in Z0)return bu[t]=n[o];return t}var Q0=_n("animationend"),J0=_n("animationiteration"),W0=_n("animationstart"),t3=_n("transitionrun"),i3=_n("transitionstart"),n3=_n("transitioncancel"),em=_n("transitionend"),tm=new Map,vu="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");vu.push("scrollEnd");function ai(t,n){tm.set(t,n),$n(n,[t])}var im=new WeakMap;function Gt(t,n){if(typeof t=="object"&&t!==null){var o=im.get(t);return o!==void 0?o:(n={value:t,source:n,stack:x0(n)},im.set(t,n),n)}return{value:t,source:n,stack:x0(n)}}var Kt=[],Aa=0,wu=0;function _s(){for(var t=Aa,n=wu=Aa=0;n<t;){var o=Kt[n];Kt[n++]=null;var l=Kt[n];Kt[n++]=null;var d=Kt[n];Kt[n++]=null;var g=Kt[n];if(Kt[n++]=null,l!==null&&d!==null){var v=l.pending;v===null?d.next=d:(d.next=v.next,v.next=d),l.pending=d}g!==0&&nm(o,d,g)}}function Hs(t,n,o,l){Kt[Aa++]=t,Kt[Aa++]=n,Kt[Aa++]=o,Kt[Aa++]=l,wu|=l,t.lanes|=l,t=t.alternate,t!==null&&(t.lanes|=l)}function Su(t,n,o,l){return Hs(t,n,o,l),Vs(t)}function Ea(t,n){return Hs(t,null,null,n),Vs(t)}function nm(t,n,o){t.lanes|=o;var l=t.alternate;l!==null&&(l.lanes|=o);for(var d=!1,g=t.return;g!==null;)g.childLanes|=o,l=g.alternate,l!==null&&(l.childLanes|=o),g.tag===22&&(t=g.stateNode,t===null||t._visibility&1||(d=!0)),t=g,g=g.return;return t.tag===3?(g=t.stateNode,d&&n!==null&&(d=31-zt(o),t=g.hiddenUpdates,l=t[d],l===null?t[d]=[n]:l.push(n),n.lane=o|536870912),g):null}function Vs(t){if(50<bo)throw bo=0,Od=null,Error(r(185));for(var n=t.return;n!==null;)t=n,n=t.return;return t.tag===3?t.stateNode:null}var Ca={};function a3(t,n,o,l){this.tag=t,this.key=o,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=n,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=l,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function Nt(t,n,o,l){return new a3(t,n,o,l)}function Tu(t){return t=t.prototype,!(!t||!t.isReactComponent)}function Mi(t,n){var o=t.alternate;return o===null?(o=Nt(t.tag,n,t.key,t.mode),o.elementType=t.elementType,o.type=t.type,o.stateNode=t.stateNode,o.alternate=t,t.alternate=o):(o.pendingProps=n,o.type=t.type,o.flags=0,o.subtreeFlags=0,o.deletions=null),o.flags=t.flags&65011712,o.childLanes=t.childLanes,o.lanes=t.lanes,o.child=t.child,o.memoizedProps=t.memoizedProps,o.memoizedState=t.memoizedState,o.updateQueue=t.updateQueue,n=t.dependencies,o.dependencies=n===null?null:{lanes:n.lanes,firstContext:n.firstContext},o.sibling=t.sibling,o.index=t.index,o.ref=t.ref,o.refCleanup=t.refCleanup,o}function am(t,n){t.flags&=65011714;var o=t.alternate;return o===null?(t.childLanes=0,t.lanes=n,t.child=null,t.subtreeFlags=0,t.memoizedProps=null,t.memoizedState=null,t.updateQueue=null,t.dependencies=null,t.stateNode=null):(t.childLanes=o.childLanes,t.lanes=o.lanes,t.child=o.child,t.subtreeFlags=0,t.deletions=null,t.memoizedProps=o.memoizedProps,t.memoizedState=o.memoizedState,t.updateQueue=o.updateQueue,t.type=o.type,n=o.dependencies,t.dependencies=n===null?null:{lanes:n.lanes,firstContext:n.firstContext}),t}function Ps(t,n,o,l,d,g){var v=0;if(l=t,typeof t=="function")Tu(t)&&(v=1);else if(typeof t=="string")v=o4(t,o,ae.current)?26:t==="html"||t==="head"||t==="body"?27:5;else e:switch(t){case J:return t=Nt(31,o,n,d),t.elementType=J,t.lanes=g,t;case A:return Hn(o.children,d,g,n);case C:v=8,d|=24;break;case B:return t=Nt(12,o,n,d|2),t.elementType=B,t.lanes=g,t;case D:return t=Nt(13,o,n,d),t.elementType=D,t.lanes=g,t;case U:return t=Nt(19,o,n,d),t.elementType=U,t.lanes=g,t;default:if(typeof t=="object"&&t!==null)switch(t.$$typeof){case E:case M:v=10;break e;case k:v=9;break e;case F:v=11;break e;case G:v=14;break e;case Z:v=16,l=null;break e}v=29,o=Error(r(130,t===null?"null":typeof t,"")),l=null}return n=Nt(v,o,n,d),n.elementType=t,n.type=l,n.lanes=g,n}function Hn(t,n,o,l){return t=Nt(7,t,l,n),t.lanes=o,t}function ju(t,n,o){return t=Nt(6,t,null,n),t.lanes=o,t}function Au(t,n,o){return n=Nt(4,t.children!==null?t.children:[],t.key,n),n.lanes=o,n.stateNode={containerInfo:t.containerInfo,pendingChildren:null,implementation:t.implementation},n}var Oa=[],Ra=0,Fs=null,Us=0,Xt=[],Zt=0,Vn=null,Bi=1,zi="";function Pn(t,n){Oa[Ra++]=Us,Oa[Ra++]=Fs,Fs=t,Us=n}function rm(t,n,o){Xt[Zt++]=Bi,Xt[Zt++]=zi,Xt[Zt++]=Vn,Vn=t;var l=Bi;t=zi;var d=32-zt(l)-1;l&=~(1<<d),o+=1;var g=32-zt(n)+d;if(30<g){var v=d-d%5;g=(l&(1<<v)-1).toString(32),l>>=v,d-=v,Bi=1<<32-zt(n)+d|o<<d|l,zi=g+t}else Bi=1<<g|o<<d|l,zi=t}function Eu(t){t.return!==null&&(Pn(t,1),rm(t,1,0))}function Cu(t){for(;t===Fs;)Fs=Oa[--Ra],Oa[Ra]=null,Us=Oa[--Ra],Oa[Ra]=null;for(;t===Vn;)Vn=Xt[--Zt],Xt[Zt]=null,zi=Xt[--Zt],Xt[Zt]=null,Bi=Xt[--Zt],Xt[Zt]=null}var Tt=null,Ke=null,Ee=!1,Fn=null,mi=!1,Ou=Error(r(519));function Un(t){var n=Error(r(418,""));throw Zr(Gt(n,t)),Ou}function om(t){var n=t.stateNode,o=t.type,l=t.memoizedProps;switch(n[yt]=t,n[At]=l,o){case"dialog":Te("cancel",n),Te("close",n);break;case"iframe":case"object":case"embed":Te("load",n);break;case"video":case"audio":for(o=0;o<wo.length;o++)Te(wo[o],n);break;case"source":Te("error",n);break;case"img":case"image":case"link":Te("error",n),Te("load",n);break;case"details":Te("toggle",n);break;case"input":Te("invalid",n),w0(n,l.value,l.defaultValue,l.checked,l.defaultChecked,l.type,l.name,!0),Rs(n);break;case"select":Te("invalid",n);break;case"textarea":Te("invalid",n),T0(n,l.value,l.defaultValue,l.children),Rs(n)}o=l.children,typeof o!="string"&&typeof o!="number"&&typeof o!="bigint"||n.textContent===""+o||l.suppressHydrationWarning===!0||T1(n.textContent,o)?(l.popover!=null&&(Te("beforetoggle",n),Te("toggle",n)),l.onScroll!=null&&Te("scroll",n),l.onScrollEnd!=null&&Te("scrollend",n),l.onClick!=null&&(n.onclick=Tl),n=!0):n=!1,n||Un(t)}function sm(t){for(Tt=t.return;Tt;)switch(Tt.tag){case 5:case 13:mi=!1;return;case 27:case 3:mi=!0;return;default:Tt=Tt.return}}function Kr(t){if(t!==Tt)return!1;if(!Ee)return sm(t),Ee=!0,!1;var n=t.tag,o;if((o=n!==3&&n!==27)&&((o=n===5)&&(o=t.type,o=!(o!=="form"&&o!=="button")||qd(t.type,t.memoizedProps)),o=!o),o&&Ke&&Un(t),sm(t),n===13){if(t=t.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(r(317));e:{for(t=t.nextSibling,n=0;t;){if(t.nodeType===8)if(o=t.data,o==="/$"){if(n===0){Ke=oi(t.nextSibling);break e}n--}else o!=="$"&&o!=="$!"&&o!=="$?"||n++;t=t.nextSibling}Ke=null}}else n===27?(n=Ke,bn(t.type)?(t=Kd,Kd=null,Ke=t):Ke=n):Ke=Tt?oi(t.stateNode.nextSibling):null;return!0}function Xr(){Ke=Tt=null,Ee=!1}function lm(){var t=Fn;return t!==null&&(Rt===null?Rt=t:Rt.push.apply(Rt,t),Fn=null),t}function Zr(t){Fn===null?Fn=[t]:Fn.push(t)}var Ru=q(null),qn=null,$i=null;function an(t,n,o){W(Ru,n._currentValue),n._currentValue=o}function Ni(t){t._currentValue=Ru.current,Q(Ru)}function ku(t,n,o){for(;t!==null;){var l=t.alternate;if((t.childLanes&n)!==n?(t.childLanes|=n,l!==null&&(l.childLanes|=n)):l!==null&&(l.childLanes&n)!==n&&(l.childLanes|=n),t===o)break;t=t.return}}function Du(t,n,o,l){var d=t.child;for(d!==null&&(d.return=t);d!==null;){var g=d.dependencies;if(g!==null){var v=d.child;g=g.firstContext;e:for(;g!==null;){var j=g;g=d;for(var R=0;R<n.length;R++)if(j.context===n[R]){g.lanes|=o,j=g.alternate,j!==null&&(j.lanes|=o),ku(g.return,o,t),l||(v=null);break e}g=j.next}}else if(d.tag===18){if(v=d.return,v===null)throw Error(r(341));v.lanes|=o,g=v.alternate,g!==null&&(g.lanes|=o),ku(v,o,t),v=null}else v=d.child;if(v!==null)v.return=d;else for(v=d;v!==null;){if(v===t){v=null;break}if(d=v.sibling,d!==null){d.return=v.return,v=d;break}v=v.return}d=v}}function Qr(t,n,o,l){t=null;for(var d=n,g=!1;d!==null;){if(!g){if((d.flags&524288)!==0)g=!0;else if((d.flags&262144)!==0)break}if(d.tag===10){var v=d.alternate;if(v===null)throw Error(r(387));if(v=v.memoizedProps,v!==null){var j=d.type;$t(d.pendingProps.value,v.value)||(t!==null?t.push(j):t=[j])}}else if(d===rt.current){if(v=d.alternate,v===null)throw Error(r(387));v.memoizedState.memoizedState!==d.memoizedState.memoizedState&&(t!==null?t.push(Co):t=[Co])}d=d.return}t!==null&&Du(n,t,o,l),n.flags|=262144}function qs(t){for(t=t.firstContext;t!==null;){if(!$t(t.context._currentValue,t.memoizedValue))return!0;t=t.next}return!1}function In(t){qn=t,$i=null,t=t.dependencies,t!==null&&(t.firstContext=null)}function xt(t){return cm(qn,t)}function Is(t,n){return qn===null&&In(t),cm(t,n)}function cm(t,n){var o=n._currentValue;if(n={context:n,memoizedValue:o,next:null},$i===null){if(t===null)throw Error(r(308));$i=n,t.dependencies={lanes:0,firstContext:n},t.flags|=524288}else $i=$i.next=n;return o}var r3=typeof AbortController<"u"?AbortController:function(){var t=[],n=this.signal={aborted:!1,addEventListener:function(o,l){t.push(l)}};this.abort=function(){n.aborted=!0,t.forEach(function(o){return o()})}},o3=e.unstable_scheduleCallback,s3=e.unstable_NormalPriority,nt={$$typeof:M,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function Mu(){return{controller:new r3,data:new Map,refCount:0}}function Jr(t){t.refCount--,t.refCount===0&&o3(s3,function(){t.controller.abort()})}var Wr=null,Bu=0,ka=0,Da=null;function l3(t,n){if(Wr===null){var o=Wr=[];Bu=0,ka=$d(),Da={status:"pending",value:void 0,then:function(l){o.push(l)}}}return Bu++,n.then(um,um),n}function um(){if(--Bu===0&&Wr!==null){Da!==null&&(Da.status="fulfilled");var t=Wr;Wr=null,ka=0,Da=null;for(var n=0;n<t.length;n++)(0,t[n])()}}function c3(t,n){var o=[],l={status:"pending",value:null,reason:null,then:function(d){o.push(d)}};return t.then(function(){l.status="fulfilled",l.value=n;for(var d=0;d<o.length;d++)(0,o[d])(n)},function(d){for(l.status="rejected",l.reason=d,d=0;d<o.length;d++)(0,o[d])(void 0)}),l}var dm=P.S;P.S=function(t,n){typeof n=="object"&&n!==null&&typeof n.then=="function"&&l3(t,n),dm!==null&&dm(t,n)};var Yn=q(null);function zu(){var t=Yn.current;return t!==null?t:He.pooledCache}function Ys(t,n){n===null?W(Yn,Yn.current):W(Yn,n.pool)}function fm(){var t=zu();return t===null?null:{parent:nt._currentValue,pool:t}}var eo=Error(r(460)),hm=Error(r(474)),Gs=Error(r(542)),$u={then:function(){}};function pm(t){return t=t.status,t==="fulfilled"||t==="rejected"}function Ks(){}function mm(t,n,o){switch(o=t[o],o===void 0?t.push(n):o!==n&&(n.then(Ks,Ks),n=o),n.status){case"fulfilled":return n.value;case"rejected":throw t=n.reason,ym(t),t;default:if(typeof n.status=="string")n.then(Ks,Ks);else{if(t=He,t!==null&&100<t.shellSuspendCounter)throw Error(r(482));t=n,t.status="pending",t.then(function(l){if(n.status==="pending"){var d=n;d.status="fulfilled",d.value=l}},function(l){if(n.status==="pending"){var d=n;d.status="rejected",d.reason=l}})}switch(n.status){case"fulfilled":return n.value;case"rejected":throw t=n.reason,ym(t),t}throw to=n,eo}}var to=null;function gm(){if(to===null)throw Error(r(459));var t=to;return to=null,t}function ym(t){if(t===eo||t===Gs)throw Error(r(483))}var rn=!1;function Nu(t){t.updateQueue={baseState:t.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function Lu(t,n){t=t.updateQueue,n.updateQueue===t&&(n.updateQueue={baseState:t.baseState,firstBaseUpdate:t.firstBaseUpdate,lastBaseUpdate:t.lastBaseUpdate,shared:t.shared,callbacks:null})}function on(t){return{lane:t,tag:0,payload:null,callback:null,next:null}}function sn(t,n,o){var l=t.updateQueue;if(l===null)return null;if(l=l.shared,(Me&2)!==0){var d=l.pending;return d===null?n.next=n:(n.next=d.next,d.next=n),l.pending=n,n=Vs(t),nm(t,null,o),n}return Hs(t,l,n,o),Vs(t)}function io(t,n,o){if(n=n.updateQueue,n!==null&&(n=n.shared,(o&4194048)!==0)){var l=n.lanes;l&=t.pendingLanes,o|=l,n.lanes=o,u0(t,o)}}function _u(t,n){var o=t.updateQueue,l=t.alternate;if(l!==null&&(l=l.updateQueue,o===l)){var d=null,g=null;if(o=o.firstBaseUpdate,o!==null){do{var v={lane:o.lane,tag:o.tag,payload:o.payload,callback:null,next:null};g===null?d=g=v:g=g.next=v,o=o.next}while(o!==null);g===null?d=g=n:g=g.next=n}else d=g=n;o={baseState:l.baseState,firstBaseUpdate:d,lastBaseUpdate:g,shared:l.shared,callbacks:l.callbacks},t.updateQueue=o;return}t=o.lastBaseUpdate,t===null?o.firstBaseUpdate=n:t.next=n,o.lastBaseUpdate=n}var Hu=!1;function no(){if(Hu){var t=Da;if(t!==null)throw t}}function ao(t,n,o,l){Hu=!1;var d=t.updateQueue;rn=!1;var g=d.firstBaseUpdate,v=d.lastBaseUpdate,j=d.shared.pending;if(j!==null){d.shared.pending=null;var R=j,_=R.next;R.next=null,v===null?g=_:v.next=_,v=R;var I=t.alternate;I!==null&&(I=I.updateQueue,j=I.lastBaseUpdate,j!==v&&(j===null?I.firstBaseUpdate=_:j.next=_,I.lastBaseUpdate=R))}if(g!==null){var K=d.baseState;v=0,I=_=R=null,j=g;do{var H=j.lane&-536870913,V=H!==j.lane;if(V?(je&H)===H:(l&H)===H){H!==0&&H===ka&&(Hu=!0),I!==null&&(I=I.next={lane:0,tag:j.tag,payload:j.payload,callback:null,next:null});e:{var ue=t,se=j;H=n;var Ne=o;switch(se.tag){case 1:if(ue=se.payload,typeof ue=="function"){K=ue.call(Ne,K,H);break e}K=ue;break e;case 3:ue.flags=ue.flags&-65537|128;case 0:if(ue=se.payload,H=typeof ue=="function"?ue.call(Ne,K,H):ue,H==null)break e;K=y({},K,H);break e;case 2:rn=!0}}H=j.callback,H!==null&&(t.flags|=64,V&&(t.flags|=8192),V=d.callbacks,V===null?d.callbacks=[H]:V.push(H))}else V={lane:H,tag:j.tag,payload:j.payload,callback:j.callback,next:null},I===null?(_=I=V,R=K):I=I.next=V,v|=H;if(j=j.next,j===null){if(j=d.shared.pending,j===null)break;V=j,j=V.next,V.next=null,d.lastBaseUpdate=V,d.shared.pending=null}}while(!0);I===null&&(R=K),d.baseState=R,d.firstBaseUpdate=_,d.lastBaseUpdate=I,g===null&&(d.shared.lanes=0),mn|=v,t.lanes=v,t.memoizedState=K}}function xm(t,n){if(typeof t!="function")throw Error(r(191,t));t.call(n)}function bm(t,n){var o=t.callbacks;if(o!==null)for(t.callbacks=null,t=0;t<o.length;t++)xm(o[t],n)}var Ma=q(null),Xs=q(0);function vm(t,n){t=Ui,W(Xs,t),W(Ma,n),Ui=t|n.baseLanes}function Vu(){W(Xs,Ui),W(Ma,Ma.current)}function Pu(){Ui=Xs.current,Q(Ma),Q(Xs)}var ln=0,be=null,ze=null,et=null,Zs=!1,Ba=!1,Gn=!1,Qs=0,ro=0,za=null,u3=0;function Qe(){throw Error(r(321))}function Fu(t,n){if(n===null)return!1;for(var o=0;o<n.length&&o<t.length;o++)if(!$t(t[o],n[o]))return!1;return!0}function Uu(t,n,o,l,d,g){return ln=g,be=n,n.memoizedState=null,n.updateQueue=null,n.lanes=0,P.H=t===null||t.memoizedState===null?ng:ag,Gn=!1,g=o(l,d),Gn=!1,Ba&&(g=Sm(n,o,l,d)),wm(t),g}function wm(t){P.H=nl;var n=ze!==null&&ze.next!==null;if(ln=0,et=ze=be=null,Zs=!1,ro=0,za=null,n)throw Error(r(300));t===null||st||(t=t.dependencies,t!==null&&qs(t)&&(st=!0))}function Sm(t,n,o,l){be=t;var d=0;do{if(Ba&&(za=null),ro=0,Ba=!1,25<=d)throw Error(r(301));if(d+=1,et=ze=null,t.updateQueue!=null){var g=t.updateQueue;g.lastEffect=null,g.events=null,g.stores=null,g.memoCache!=null&&(g.memoCache.index=0)}P.H=y3,g=n(o,l)}while(Ba);return g}function d3(){var t=P.H,n=t.useState()[0];return n=typeof n.then=="function"?oo(n):n,t=t.useState()[0],(ze!==null?ze.memoizedState:null)!==t&&(be.flags|=1024),n}function qu(){var t=Qs!==0;return Qs=0,t}function Iu(t,n,o){n.updateQueue=t.updateQueue,n.flags&=-2053,t.lanes&=~o}function Yu(t){if(Zs){for(t=t.memoizedState;t!==null;){var n=t.queue;n!==null&&(n.pending=null),t=t.next}Zs=!1}ln=0,et=ze=be=null,Ba=!1,ro=Qs=0,za=null}function Ct(){var t={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return et===null?be.memoizedState=et=t:et=et.next=t,et}function tt(){if(ze===null){var t=be.alternate;t=t!==null?t.memoizedState:null}else t=ze.next;var n=et===null?be.memoizedState:et.next;if(n!==null)et=n,ze=t;else{if(t===null)throw be.alternate===null?Error(r(467)):Error(r(310));ze=t,t={memoizedState:ze.memoizedState,baseState:ze.baseState,baseQueue:ze.baseQueue,queue:ze.queue,next:null},et===null?be.memoizedState=et=t:et=et.next=t}return et}function Gu(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function oo(t){var n=ro;return ro+=1,za===null&&(za=[]),t=mm(za,t,n),n=be,(et===null?n.memoizedState:et.next)===null&&(n=n.alternate,P.H=n===null||n.memoizedState===null?ng:ag),t}function Js(t){if(t!==null&&typeof t=="object"){if(typeof t.then=="function")return oo(t);if(t.$$typeof===M)return xt(t)}throw Error(r(438,String(t)))}function Ku(t){var n=null,o=be.updateQueue;if(o!==null&&(n=o.memoCache),n==null){var l=be.alternate;l!==null&&(l=l.updateQueue,l!==null&&(l=l.memoCache,l!=null&&(n={data:l.data.map(function(d){return d.slice()}),index:0})))}if(n==null&&(n={data:[],index:0}),o===null&&(o=Gu(),be.updateQueue=o),o.memoCache=n,o=n.data[n.index],o===void 0)for(o=n.data[n.index]=Array(t),l=0;l<t;l++)o[l]=ie;return n.index++,o}function Li(t,n){return typeof n=="function"?n(t):n}function Ws(t){var n=tt();return Xu(n,ze,t)}function Xu(t,n,o){var l=t.queue;if(l===null)throw Error(r(311));l.lastRenderedReducer=o;var d=t.baseQueue,g=l.pending;if(g!==null){if(d!==null){var v=d.next;d.next=g.next,g.next=v}n.baseQueue=d=g,l.pending=null}if(g=t.baseState,d===null)t.memoizedState=g;else{n=d.next;var j=v=null,R=null,_=n,I=!1;do{var K=_.lane&-536870913;if(K!==_.lane?(je&K)===K:(ln&K)===K){var H=_.revertLane;if(H===0)R!==null&&(R=R.next={lane:0,revertLane:0,action:_.action,hasEagerState:_.hasEagerState,eagerState:_.eagerState,next:null}),K===ka&&(I=!0);else if((ln&H)===H){_=_.next,H===ka&&(I=!0);continue}else K={lane:0,revertLane:_.revertLane,action:_.action,hasEagerState:_.hasEagerState,eagerState:_.eagerState,next:null},R===null?(j=R=K,v=g):R=R.next=K,be.lanes|=H,mn|=H;K=_.action,Gn&&o(g,K),g=_.hasEagerState?_.eagerState:o(g,K)}else H={lane:K,revertLane:_.revertLane,action:_.action,hasEagerState:_.hasEagerState,eagerState:_.eagerState,next:null},R===null?(j=R=H,v=g):R=R.next=H,be.lanes|=K,mn|=K;_=_.next}while(_!==null&&_!==n);if(R===null?v=g:R.next=j,!$t(g,t.memoizedState)&&(st=!0,I&&(o=Da,o!==null)))throw o;t.memoizedState=g,t.baseState=v,t.baseQueue=R,l.lastRenderedState=g}return d===null&&(l.lanes=0),[t.memoizedState,l.dispatch]}function Zu(t){var n=tt(),o=n.queue;if(o===null)throw Error(r(311));o.lastRenderedReducer=t;var l=o.dispatch,d=o.pending,g=n.memoizedState;if(d!==null){o.pending=null;var v=d=d.next;do g=t(g,v.action),v=v.next;while(v!==d);$t(g,n.memoizedState)||(st=!0),n.memoizedState=g,n.baseQueue===null&&(n.baseState=g),o.lastRenderedState=g}return[g,l]}function Tm(t,n,o){var l=be,d=tt(),g=Ee;if(g){if(o===void 0)throw Error(r(407));o=o()}else o=n();var v=!$t((ze||d).memoizedState,o);v&&(d.memoizedState=o,st=!0),d=d.queue;var j=Em.bind(null,l,d,t);if(so(2048,8,j,[t]),d.getSnapshot!==n||v||et!==null&&et.memoizedState.tag&1){if(l.flags|=2048,$a(9,el(),Am.bind(null,l,d,o,n),null),He===null)throw Error(r(349));g||(ln&124)!==0||jm(l,n,o)}return o}function jm(t,n,o){t.flags|=16384,t={getSnapshot:n,value:o},n=be.updateQueue,n===null?(n=Gu(),be.updateQueue=n,n.stores=[t]):(o=n.stores,o===null?n.stores=[t]:o.push(t))}function Am(t,n,o,l){n.value=o,n.getSnapshot=l,Cm(n)&&Om(t)}function Em(t,n,o){return o(function(){Cm(n)&&Om(t)})}function Cm(t){var n=t.getSnapshot;t=t.value;try{var o=n();return!$t(t,o)}catch{return!0}}function Om(t){var n=Ea(t,2);n!==null&&Pt(n,t,2)}function Qu(t){var n=Ct();if(typeof t=="function"){var o=t;if(t=o(),Gn){en(!0);try{o()}finally{en(!1)}}}return n.memoizedState=n.baseState=t,n.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Li,lastRenderedState:t},n}function Rm(t,n,o,l){return t.baseState=o,Xu(t,ze,typeof l=="function"?l:Li)}function f3(t,n,o,l,d){if(il(t))throw Error(r(485));if(t=n.action,t!==null){var g={payload:d,action:t,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(v){g.listeners.push(v)}};P.T!==null?o(!0):g.isTransition=!1,l(g),o=n.pending,o===null?(g.next=n.pending=g,km(n,g)):(g.next=o.next,n.pending=o.next=g)}}function km(t,n){var o=n.action,l=n.payload,d=t.state;if(n.isTransition){var g=P.T,v={};P.T=v;try{var j=o(d,l),R=P.S;R!==null&&R(v,j),Dm(t,n,j)}catch(_){Ju(t,n,_)}finally{P.T=g}}else try{g=o(d,l),Dm(t,n,g)}catch(_){Ju(t,n,_)}}function Dm(t,n,o){o!==null&&typeof o=="object"&&typeof o.then=="function"?o.then(function(l){Mm(t,n,l)},function(l){return Ju(t,n,l)}):Mm(t,n,o)}function Mm(t,n,o){n.status="fulfilled",n.value=o,Bm(n),t.state=o,n=t.pending,n!==null&&(o=n.next,o===n?t.pending=null:(o=o.next,n.next=o,km(t,o)))}function Ju(t,n,o){var l=t.pending;if(t.pending=null,l!==null){l=l.next;do n.status="rejected",n.reason=o,Bm(n),n=n.next;while(n!==l)}t.action=null}function Bm(t){t=t.listeners;for(var n=0;n<t.length;n++)(0,t[n])()}function zm(t,n){return n}function $m(t,n){if(Ee){var o=He.formState;if(o!==null){e:{var l=be;if(Ee){if(Ke){t:{for(var d=Ke,g=mi;d.nodeType!==8;){if(!g){d=null;break t}if(d=oi(d.nextSibling),d===null){d=null;break t}}g=d.data,d=g==="F!"||g==="F"?d:null}if(d){Ke=oi(d.nextSibling),l=d.data==="F!";break e}}Un(l)}l=!1}l&&(n=o[0])}}return o=Ct(),o.memoizedState=o.baseState=n,l={pending:null,lanes:0,dispatch:null,lastRenderedReducer:zm,lastRenderedState:n},o.queue=l,o=eg.bind(null,be,l),l.dispatch=o,l=Qu(!1),g=nd.bind(null,be,!1,l.queue),l=Ct(),d={state:n,dispatch:null,action:t,pending:null},l.queue=d,o=f3.bind(null,be,d,g,o),d.dispatch=o,l.memoizedState=t,[n,o,!1]}function Nm(t){var n=tt();return Lm(n,ze,t)}function Lm(t,n,o){if(n=Xu(t,n,zm)[0],t=Ws(Li)[0],typeof n=="object"&&n!==null&&typeof n.then=="function")try{var l=oo(n)}catch(v){throw v===eo?Gs:v}else l=n;n=tt();var d=n.queue,g=d.dispatch;return o!==n.memoizedState&&(be.flags|=2048,$a(9,el(),h3.bind(null,d,o),null)),[l,g,t]}function h3(t,n){t.action=n}function _m(t){var n=tt(),o=ze;if(o!==null)return Lm(n,o,t);tt(),n=n.memoizedState,o=tt();var l=o.queue.dispatch;return o.memoizedState=t,[n,l,!1]}function $a(t,n,o,l){return t={tag:t,create:o,deps:l,inst:n,next:null},n=be.updateQueue,n===null&&(n=Gu(),be.updateQueue=n),o=n.lastEffect,o===null?n.lastEffect=t.next=t:(l=o.next,o.next=t,t.next=l,n.lastEffect=t),t}function el(){return{destroy:void 0,resource:void 0}}function Hm(){return tt().memoizedState}function tl(t,n,o,l){var d=Ct();l=l===void 0?null:l,be.flags|=t,d.memoizedState=$a(1|n,el(),o,l)}function so(t,n,o,l){var d=tt();l=l===void 0?null:l;var g=d.memoizedState.inst;ze!==null&&l!==null&&Fu(l,ze.memoizedState.deps)?d.memoizedState=$a(n,g,o,l):(be.flags|=t,d.memoizedState=$a(1|n,g,o,l))}function Vm(t,n){tl(8390656,8,t,n)}function Pm(t,n){so(2048,8,t,n)}function Fm(t,n){return so(4,2,t,n)}function Um(t,n){return so(4,4,t,n)}function qm(t,n){if(typeof n=="function"){t=t();var o=n(t);return function(){typeof o=="function"?o():n(null)}}if(n!=null)return t=t(),n.current=t,function(){n.current=null}}function Im(t,n,o){o=o!=null?o.concat([t]):null,so(4,4,qm.bind(null,n,t),o)}function Wu(){}function Ym(t,n){var o=tt();n=n===void 0?null:n;var l=o.memoizedState;return n!==null&&Fu(n,l[1])?l[0]:(o.memoizedState=[t,n],t)}function Gm(t,n){var o=tt();n=n===void 0?null:n;var l=o.memoizedState;if(n!==null&&Fu(n,l[1]))return l[0];if(l=t(),Gn){en(!0);try{t()}finally{en(!1)}}return o.memoizedState=[l,n],l}function ed(t,n,o){return o===void 0||(ln&1073741824)!==0?t.memoizedState=n:(t.memoizedState=o,t=Zg(),be.lanes|=t,mn|=t,o)}function Km(t,n,o,l){return $t(o,n)?o:Ma.current!==null?(t=ed(t,o,l),$t(t,n)||(st=!0),t):(ln&42)===0?(st=!0,t.memoizedState=o):(t=Zg(),be.lanes|=t,mn|=t,n)}function Xm(t,n,o,l,d){var g=X.p;X.p=g!==0&&8>g?g:8;var v=P.T,j={};P.T=j,nd(t,!1,n,o);try{var R=d(),_=P.S;if(_!==null&&_(j,R),R!==null&&typeof R=="object"&&typeof R.then=="function"){var I=c3(R,l);lo(t,n,I,Vt(t))}else lo(t,n,l,Vt(t))}catch(K){lo(t,n,{then:function(){},status:"rejected",reason:K},Vt())}finally{X.p=g,P.T=v}}function p3(){}function td(t,n,o,l){if(t.tag!==5)throw Error(r(476));var d=Zm(t).queue;Xm(t,d,n,ee,o===null?p3:function(){return Qm(t),o(l)})}function Zm(t){var n=t.memoizedState;if(n!==null)return n;n={memoizedState:ee,baseState:ee,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Li,lastRenderedState:ee},next:null};var o={};return n.next={memoizedState:o,baseState:o,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Li,lastRenderedState:o},next:null},t.memoizedState=n,t=t.alternate,t!==null&&(t.memoizedState=n),n}function Qm(t){var n=Zm(t).next.queue;lo(t,n,{},Vt())}function id(){return xt(Co)}function Jm(){return tt().memoizedState}function Wm(){return tt().memoizedState}function m3(t){for(var n=t.return;n!==null;){switch(n.tag){case 24:case 3:var o=Vt();t=on(o);var l=sn(n,t,o);l!==null&&(Pt(l,n,o),io(l,n,o)),n={cache:Mu()},t.payload=n;return}n=n.return}}function g3(t,n,o){var l=Vt();o={lane:l,revertLane:0,action:o,hasEagerState:!1,eagerState:null,next:null},il(t)?tg(n,o):(o=Su(t,n,o,l),o!==null&&(Pt(o,t,l),ig(o,n,l)))}function eg(t,n,o){var l=Vt();lo(t,n,o,l)}function lo(t,n,o,l){var d={lane:l,revertLane:0,action:o,hasEagerState:!1,eagerState:null,next:null};if(il(t))tg(n,d);else{var g=t.alternate;if(t.lanes===0&&(g===null||g.lanes===0)&&(g=n.lastRenderedReducer,g!==null))try{var v=n.lastRenderedState,j=g(v,o);if(d.hasEagerState=!0,d.eagerState=j,$t(j,v))return Hs(t,n,d,0),He===null&&_s(),!1}catch{}finally{}if(o=Su(t,n,d,l),o!==null)return Pt(o,t,l),ig(o,n,l),!0}return!1}function nd(t,n,o,l){if(l={lane:2,revertLane:$d(),action:l,hasEagerState:!1,eagerState:null,next:null},il(t)){if(n)throw Error(r(479))}else n=Su(t,o,l,2),n!==null&&Pt(n,t,2)}function il(t){var n=t.alternate;return t===be||n!==null&&n===be}function tg(t,n){Ba=Zs=!0;var o=t.pending;o===null?n.next=n:(n.next=o.next,o.next=n),t.pending=n}function ig(t,n,o){if((o&4194048)!==0){var l=n.lanes;l&=t.pendingLanes,o|=l,n.lanes=o,u0(t,o)}}var nl={readContext:xt,use:Js,useCallback:Qe,useContext:Qe,useEffect:Qe,useImperativeHandle:Qe,useLayoutEffect:Qe,useInsertionEffect:Qe,useMemo:Qe,useReducer:Qe,useRef:Qe,useState:Qe,useDebugValue:Qe,useDeferredValue:Qe,useTransition:Qe,useSyncExternalStore:Qe,useId:Qe,useHostTransitionStatus:Qe,useFormState:Qe,useActionState:Qe,useOptimistic:Qe,useMemoCache:Qe,useCacheRefresh:Qe},ng={readContext:xt,use:Js,useCallback:function(t,n){return Ct().memoizedState=[t,n===void 0?null:n],t},useContext:xt,useEffect:Vm,useImperativeHandle:function(t,n,o){o=o!=null?o.concat([t]):null,tl(4194308,4,qm.bind(null,n,t),o)},useLayoutEffect:function(t,n){return tl(4194308,4,t,n)},useInsertionEffect:function(t,n){tl(4,2,t,n)},useMemo:function(t,n){var o=Ct();n=n===void 0?null:n;var l=t();if(Gn){en(!0);try{t()}finally{en(!1)}}return o.memoizedState=[l,n],l},useReducer:function(t,n,o){var l=Ct();if(o!==void 0){var d=o(n);if(Gn){en(!0);try{o(n)}finally{en(!1)}}}else d=n;return l.memoizedState=l.baseState=d,t={pending:null,lanes:0,dispatch:null,lastRenderedReducer:t,lastRenderedState:d},l.queue=t,t=t.dispatch=g3.bind(null,be,t),[l.memoizedState,t]},useRef:function(t){var n=Ct();return t={current:t},n.memoizedState=t},useState:function(t){t=Qu(t);var n=t.queue,o=eg.bind(null,be,n);return n.dispatch=o,[t.memoizedState,o]},useDebugValue:Wu,useDeferredValue:function(t,n){var o=Ct();return ed(o,t,n)},useTransition:function(){var t=Qu(!1);return t=Xm.bind(null,be,t.queue,!0,!1),Ct().memoizedState=t,[!1,t]},useSyncExternalStore:function(t,n,o){var l=be,d=Ct();if(Ee){if(o===void 0)throw Error(r(407));o=o()}else{if(o=n(),He===null)throw Error(r(349));(je&124)!==0||jm(l,n,o)}d.memoizedState=o;var g={value:o,getSnapshot:n};return d.queue=g,Vm(Em.bind(null,l,g,t),[t]),l.flags|=2048,$a(9,el(),Am.bind(null,l,g,o,n),null),o},useId:function(){var t=Ct(),n=He.identifierPrefix;if(Ee){var o=zi,l=Bi;o=(l&~(1<<32-zt(l)-1)).toString(32)+o,n="«"+n+"R"+o,o=Qs++,0<o&&(n+="H"+o.toString(32)),n+="»"}else o=u3++,n="«"+n+"r"+o.toString(32)+"»";return t.memoizedState=n},useHostTransitionStatus:id,useFormState:$m,useActionState:$m,useOptimistic:function(t){var n=Ct();n.memoizedState=n.baseState=t;var o={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return n.queue=o,n=nd.bind(null,be,!0,o),o.dispatch=n,[t,n]},useMemoCache:Ku,useCacheRefresh:function(){return Ct().memoizedState=m3.bind(null,be)}},ag={readContext:xt,use:Js,useCallback:Ym,useContext:xt,useEffect:Pm,useImperativeHandle:Im,useInsertionEffect:Fm,useLayoutEffect:Um,useMemo:Gm,useReducer:Ws,useRef:Hm,useState:function(){return Ws(Li)},useDebugValue:Wu,useDeferredValue:function(t,n){var o=tt();return Km(o,ze.memoizedState,t,n)},useTransition:function(){var t=Ws(Li)[0],n=tt().memoizedState;return[typeof t=="boolean"?t:oo(t),n]},useSyncExternalStore:Tm,useId:Jm,useHostTransitionStatus:id,useFormState:Nm,useActionState:Nm,useOptimistic:function(t,n){var o=tt();return Rm(o,ze,t,n)},useMemoCache:Ku,useCacheRefresh:Wm},y3={readContext:xt,use:Js,useCallback:Ym,useContext:xt,useEffect:Pm,useImperativeHandle:Im,useInsertionEffect:Fm,useLayoutEffect:Um,useMemo:Gm,useReducer:Zu,useRef:Hm,useState:function(){return Zu(Li)},useDebugValue:Wu,useDeferredValue:function(t,n){var o=tt();return ze===null?ed(o,t,n):Km(o,ze.memoizedState,t,n)},useTransition:function(){var t=Zu(Li)[0],n=tt().memoizedState;return[typeof t=="boolean"?t:oo(t),n]},useSyncExternalStore:Tm,useId:Jm,useHostTransitionStatus:id,useFormState:_m,useActionState:_m,useOptimistic:function(t,n){var o=tt();return ze!==null?Rm(o,ze,t,n):(o.baseState=t,[t,o.queue.dispatch])},useMemoCache:Ku,useCacheRefresh:Wm},Na=null,co=0;function al(t){var n=co;return co+=1,Na===null&&(Na=[]),mm(Na,t,n)}function uo(t,n){n=n.props.ref,t.ref=n!==void 0?n:null}function rl(t,n){throw n.$$typeof===x?Error(r(525)):(t=Object.prototype.toString.call(n),Error(r(31,t==="[object Object]"?"object with keys {"+Object.keys(n).join(", ")+"}":t)))}function rg(t){var n=t._init;return n(t._payload)}function og(t){function n(N,$){if(t){var L=N.deletions;L===null?(N.deletions=[$],N.flags|=16):L.push($)}}function o(N,$){if(!t)return null;for(;$!==null;)n(N,$),$=$.sibling;return null}function l(N){for(var $=new Map;N!==null;)N.key!==null?$.set(N.key,N):$.set(N.index,N),N=N.sibling;return $}function d(N,$){return N=Mi(N,$),N.index=0,N.sibling=null,N}function g(N,$,L){return N.index=L,t?(L=N.alternate,L!==null?(L=L.index,L<$?(N.flags|=67108866,$):L):(N.flags|=67108866,$)):(N.flags|=1048576,$)}function v(N){return t&&N.alternate===null&&(N.flags|=67108866),N}function j(N,$,L,Y){return $===null||$.tag!==6?($=ju(L,N.mode,Y),$.return=N,$):($=d($,L),$.return=N,$)}function R(N,$,L,Y){var te=L.type;return te===A?I(N,$,L.props.children,Y,L.key):$!==null&&($.elementType===te||typeof te=="object"&&te!==null&&te.$$typeof===Z&&rg(te)===$.type)?($=d($,L.props),uo($,L),$.return=N,$):($=Ps(L.type,L.key,L.props,null,N.mode,Y),uo($,L),$.return=N,$)}function _(N,$,L,Y){return $===null||$.tag!==4||$.stateNode.containerInfo!==L.containerInfo||$.stateNode.implementation!==L.implementation?($=Au(L,N.mode,Y),$.return=N,$):($=d($,L.children||[]),$.return=N,$)}function I(N,$,L,Y,te){return $===null||$.tag!==7?($=Hn(L,N.mode,Y,te),$.return=N,$):($=d($,L),$.return=N,$)}function K(N,$,L){if(typeof $=="string"&&$!==""||typeof $=="number"||typeof $=="bigint")return $=ju(""+$,N.mode,L),$.return=N,$;if(typeof $=="object"&&$!==null){switch($.$$typeof){case b:return L=Ps($.type,$.key,$.props,null,N.mode,L),uo(L,$),L.return=N,L;case T:return $=Au($,N.mode,L),$.return=N,$;case Z:var Y=$._init;return $=Y($._payload),K(N,$,L)}if(we($)||xe($))return $=Hn($,N.mode,L,null),$.return=N,$;if(typeof $.then=="function")return K(N,al($),L);if($.$$typeof===M)return K(N,Is(N,$),L);rl(N,$)}return null}function H(N,$,L,Y){var te=$!==null?$.key:null;if(typeof L=="string"&&L!==""||typeof L=="number"||typeof L=="bigint")return te!==null?null:j(N,$,""+L,Y);if(typeof L=="object"&&L!==null){switch(L.$$typeof){case b:return L.key===te?R(N,$,L,Y):null;case T:return L.key===te?_(N,$,L,Y):null;case Z:return te=L._init,L=te(L._payload),H(N,$,L,Y)}if(we(L)||xe(L))return te!==null?null:I(N,$,L,Y,null);if(typeof L.then=="function")return H(N,$,al(L),Y);if(L.$$typeof===M)return H(N,$,Is(N,L),Y);rl(N,L)}return null}function V(N,$,L,Y,te){if(typeof Y=="string"&&Y!==""||typeof Y=="number"||typeof Y=="bigint")return N=N.get(L)||null,j($,N,""+Y,te);if(typeof Y=="object"&&Y!==null){switch(Y.$$typeof){case b:return N=N.get(Y.key===null?L:Y.key)||null,R($,N,Y,te);case T:return N=N.get(Y.key===null?L:Y.key)||null,_($,N,Y,te);case Z:var ve=Y._init;return Y=ve(Y._payload),V(N,$,L,Y,te)}if(we(Y)||xe(Y))return N=N.get(L)||null,I($,N,Y,te,null);if(typeof Y.then=="function")return V(N,$,L,al(Y),te);if(Y.$$typeof===M)return V(N,$,L,Is($,Y),te);rl($,Y)}return null}function ue(N,$,L,Y){for(var te=null,ve=null,re=$,ce=$=0,ct=null;re!==null&&ce<L.length;ce++){re.index>ce?(ct=re,re=null):ct=re.sibling;var Ae=H(N,re,L[ce],Y);if(Ae===null){re===null&&(re=ct);break}t&&re&&Ae.alternate===null&&n(N,re),$=g(Ae,$,ce),ve===null?te=Ae:ve.sibling=Ae,ve=Ae,re=ct}if(ce===L.length)return o(N,re),Ee&&Pn(N,ce),te;if(re===null){for(;ce<L.length;ce++)re=K(N,L[ce],Y),re!==null&&($=g(re,$,ce),ve===null?te=re:ve.sibling=re,ve=re);return Ee&&Pn(N,ce),te}for(re=l(re);ce<L.length;ce++)ct=V(re,N,ce,L[ce],Y),ct!==null&&(t&&ct.alternate!==null&&re.delete(ct.key===null?ce:ct.key),$=g(ct,$,ce),ve===null?te=ct:ve.sibling=ct,ve=ct);return t&&re.forEach(function(jn){return n(N,jn)}),Ee&&Pn(N,ce),te}function se(N,$,L,Y){if(L==null)throw Error(r(151));for(var te=null,ve=null,re=$,ce=$=0,ct=null,Ae=L.next();re!==null&&!Ae.done;ce++,Ae=L.next()){re.index>ce?(ct=re,re=null):ct=re.sibling;var jn=H(N,re,Ae.value,Y);if(jn===null){re===null&&(re=ct);break}t&&re&&jn.alternate===null&&n(N,re),$=g(jn,$,ce),ve===null?te=jn:ve.sibling=jn,ve=jn,re=ct}if(Ae.done)return o(N,re),Ee&&Pn(N,ce),te;if(re===null){for(;!Ae.done;ce++,Ae=L.next())Ae=K(N,Ae.value,Y),Ae!==null&&($=g(Ae,$,ce),ve===null?te=Ae:ve.sibling=Ae,ve=Ae);return Ee&&Pn(N,ce),te}for(re=l(re);!Ae.done;ce++,Ae=L.next())Ae=V(re,N,ce,Ae.value,Y),Ae!==null&&(t&&Ae.alternate!==null&&re.delete(Ae.key===null?ce:Ae.key),$=g(Ae,$,ce),ve===null?te=Ae:ve.sibling=Ae,ve=Ae);return t&&re.forEach(function(x4){return n(N,x4)}),Ee&&Pn(N,ce),te}function Ne(N,$,L,Y){if(typeof L=="object"&&L!==null&&L.type===A&&L.key===null&&(L=L.props.children),typeof L=="object"&&L!==null){switch(L.$$typeof){case b:e:{for(var te=L.key;$!==null;){if($.key===te){if(te=L.type,te===A){if($.tag===7){o(N,$.sibling),Y=d($,L.props.children),Y.return=N,N=Y;break e}}else if($.elementType===te||typeof te=="object"&&te!==null&&te.$$typeof===Z&&rg(te)===$.type){o(N,$.sibling),Y=d($,L.props),uo(Y,L),Y.return=N,N=Y;break e}o(N,$);break}else n(N,$);$=$.sibling}L.type===A?(Y=Hn(L.props.children,N.mode,Y,L.key),Y.return=N,N=Y):(Y=Ps(L.type,L.key,L.props,null,N.mode,Y),uo(Y,L),Y.return=N,N=Y)}return v(N);case T:e:{for(te=L.key;$!==null;){if($.key===te)if($.tag===4&&$.stateNode.containerInfo===L.containerInfo&&$.stateNode.implementation===L.implementation){o(N,$.sibling),Y=d($,L.children||[]),Y.return=N,N=Y;break e}else{o(N,$);break}else n(N,$);$=$.sibling}Y=Au(L,N.mode,Y),Y.return=N,N=Y}return v(N);case Z:return te=L._init,L=te(L._payload),Ne(N,$,L,Y)}if(we(L))return ue(N,$,L,Y);if(xe(L)){if(te=xe(L),typeof te!="function")throw Error(r(150));return L=te.call(L),se(N,$,L,Y)}if(typeof L.then=="function")return Ne(N,$,al(L),Y);if(L.$$typeof===M)return Ne(N,$,Is(N,L),Y);rl(N,L)}return typeof L=="string"&&L!==""||typeof L=="number"||typeof L=="bigint"?(L=""+L,$!==null&&$.tag===6?(o(N,$.sibling),Y=d($,L),Y.return=N,N=Y):(o(N,$),Y=ju(L,N.mode,Y),Y.return=N,N=Y),v(N)):o(N,$)}return function(N,$,L,Y){try{co=0;var te=Ne(N,$,L,Y);return Na=null,te}catch(re){if(re===eo||re===Gs)throw re;var ve=Nt(29,re,null,N.mode);return ve.lanes=Y,ve.return=N,ve}finally{}}}var La=og(!0),sg=og(!1),Qt=q(null),gi=null;function cn(t){var n=t.alternate;W(at,at.current&1),W(Qt,t),gi===null&&(n===null||Ma.current!==null||n.memoizedState!==null)&&(gi=t)}function lg(t){if(t.tag===22){if(W(at,at.current),W(Qt,t),gi===null){var n=t.alternate;n!==null&&n.memoizedState!==null&&(gi=t)}}else un()}function un(){W(at,at.current),W(Qt,Qt.current)}function _i(t){Q(Qt),gi===t&&(gi=null),Q(at)}var at=q(0);function ol(t){for(var n=t;n!==null;){if(n.tag===13){var o=n.memoizedState;if(o!==null&&(o=o.dehydrated,o===null||o.data==="$?"||Gd(o)))return n}else if(n.tag===19&&n.memoizedProps.revealOrder!==void 0){if((n.flags&128)!==0)return n}else if(n.child!==null){n.child.return=n,n=n.child;continue}if(n===t)break;for(;n.sibling===null;){if(n.return===null||n.return===t)return null;n=n.return}n.sibling.return=n.return,n=n.sibling}return null}function ad(t,n,o,l){n=t.memoizedState,o=o(l,n),o=o==null?n:y({},n,o),t.memoizedState=o,t.lanes===0&&(t.updateQueue.baseState=o)}var rd={enqueueSetState:function(t,n,o){t=t._reactInternals;var l=Vt(),d=on(l);d.payload=n,o!=null&&(d.callback=o),n=sn(t,d,l),n!==null&&(Pt(n,t,l),io(n,t,l))},enqueueReplaceState:function(t,n,o){t=t._reactInternals;var l=Vt(),d=on(l);d.tag=1,d.payload=n,o!=null&&(d.callback=o),n=sn(t,d,l),n!==null&&(Pt(n,t,l),io(n,t,l))},enqueueForceUpdate:function(t,n){t=t._reactInternals;var o=Vt(),l=on(o);l.tag=2,n!=null&&(l.callback=n),n=sn(t,l,o),n!==null&&(Pt(n,t,o),io(n,t,o))}};function cg(t,n,o,l,d,g,v){return t=t.stateNode,typeof t.shouldComponentUpdate=="function"?t.shouldComponentUpdate(l,g,v):n.prototype&&n.prototype.isPureReactComponent?!Yr(o,l)||!Yr(d,g):!0}function ug(t,n,o,l){t=n.state,typeof n.componentWillReceiveProps=="function"&&n.componentWillReceiveProps(o,l),typeof n.UNSAFE_componentWillReceiveProps=="function"&&n.UNSAFE_componentWillReceiveProps(o,l),n.state!==t&&rd.enqueueReplaceState(n,n.state,null)}function Kn(t,n){var o=n;if("ref"in n){o={};for(var l in n)l!=="ref"&&(o[l]=n[l])}if(t=t.defaultProps){o===n&&(o=y({},o));for(var d in t)o[d]===void 0&&(o[d]=t[d])}return o}var sl=typeof reportError=="function"?reportError:function(t){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var n=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof t=="object"&&t!==null&&typeof t.message=="string"?String(t.message):String(t),error:t});if(!window.dispatchEvent(n))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",t);return}console.error(t)};function dg(t){sl(t)}function fg(t){console.error(t)}function hg(t){sl(t)}function ll(t,n){try{var o=t.onUncaughtError;o(n.value,{componentStack:n.stack})}catch(l){setTimeout(function(){throw l})}}function pg(t,n,o){try{var l=t.onCaughtError;l(o.value,{componentStack:o.stack,errorBoundary:n.tag===1?n.stateNode:null})}catch(d){setTimeout(function(){throw d})}}function od(t,n,o){return o=on(o),o.tag=3,o.payload={element:null},o.callback=function(){ll(t,n)},o}function mg(t){return t=on(t),t.tag=3,t}function gg(t,n,o,l){var d=o.type.getDerivedStateFromError;if(typeof d=="function"){var g=l.value;t.payload=function(){return d(g)},t.callback=function(){pg(n,o,l)}}var v=o.stateNode;v!==null&&typeof v.componentDidCatch=="function"&&(t.callback=function(){pg(n,o,l),typeof d!="function"&&(gn===null?gn=new Set([this]):gn.add(this));var j=l.stack;this.componentDidCatch(l.value,{componentStack:j!==null?j:""})})}function x3(t,n,o,l,d){if(o.flags|=32768,l!==null&&typeof l=="object"&&typeof l.then=="function"){if(n=o.alternate,n!==null&&Qr(n,o,d,!0),o=Qt.current,o!==null){switch(o.tag){case 13:return gi===null?kd():o.alternate===null&&Xe===0&&(Xe=3),o.flags&=-257,o.flags|=65536,o.lanes=d,l===$u?o.flags|=16384:(n=o.updateQueue,n===null?o.updateQueue=new Set([l]):n.add(l),Md(t,l,d)),!1;case 22:return o.flags|=65536,l===$u?o.flags|=16384:(n=o.updateQueue,n===null?(n={transitions:null,markerInstances:null,retryQueue:new Set([l])},o.updateQueue=n):(o=n.retryQueue,o===null?n.retryQueue=new Set([l]):o.add(l)),Md(t,l,d)),!1}throw Error(r(435,o.tag))}return Md(t,l,d),kd(),!1}if(Ee)return n=Qt.current,n!==null?((n.flags&65536)===0&&(n.flags|=256),n.flags|=65536,n.lanes=d,l!==Ou&&(t=Error(r(422),{cause:l}),Zr(Gt(t,o)))):(l!==Ou&&(n=Error(r(423),{cause:l}),Zr(Gt(n,o))),t=t.current.alternate,t.flags|=65536,d&=-d,t.lanes|=d,l=Gt(l,o),d=od(t.stateNode,l,d),_u(t,d),Xe!==4&&(Xe=2)),!1;var g=Error(r(520),{cause:l});if(g=Gt(g,o),xo===null?xo=[g]:xo.push(g),Xe!==4&&(Xe=2),n===null)return!0;l=Gt(l,o),o=n;do{switch(o.tag){case 3:return o.flags|=65536,t=d&-d,o.lanes|=t,t=od(o.stateNode,l,t),_u(o,t),!1;case 1:if(n=o.type,g=o.stateNode,(o.flags&128)===0&&(typeof n.getDerivedStateFromError=="function"||g!==null&&typeof g.componentDidCatch=="function"&&(gn===null||!gn.has(g))))return o.flags|=65536,d&=-d,o.lanes|=d,d=mg(d),gg(d,t,o,l),_u(o,d),!1}o=o.return}while(o!==null);return!1}var yg=Error(r(461)),st=!1;function ft(t,n,o,l){n.child=t===null?sg(n,null,o,l):La(n,t.child,o,l)}function xg(t,n,o,l,d){o=o.render;var g=n.ref;if("ref"in l){var v={};for(var j in l)j!=="ref"&&(v[j]=l[j])}else v=l;return In(n),l=Uu(t,n,o,v,g,d),j=qu(),t!==null&&!st?(Iu(t,n,d),Hi(t,n,d)):(Ee&&j&&Eu(n),n.flags|=1,ft(t,n,l,d),n.child)}function bg(t,n,o,l,d){if(t===null){var g=o.type;return typeof g=="function"&&!Tu(g)&&g.defaultProps===void 0&&o.compare===null?(n.tag=15,n.type=g,vg(t,n,g,l,d)):(t=Ps(o.type,null,l,n,n.mode,d),t.ref=n.ref,t.return=n,n.child=t)}if(g=t.child,!pd(t,d)){var v=g.memoizedProps;if(o=o.compare,o=o!==null?o:Yr,o(v,l)&&t.ref===n.ref)return Hi(t,n,d)}return n.flags|=1,t=Mi(g,l),t.ref=n.ref,t.return=n,n.child=t}function vg(t,n,o,l,d){if(t!==null){var g=t.memoizedProps;if(Yr(g,l)&&t.ref===n.ref)if(st=!1,n.pendingProps=l=g,pd(t,d))(t.flags&131072)!==0&&(st=!0);else return n.lanes=t.lanes,Hi(t,n,d)}return sd(t,n,o,l,d)}function wg(t,n,o){var l=n.pendingProps,d=l.children,g=t!==null?t.memoizedState:null;if(l.mode==="hidden"){if((n.flags&128)!==0){if(l=g!==null?g.baseLanes|o:o,t!==null){for(d=n.child=t.child,g=0;d!==null;)g=g|d.lanes|d.childLanes,d=d.sibling;n.childLanes=g&~l}else n.childLanes=0,n.child=null;return Sg(t,n,l,o)}if((o&536870912)!==0)n.memoizedState={baseLanes:0,cachePool:null},t!==null&&Ys(n,g!==null?g.cachePool:null),g!==null?vm(n,g):Vu(),lg(n);else return n.lanes=n.childLanes=536870912,Sg(t,n,g!==null?g.baseLanes|o:o,o)}else g!==null?(Ys(n,g.cachePool),vm(n,g),un(),n.memoizedState=null):(t!==null&&Ys(n,null),Vu(),un());return ft(t,n,d,o),n.child}function Sg(t,n,o,l){var d=zu();return d=d===null?null:{parent:nt._currentValue,pool:d},n.memoizedState={baseLanes:o,cachePool:d},t!==null&&Ys(n,null),Vu(),lg(n),t!==null&&Qr(t,n,l,!0),null}function cl(t,n){var o=n.ref;if(o===null)t!==null&&t.ref!==null&&(n.flags|=4194816);else{if(typeof o!="function"&&typeof o!="object")throw Error(r(284));(t===null||t.ref!==o)&&(n.flags|=4194816)}}function sd(t,n,o,l,d){return In(n),o=Uu(t,n,o,l,void 0,d),l=qu(),t!==null&&!st?(Iu(t,n,d),Hi(t,n,d)):(Ee&&l&&Eu(n),n.flags|=1,ft(t,n,o,d),n.child)}function Tg(t,n,o,l,d,g){return In(n),n.updateQueue=null,o=Sm(n,l,o,d),wm(t),l=qu(),t!==null&&!st?(Iu(t,n,g),Hi(t,n,g)):(Ee&&l&&Eu(n),n.flags|=1,ft(t,n,o,g),n.child)}function jg(t,n,o,l,d){if(In(n),n.stateNode===null){var g=Ca,v=o.contextType;typeof v=="object"&&v!==null&&(g=xt(v)),g=new o(l,g),n.memoizedState=g.state!==null&&g.state!==void 0?g.state:null,g.updater=rd,n.stateNode=g,g._reactInternals=n,g=n.stateNode,g.props=l,g.state=n.memoizedState,g.refs={},Nu(n),v=o.contextType,g.context=typeof v=="object"&&v!==null?xt(v):Ca,g.state=n.memoizedState,v=o.getDerivedStateFromProps,typeof v=="function"&&(ad(n,o,v,l),g.state=n.memoizedState),typeof o.getDerivedStateFromProps=="function"||typeof g.getSnapshotBeforeUpdate=="function"||typeof g.UNSAFE_componentWillMount!="function"&&typeof g.componentWillMount!="function"||(v=g.state,typeof g.componentWillMount=="function"&&g.componentWillMount(),typeof g.UNSAFE_componentWillMount=="function"&&g.UNSAFE_componentWillMount(),v!==g.state&&rd.enqueueReplaceState(g,g.state,null),ao(n,l,g,d),no(),g.state=n.memoizedState),typeof g.componentDidMount=="function"&&(n.flags|=4194308),l=!0}else if(t===null){g=n.stateNode;var j=n.memoizedProps,R=Kn(o,j);g.props=R;var _=g.context,I=o.contextType;v=Ca,typeof I=="object"&&I!==null&&(v=xt(I));var K=o.getDerivedStateFromProps;I=typeof K=="function"||typeof g.getSnapshotBeforeUpdate=="function",j=n.pendingProps!==j,I||typeof g.UNSAFE_componentWillReceiveProps!="function"&&typeof g.componentWillReceiveProps!="function"||(j||_!==v)&&ug(n,g,l,v),rn=!1;var H=n.memoizedState;g.state=H,ao(n,l,g,d),no(),_=n.memoizedState,j||H!==_||rn?(typeof K=="function"&&(ad(n,o,K,l),_=n.memoizedState),(R=rn||cg(n,o,R,l,H,_,v))?(I||typeof g.UNSAFE_componentWillMount!="function"&&typeof g.componentWillMount!="function"||(typeof g.componentWillMount=="function"&&g.componentWillMount(),typeof g.UNSAFE_componentWillMount=="function"&&g.UNSAFE_componentWillMount()),typeof g.componentDidMount=="function"&&(n.flags|=4194308)):(typeof g.componentDidMount=="function"&&(n.flags|=4194308),n.memoizedProps=l,n.memoizedState=_),g.props=l,g.state=_,g.context=v,l=R):(typeof g.componentDidMount=="function"&&(n.flags|=4194308),l=!1)}else{g=n.stateNode,Lu(t,n),v=n.memoizedProps,I=Kn(o,v),g.props=I,K=n.pendingProps,H=g.context,_=o.contextType,R=Ca,typeof _=="object"&&_!==null&&(R=xt(_)),j=o.getDerivedStateFromProps,(_=typeof j=="function"||typeof g.getSnapshotBeforeUpdate=="function")||typeof g.UNSAFE_componentWillReceiveProps!="function"&&typeof g.componentWillReceiveProps!="function"||(v!==K||H!==R)&&ug(n,g,l,R),rn=!1,H=n.memoizedState,g.state=H,ao(n,l,g,d),no();var V=n.memoizedState;v!==K||H!==V||rn||t!==null&&t.dependencies!==null&&qs(t.dependencies)?(typeof j=="function"&&(ad(n,o,j,l),V=n.memoizedState),(I=rn||cg(n,o,I,l,H,V,R)||t!==null&&t.dependencies!==null&&qs(t.dependencies))?(_||typeof g.UNSAFE_componentWillUpdate!="function"&&typeof g.componentWillUpdate!="function"||(typeof g.componentWillUpdate=="function"&&g.componentWillUpdate(l,V,R),typeof g.UNSAFE_componentWillUpdate=="function"&&g.UNSAFE_componentWillUpdate(l,V,R)),typeof g.componentDidUpdate=="function"&&(n.flags|=4),typeof g.getSnapshotBeforeUpdate=="function"&&(n.flags|=1024)):(typeof g.componentDidUpdate!="function"||v===t.memoizedProps&&H===t.memoizedState||(n.flags|=4),typeof g.getSnapshotBeforeUpdate!="function"||v===t.memoizedProps&&H===t.memoizedState||(n.flags|=1024),n.memoizedProps=l,n.memoizedState=V),g.props=l,g.state=V,g.context=R,l=I):(typeof g.componentDidUpdate!="function"||v===t.memoizedProps&&H===t.memoizedState||(n.flags|=4),typeof g.getSnapshotBeforeUpdate!="function"||v===t.memoizedProps&&H===t.memoizedState||(n.flags|=1024),l=!1)}return g=l,cl(t,n),l=(n.flags&128)!==0,g||l?(g=n.stateNode,o=l&&typeof o.getDerivedStateFromError!="function"?null:g.render(),n.flags|=1,t!==null&&l?(n.child=La(n,t.child,null,d),n.child=La(n,null,o,d)):ft(t,n,o,d),n.memoizedState=g.state,t=n.child):t=Hi(t,n,d),t}function Ag(t,n,o,l){return Xr(),n.flags|=256,ft(t,n,o,l),n.child}var ld={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function cd(t){return{baseLanes:t,cachePool:fm()}}function ud(t,n,o){return t=t!==null?t.childLanes&~o:0,n&&(t|=Jt),t}function Eg(t,n,o){var l=n.pendingProps,d=!1,g=(n.flags&128)!==0,v;if((v=g)||(v=t!==null&&t.memoizedState===null?!1:(at.current&2)!==0),v&&(d=!0,n.flags&=-129),v=(n.flags&32)!==0,n.flags&=-33,t===null){if(Ee){if(d?cn(n):un(),Ee){var j=Ke,R;if(R=j){e:{for(R=j,j=mi;R.nodeType!==8;){if(!j){j=null;break e}if(R=oi(R.nextSibling),R===null){j=null;break e}}j=R}j!==null?(n.memoizedState={dehydrated:j,treeContext:Vn!==null?{id:Bi,overflow:zi}:null,retryLane:536870912,hydrationErrors:null},R=Nt(18,null,null,0),R.stateNode=j,R.return=n,n.child=R,Tt=n,Ke=null,R=!0):R=!1}R||Un(n)}if(j=n.memoizedState,j!==null&&(j=j.dehydrated,j!==null))return Gd(j)?n.lanes=32:n.lanes=536870912,null;_i(n)}return j=l.children,l=l.fallback,d?(un(),d=n.mode,j=ul({mode:"hidden",children:j},d),l=Hn(l,d,o,null),j.return=n,l.return=n,j.sibling=l,n.child=j,d=n.child,d.memoizedState=cd(o),d.childLanes=ud(t,v,o),n.memoizedState=ld,l):(cn(n),dd(n,j))}if(R=t.memoizedState,R!==null&&(j=R.dehydrated,j!==null)){if(g)n.flags&256?(cn(n),n.flags&=-257,n=fd(t,n,o)):n.memoizedState!==null?(un(),n.child=t.child,n.flags|=128,n=null):(un(),d=l.fallback,j=n.mode,l=ul({mode:"visible",children:l.children},j),d=Hn(d,j,o,null),d.flags|=2,l.return=n,d.return=n,l.sibling=d,n.child=l,La(n,t.child,null,o),l=n.child,l.memoizedState=cd(o),l.childLanes=ud(t,v,o),n.memoizedState=ld,n=d);else if(cn(n),Gd(j)){if(v=j.nextSibling&&j.nextSibling.dataset,v)var _=v.dgst;v=_,l=Error(r(419)),l.stack="",l.digest=v,Zr({value:l,source:null,stack:null}),n=fd(t,n,o)}else if(st||Qr(t,n,o,!1),v=(o&t.childLanes)!==0,st||v){if(v=He,v!==null&&(l=o&-o,l=(l&42)!==0?1:Kc(l),l=(l&(v.suspendedLanes|o))!==0?0:l,l!==0&&l!==R.retryLane))throw R.retryLane=l,Ea(t,l),Pt(v,t,l),yg;j.data==="$?"||kd(),n=fd(t,n,o)}else j.data==="$?"?(n.flags|=192,n.child=t.child,n=null):(t=R.treeContext,Ke=oi(j.nextSibling),Tt=n,Ee=!0,Fn=null,mi=!1,t!==null&&(Xt[Zt++]=Bi,Xt[Zt++]=zi,Xt[Zt++]=Vn,Bi=t.id,zi=t.overflow,Vn=n),n=dd(n,l.children),n.flags|=4096);return n}return d?(un(),d=l.fallback,j=n.mode,R=t.child,_=R.sibling,l=Mi(R,{mode:"hidden",children:l.children}),l.subtreeFlags=R.subtreeFlags&65011712,_!==null?d=Mi(_,d):(d=Hn(d,j,o,null),d.flags|=2),d.return=n,l.return=n,l.sibling=d,n.child=l,l=d,d=n.child,j=t.child.memoizedState,j===null?j=cd(o):(R=j.cachePool,R!==null?(_=nt._currentValue,R=R.parent!==_?{parent:_,pool:_}:R):R=fm(),j={baseLanes:j.baseLanes|o,cachePool:R}),d.memoizedState=j,d.childLanes=ud(t,v,o),n.memoizedState=ld,l):(cn(n),o=t.child,t=o.sibling,o=Mi(o,{mode:"visible",children:l.children}),o.return=n,o.sibling=null,t!==null&&(v=n.deletions,v===null?(n.deletions=[t],n.flags|=16):v.push(t)),n.child=o,n.memoizedState=null,o)}function dd(t,n){return n=ul({mode:"visible",children:n},t.mode),n.return=t,t.child=n}function ul(t,n){return t=Nt(22,t,null,n),t.lanes=0,t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null},t}function fd(t,n,o){return La(n,t.child,null,o),t=dd(n,n.pendingProps.children),t.flags|=2,n.memoizedState=null,t}function Cg(t,n,o){t.lanes|=n;var l=t.alternate;l!==null&&(l.lanes|=n),ku(t.return,n,o)}function hd(t,n,o,l,d){var g=t.memoizedState;g===null?t.memoizedState={isBackwards:n,rendering:null,renderingStartTime:0,last:l,tail:o,tailMode:d}:(g.isBackwards=n,g.rendering=null,g.renderingStartTime=0,g.last=l,g.tail=o,g.tailMode=d)}function Og(t,n,o){var l=n.pendingProps,d=l.revealOrder,g=l.tail;if(ft(t,n,l.children,o),l=at.current,(l&2)!==0)l=l&1|2,n.flags|=128;else{if(t!==null&&(t.flags&128)!==0)e:for(t=n.child;t!==null;){if(t.tag===13)t.memoizedState!==null&&Cg(t,o,n);else if(t.tag===19)Cg(t,o,n);else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===n)break e;for(;t.sibling===null;){if(t.return===null||t.return===n)break e;t=t.return}t.sibling.return=t.return,t=t.sibling}l&=1}switch(W(at,l),d){case"forwards":for(o=n.child,d=null;o!==null;)t=o.alternate,t!==null&&ol(t)===null&&(d=o),o=o.sibling;o=d,o===null?(d=n.child,n.child=null):(d=o.sibling,o.sibling=null),hd(n,!1,d,o,g);break;case"backwards":for(o=null,d=n.child,n.child=null;d!==null;){if(t=d.alternate,t!==null&&ol(t)===null){n.child=d;break}t=d.sibling,d.sibling=o,o=d,d=t}hd(n,!0,o,null,g);break;case"together":hd(n,!1,null,null,void 0);break;default:n.memoizedState=null}return n.child}function Hi(t,n,o){if(t!==null&&(n.dependencies=t.dependencies),mn|=n.lanes,(o&n.childLanes)===0)if(t!==null){if(Qr(t,n,o,!1),(o&n.childLanes)===0)return null}else return null;if(t!==null&&n.child!==t.child)throw Error(r(153));if(n.child!==null){for(t=n.child,o=Mi(t,t.pendingProps),n.child=o,o.return=n;t.sibling!==null;)t=t.sibling,o=o.sibling=Mi(t,t.pendingProps),o.return=n;o.sibling=null}return n.child}function pd(t,n){return(t.lanes&n)!==0?!0:(t=t.dependencies,!!(t!==null&&qs(t)))}function b3(t,n,o){switch(n.tag){case 3:Oe(n,n.stateNode.containerInfo),an(n,nt,t.memoizedState.cache),Xr();break;case 27:case 5:Bn(n);break;case 4:Oe(n,n.stateNode.containerInfo);break;case 10:an(n,n.type,n.memoizedProps.value);break;case 13:var l=n.memoizedState;if(l!==null)return l.dehydrated!==null?(cn(n),n.flags|=128,null):(o&n.child.childLanes)!==0?Eg(t,n,o):(cn(n),t=Hi(t,n,o),t!==null?t.sibling:null);cn(n);break;case 19:var d=(t.flags&128)!==0;if(l=(o&n.childLanes)!==0,l||(Qr(t,n,o,!1),l=(o&n.childLanes)!==0),d){if(l)return Og(t,n,o);n.flags|=128}if(d=n.memoizedState,d!==null&&(d.rendering=null,d.tail=null,d.lastEffect=null),W(at,at.current),l)break;return null;case 22:case 23:return n.lanes=0,wg(t,n,o);case 24:an(n,nt,t.memoizedState.cache)}return Hi(t,n,o)}function Rg(t,n,o){if(t!==null)if(t.memoizedProps!==n.pendingProps)st=!0;else{if(!pd(t,o)&&(n.flags&128)===0)return st=!1,b3(t,n,o);st=(t.flags&131072)!==0}else st=!1,Ee&&(n.flags&1048576)!==0&&rm(n,Us,n.index);switch(n.lanes=0,n.tag){case 16:e:{t=n.pendingProps;var l=n.elementType,d=l._init;if(l=d(l._payload),n.type=l,typeof l=="function")Tu(l)?(t=Kn(l,t),n.tag=1,n=jg(null,n,l,t,o)):(n.tag=0,n=sd(null,n,l,t,o));else{if(l!=null){if(d=l.$$typeof,d===F){n.tag=11,n=xg(null,n,l,t,o);break e}else if(d===G){n.tag=14,n=bg(null,n,l,t,o);break e}}throw n=ne(l)||l,Error(r(306,n,""))}}return n;case 0:return sd(t,n,n.type,n.pendingProps,o);case 1:return l=n.type,d=Kn(l,n.pendingProps),jg(t,n,l,d,o);case 3:e:{if(Oe(n,n.stateNode.containerInfo),t===null)throw Error(r(387));l=n.pendingProps;var g=n.memoizedState;d=g.element,Lu(t,n),ao(n,l,null,o);var v=n.memoizedState;if(l=v.cache,an(n,nt,l),l!==g.cache&&Du(n,[nt],o,!0),no(),l=v.element,g.isDehydrated)if(g={element:l,isDehydrated:!1,cache:v.cache},n.updateQueue.baseState=g,n.memoizedState=g,n.flags&256){n=Ag(t,n,l,o);break e}else if(l!==d){d=Gt(Error(r(424)),n),Zr(d),n=Ag(t,n,l,o);break e}else{switch(t=n.stateNode.containerInfo,t.nodeType){case 9:t=t.body;break;default:t=t.nodeName==="HTML"?t.ownerDocument.body:t}for(Ke=oi(t.firstChild),Tt=n,Ee=!0,Fn=null,mi=!0,o=sg(n,null,l,o),n.child=o;o;)o.flags=o.flags&-3|4096,o=o.sibling}else{if(Xr(),l===d){n=Hi(t,n,o);break e}ft(t,n,l,o)}n=n.child}return n;case 26:return cl(t,n),t===null?(o=B1(n.type,null,n.pendingProps,null))?n.memoizedState=o:Ee||(o=n.type,t=n.pendingProps,l=jl(le.current).createElement(o),l[yt]=n,l[At]=t,pt(l,o,t),ot(l),n.stateNode=l):n.memoizedState=B1(n.type,t.memoizedProps,n.pendingProps,t.memoizedState),null;case 27:return Bn(n),t===null&&Ee&&(l=n.stateNode=k1(n.type,n.pendingProps,le.current),Tt=n,mi=!0,d=Ke,bn(n.type)?(Kd=d,Ke=oi(l.firstChild)):Ke=d),ft(t,n,n.pendingProps.children,o),cl(t,n),t===null&&(n.flags|=4194304),n.child;case 5:return t===null&&Ee&&((d=l=Ke)&&(l=G3(l,n.type,n.pendingProps,mi),l!==null?(n.stateNode=l,Tt=n,Ke=oi(l.firstChild),mi=!1,d=!0):d=!1),d||Un(n)),Bn(n),d=n.type,g=n.pendingProps,v=t!==null?t.memoizedProps:null,l=g.children,qd(d,g)?l=null:v!==null&&qd(d,v)&&(n.flags|=32),n.memoizedState!==null&&(d=Uu(t,n,d3,null,null,o),Co._currentValue=d),cl(t,n),ft(t,n,l,o),n.child;case 6:return t===null&&Ee&&((t=o=Ke)&&(o=K3(o,n.pendingProps,mi),o!==null?(n.stateNode=o,Tt=n,Ke=null,t=!0):t=!1),t||Un(n)),null;case 13:return Eg(t,n,o);case 4:return Oe(n,n.stateNode.containerInfo),l=n.pendingProps,t===null?n.child=La(n,null,l,o):ft(t,n,l,o),n.child;case 11:return xg(t,n,n.type,n.pendingProps,o);case 7:return ft(t,n,n.pendingProps,o),n.child;case 8:return ft(t,n,n.pendingProps.children,o),n.child;case 12:return ft(t,n,n.pendingProps.children,o),n.child;case 10:return l=n.pendingProps,an(n,n.type,l.value),ft(t,n,l.children,o),n.child;case 9:return d=n.type._context,l=n.pendingProps.children,In(n),d=xt(d),l=l(d),n.flags|=1,ft(t,n,l,o),n.child;case 14:return bg(t,n,n.type,n.pendingProps,o);case 15:return vg(t,n,n.type,n.pendingProps,o);case 19:return Og(t,n,o);case 31:return l=n.pendingProps,o=n.mode,l={mode:l.mode,children:l.children},t===null?(o=ul(l,o),o.ref=n.ref,n.child=o,o.return=n,n=o):(o=Mi(t.child,l),o.ref=n.ref,n.child=o,o.return=n,n=o),n;case 22:return wg(t,n,o);case 24:return In(n),l=xt(nt),t===null?(d=zu(),d===null&&(d=He,g=Mu(),d.pooledCache=g,g.refCount++,g!==null&&(d.pooledCacheLanes|=o),d=g),n.memoizedState={parent:l,cache:d},Nu(n),an(n,nt,d)):((t.lanes&o)!==0&&(Lu(t,n),ao(n,null,null,o),no()),d=t.memoizedState,g=n.memoizedState,d.parent!==l?(d={parent:l,cache:l},n.memoizedState=d,n.lanes===0&&(n.memoizedState=n.updateQueue.baseState=d),an(n,nt,l)):(l=g.cache,an(n,nt,l),l!==d.cache&&Du(n,[nt],o,!0))),ft(t,n,n.pendingProps.children,o),n.child;case 29:throw n.pendingProps}throw Error(r(156,n.tag))}function Vi(t){t.flags|=4}function kg(t,n){if(n.type!=="stylesheet"||(n.state.loading&4)!==0)t.flags&=-16777217;else if(t.flags|=16777216,!_1(n)){if(n=Qt.current,n!==null&&((je&4194048)===je?gi!==null:(je&62914560)!==je&&(je&536870912)===0||n!==gi))throw to=$u,hm;t.flags|=8192}}function dl(t,n){n!==null&&(t.flags|=4),t.flags&16384&&(n=t.tag!==22?l0():536870912,t.lanes|=n,Pa|=n)}function fo(t,n){if(!Ee)switch(t.tailMode){case"hidden":n=t.tail;for(var o=null;n!==null;)n.alternate!==null&&(o=n),n=n.sibling;o===null?t.tail=null:o.sibling=null;break;case"collapsed":o=t.tail;for(var l=null;o!==null;)o.alternate!==null&&(l=o),o=o.sibling;l===null?n||t.tail===null?t.tail=null:t.tail.sibling=null:l.sibling=null}}function Ie(t){var n=t.alternate!==null&&t.alternate.child===t.child,o=0,l=0;if(n)for(var d=t.child;d!==null;)o|=d.lanes|d.childLanes,l|=d.subtreeFlags&65011712,l|=d.flags&65011712,d.return=t,d=d.sibling;else for(d=t.child;d!==null;)o|=d.lanes|d.childLanes,l|=d.subtreeFlags,l|=d.flags,d.return=t,d=d.sibling;return t.subtreeFlags|=l,t.childLanes=o,n}function v3(t,n,o){var l=n.pendingProps;switch(Cu(n),n.tag){case 31:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return Ie(n),null;case 1:return Ie(n),null;case 3:return o=n.stateNode,l=null,t!==null&&(l=t.memoizedState.cache),n.memoizedState.cache!==l&&(n.flags|=2048),Ni(nt),gt(),o.pendingContext&&(o.context=o.pendingContext,o.pendingContext=null),(t===null||t.child===null)&&(Kr(n)?Vi(n):t===null||t.memoizedState.isDehydrated&&(n.flags&256)===0||(n.flags|=1024,lm())),Ie(n),null;case 26:return o=n.memoizedState,t===null?(Vi(n),o!==null?(Ie(n),kg(n,o)):(Ie(n),n.flags&=-16777217)):o?o!==t.memoizedState?(Vi(n),Ie(n),kg(n,o)):(Ie(n),n.flags&=-16777217):(t.memoizedProps!==l&&Vi(n),Ie(n),n.flags&=-16777217),null;case 27:Ri(n),o=le.current;var d=n.type;if(t!==null&&n.stateNode!=null)t.memoizedProps!==l&&Vi(n);else{if(!l){if(n.stateNode===null)throw Error(r(166));return Ie(n),null}t=ae.current,Kr(n)?om(n):(t=k1(d,l,o),n.stateNode=t,Vi(n))}return Ie(n),null;case 5:if(Ri(n),o=n.type,t!==null&&n.stateNode!=null)t.memoizedProps!==l&&Vi(n);else{if(!l){if(n.stateNode===null)throw Error(r(166));return Ie(n),null}if(t=ae.current,Kr(n))om(n);else{switch(d=jl(le.current),t){case 1:t=d.createElementNS("http://www.w3.org/2000/svg",o);break;case 2:t=d.createElementNS("http://www.w3.org/1998/Math/MathML",o);break;default:switch(o){case"svg":t=d.createElementNS("http://www.w3.org/2000/svg",o);break;case"math":t=d.createElementNS("http://www.w3.org/1998/Math/MathML",o);break;case"script":t=d.createElement("div"),t.innerHTML="<script><\/script>",t=t.removeChild(t.firstChild);break;case"select":t=typeof l.is=="string"?d.createElement("select",{is:l.is}):d.createElement("select"),l.multiple?t.multiple=!0:l.size&&(t.size=l.size);break;default:t=typeof l.is=="string"?d.createElement(o,{is:l.is}):d.createElement(o)}}t[yt]=n,t[At]=l;e:for(d=n.child;d!==null;){if(d.tag===5||d.tag===6)t.appendChild(d.stateNode);else if(d.tag!==4&&d.tag!==27&&d.child!==null){d.child.return=d,d=d.child;continue}if(d===n)break e;for(;d.sibling===null;){if(d.return===null||d.return===n)break e;d=d.return}d.sibling.return=d.return,d=d.sibling}n.stateNode=t;e:switch(pt(t,o,l),o){case"button":case"input":case"select":case"textarea":t=!!l.autoFocus;break e;case"img":t=!0;break e;default:t=!1}t&&Vi(n)}}return Ie(n),n.flags&=-16777217,null;case 6:if(t&&n.stateNode!=null)t.memoizedProps!==l&&Vi(n);else{if(typeof l!="string"&&n.stateNode===null)throw Error(r(166));if(t=le.current,Kr(n)){if(t=n.stateNode,o=n.memoizedProps,l=null,d=Tt,d!==null)switch(d.tag){case 27:case 5:l=d.memoizedProps}t[yt]=n,t=!!(t.nodeValue===o||l!==null&&l.suppressHydrationWarning===!0||T1(t.nodeValue,o)),t||Un(n)}else t=jl(t).createTextNode(l),t[yt]=n,n.stateNode=t}return Ie(n),null;case 13:if(l=n.memoizedState,t===null||t.memoizedState!==null&&t.memoizedState.dehydrated!==null){if(d=Kr(n),l!==null&&l.dehydrated!==null){if(t===null){if(!d)throw Error(r(318));if(d=n.memoizedState,d=d!==null?d.dehydrated:null,!d)throw Error(r(317));d[yt]=n}else Xr(),(n.flags&128)===0&&(n.memoizedState=null),n.flags|=4;Ie(n),d=!1}else d=lm(),t!==null&&t.memoizedState!==null&&(t.memoizedState.hydrationErrors=d),d=!0;if(!d)return n.flags&256?(_i(n),n):(_i(n),null)}if(_i(n),(n.flags&128)!==0)return n.lanes=o,n;if(o=l!==null,t=t!==null&&t.memoizedState!==null,o){l=n.child,d=null,l.alternate!==null&&l.alternate.memoizedState!==null&&l.alternate.memoizedState.cachePool!==null&&(d=l.alternate.memoizedState.cachePool.pool);var g=null;l.memoizedState!==null&&l.memoizedState.cachePool!==null&&(g=l.memoizedState.cachePool.pool),g!==d&&(l.flags|=2048)}return o!==t&&o&&(n.child.flags|=8192),dl(n,n.updateQueue),Ie(n),null;case 4:return gt(),t===null&&Hd(n.stateNode.containerInfo),Ie(n),null;case 10:return Ni(n.type),Ie(n),null;case 19:if(Q(at),d=n.memoizedState,d===null)return Ie(n),null;if(l=(n.flags&128)!==0,g=d.rendering,g===null)if(l)fo(d,!1);else{if(Xe!==0||t!==null&&(t.flags&128)!==0)for(t=n.child;t!==null;){if(g=ol(t),g!==null){for(n.flags|=128,fo(d,!1),t=g.updateQueue,n.updateQueue=t,dl(n,t),n.subtreeFlags=0,t=o,o=n.child;o!==null;)am(o,t),o=o.sibling;return W(at,at.current&1|2),n.child}t=t.sibling}d.tail!==null&&pi()>pl&&(n.flags|=128,l=!0,fo(d,!1),n.lanes=4194304)}else{if(!l)if(t=ol(g),t!==null){if(n.flags|=128,l=!0,t=t.updateQueue,n.updateQueue=t,dl(n,t),fo(d,!0),d.tail===null&&d.tailMode==="hidden"&&!g.alternate&&!Ee)return Ie(n),null}else 2*pi()-d.renderingStartTime>pl&&o!==536870912&&(n.flags|=128,l=!0,fo(d,!1),n.lanes=4194304);d.isBackwards?(g.sibling=n.child,n.child=g):(t=d.last,t!==null?t.sibling=g:n.child=g,d.last=g)}return d.tail!==null?(n=d.tail,d.rendering=n,d.tail=n.sibling,d.renderingStartTime=pi(),n.sibling=null,t=at.current,W(at,l?t&1|2:t&1),n):(Ie(n),null);case 22:case 23:return _i(n),Pu(),l=n.memoizedState!==null,t!==null?t.memoizedState!==null!==l&&(n.flags|=8192):l&&(n.flags|=8192),l?(o&536870912)!==0&&(n.flags&128)===0&&(Ie(n),n.subtreeFlags&6&&(n.flags|=8192)):Ie(n),o=n.updateQueue,o!==null&&dl(n,o.retryQueue),o=null,t!==null&&t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(o=t.memoizedState.cachePool.pool),l=null,n.memoizedState!==null&&n.memoizedState.cachePool!==null&&(l=n.memoizedState.cachePool.pool),l!==o&&(n.flags|=2048),t!==null&&Q(Yn),null;case 24:return o=null,t!==null&&(o=t.memoizedState.cache),n.memoizedState.cache!==o&&(n.flags|=2048),Ni(nt),Ie(n),null;case 25:return null;case 30:return null}throw Error(r(156,n.tag))}function w3(t,n){switch(Cu(n),n.tag){case 1:return t=n.flags,t&65536?(n.flags=t&-65537|128,n):null;case 3:return Ni(nt),gt(),t=n.flags,(t&65536)!==0&&(t&128)===0?(n.flags=t&-65537|128,n):null;case 26:case 27:case 5:return Ri(n),null;case 13:if(_i(n),t=n.memoizedState,t!==null&&t.dehydrated!==null){if(n.alternate===null)throw Error(r(340));Xr()}return t=n.flags,t&65536?(n.flags=t&-65537|128,n):null;case 19:return Q(at),null;case 4:return gt(),null;case 10:return Ni(n.type),null;case 22:case 23:return _i(n),Pu(),t!==null&&Q(Yn),t=n.flags,t&65536?(n.flags=t&-65537|128,n):null;case 24:return Ni(nt),null;case 25:return null;default:return null}}function Dg(t,n){switch(Cu(n),n.tag){case 3:Ni(nt),gt();break;case 26:case 27:case 5:Ri(n);break;case 4:gt();break;case 13:_i(n);break;case 19:Q(at);break;case 10:Ni(n.type);break;case 22:case 23:_i(n),Pu(),t!==null&&Q(Yn);break;case 24:Ni(nt)}}function ho(t,n){try{var o=n.updateQueue,l=o!==null?o.lastEffect:null;if(l!==null){var d=l.next;o=d;do{if((o.tag&t)===t){l=void 0;var g=o.create,v=o.inst;l=g(),v.destroy=l}o=o.next}while(o!==d)}}catch(j){_e(n,n.return,j)}}function dn(t,n,o){try{var l=n.updateQueue,d=l!==null?l.lastEffect:null;if(d!==null){var g=d.next;l=g;do{if((l.tag&t)===t){var v=l.inst,j=v.destroy;if(j!==void 0){v.destroy=void 0,d=n;var R=o,_=j;try{_()}catch(I){_e(d,R,I)}}}l=l.next}while(l!==g)}}catch(I){_e(n,n.return,I)}}function Mg(t){var n=t.updateQueue;if(n!==null){var o=t.stateNode;try{bm(n,o)}catch(l){_e(t,t.return,l)}}}function Bg(t,n,o){o.props=Kn(t.type,t.memoizedProps),o.state=t.memoizedState;try{o.componentWillUnmount()}catch(l){_e(t,n,l)}}function po(t,n){try{var o=t.ref;if(o!==null){switch(t.tag){case 26:case 27:case 5:var l=t.stateNode;break;case 30:l=t.stateNode;break;default:l=t.stateNode}typeof o=="function"?t.refCleanup=o(l):o.current=l}}catch(d){_e(t,n,d)}}function yi(t,n){var o=t.ref,l=t.refCleanup;if(o!==null)if(typeof l=="function")try{l()}catch(d){_e(t,n,d)}finally{t.refCleanup=null,t=t.alternate,t!=null&&(t.refCleanup=null)}else if(typeof o=="function")try{o(null)}catch(d){_e(t,n,d)}else o.current=null}function zg(t){var n=t.type,o=t.memoizedProps,l=t.stateNode;try{e:switch(n){case"button":case"input":case"select":case"textarea":o.autoFocus&&l.focus();break e;case"img":o.src?l.src=o.src:o.srcSet&&(l.srcset=o.srcSet)}}catch(d){_e(t,t.return,d)}}function md(t,n,o){try{var l=t.stateNode;F3(l,t.type,o,n),l[At]=n}catch(d){_e(t,t.return,d)}}function $g(t){return t.tag===5||t.tag===3||t.tag===26||t.tag===27&&bn(t.type)||t.tag===4}function gd(t){e:for(;;){for(;t.sibling===null;){if(t.return===null||$g(t.return))return null;t=t.return}for(t.sibling.return=t.return,t=t.sibling;t.tag!==5&&t.tag!==6&&t.tag!==18;){if(t.tag===27&&bn(t.type)||t.flags&2||t.child===null||t.tag===4)continue e;t.child.return=t,t=t.child}if(!(t.flags&2))return t.stateNode}}function yd(t,n,o){var l=t.tag;if(l===5||l===6)t=t.stateNode,n?(o.nodeType===9?o.body:o.nodeName==="HTML"?o.ownerDocument.body:o).insertBefore(t,n):(n=o.nodeType===9?o.body:o.nodeName==="HTML"?o.ownerDocument.body:o,n.appendChild(t),o=o._reactRootContainer,o!=null||n.onclick!==null||(n.onclick=Tl));else if(l!==4&&(l===27&&bn(t.type)&&(o=t.stateNode,n=null),t=t.child,t!==null))for(yd(t,n,o),t=t.sibling;t!==null;)yd(t,n,o),t=t.sibling}function fl(t,n,o){var l=t.tag;if(l===5||l===6)t=t.stateNode,n?o.insertBefore(t,n):o.appendChild(t);else if(l!==4&&(l===27&&bn(t.type)&&(o=t.stateNode),t=t.child,t!==null))for(fl(t,n,o),t=t.sibling;t!==null;)fl(t,n,o),t=t.sibling}function Ng(t){var n=t.stateNode,o=t.memoizedProps;try{for(var l=t.type,d=n.attributes;d.length;)n.removeAttributeNode(d[0]);pt(n,l,o),n[yt]=t,n[At]=o}catch(g){_e(t,t.return,g)}}var Pi=!1,Je=!1,xd=!1,Lg=typeof WeakSet=="function"?WeakSet:Set,lt=null;function S3(t,n){if(t=t.containerInfo,Fd=kl,t=K0(t),gu(t)){if("selectionStart"in t)var o={start:t.selectionStart,end:t.selectionEnd};else e:{o=(o=t.ownerDocument)&&o.defaultView||window;var l=o.getSelection&&o.getSelection();if(l&&l.rangeCount!==0){o=l.anchorNode;var d=l.anchorOffset,g=l.focusNode;l=l.focusOffset;try{o.nodeType,g.nodeType}catch{o=null;break e}var v=0,j=-1,R=-1,_=0,I=0,K=t,H=null;t:for(;;){for(var V;K!==o||d!==0&&K.nodeType!==3||(j=v+d),K!==g||l!==0&&K.nodeType!==3||(R=v+l),K.nodeType===3&&(v+=K.nodeValue.length),(V=K.firstChild)!==null;)H=K,K=V;for(;;){if(K===t)break t;if(H===o&&++_===d&&(j=v),H===g&&++I===l&&(R=v),(V=K.nextSibling)!==null)break;K=H,H=K.parentNode}K=V}o=j===-1||R===-1?null:{start:j,end:R}}else o=null}o=o||{start:0,end:0}}else o=null;for(Ud={focusedElem:t,selectionRange:o},kl=!1,lt=n;lt!==null;)if(n=lt,t=n.child,(n.subtreeFlags&1024)!==0&&t!==null)t.return=n,lt=t;else for(;lt!==null;){switch(n=lt,g=n.alternate,t=n.flags,n.tag){case 0:break;case 11:case 15:break;case 1:if((t&1024)!==0&&g!==null){t=void 0,o=n,d=g.memoizedProps,g=g.memoizedState,l=o.stateNode;try{var ue=Kn(o.type,d,o.elementType===o.type);t=l.getSnapshotBeforeUpdate(ue,g),l.__reactInternalSnapshotBeforeUpdate=t}catch(se){_e(o,o.return,se)}}break;case 3:if((t&1024)!==0){if(t=n.stateNode.containerInfo,o=t.nodeType,o===9)Yd(t);else if(o===1)switch(t.nodeName){case"HEAD":case"HTML":case"BODY":Yd(t);break;default:t.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if((t&1024)!==0)throw Error(r(163))}if(t=n.sibling,t!==null){t.return=n.return,lt=t;break}lt=n.return}}function _g(t,n,o){var l=o.flags;switch(o.tag){case 0:case 11:case 15:fn(t,o),l&4&&ho(5,o);break;case 1:if(fn(t,o),l&4)if(t=o.stateNode,n===null)try{t.componentDidMount()}catch(v){_e(o,o.return,v)}else{var d=Kn(o.type,n.memoizedProps);n=n.memoizedState;try{t.componentDidUpdate(d,n,t.__reactInternalSnapshotBeforeUpdate)}catch(v){_e(o,o.return,v)}}l&64&&Mg(o),l&512&&po(o,o.return);break;case 3:if(fn(t,o),l&64&&(t=o.updateQueue,t!==null)){if(n=null,o.child!==null)switch(o.child.tag){case 27:case 5:n=o.child.stateNode;break;case 1:n=o.child.stateNode}try{bm(t,n)}catch(v){_e(o,o.return,v)}}break;case 27:n===null&&l&4&&Ng(o);case 26:case 5:fn(t,o),n===null&&l&4&&zg(o),l&512&&po(o,o.return);break;case 12:fn(t,o);break;case 13:fn(t,o),l&4&&Pg(t,o),l&64&&(t=o.memoizedState,t!==null&&(t=t.dehydrated,t!==null&&(o=D3.bind(null,o),X3(t,o))));break;case 22:if(l=o.memoizedState!==null||Pi,!l){n=n!==null&&n.memoizedState!==null||Je,d=Pi;var g=Je;Pi=l,(Je=n)&&!g?hn(t,o,(o.subtreeFlags&8772)!==0):fn(t,o),Pi=d,Je=g}break;case 30:break;default:fn(t,o)}}function Hg(t){var n=t.alternate;n!==null&&(t.alternate=null,Hg(n)),t.child=null,t.deletions=null,t.sibling=null,t.tag===5&&(n=t.stateNode,n!==null&&Qc(n)),t.stateNode=null,t.return=null,t.dependencies=null,t.memoizedProps=null,t.memoizedState=null,t.pendingProps=null,t.stateNode=null,t.updateQueue=null}var Pe=null,Ot=!1;function Fi(t,n,o){for(o=o.child;o!==null;)Vg(t,n,o),o=o.sibling}function Vg(t,n,o){if(Bt&&typeof Bt.onCommitFiberUnmount=="function")try{Bt.onCommitFiberUnmount(zr,o)}catch{}switch(o.tag){case 26:Je||yi(o,n),Fi(t,n,o),o.memoizedState?o.memoizedState.count--:o.stateNode&&(o=o.stateNode,o.parentNode.removeChild(o));break;case 27:Je||yi(o,n);var l=Pe,d=Ot;bn(o.type)&&(Pe=o.stateNode,Ot=!1),Fi(t,n,o),To(o.stateNode),Pe=l,Ot=d;break;case 5:Je||yi(o,n);case 6:if(l=Pe,d=Ot,Pe=null,Fi(t,n,o),Pe=l,Ot=d,Pe!==null)if(Ot)try{(Pe.nodeType===9?Pe.body:Pe.nodeName==="HTML"?Pe.ownerDocument.body:Pe).removeChild(o.stateNode)}catch(g){_e(o,n,g)}else try{Pe.removeChild(o.stateNode)}catch(g){_e(o,n,g)}break;case 18:Pe!==null&&(Ot?(t=Pe,O1(t.nodeType===9?t.body:t.nodeName==="HTML"?t.ownerDocument.body:t,o.stateNode),Do(t)):O1(Pe,o.stateNode));break;case 4:l=Pe,d=Ot,Pe=o.stateNode.containerInfo,Ot=!0,Fi(t,n,o),Pe=l,Ot=d;break;case 0:case 11:case 14:case 15:Je||dn(2,o,n),Je||dn(4,o,n),Fi(t,n,o);break;case 1:Je||(yi(o,n),l=o.stateNode,typeof l.componentWillUnmount=="function"&&Bg(o,n,l)),Fi(t,n,o);break;case 21:Fi(t,n,o);break;case 22:Je=(l=Je)||o.memoizedState!==null,Fi(t,n,o),Je=l;break;default:Fi(t,n,o)}}function Pg(t,n){if(n.memoizedState===null&&(t=n.alternate,t!==null&&(t=t.memoizedState,t!==null&&(t=t.dehydrated,t!==null))))try{Do(t)}catch(o){_e(n,n.return,o)}}function T3(t){switch(t.tag){case 13:case 19:var n=t.stateNode;return n===null&&(n=t.stateNode=new Lg),n;case 22:return t=t.stateNode,n=t._retryCache,n===null&&(n=t._retryCache=new Lg),n;default:throw Error(r(435,t.tag))}}function bd(t,n){var o=T3(t);n.forEach(function(l){var d=M3.bind(null,t,l);o.has(l)||(o.add(l),l.then(d,d))})}function Lt(t,n){var o=n.deletions;if(o!==null)for(var l=0;l<o.length;l++){var d=o[l],g=t,v=n,j=v;e:for(;j!==null;){switch(j.tag){case 27:if(bn(j.type)){Pe=j.stateNode,Ot=!1;break e}break;case 5:Pe=j.stateNode,Ot=!1;break e;case 3:case 4:Pe=j.stateNode.containerInfo,Ot=!0;break e}j=j.return}if(Pe===null)throw Error(r(160));Vg(g,v,d),Pe=null,Ot=!1,g=d.alternate,g!==null&&(g.return=null),d.return=null}if(n.subtreeFlags&13878)for(n=n.child;n!==null;)Fg(n,t),n=n.sibling}var ri=null;function Fg(t,n){var o=t.alternate,l=t.flags;switch(t.tag){case 0:case 11:case 14:case 15:Lt(n,t),_t(t),l&4&&(dn(3,t,t.return),ho(3,t),dn(5,t,t.return));break;case 1:Lt(n,t),_t(t),l&512&&(Je||o===null||yi(o,o.return)),l&64&&Pi&&(t=t.updateQueue,t!==null&&(l=t.callbacks,l!==null&&(o=t.shared.hiddenCallbacks,t.shared.hiddenCallbacks=o===null?l:o.concat(l))));break;case 26:var d=ri;if(Lt(n,t),_t(t),l&512&&(Je||o===null||yi(o,o.return)),l&4){var g=o!==null?o.memoizedState:null;if(l=t.memoizedState,o===null)if(l===null)if(t.stateNode===null){e:{l=t.type,o=t.memoizedProps,d=d.ownerDocument||d;t:switch(l){case"title":g=d.getElementsByTagName("title")[0],(!g||g[Lr]||g[yt]||g.namespaceURI==="http://www.w3.org/2000/svg"||g.hasAttribute("itemprop"))&&(g=d.createElement(l),d.head.insertBefore(g,d.querySelector("head > title"))),pt(g,l,o),g[yt]=t,ot(g),l=g;break e;case"link":var v=N1("link","href",d).get(l+(o.href||""));if(v){for(var j=0;j<v.length;j++)if(g=v[j],g.getAttribute("href")===(o.href==null||o.href===""?null:o.href)&&g.getAttribute("rel")===(o.rel==null?null:o.rel)&&g.getAttribute("title")===(o.title==null?null:o.title)&&g.getAttribute("crossorigin")===(o.crossOrigin==null?null:o.crossOrigin)){v.splice(j,1);break t}}g=d.createElement(l),pt(g,l,o),d.head.appendChild(g);break;case"meta":if(v=N1("meta","content",d).get(l+(o.content||""))){for(j=0;j<v.length;j++)if(g=v[j],g.getAttribute("content")===(o.content==null?null:""+o.content)&&g.getAttribute("name")===(o.name==null?null:o.name)&&g.getAttribute("property")===(o.property==null?null:o.property)&&g.getAttribute("http-equiv")===(o.httpEquiv==null?null:o.httpEquiv)&&g.getAttribute("charset")===(o.charSet==null?null:o.charSet)){v.splice(j,1);break t}}g=d.createElement(l),pt(g,l,o),d.head.appendChild(g);break;default:throw Error(r(468,l))}g[yt]=t,ot(g),l=g}t.stateNode=l}else L1(d,t.type,t.stateNode);else t.stateNode=$1(d,l,t.memoizedProps);else g!==l?(g===null?o.stateNode!==null&&(o=o.stateNode,o.parentNode.removeChild(o)):g.count--,l===null?L1(d,t.type,t.stateNode):$1(d,l,t.memoizedProps)):l===null&&t.stateNode!==null&&md(t,t.memoizedProps,o.memoizedProps)}break;case 27:Lt(n,t),_t(t),l&512&&(Je||o===null||yi(o,o.return)),o!==null&&l&4&&md(t,t.memoizedProps,o.memoizedProps);break;case 5:if(Lt(n,t),_t(t),l&512&&(Je||o===null||yi(o,o.return)),t.flags&32){d=t.stateNode;try{ba(d,"")}catch(V){_e(t,t.return,V)}}l&4&&t.stateNode!=null&&(d=t.memoizedProps,md(t,d,o!==null?o.memoizedProps:d)),l&1024&&(xd=!0);break;case 6:if(Lt(n,t),_t(t),l&4){if(t.stateNode===null)throw Error(r(162));l=t.memoizedProps,o=t.stateNode;try{o.nodeValue=l}catch(V){_e(t,t.return,V)}}break;case 3:if(Cl=null,d=ri,ri=Al(n.containerInfo),Lt(n,t),ri=d,_t(t),l&4&&o!==null&&o.memoizedState.isDehydrated)try{Do(n.containerInfo)}catch(V){_e(t,t.return,V)}xd&&(xd=!1,Ug(t));break;case 4:l=ri,ri=Al(t.stateNode.containerInfo),Lt(n,t),_t(t),ri=l;break;case 12:Lt(n,t),_t(t);break;case 13:Lt(n,t),_t(t),t.child.flags&8192&&t.memoizedState!==null!=(o!==null&&o.memoizedState!==null)&&(Ad=pi()),l&4&&(l=t.updateQueue,l!==null&&(t.updateQueue=null,bd(t,l)));break;case 22:d=t.memoizedState!==null;var R=o!==null&&o.memoizedState!==null,_=Pi,I=Je;if(Pi=_||d,Je=I||R,Lt(n,t),Je=I,Pi=_,_t(t),l&8192)e:for(n=t.stateNode,n._visibility=d?n._visibility&-2:n._visibility|1,d&&(o===null||R||Pi||Je||Xn(t)),o=null,n=t;;){if(n.tag===5||n.tag===26){if(o===null){R=o=n;try{if(g=R.stateNode,d)v=g.style,typeof v.setProperty=="function"?v.setProperty("display","none","important"):v.display="none";else{j=R.stateNode;var K=R.memoizedProps.style,H=K!=null&&K.hasOwnProperty("display")?K.display:null;j.style.display=H==null||typeof H=="boolean"?"":(""+H).trim()}}catch(V){_e(R,R.return,V)}}}else if(n.tag===6){if(o===null){R=n;try{R.stateNode.nodeValue=d?"":R.memoizedProps}catch(V){_e(R,R.return,V)}}}else if((n.tag!==22&&n.tag!==23||n.memoizedState===null||n===t)&&n.child!==null){n.child.return=n,n=n.child;continue}if(n===t)break e;for(;n.sibling===null;){if(n.return===null||n.return===t)break e;o===n&&(o=null),n=n.return}o===n&&(o=null),n.sibling.return=n.return,n=n.sibling}l&4&&(l=t.updateQueue,l!==null&&(o=l.retryQueue,o!==null&&(l.retryQueue=null,bd(t,o))));break;case 19:Lt(n,t),_t(t),l&4&&(l=t.updateQueue,l!==null&&(t.updateQueue=null,bd(t,l)));break;case 30:break;case 21:break;default:Lt(n,t),_t(t)}}function _t(t){var n=t.flags;if(n&2){try{for(var o,l=t.return;l!==null;){if($g(l)){o=l;break}l=l.return}if(o==null)throw Error(r(160));switch(o.tag){case 27:var d=o.stateNode,g=gd(t);fl(t,g,d);break;case 5:var v=o.stateNode;o.flags&32&&(ba(v,""),o.flags&=-33);var j=gd(t);fl(t,j,v);break;case 3:case 4:var R=o.stateNode.containerInfo,_=gd(t);yd(t,_,R);break;default:throw Error(r(161))}}catch(I){_e(t,t.return,I)}t.flags&=-3}n&4096&&(t.flags&=-4097)}function Ug(t){if(t.subtreeFlags&1024)for(t=t.child;t!==null;){var n=t;Ug(n),n.tag===5&&n.flags&1024&&n.stateNode.reset(),t=t.sibling}}function fn(t,n){if(n.subtreeFlags&8772)for(n=n.child;n!==null;)_g(t,n.alternate,n),n=n.sibling}function Xn(t){for(t=t.child;t!==null;){var n=t;switch(n.tag){case 0:case 11:case 14:case 15:dn(4,n,n.return),Xn(n);break;case 1:yi(n,n.return);var o=n.stateNode;typeof o.componentWillUnmount=="function"&&Bg(n,n.return,o),Xn(n);break;case 27:To(n.stateNode);case 26:case 5:yi(n,n.return),Xn(n);break;case 22:n.memoizedState===null&&Xn(n);break;case 30:Xn(n);break;default:Xn(n)}t=t.sibling}}function hn(t,n,o){for(o=o&&(n.subtreeFlags&8772)!==0,n=n.child;n!==null;){var l=n.alternate,d=t,g=n,v=g.flags;switch(g.tag){case 0:case 11:case 15:hn(d,g,o),ho(4,g);break;case 1:if(hn(d,g,o),l=g,d=l.stateNode,typeof d.componentDidMount=="function")try{d.componentDidMount()}catch(_){_e(l,l.return,_)}if(l=g,d=l.updateQueue,d!==null){var j=l.stateNode;try{var R=d.shared.hiddenCallbacks;if(R!==null)for(d.shared.hiddenCallbacks=null,d=0;d<R.length;d++)xm(R[d],j)}catch(_){_e(l,l.return,_)}}o&&v&64&&Mg(g),po(g,g.return);break;case 27:Ng(g);case 26:case 5:hn(d,g,o),o&&l===null&&v&4&&zg(g),po(g,g.return);break;case 12:hn(d,g,o);break;case 13:hn(d,g,o),o&&v&4&&Pg(d,g);break;case 22:g.memoizedState===null&&hn(d,g,o),po(g,g.return);break;case 30:break;default:hn(d,g,o)}n=n.sibling}}function vd(t,n){var o=null;t!==null&&t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(o=t.memoizedState.cachePool.pool),t=null,n.memoizedState!==null&&n.memoizedState.cachePool!==null&&(t=n.memoizedState.cachePool.pool),t!==o&&(t!=null&&t.refCount++,o!=null&&Jr(o))}function wd(t,n){t=null,n.alternate!==null&&(t=n.alternate.memoizedState.cache),n=n.memoizedState.cache,n!==t&&(n.refCount++,t!=null&&Jr(t))}function xi(t,n,o,l){if(n.subtreeFlags&10256)for(n=n.child;n!==null;)qg(t,n,o,l),n=n.sibling}function qg(t,n,o,l){var d=n.flags;switch(n.tag){case 0:case 11:case 15:xi(t,n,o,l),d&2048&&ho(9,n);break;case 1:xi(t,n,o,l);break;case 3:xi(t,n,o,l),d&2048&&(t=null,n.alternate!==null&&(t=n.alternate.memoizedState.cache),n=n.memoizedState.cache,n!==t&&(n.refCount++,t!=null&&Jr(t)));break;case 12:if(d&2048){xi(t,n,o,l),t=n.stateNode;try{var g=n.memoizedProps,v=g.id,j=g.onPostCommit;typeof j=="function"&&j(v,n.alternate===null?"mount":"update",t.passiveEffectDuration,-0)}catch(R){_e(n,n.return,R)}}else xi(t,n,o,l);break;case 13:xi(t,n,o,l);break;case 23:break;case 22:g=n.stateNode,v=n.alternate,n.memoizedState!==null?g._visibility&2?xi(t,n,o,l):mo(t,n):g._visibility&2?xi(t,n,o,l):(g._visibility|=2,_a(t,n,o,l,(n.subtreeFlags&10256)!==0)),d&2048&&vd(v,n);break;case 24:xi(t,n,o,l),d&2048&&wd(n.alternate,n);break;default:xi(t,n,o,l)}}function _a(t,n,o,l,d){for(d=d&&(n.subtreeFlags&10256)!==0,n=n.child;n!==null;){var g=t,v=n,j=o,R=l,_=v.flags;switch(v.tag){case 0:case 11:case 15:_a(g,v,j,R,d),ho(8,v);break;case 23:break;case 22:var I=v.stateNode;v.memoizedState!==null?I._visibility&2?_a(g,v,j,R,d):mo(g,v):(I._visibility|=2,_a(g,v,j,R,d)),d&&_&2048&&vd(v.alternate,v);break;case 24:_a(g,v,j,R,d),d&&_&2048&&wd(v.alternate,v);break;default:_a(g,v,j,R,d)}n=n.sibling}}function mo(t,n){if(n.subtreeFlags&10256)for(n=n.child;n!==null;){var o=t,l=n,d=l.flags;switch(l.tag){case 22:mo(o,l),d&2048&&vd(l.alternate,l);break;case 24:mo(o,l),d&2048&&wd(l.alternate,l);break;default:mo(o,l)}n=n.sibling}}var go=8192;function Ha(t){if(t.subtreeFlags&go)for(t=t.child;t!==null;)Ig(t),t=t.sibling}function Ig(t){switch(t.tag){case 26:Ha(t),t.flags&go&&t.memoizedState!==null&&l4(ri,t.memoizedState,t.memoizedProps);break;case 5:Ha(t);break;case 3:case 4:var n=ri;ri=Al(t.stateNode.containerInfo),Ha(t),ri=n;break;case 22:t.memoizedState===null&&(n=t.alternate,n!==null&&n.memoizedState!==null?(n=go,go=16777216,Ha(t),go=n):Ha(t));break;default:Ha(t)}}function Yg(t){var n=t.alternate;if(n!==null&&(t=n.child,t!==null)){n.child=null;do n=t.sibling,t.sibling=null,t=n;while(t!==null)}}function yo(t){var n=t.deletions;if((t.flags&16)!==0){if(n!==null)for(var o=0;o<n.length;o++){var l=n[o];lt=l,Kg(l,t)}Yg(t)}if(t.subtreeFlags&10256)for(t=t.child;t!==null;)Gg(t),t=t.sibling}function Gg(t){switch(t.tag){case 0:case 11:case 15:yo(t),t.flags&2048&&dn(9,t,t.return);break;case 3:yo(t);break;case 12:yo(t);break;case 22:var n=t.stateNode;t.memoizedState!==null&&n._visibility&2&&(t.return===null||t.return.tag!==13)?(n._visibility&=-3,hl(t)):yo(t);break;default:yo(t)}}function hl(t){var n=t.deletions;if((t.flags&16)!==0){if(n!==null)for(var o=0;o<n.length;o++){var l=n[o];lt=l,Kg(l,t)}Yg(t)}for(t=t.child;t!==null;){switch(n=t,n.tag){case 0:case 11:case 15:dn(8,n,n.return),hl(n);break;case 22:o=n.stateNode,o._visibility&2&&(o._visibility&=-3,hl(n));break;default:hl(n)}t=t.sibling}}function Kg(t,n){for(;lt!==null;){var o=lt;switch(o.tag){case 0:case 11:case 15:dn(8,o,n);break;case 23:case 22:if(o.memoizedState!==null&&o.memoizedState.cachePool!==null){var l=o.memoizedState.cachePool.pool;l!=null&&l.refCount++}break;case 24:Jr(o.memoizedState.cache)}if(l=o.child,l!==null)l.return=o,lt=l;else e:for(o=t;lt!==null;){l=lt;var d=l.sibling,g=l.return;if(Hg(l),l===o){lt=null;break e}if(d!==null){d.return=g,lt=d;break e}lt=g}}}var j3={getCacheForType:function(t){var n=xt(nt),o=n.data.get(t);return o===void 0&&(o=t(),n.data.set(t,o)),o}},A3=typeof WeakMap=="function"?WeakMap:Map,Me=0,He=null,Se=null,je=0,Be=0,Ht=null,pn=!1,Va=!1,Sd=!1,Ui=0,Xe=0,mn=0,Zn=0,Td=0,Jt=0,Pa=0,xo=null,Rt=null,jd=!1,Ad=0,pl=1/0,ml=null,gn=null,ht=0,yn=null,Fa=null,Ua=0,Ed=0,Cd=null,Xg=null,bo=0,Od=null;function Vt(){if((Me&2)!==0&&je!==0)return je&-je;if(P.T!==null){var t=ka;return t!==0?t:$d()}return d0()}function Zg(){Jt===0&&(Jt=(je&536870912)===0||Ee?s0():536870912);var t=Qt.current;return t!==null&&(t.flags|=32),Jt}function Pt(t,n,o){(t===He&&(Be===2||Be===9)||t.cancelPendingCommit!==null)&&(qa(t,0),xn(t,je,Jt,!1)),Nr(t,o),((Me&2)===0||t!==He)&&(t===He&&((Me&2)===0&&(Zn|=o),Xe===4&&xn(t,je,Jt,!1)),bi(t))}function Qg(t,n,o){if((Me&6)!==0)throw Error(r(327));var l=!o&&(n&124)===0&&(n&t.expiredLanes)===0||$r(t,n),d=l?O3(t,n):Dd(t,n,!0),g=l;do{if(d===0){Va&&!l&&xn(t,n,0,!1);break}else{if(o=t.current.alternate,g&&!E3(o)){d=Dd(t,n,!1),g=!1;continue}if(d===2){if(g=n,t.errorRecoveryDisabledLanes&g)var v=0;else v=t.pendingLanes&-536870913,v=v!==0?v:v&536870912?536870912:0;if(v!==0){n=v;e:{var j=t;d=xo;var R=j.current.memoizedState.isDehydrated;if(R&&(qa(j,v).flags|=256),v=Dd(j,v,!1),v!==2){if(Sd&&!R){j.errorRecoveryDisabledLanes|=g,Zn|=g,d=4;break e}g=Rt,Rt=d,g!==null&&(Rt===null?Rt=g:Rt.push.apply(Rt,g))}d=v}if(g=!1,d!==2)continue}}if(d===1){qa(t,0),xn(t,n,0,!0);break}e:{switch(l=t,g=d,g){case 0:case 1:throw Error(r(345));case 4:if((n&4194048)!==n)break;case 6:xn(l,n,Jt,!pn);break e;case 2:Rt=null;break;case 3:case 5:break;default:throw Error(r(329))}if((n&62914560)===n&&(d=Ad+300-pi(),10<d)){if(xn(l,n,Jt,!pn),Es(l,0,!0)!==0)break e;l.timeoutHandle=E1(Jg.bind(null,l,o,Rt,ml,jd,n,Jt,Zn,Pa,pn,g,2,-0,0),d);break e}Jg(l,o,Rt,ml,jd,n,Jt,Zn,Pa,pn,g,0,-0,0)}}break}while(!0);bi(t)}function Jg(t,n,o,l,d,g,v,j,R,_,I,K,H,V){if(t.timeoutHandle=-1,K=n.subtreeFlags,(K&8192||(K&16785408)===16785408)&&(Eo={stylesheets:null,count:0,unsuspend:s4},Ig(n),K=c4(),K!==null)){t.cancelPendingCommit=K(r1.bind(null,t,n,g,o,l,d,v,j,R,I,1,H,V)),xn(t,g,v,!_);return}r1(t,n,g,o,l,d,v,j,R)}function E3(t){for(var n=t;;){var o=n.tag;if((o===0||o===11||o===15)&&n.flags&16384&&(o=n.updateQueue,o!==null&&(o=o.stores,o!==null)))for(var l=0;l<o.length;l++){var d=o[l],g=d.getSnapshot;d=d.value;try{if(!$t(g(),d))return!1}catch{return!1}}if(o=n.child,n.subtreeFlags&16384&&o!==null)o.return=n,n=o;else{if(n===t)break;for(;n.sibling===null;){if(n.return===null||n.return===t)return!0;n=n.return}n.sibling.return=n.return,n=n.sibling}}return!0}function xn(t,n,o,l){n&=~Td,n&=~Zn,t.suspendedLanes|=n,t.pingedLanes&=~n,l&&(t.warmLanes|=n),l=t.expirationTimes;for(var d=n;0<d;){var g=31-zt(d),v=1<<g;l[g]=-1,d&=~v}o!==0&&c0(t,o,n)}function gl(){return(Me&6)===0?(vo(0),!1):!0}function Rd(){if(Se!==null){if(Be===0)var t=Se.return;else t=Se,$i=qn=null,Yu(t),Na=null,co=0,t=Se;for(;t!==null;)Dg(t.alternate,t),t=t.return;Se=null}}function qa(t,n){var o=t.timeoutHandle;o!==-1&&(t.timeoutHandle=-1,q3(o)),o=t.cancelPendingCommit,o!==null&&(t.cancelPendingCommit=null,o()),Rd(),He=t,Se=o=Mi(t.current,null),je=n,Be=0,Ht=null,pn=!1,Va=$r(t,n),Sd=!1,Pa=Jt=Td=Zn=mn=Xe=0,Rt=xo=null,jd=!1,(n&8)!==0&&(n|=n&32);var l=t.entangledLanes;if(l!==0)for(t=t.entanglements,l&=n;0<l;){var d=31-zt(l),g=1<<d;n|=t[d],l&=~g}return Ui=n,_s(),o}function Wg(t,n){be=null,P.H=nl,n===eo||n===Gs?(n=gm(),Be=3):n===hm?(n=gm(),Be=4):Be=n===yg?8:n!==null&&typeof n=="object"&&typeof n.then=="function"?6:1,Ht=n,Se===null&&(Xe=1,ll(t,Gt(n,t.current)))}function e1(){var t=P.H;return P.H=nl,t===null?nl:t}function t1(){var t=P.A;return P.A=j3,t}function kd(){Xe=4,pn||(je&4194048)!==je&&Qt.current!==null||(Va=!0),(mn&134217727)===0&&(Zn&134217727)===0||He===null||xn(He,je,Jt,!1)}function Dd(t,n,o){var l=Me;Me|=2;var d=e1(),g=t1();(He!==t||je!==n)&&(ml=null,qa(t,n)),n=!1;var v=Xe;e:do try{if(Be!==0&&Se!==null){var j=Se,R=Ht;switch(Be){case 8:Rd(),v=6;break e;case 3:case 2:case 9:case 6:Qt.current===null&&(n=!0);var _=Be;if(Be=0,Ht=null,Ia(t,j,R,_),o&&Va){v=0;break e}break;default:_=Be,Be=0,Ht=null,Ia(t,j,R,_)}}C3(),v=Xe;break}catch(I){Wg(t,I)}while(!0);return n&&t.shellSuspendCounter++,$i=qn=null,Me=l,P.H=d,P.A=g,Se===null&&(He=null,je=0,_s()),v}function C3(){for(;Se!==null;)i1(Se)}function O3(t,n){var o=Me;Me|=2;var l=e1(),d=t1();He!==t||je!==n?(ml=null,pl=pi()+500,qa(t,n)):Va=$r(t,n);e:do try{if(Be!==0&&Se!==null){n=Se;var g=Ht;t:switch(Be){case 1:Be=0,Ht=null,Ia(t,n,g,1);break;case 2:case 9:if(pm(g)){Be=0,Ht=null,n1(n);break}n=function(){Be!==2&&Be!==9||He!==t||(Be=7),bi(t)},g.then(n,n);break e;case 3:Be=7;break e;case 4:Be=5;break e;case 7:pm(g)?(Be=0,Ht=null,n1(n)):(Be=0,Ht=null,Ia(t,n,g,7));break;case 5:var v=null;switch(Se.tag){case 26:v=Se.memoizedState;case 5:case 27:var j=Se;if(!v||_1(v)){Be=0,Ht=null;var R=j.sibling;if(R!==null)Se=R;else{var _=j.return;_!==null?(Se=_,yl(_)):Se=null}break t}}Be=0,Ht=null,Ia(t,n,g,5);break;case 6:Be=0,Ht=null,Ia(t,n,g,6);break;case 8:Rd(),Xe=6;break e;default:throw Error(r(462))}}R3();break}catch(I){Wg(t,I)}while(!0);return $i=qn=null,P.H=l,P.A=d,Me=o,Se!==null?0:(He=null,je=0,_s(),Xe)}function R3(){for(;Se!==null&&!Q2();)i1(Se)}function i1(t){var n=Rg(t.alternate,t,Ui);t.memoizedProps=t.pendingProps,n===null?yl(t):Se=n}function n1(t){var n=t,o=n.alternate;switch(n.tag){case 15:case 0:n=Tg(o,n,n.pendingProps,n.type,void 0,je);break;case 11:n=Tg(o,n,n.pendingProps,n.type.render,n.ref,je);break;case 5:Yu(n);default:Dg(o,n),n=Se=am(n,Ui),n=Rg(o,n,Ui)}t.memoizedProps=t.pendingProps,n===null?yl(t):Se=n}function Ia(t,n,o,l){$i=qn=null,Yu(n),Na=null,co=0;var d=n.return;try{if(x3(t,d,n,o,je)){Xe=1,ll(t,Gt(o,t.current)),Se=null;return}}catch(g){if(d!==null)throw Se=d,g;Xe=1,ll(t,Gt(o,t.current)),Se=null;return}n.flags&32768?(Ee||l===1?t=!0:Va||(je&536870912)!==0?t=!1:(pn=t=!0,(l===2||l===9||l===3||l===6)&&(l=Qt.current,l!==null&&l.tag===13&&(l.flags|=16384))),a1(n,t)):yl(n)}function yl(t){var n=t;do{if((n.flags&32768)!==0){a1(n,pn);return}t=n.return;var o=v3(n.alternate,n,Ui);if(o!==null){Se=o;return}if(n=n.sibling,n!==null){Se=n;return}Se=n=t}while(n!==null);Xe===0&&(Xe=5)}function a1(t,n){do{var o=w3(t.alternate,t);if(o!==null){o.flags&=32767,Se=o;return}if(o=t.return,o!==null&&(o.flags|=32768,o.subtreeFlags=0,o.deletions=null),!n&&(t=t.sibling,t!==null)){Se=t;return}Se=t=o}while(t!==null);Xe=6,Se=null}function r1(t,n,o,l,d,g,v,j,R){t.cancelPendingCommit=null;do xl();while(ht!==0);if((Me&6)!==0)throw Error(r(327));if(n!==null){if(n===t.current)throw Error(r(177));if(g=n.lanes|n.childLanes,g|=wu,sw(t,o,g,v,j,R),t===He&&(Se=He=null,je=0),Fa=n,yn=t,Ua=o,Ed=g,Cd=d,Xg=l,(n.subtreeFlags&10256)!==0||(n.flags&10256)!==0?(t.callbackNode=null,t.callbackPriority=0,B3(Ts,function(){return u1(),null})):(t.callbackNode=null,t.callbackPriority=0),l=(n.flags&13878)!==0,(n.subtreeFlags&13878)!==0||l){l=P.T,P.T=null,d=X.p,X.p=2,v=Me,Me|=4;try{S3(t,n,o)}finally{Me=v,X.p=d,P.T=l}}ht=1,o1(),s1(),l1()}}function o1(){if(ht===1){ht=0;var t=yn,n=Fa,o=(n.flags&13878)!==0;if((n.subtreeFlags&13878)!==0||o){o=P.T,P.T=null;var l=X.p;X.p=2;var d=Me;Me|=4;try{Fg(n,t);var g=Ud,v=K0(t.containerInfo),j=g.focusedElem,R=g.selectionRange;if(v!==j&&j&&j.ownerDocument&&G0(j.ownerDocument.documentElement,j)){if(R!==null&&gu(j)){var _=R.start,I=R.end;if(I===void 0&&(I=_),"selectionStart"in j)j.selectionStart=_,j.selectionEnd=Math.min(I,j.value.length);else{var K=j.ownerDocument||document,H=K&&K.defaultView||window;if(H.getSelection){var V=H.getSelection(),ue=j.textContent.length,se=Math.min(R.start,ue),Ne=R.end===void 0?se:Math.min(R.end,ue);!V.extend&&se>Ne&&(v=Ne,Ne=se,se=v);var N=Y0(j,se),$=Y0(j,Ne);if(N&&$&&(V.rangeCount!==1||V.anchorNode!==N.node||V.anchorOffset!==N.offset||V.focusNode!==$.node||V.focusOffset!==$.offset)){var L=K.createRange();L.setStart(N.node,N.offset),V.removeAllRanges(),se>Ne?(V.addRange(L),V.extend($.node,$.offset)):(L.setEnd($.node,$.offset),V.addRange(L))}}}}for(K=[],V=j;V=V.parentNode;)V.nodeType===1&&K.push({element:V,left:V.scrollLeft,top:V.scrollTop});for(typeof j.focus=="function"&&j.focus(),j=0;j<K.length;j++){var Y=K[j];Y.element.scrollLeft=Y.left,Y.element.scrollTop=Y.top}}kl=!!Fd,Ud=Fd=null}finally{Me=d,X.p=l,P.T=o}}t.current=n,ht=2}}function s1(){if(ht===2){ht=0;var t=yn,n=Fa,o=(n.flags&8772)!==0;if((n.subtreeFlags&8772)!==0||o){o=P.T,P.T=null;var l=X.p;X.p=2;var d=Me;Me|=4;try{_g(t,n.alternate,n)}finally{Me=d,X.p=l,P.T=o}}ht=3}}function l1(){if(ht===4||ht===3){ht=0,J2();var t=yn,n=Fa,o=Ua,l=Xg;(n.subtreeFlags&10256)!==0||(n.flags&10256)!==0?ht=5:(ht=0,Fa=yn=null,c1(t,t.pendingLanes));var d=t.pendingLanes;if(d===0&&(gn=null),Xc(o),n=n.stateNode,Bt&&typeof Bt.onCommitFiberRoot=="function")try{Bt.onCommitFiberRoot(zr,n,void 0,(n.current.flags&128)===128)}catch{}if(l!==null){n=P.T,d=X.p,X.p=2,P.T=null;try{for(var g=t.onRecoverableError,v=0;v<l.length;v++){var j=l[v];g(j.value,{componentStack:j.stack})}}finally{P.T=n,X.p=d}}(Ua&3)!==0&&xl(),bi(t),d=t.pendingLanes,(o&4194090)!==0&&(d&42)!==0?t===Od?bo++:(bo=0,Od=t):bo=0,vo(0)}}function c1(t,n){(t.pooledCacheLanes&=n)===0&&(n=t.pooledCache,n!=null&&(t.pooledCache=null,Jr(n)))}function xl(t){return o1(),s1(),l1(),u1()}function u1(){if(ht!==5)return!1;var t=yn,n=Ed;Ed=0;var o=Xc(Ua),l=P.T,d=X.p;try{X.p=32>o?32:o,P.T=null,o=Cd,Cd=null;var g=yn,v=Ua;if(ht=0,Fa=yn=null,Ua=0,(Me&6)!==0)throw Error(r(331));var j=Me;if(Me|=4,Gg(g.current),qg(g,g.current,v,o),Me=j,vo(0,!1),Bt&&typeof Bt.onPostCommitFiberRoot=="function")try{Bt.onPostCommitFiberRoot(zr,g)}catch{}return!0}finally{X.p=d,P.T=l,c1(t,n)}}function d1(t,n,o){n=Gt(o,n),n=od(t.stateNode,n,2),t=sn(t,n,2),t!==null&&(Nr(t,2),bi(t))}function _e(t,n,o){if(t.tag===3)d1(t,t,o);else for(;n!==null;){if(n.tag===3){d1(n,t,o);break}else if(n.tag===1){var l=n.stateNode;if(typeof n.type.getDerivedStateFromError=="function"||typeof l.componentDidCatch=="function"&&(gn===null||!gn.has(l))){t=Gt(o,t),o=mg(2),l=sn(n,o,2),l!==null&&(gg(o,l,n,t),Nr(l,2),bi(l));break}}n=n.return}}function Md(t,n,o){var l=t.pingCache;if(l===null){l=t.pingCache=new A3;var d=new Set;l.set(n,d)}else d=l.get(n),d===void 0&&(d=new Set,l.set(n,d));d.has(o)||(Sd=!0,d.add(o),t=k3.bind(null,t,n,o),n.then(t,t))}function k3(t,n,o){var l=t.pingCache;l!==null&&l.delete(n),t.pingedLanes|=t.suspendedLanes&o,t.warmLanes&=~o,He===t&&(je&o)===o&&(Xe===4||Xe===3&&(je&62914560)===je&&300>pi()-Ad?(Me&2)===0&&qa(t,0):Td|=o,Pa===je&&(Pa=0)),bi(t)}function f1(t,n){n===0&&(n=l0()),t=Ea(t,n),t!==null&&(Nr(t,n),bi(t))}function D3(t){var n=t.memoizedState,o=0;n!==null&&(o=n.retryLane),f1(t,o)}function M3(t,n){var o=0;switch(t.tag){case 13:var l=t.stateNode,d=t.memoizedState;d!==null&&(o=d.retryLane);break;case 19:l=t.stateNode;break;case 22:l=t.stateNode._retryCache;break;default:throw Error(r(314))}l!==null&&l.delete(n),f1(t,o)}function B3(t,n){return Ic(t,n)}var bl=null,Ya=null,Bd=!1,vl=!1,zd=!1,Qn=0;function bi(t){t!==Ya&&t.next===null&&(Ya===null?bl=Ya=t:Ya=Ya.next=t),vl=!0,Bd||(Bd=!0,$3())}function vo(t,n){if(!zd&&vl){zd=!0;do for(var o=!1,l=bl;l!==null;){if(t!==0){var d=l.pendingLanes;if(d===0)var g=0;else{var v=l.suspendedLanes,j=l.pingedLanes;g=(1<<31-zt(42|t)+1)-1,g&=d&~(v&~j),g=g&201326741?g&201326741|1:g?g|2:0}g!==0&&(o=!0,g1(l,g))}else g=je,g=Es(l,l===He?g:0,l.cancelPendingCommit!==null||l.timeoutHandle!==-1),(g&3)===0||$r(l,g)||(o=!0,g1(l,g));l=l.next}while(o);zd=!1}}function z3(){h1()}function h1(){vl=Bd=!1;var t=0;Qn!==0&&(U3()&&(t=Qn),Qn=0);for(var n=pi(),o=null,l=bl;l!==null;){var d=l.next,g=p1(l,n);g===0?(l.next=null,o===null?bl=d:o.next=d,d===null&&(Ya=o)):(o=l,(t!==0||(g&3)!==0)&&(vl=!0)),l=d}vo(t)}function p1(t,n){for(var o=t.suspendedLanes,l=t.pingedLanes,d=t.expirationTimes,g=t.pendingLanes&-62914561;0<g;){var v=31-zt(g),j=1<<v,R=d[v];R===-1?((j&o)===0||(j&l)!==0)&&(d[v]=ow(j,n)):R<=n&&(t.expiredLanes|=j),g&=~j}if(n=He,o=je,o=Es(t,t===n?o:0,t.cancelPendingCommit!==null||t.timeoutHandle!==-1),l=t.callbackNode,o===0||t===n&&(Be===2||Be===9)||t.cancelPendingCommit!==null)return l!==null&&l!==null&&Yc(l),t.callbackNode=null,t.callbackPriority=0;if((o&3)===0||$r(t,o)){if(n=o&-o,n===t.callbackPriority)return n;switch(l!==null&&Yc(l),Xc(o)){case 2:case 8:o=r0;break;case 32:o=Ts;break;case 268435456:o=o0;break;default:o=Ts}return l=m1.bind(null,t),o=Ic(o,l),t.callbackPriority=n,t.callbackNode=o,n}return l!==null&&l!==null&&Yc(l),t.callbackPriority=2,t.callbackNode=null,2}function m1(t,n){if(ht!==0&&ht!==5)return t.callbackNode=null,t.callbackPriority=0,null;var o=t.callbackNode;if(xl()&&t.callbackNode!==o)return null;var l=je;return l=Es(t,t===He?l:0,t.cancelPendingCommit!==null||t.timeoutHandle!==-1),l===0?null:(Qg(t,l,n),p1(t,pi()),t.callbackNode!=null&&t.callbackNode===o?m1.bind(null,t):null)}function g1(t,n){if(xl())return null;Qg(t,n,!0)}function $3(){I3(function(){(Me&6)!==0?Ic(a0,z3):h1()})}function $d(){return Qn===0&&(Qn=s0()),Qn}function y1(t){return t==null||typeof t=="symbol"||typeof t=="boolean"?null:typeof t=="function"?t:Ds(""+t)}function x1(t,n){var o=n.ownerDocument.createElement("input");return o.name=n.name,o.value=n.value,t.id&&o.setAttribute("form",t.id),n.parentNode.insertBefore(o,n),t=new FormData(t),o.parentNode.removeChild(o),t}function N3(t,n,o,l,d){if(n==="submit"&&o&&o.stateNode===d){var g=y1((d[At]||null).action),v=l.submitter;v&&(n=(n=v[At]||null)?y1(n.formAction):v.getAttribute("formAction"),n!==null&&(g=n,v=null));var j=new $s("action","action",null,l,d);t.push({event:j,listeners:[{instance:null,listener:function(){if(l.defaultPrevented){if(Qn!==0){var R=v?x1(d,v):new FormData(d);td(o,{pending:!0,data:R,method:d.method,action:g},null,R)}}else typeof g=="function"&&(j.preventDefault(),R=v?x1(d,v):new FormData(d),td(o,{pending:!0,data:R,method:d.method,action:g},g,R))},currentTarget:d}]})}}for(var Nd=0;Nd<vu.length;Nd++){var Ld=vu[Nd],L3=Ld.toLowerCase(),_3=Ld[0].toUpperCase()+Ld.slice(1);ai(L3,"on"+_3)}ai(Q0,"onAnimationEnd"),ai(J0,"onAnimationIteration"),ai(W0,"onAnimationStart"),ai("dblclick","onDoubleClick"),ai("focusin","onFocus"),ai("focusout","onBlur"),ai(t3,"onTransitionRun"),ai(i3,"onTransitionStart"),ai(n3,"onTransitionCancel"),ai(em,"onTransitionEnd"),ga("onMouseEnter",["mouseout","mouseover"]),ga("onMouseLeave",["mouseout","mouseover"]),ga("onPointerEnter",["pointerout","pointerover"]),ga("onPointerLeave",["pointerout","pointerover"]),$n("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),$n("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),$n("onBeforeInput",["compositionend","keypress","textInput","paste"]),$n("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),$n("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),$n("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var wo="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),H3=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(wo));function b1(t,n){n=(n&4)!==0;for(var o=0;o<t.length;o++){var l=t[o],d=l.event;l=l.listeners;e:{var g=void 0;if(n)for(var v=l.length-1;0<=v;v--){var j=l[v],R=j.instance,_=j.currentTarget;if(j=j.listener,R!==g&&d.isPropagationStopped())break e;g=j,d.currentTarget=_;try{g(d)}catch(I){sl(I)}d.currentTarget=null,g=R}else for(v=0;v<l.length;v++){if(j=l[v],R=j.instance,_=j.currentTarget,j=j.listener,R!==g&&d.isPropagationStopped())break e;g=j,d.currentTarget=_;try{g(d)}catch(I){sl(I)}d.currentTarget=null,g=R}}}}function Te(t,n){var o=n[Zc];o===void 0&&(o=n[Zc]=new Set);var l=t+"__bubble";o.has(l)||(v1(n,t,2,!1),o.add(l))}function _d(t,n,o){var l=0;n&&(l|=4),v1(o,t,l,n)}var wl="_reactListening"+Math.random().toString(36).slice(2);function Hd(t){if(!t[wl]){t[wl]=!0,h0.forEach(function(o){o!=="selectionchange"&&(H3.has(o)||_d(o,!1,t),_d(o,!0,t))});var n=t.nodeType===9?t:t.ownerDocument;n===null||n[wl]||(n[wl]=!0,_d("selectionchange",!1,n))}}function v1(t,n,o,l){switch(q1(n)){case 2:var d=f4;break;case 8:d=h4;break;default:d=Wd}o=d.bind(null,n,o,t),d=void 0,!su||n!=="touchstart"&&n!=="touchmove"&&n!=="wheel"||(d=!0),l?d!==void 0?t.addEventListener(n,o,{capture:!0,passive:d}):t.addEventListener(n,o,!0):d!==void 0?t.addEventListener(n,o,{passive:d}):t.addEventListener(n,o,!1)}function Vd(t,n,o,l,d){var g=l;if((n&1)===0&&(n&2)===0&&l!==null)e:for(;;){if(l===null)return;var v=l.tag;if(v===3||v===4){var j=l.stateNode.containerInfo;if(j===d)break;if(v===4)for(v=l.return;v!==null;){var R=v.tag;if((R===3||R===4)&&v.stateNode.containerInfo===d)return;v=v.return}for(;j!==null;){if(v=ha(j),v===null)return;if(R=v.tag,R===5||R===6||R===26||R===27){l=g=v;continue e}j=j.parentNode}}l=l.return}C0(function(){var _=g,I=ru(o),K=[];e:{var H=tm.get(t);if(H!==void 0){var V=$s,ue=t;switch(t){case"keypress":if(Bs(o)===0)break e;case"keydown":case"keyup":V=Bw;break;case"focusin":ue="focus",V=du;break;case"focusout":ue="blur",V=du;break;case"beforeblur":case"afterblur":V=du;break;case"click":if(o.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":V=k0;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":V=ww;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":V=Nw;break;case Q0:case J0:case W0:V=jw;break;case em:V=_w;break;case"scroll":case"scrollend":V=bw;break;case"wheel":V=Vw;break;case"copy":case"cut":case"paste":V=Ew;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":V=M0;break;case"toggle":case"beforetoggle":V=Fw}var se=(n&4)!==0,Ne=!se&&(t==="scroll"||t==="scrollend"),N=se?H!==null?H+"Capture":null:H;se=[];for(var $=_,L;$!==null;){var Y=$;if(L=Y.stateNode,Y=Y.tag,Y!==5&&Y!==26&&Y!==27||L===null||N===null||(Y=Hr($,N),Y!=null&&se.push(So($,Y,L))),Ne)break;$=$.return}0<se.length&&(H=new V(H,ue,null,o,I),K.push({event:H,listeners:se}))}}if((n&7)===0){e:{if(H=t==="mouseover"||t==="pointerover",V=t==="mouseout"||t==="pointerout",H&&o!==au&&(ue=o.relatedTarget||o.fromElement)&&(ha(ue)||ue[fa]))break e;if((V||H)&&(H=I.window===I?I:(H=I.ownerDocument)?H.defaultView||H.parentWindow:window,V?(ue=o.relatedTarget||o.toElement,V=_,ue=ue?ha(ue):null,ue!==null&&(Ne=c(ue),se=ue.tag,ue!==Ne||se!==5&&se!==27&&se!==6)&&(ue=null)):(V=null,ue=_),V!==ue)){if(se=k0,Y="onMouseLeave",N="onMouseEnter",$="mouse",(t==="pointerout"||t==="pointerover")&&(se=M0,Y="onPointerLeave",N="onPointerEnter",$="pointer"),Ne=V==null?H:_r(V),L=ue==null?H:_r(ue),H=new se(Y,$+"leave",V,o,I),H.target=Ne,H.relatedTarget=L,Y=null,ha(I)===_&&(se=new se(N,$+"enter",ue,o,I),se.target=L,se.relatedTarget=Ne,Y=se),Ne=Y,V&&ue)t:{for(se=V,N=ue,$=0,L=se;L;L=Ga(L))$++;for(L=0,Y=N;Y;Y=Ga(Y))L++;for(;0<$-L;)se=Ga(se),$--;for(;0<L-$;)N=Ga(N),L--;for(;$--;){if(se===N||N!==null&&se===N.alternate)break t;se=Ga(se),N=Ga(N)}se=null}else se=null;V!==null&&w1(K,H,V,se,!1),ue!==null&&Ne!==null&&w1(K,Ne,ue,se,!0)}}e:{if(H=_?_r(_):window,V=H.nodeName&&H.nodeName.toLowerCase(),V==="select"||V==="input"&&H.type==="file")var te=V0;else if(_0(H))if(P0)te=Jw;else{te=Zw;var ve=Xw}else V=H.nodeName,!V||V.toLowerCase()!=="input"||H.type!=="checkbox"&&H.type!=="radio"?_&&nu(_.elementType)&&(te=V0):te=Qw;if(te&&(te=te(t,_))){H0(K,te,o,I);break e}ve&&ve(t,H,_),t==="focusout"&&_&&H.type==="number"&&_.memoizedProps.value!=null&&iu(H,"number",H.value)}switch(ve=_?_r(_):window,t){case"focusin":(_0(ve)||ve.contentEditable==="true")&&(Ta=ve,yu=_,Gr=null);break;case"focusout":Gr=yu=Ta=null;break;case"mousedown":xu=!0;break;case"contextmenu":case"mouseup":case"dragend":xu=!1,X0(K,o,I);break;case"selectionchange":if(e3)break;case"keydown":case"keyup":X0(K,o,I)}var re;if(hu)e:{switch(t){case"compositionstart":var ce="onCompositionStart";break e;case"compositionend":ce="onCompositionEnd";break e;case"compositionupdate":ce="onCompositionUpdate";break e}ce=void 0}else Sa?N0(t,o)&&(ce="onCompositionEnd"):t==="keydown"&&o.keyCode===229&&(ce="onCompositionStart");ce&&(B0&&o.locale!=="ko"&&(Sa||ce!=="onCompositionStart"?ce==="onCompositionEnd"&&Sa&&(re=O0()):(nn=I,lu="value"in nn?nn.value:nn.textContent,Sa=!0)),ve=Sl(_,ce),0<ve.length&&(ce=new D0(ce,t,null,o,I),K.push({event:ce,listeners:ve}),re?ce.data=re:(re=L0(o),re!==null&&(ce.data=re)))),(re=qw?Iw(t,o):Yw(t,o))&&(ce=Sl(_,"onBeforeInput"),0<ce.length&&(ve=new D0("onBeforeInput","beforeinput",null,o,I),K.push({event:ve,listeners:ce}),ve.data=re)),N3(K,t,_,o,I)}b1(K,n)})}function So(t,n,o){return{instance:t,listener:n,currentTarget:o}}function Sl(t,n){for(var o=n+"Capture",l=[];t!==null;){var d=t,g=d.stateNode;if(d=d.tag,d!==5&&d!==26&&d!==27||g===null||(d=Hr(t,o),d!=null&&l.unshift(So(t,d,g)),d=Hr(t,n),d!=null&&l.push(So(t,d,g))),t.tag===3)return l;t=t.return}return[]}function Ga(t){if(t===null)return null;do t=t.return;while(t&&t.tag!==5&&t.tag!==27);return t||null}function w1(t,n,o,l,d){for(var g=n._reactName,v=[];o!==null&&o!==l;){var j=o,R=j.alternate,_=j.stateNode;if(j=j.tag,R!==null&&R===l)break;j!==5&&j!==26&&j!==27||_===null||(R=_,d?(_=Hr(o,g),_!=null&&v.unshift(So(o,_,R))):d||(_=Hr(o,g),_!=null&&v.push(So(o,_,R)))),o=o.return}v.length!==0&&t.push({event:n,listeners:v})}var V3=/\r\n?/g,P3=/\u0000|\uFFFD/g;function S1(t){return(typeof t=="string"?t:""+t).replace(V3,`
`).replace(P3,"")}function T1(t,n){return n=S1(n),S1(t)===n}function Tl(){}function $e(t,n,o,l,d,g){switch(o){case"children":typeof l=="string"?n==="body"||n==="textarea"&&l===""||ba(t,l):(typeof l=="number"||typeof l=="bigint")&&n!=="body"&&ba(t,""+l);break;case"className":Os(t,"class",l);break;case"tabIndex":Os(t,"tabindex",l);break;case"dir":case"role":case"viewBox":case"width":case"height":Os(t,o,l);break;case"style":A0(t,l,g);break;case"data":if(n!=="object"){Os(t,"data",l);break}case"src":case"href":if(l===""&&(n!=="a"||o!=="href")){t.removeAttribute(o);break}if(l==null||typeof l=="function"||typeof l=="symbol"||typeof l=="boolean"){t.removeAttribute(o);break}l=Ds(""+l),t.setAttribute(o,l);break;case"action":case"formAction":if(typeof l=="function"){t.setAttribute(o,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof g=="function"&&(o==="formAction"?(n!=="input"&&$e(t,n,"name",d.name,d,null),$e(t,n,"formEncType",d.formEncType,d,null),$e(t,n,"formMethod",d.formMethod,d,null),$e(t,n,"formTarget",d.formTarget,d,null)):($e(t,n,"encType",d.encType,d,null),$e(t,n,"method",d.method,d,null),$e(t,n,"target",d.target,d,null)));if(l==null||typeof l=="symbol"||typeof l=="boolean"){t.removeAttribute(o);break}l=Ds(""+l),t.setAttribute(o,l);break;case"onClick":l!=null&&(t.onclick=Tl);break;case"onScroll":l!=null&&Te("scroll",t);break;case"onScrollEnd":l!=null&&Te("scrollend",t);break;case"dangerouslySetInnerHTML":if(l!=null){if(typeof l!="object"||!("__html"in l))throw Error(r(61));if(o=l.__html,o!=null){if(d.children!=null)throw Error(r(60));t.innerHTML=o}}break;case"multiple":t.multiple=l&&typeof l!="function"&&typeof l!="symbol";break;case"muted":t.muted=l&&typeof l!="function"&&typeof l!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(l==null||typeof l=="function"||typeof l=="boolean"||typeof l=="symbol"){t.removeAttribute("xlink:href");break}o=Ds(""+l),t.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",o);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":l!=null&&typeof l!="function"&&typeof l!="symbol"?t.setAttribute(o,""+l):t.removeAttribute(o);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":l&&typeof l!="function"&&typeof l!="symbol"?t.setAttribute(o,""):t.removeAttribute(o);break;case"capture":case"download":l===!0?t.setAttribute(o,""):l!==!1&&l!=null&&typeof l!="function"&&typeof l!="symbol"?t.setAttribute(o,l):t.removeAttribute(o);break;case"cols":case"rows":case"size":case"span":l!=null&&typeof l!="function"&&typeof l!="symbol"&&!isNaN(l)&&1<=l?t.setAttribute(o,l):t.removeAttribute(o);break;case"rowSpan":case"start":l==null||typeof l=="function"||typeof l=="symbol"||isNaN(l)?t.removeAttribute(o):t.setAttribute(o,l);break;case"popover":Te("beforetoggle",t),Te("toggle",t),Cs(t,"popover",l);break;case"xlinkActuate":ki(t,"http://www.w3.org/1999/xlink","xlink:actuate",l);break;case"xlinkArcrole":ki(t,"http://www.w3.org/1999/xlink","xlink:arcrole",l);break;case"xlinkRole":ki(t,"http://www.w3.org/1999/xlink","xlink:role",l);break;case"xlinkShow":ki(t,"http://www.w3.org/1999/xlink","xlink:show",l);break;case"xlinkTitle":ki(t,"http://www.w3.org/1999/xlink","xlink:title",l);break;case"xlinkType":ki(t,"http://www.w3.org/1999/xlink","xlink:type",l);break;case"xmlBase":ki(t,"http://www.w3.org/XML/1998/namespace","xml:base",l);break;case"xmlLang":ki(t,"http://www.w3.org/XML/1998/namespace","xml:lang",l);break;case"xmlSpace":ki(t,"http://www.w3.org/XML/1998/namespace","xml:space",l);break;case"is":Cs(t,"is",l);break;case"innerText":case"textContent":break;default:(!(2<o.length)||o[0]!=="o"&&o[0]!=="O"||o[1]!=="n"&&o[1]!=="N")&&(o=yw.get(o)||o,Cs(t,o,l))}}function Pd(t,n,o,l,d,g){switch(o){case"style":A0(t,l,g);break;case"dangerouslySetInnerHTML":if(l!=null){if(typeof l!="object"||!("__html"in l))throw Error(r(61));if(o=l.__html,o!=null){if(d.children!=null)throw Error(r(60));t.innerHTML=o}}break;case"children":typeof l=="string"?ba(t,l):(typeof l=="number"||typeof l=="bigint")&&ba(t,""+l);break;case"onScroll":l!=null&&Te("scroll",t);break;case"onScrollEnd":l!=null&&Te("scrollend",t);break;case"onClick":l!=null&&(t.onclick=Tl);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":break;case"innerText":case"textContent":break;default:if(!p0.hasOwnProperty(o))e:{if(o[0]==="o"&&o[1]==="n"&&(d=o.endsWith("Capture"),n=o.slice(2,d?o.length-7:void 0),g=t[At]||null,g=g!=null?g[o]:null,typeof g=="function"&&t.removeEventListener(n,g,d),typeof l=="function")){typeof g!="function"&&g!==null&&(o in t?t[o]=null:t.hasAttribute(o)&&t.removeAttribute(o)),t.addEventListener(n,l,d);break e}o in t?t[o]=l:l===!0?t.setAttribute(o,""):Cs(t,o,l)}}}function pt(t,n,o){switch(n){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":Te("error",t),Te("load",t);var l=!1,d=!1,g;for(g in o)if(o.hasOwnProperty(g)){var v=o[g];if(v!=null)switch(g){case"src":l=!0;break;case"srcSet":d=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(r(137,n));default:$e(t,n,g,v,o,null)}}d&&$e(t,n,"srcSet",o.srcSet,o,null),l&&$e(t,n,"src",o.src,o,null);return;case"input":Te("invalid",t);var j=g=v=d=null,R=null,_=null;for(l in o)if(o.hasOwnProperty(l)){var I=o[l];if(I!=null)switch(l){case"name":d=I;break;case"type":v=I;break;case"checked":R=I;break;case"defaultChecked":_=I;break;case"value":g=I;break;case"defaultValue":j=I;break;case"children":case"dangerouslySetInnerHTML":if(I!=null)throw Error(r(137,n));break;default:$e(t,n,l,I,o,null)}}w0(t,g,j,R,_,v,d,!1),Rs(t);return;case"select":Te("invalid",t),l=v=g=null;for(d in o)if(o.hasOwnProperty(d)&&(j=o[d],j!=null))switch(d){case"value":g=j;break;case"defaultValue":v=j;break;case"multiple":l=j;default:$e(t,n,d,j,o,null)}n=g,o=v,t.multiple=!!l,n!=null?xa(t,!!l,n,!1):o!=null&&xa(t,!!l,o,!0);return;case"textarea":Te("invalid",t),g=d=l=null;for(v in o)if(o.hasOwnProperty(v)&&(j=o[v],j!=null))switch(v){case"value":l=j;break;case"defaultValue":d=j;break;case"children":g=j;break;case"dangerouslySetInnerHTML":if(j!=null)throw Error(r(91));break;default:$e(t,n,v,j,o,null)}T0(t,l,d,g),Rs(t);return;case"option":for(R in o)if(o.hasOwnProperty(R)&&(l=o[R],l!=null))switch(R){case"selected":t.selected=l&&typeof l!="function"&&typeof l!="symbol";break;default:$e(t,n,R,l,o,null)}return;case"dialog":Te("beforetoggle",t),Te("toggle",t),Te("cancel",t),Te("close",t);break;case"iframe":case"object":Te("load",t);break;case"video":case"audio":for(l=0;l<wo.length;l++)Te(wo[l],t);break;case"image":Te("error",t),Te("load",t);break;case"details":Te("toggle",t);break;case"embed":case"source":case"link":Te("error",t),Te("load",t);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(_ in o)if(o.hasOwnProperty(_)&&(l=o[_],l!=null))switch(_){case"children":case"dangerouslySetInnerHTML":throw Error(r(137,n));default:$e(t,n,_,l,o,null)}return;default:if(nu(n)){for(I in o)o.hasOwnProperty(I)&&(l=o[I],l!==void 0&&Pd(t,n,I,l,o,void 0));return}}for(j in o)o.hasOwnProperty(j)&&(l=o[j],l!=null&&$e(t,n,j,l,o,null))}function F3(t,n,o,l){switch(n){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var d=null,g=null,v=null,j=null,R=null,_=null,I=null;for(V in o){var K=o[V];if(o.hasOwnProperty(V)&&K!=null)switch(V){case"checked":break;case"value":break;case"defaultValue":R=K;default:l.hasOwnProperty(V)||$e(t,n,V,null,l,K)}}for(var H in l){var V=l[H];if(K=o[H],l.hasOwnProperty(H)&&(V!=null||K!=null))switch(H){case"type":g=V;break;case"name":d=V;break;case"checked":_=V;break;case"defaultChecked":I=V;break;case"value":v=V;break;case"defaultValue":j=V;break;case"children":case"dangerouslySetInnerHTML":if(V!=null)throw Error(r(137,n));break;default:V!==K&&$e(t,n,H,V,l,K)}}tu(t,v,j,R,_,I,g,d);return;case"select":V=v=j=H=null;for(g in o)if(R=o[g],o.hasOwnProperty(g)&&R!=null)switch(g){case"value":break;case"multiple":V=R;default:l.hasOwnProperty(g)||$e(t,n,g,null,l,R)}for(d in l)if(g=l[d],R=o[d],l.hasOwnProperty(d)&&(g!=null||R!=null))switch(d){case"value":H=g;break;case"defaultValue":j=g;break;case"multiple":v=g;default:g!==R&&$e(t,n,d,g,l,R)}n=j,o=v,l=V,H!=null?xa(t,!!o,H,!1):!!l!=!!o&&(n!=null?xa(t,!!o,n,!0):xa(t,!!o,o?[]:"",!1));return;case"textarea":V=H=null;for(j in o)if(d=o[j],o.hasOwnProperty(j)&&d!=null&&!l.hasOwnProperty(j))switch(j){case"value":break;case"children":break;default:$e(t,n,j,null,l,d)}for(v in l)if(d=l[v],g=o[v],l.hasOwnProperty(v)&&(d!=null||g!=null))switch(v){case"value":H=d;break;case"defaultValue":V=d;break;case"children":break;case"dangerouslySetInnerHTML":if(d!=null)throw Error(r(91));break;default:d!==g&&$e(t,n,v,d,l,g)}S0(t,H,V);return;case"option":for(var ue in o)if(H=o[ue],o.hasOwnProperty(ue)&&H!=null&&!l.hasOwnProperty(ue))switch(ue){case"selected":t.selected=!1;break;default:$e(t,n,ue,null,l,H)}for(R in l)if(H=l[R],V=o[R],l.hasOwnProperty(R)&&H!==V&&(H!=null||V!=null))switch(R){case"selected":t.selected=H&&typeof H!="function"&&typeof H!="symbol";break;default:$e(t,n,R,H,l,V)}return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var se in o)H=o[se],o.hasOwnProperty(se)&&H!=null&&!l.hasOwnProperty(se)&&$e(t,n,se,null,l,H);for(_ in l)if(H=l[_],V=o[_],l.hasOwnProperty(_)&&H!==V&&(H!=null||V!=null))switch(_){case"children":case"dangerouslySetInnerHTML":if(H!=null)throw Error(r(137,n));break;default:$e(t,n,_,H,l,V)}return;default:if(nu(n)){for(var Ne in o)H=o[Ne],o.hasOwnProperty(Ne)&&H!==void 0&&!l.hasOwnProperty(Ne)&&Pd(t,n,Ne,void 0,l,H);for(I in l)H=l[I],V=o[I],!l.hasOwnProperty(I)||H===V||H===void 0&&V===void 0||Pd(t,n,I,H,l,V);return}}for(var N in o)H=o[N],o.hasOwnProperty(N)&&H!=null&&!l.hasOwnProperty(N)&&$e(t,n,N,null,l,H);for(K in l)H=l[K],V=o[K],!l.hasOwnProperty(K)||H===V||H==null&&V==null||$e(t,n,K,H,l,V)}var Fd=null,Ud=null;function jl(t){return t.nodeType===9?t:t.ownerDocument}function j1(t){switch(t){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function A1(t,n){if(t===0)switch(n){case"svg":return 1;case"math":return 2;default:return 0}return t===1&&n==="foreignObject"?0:t}function qd(t,n){return t==="textarea"||t==="noscript"||typeof n.children=="string"||typeof n.children=="number"||typeof n.children=="bigint"||typeof n.dangerouslySetInnerHTML=="object"&&n.dangerouslySetInnerHTML!==null&&n.dangerouslySetInnerHTML.__html!=null}var Id=null;function U3(){var t=window.event;return t&&t.type==="popstate"?t===Id?!1:(Id=t,!0):(Id=null,!1)}var E1=typeof setTimeout=="function"?setTimeout:void 0,q3=typeof clearTimeout=="function"?clearTimeout:void 0,C1=typeof Promise=="function"?Promise:void 0,I3=typeof queueMicrotask=="function"?queueMicrotask:typeof C1<"u"?function(t){return C1.resolve(null).then(t).catch(Y3)}:E1;function Y3(t){setTimeout(function(){throw t})}function bn(t){return t==="head"}function O1(t,n){var o=n,l=0,d=0;do{var g=o.nextSibling;if(t.removeChild(o),g&&g.nodeType===8)if(o=g.data,o==="/$"){if(0<l&&8>l){o=l;var v=t.ownerDocument;if(o&1&&To(v.documentElement),o&2&&To(v.body),o&4)for(o=v.head,To(o),v=o.firstChild;v;){var j=v.nextSibling,R=v.nodeName;v[Lr]||R==="SCRIPT"||R==="STYLE"||R==="LINK"&&v.rel.toLowerCase()==="stylesheet"||o.removeChild(v),v=j}}if(d===0){t.removeChild(g),Do(n);return}d--}else o==="$"||o==="$?"||o==="$!"?d++:l=o.charCodeAt(0)-48;else l=0;o=g}while(o);Do(n)}function Yd(t){var n=t.firstChild;for(n&&n.nodeType===10&&(n=n.nextSibling);n;){var o=n;switch(n=n.nextSibling,o.nodeName){case"HTML":case"HEAD":case"BODY":Yd(o),Qc(o);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(o.rel.toLowerCase()==="stylesheet")continue}t.removeChild(o)}}function G3(t,n,o,l){for(;t.nodeType===1;){var d=o;if(t.nodeName.toLowerCase()!==n.toLowerCase()){if(!l&&(t.nodeName!=="INPUT"||t.type!=="hidden"))break}else if(l){if(!t[Lr])switch(n){case"meta":if(!t.hasAttribute("itemprop"))break;return t;case"link":if(g=t.getAttribute("rel"),g==="stylesheet"&&t.hasAttribute("data-precedence"))break;if(g!==d.rel||t.getAttribute("href")!==(d.href==null||d.href===""?null:d.href)||t.getAttribute("crossorigin")!==(d.crossOrigin==null?null:d.crossOrigin)||t.getAttribute("title")!==(d.title==null?null:d.title))break;return t;case"style":if(t.hasAttribute("data-precedence"))break;return t;case"script":if(g=t.getAttribute("src"),(g!==(d.src==null?null:d.src)||t.getAttribute("type")!==(d.type==null?null:d.type)||t.getAttribute("crossorigin")!==(d.crossOrigin==null?null:d.crossOrigin))&&g&&t.hasAttribute("async")&&!t.hasAttribute("itemprop"))break;return t;default:return t}}else if(n==="input"&&t.type==="hidden"){var g=d.name==null?null:""+d.name;if(d.type==="hidden"&&t.getAttribute("name")===g)return t}else return t;if(t=oi(t.nextSibling),t===null)break}return null}function K3(t,n,o){if(n==="")return null;for(;t.nodeType!==3;)if((t.nodeType!==1||t.nodeName!=="INPUT"||t.type!=="hidden")&&!o||(t=oi(t.nextSibling),t===null))return null;return t}function Gd(t){return t.data==="$!"||t.data==="$?"&&t.ownerDocument.readyState==="complete"}function X3(t,n){var o=t.ownerDocument;if(t.data!=="$?"||o.readyState==="complete")n();else{var l=function(){n(),o.removeEventListener("DOMContentLoaded",l)};o.addEventListener("DOMContentLoaded",l),t._reactRetry=l}}function oi(t){for(;t!=null;t=t.nextSibling){var n=t.nodeType;if(n===1||n===3)break;if(n===8){if(n=t.data,n==="$"||n==="$!"||n==="$?"||n==="F!"||n==="F")break;if(n==="/$")return null}}return t}var Kd=null;function R1(t){t=t.previousSibling;for(var n=0;t;){if(t.nodeType===8){var o=t.data;if(o==="$"||o==="$!"||o==="$?"){if(n===0)return t;n--}else o==="/$"&&n++}t=t.previousSibling}return null}function k1(t,n,o){switch(n=jl(o),t){case"html":if(t=n.documentElement,!t)throw Error(r(452));return t;case"head":if(t=n.head,!t)throw Error(r(453));return t;case"body":if(t=n.body,!t)throw Error(r(454));return t;default:throw Error(r(451))}}function To(t){for(var n=t.attributes;n.length;)t.removeAttributeNode(n[0]);Qc(t)}var Wt=new Map,D1=new Set;function Al(t){return typeof t.getRootNode=="function"?t.getRootNode():t.nodeType===9?t:t.ownerDocument}var qi=X.d;X.d={f:Z3,r:Q3,D:J3,C:W3,L:e4,m:t4,X:n4,S:i4,M:a4};function Z3(){var t=qi.f(),n=gl();return t||n}function Q3(t){var n=pa(t);n!==null&&n.tag===5&&n.type==="form"?Qm(n):qi.r(t)}var Ka=typeof document>"u"?null:document;function M1(t,n,o){var l=Ka;if(l&&typeof n=="string"&&n){var d=Yt(n);d='link[rel="'+t+'"][href="'+d+'"]',typeof o=="string"&&(d+='[crossorigin="'+o+'"]'),D1.has(d)||(D1.add(d),t={rel:t,crossOrigin:o,href:n},l.querySelector(d)===null&&(n=l.createElement("link"),pt(n,"link",t),ot(n),l.head.appendChild(n)))}}function J3(t){qi.D(t),M1("dns-prefetch",t,null)}function W3(t,n){qi.C(t,n),M1("preconnect",t,n)}function e4(t,n,o){qi.L(t,n,o);var l=Ka;if(l&&t&&n){var d='link[rel="preload"][as="'+Yt(n)+'"]';n==="image"&&o&&o.imageSrcSet?(d+='[imagesrcset="'+Yt(o.imageSrcSet)+'"]',typeof o.imageSizes=="string"&&(d+='[imagesizes="'+Yt(o.imageSizes)+'"]')):d+='[href="'+Yt(t)+'"]';var g=d;switch(n){case"style":g=Xa(t);break;case"script":g=Za(t)}Wt.has(g)||(t=y({rel:"preload",href:n==="image"&&o&&o.imageSrcSet?void 0:t,as:n},o),Wt.set(g,t),l.querySelector(d)!==null||n==="style"&&l.querySelector(jo(g))||n==="script"&&l.querySelector(Ao(g))||(n=l.createElement("link"),pt(n,"link",t),ot(n),l.head.appendChild(n)))}}function t4(t,n){qi.m(t,n);var o=Ka;if(o&&t){var l=n&&typeof n.as=="string"?n.as:"script",d='link[rel="modulepreload"][as="'+Yt(l)+'"][href="'+Yt(t)+'"]',g=d;switch(l){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":g=Za(t)}if(!Wt.has(g)&&(t=y({rel:"modulepreload",href:t},n),Wt.set(g,t),o.querySelector(d)===null)){switch(l){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(o.querySelector(Ao(g)))return}l=o.createElement("link"),pt(l,"link",t),ot(l),o.head.appendChild(l)}}}function i4(t,n,o){qi.S(t,n,o);var l=Ka;if(l&&t){var d=ma(l).hoistableStyles,g=Xa(t);n=n||"default";var v=d.get(g);if(!v){var j={loading:0,preload:null};if(v=l.querySelector(jo(g)))j.loading=5;else{t=y({rel:"stylesheet",href:t,"data-precedence":n},o),(o=Wt.get(g))&&Xd(t,o);var R=v=l.createElement("link");ot(R),pt(R,"link",t),R._p=new Promise(function(_,I){R.onload=_,R.onerror=I}),R.addEventListener("load",function(){j.loading|=1}),R.addEventListener("error",function(){j.loading|=2}),j.loading|=4,El(v,n,l)}v={type:"stylesheet",instance:v,count:1,state:j},d.set(g,v)}}}function n4(t,n){qi.X(t,n);var o=Ka;if(o&&t){var l=ma(o).hoistableScripts,d=Za(t),g=l.get(d);g||(g=o.querySelector(Ao(d)),g||(t=y({src:t,async:!0},n),(n=Wt.get(d))&&Zd(t,n),g=o.createElement("script"),ot(g),pt(g,"link",t),o.head.appendChild(g)),g={type:"script",instance:g,count:1,state:null},l.set(d,g))}}function a4(t,n){qi.M(t,n);var o=Ka;if(o&&t){var l=ma(o).hoistableScripts,d=Za(t),g=l.get(d);g||(g=o.querySelector(Ao(d)),g||(t=y({src:t,async:!0,type:"module"},n),(n=Wt.get(d))&&Zd(t,n),g=o.createElement("script"),ot(g),pt(g,"link",t),o.head.appendChild(g)),g={type:"script",instance:g,count:1,state:null},l.set(d,g))}}function B1(t,n,o,l){var d=(d=le.current)?Al(d):null;if(!d)throw Error(r(446));switch(t){case"meta":case"title":return null;case"style":return typeof o.precedence=="string"&&typeof o.href=="string"?(n=Xa(o.href),o=ma(d).hoistableStyles,l=o.get(n),l||(l={type:"style",instance:null,count:0,state:null},o.set(n,l)),l):{type:"void",instance:null,count:0,state:null};case"link":if(o.rel==="stylesheet"&&typeof o.href=="string"&&typeof o.precedence=="string"){t=Xa(o.href);var g=ma(d).hoistableStyles,v=g.get(t);if(v||(d=d.ownerDocument||d,v={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},g.set(t,v),(g=d.querySelector(jo(t)))&&!g._p&&(v.instance=g,v.state.loading=5),Wt.has(t)||(o={rel:"preload",as:"style",href:o.href,crossOrigin:o.crossOrigin,integrity:o.integrity,media:o.media,hrefLang:o.hrefLang,referrerPolicy:o.referrerPolicy},Wt.set(t,o),g||r4(d,t,o,v.state))),n&&l===null)throw Error(r(528,""));return v}if(n&&l!==null)throw Error(r(529,""));return null;case"script":return n=o.async,o=o.src,typeof o=="string"&&n&&typeof n!="function"&&typeof n!="symbol"?(n=Za(o),o=ma(d).hoistableScripts,l=o.get(n),l||(l={type:"script",instance:null,count:0,state:null},o.set(n,l)),l):{type:"void",instance:null,count:0,state:null};default:throw Error(r(444,t))}}function Xa(t){return'href="'+Yt(t)+'"'}function jo(t){return'link[rel="stylesheet"]['+t+"]"}function z1(t){return y({},t,{"data-precedence":t.precedence,precedence:null})}function r4(t,n,o,l){t.querySelector('link[rel="preload"][as="style"]['+n+"]")?l.loading=1:(n=t.createElement("link"),l.preload=n,n.addEventListener("load",function(){return l.loading|=1}),n.addEventListener("error",function(){return l.loading|=2}),pt(n,"link",o),ot(n),t.head.appendChild(n))}function Za(t){return'[src="'+Yt(t)+'"]'}function Ao(t){return"script[async]"+t}function $1(t,n,o){if(n.count++,n.instance===null)switch(n.type){case"style":var l=t.querySelector('style[data-href~="'+Yt(o.href)+'"]');if(l)return n.instance=l,ot(l),l;var d=y({},o,{"data-href":o.href,"data-precedence":o.precedence,href:null,precedence:null});return l=(t.ownerDocument||t).createElement("style"),ot(l),pt(l,"style",d),El(l,o.precedence,t),n.instance=l;case"stylesheet":d=Xa(o.href);var g=t.querySelector(jo(d));if(g)return n.state.loading|=4,n.instance=g,ot(g),g;l=z1(o),(d=Wt.get(d))&&Xd(l,d),g=(t.ownerDocument||t).createElement("link"),ot(g);var v=g;return v._p=new Promise(function(j,R){v.onload=j,v.onerror=R}),pt(g,"link",l),n.state.loading|=4,El(g,o.precedence,t),n.instance=g;case"script":return g=Za(o.src),(d=t.querySelector(Ao(g)))?(n.instance=d,ot(d),d):(l=o,(d=Wt.get(g))&&(l=y({},o),Zd(l,d)),t=t.ownerDocument||t,d=t.createElement("script"),ot(d),pt(d,"link",l),t.head.appendChild(d),n.instance=d);case"void":return null;default:throw Error(r(443,n.type))}else n.type==="stylesheet"&&(n.state.loading&4)===0&&(l=n.instance,n.state.loading|=4,El(l,o.precedence,t));return n.instance}function El(t,n,o){for(var l=o.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),d=l.length?l[l.length-1]:null,g=d,v=0;v<l.length;v++){var j=l[v];if(j.dataset.precedence===n)g=j;else if(g!==d)break}g?g.parentNode.insertBefore(t,g.nextSibling):(n=o.nodeType===9?o.head:o,n.insertBefore(t,n.firstChild))}function Xd(t,n){t.crossOrigin==null&&(t.crossOrigin=n.crossOrigin),t.referrerPolicy==null&&(t.referrerPolicy=n.referrerPolicy),t.title==null&&(t.title=n.title)}function Zd(t,n){t.crossOrigin==null&&(t.crossOrigin=n.crossOrigin),t.referrerPolicy==null&&(t.referrerPolicy=n.referrerPolicy),t.integrity==null&&(t.integrity=n.integrity)}var Cl=null;function N1(t,n,o){if(Cl===null){var l=new Map,d=Cl=new Map;d.set(o,l)}else d=Cl,l=d.get(o),l||(l=new Map,d.set(o,l));if(l.has(t))return l;for(l.set(t,null),o=o.getElementsByTagName(t),d=0;d<o.length;d++){var g=o[d];if(!(g[Lr]||g[yt]||t==="link"&&g.getAttribute("rel")==="stylesheet")&&g.namespaceURI!=="http://www.w3.org/2000/svg"){var v=g.getAttribute(n)||"";v=t+v;var j=l.get(v);j?j.push(g):l.set(v,[g])}}return l}function L1(t,n,o){t=t.ownerDocument||t,t.head.insertBefore(o,n==="title"?t.querySelector("head > title"):null)}function o4(t,n,o){if(o===1||n.itemProp!=null)return!1;switch(t){case"meta":case"title":return!0;case"style":if(typeof n.precedence!="string"||typeof n.href!="string"||n.href==="")break;return!0;case"link":if(typeof n.rel!="string"||typeof n.href!="string"||n.href===""||n.onLoad||n.onError)break;switch(n.rel){case"stylesheet":return t=n.disabled,typeof n.precedence=="string"&&t==null;default:return!0}case"script":if(n.async&&typeof n.async!="function"&&typeof n.async!="symbol"&&!n.onLoad&&!n.onError&&n.src&&typeof n.src=="string")return!0}return!1}function _1(t){return!(t.type==="stylesheet"&&(t.state.loading&3)===0)}var Eo=null;function s4(){}function l4(t,n,o){if(Eo===null)throw Error(r(475));var l=Eo;if(n.type==="stylesheet"&&(typeof o.media!="string"||matchMedia(o.media).matches!==!1)&&(n.state.loading&4)===0){if(n.instance===null){var d=Xa(o.href),g=t.querySelector(jo(d));if(g){t=g._p,t!==null&&typeof t=="object"&&typeof t.then=="function"&&(l.count++,l=Ol.bind(l),t.then(l,l)),n.state.loading|=4,n.instance=g,ot(g);return}g=t.ownerDocument||t,o=z1(o),(d=Wt.get(d))&&Xd(o,d),g=g.createElement("link"),ot(g);var v=g;v._p=new Promise(function(j,R){v.onload=j,v.onerror=R}),pt(g,"link",o),n.instance=g}l.stylesheets===null&&(l.stylesheets=new Map),l.stylesheets.set(n,t),(t=n.state.preload)&&(n.state.loading&3)===0&&(l.count++,n=Ol.bind(l),t.addEventListener("load",n),t.addEventListener("error",n))}}function c4(){if(Eo===null)throw Error(r(475));var t=Eo;return t.stylesheets&&t.count===0&&Qd(t,t.stylesheets),0<t.count?function(n){var o=setTimeout(function(){if(t.stylesheets&&Qd(t,t.stylesheets),t.unsuspend){var l=t.unsuspend;t.unsuspend=null,l()}},6e4);return t.unsuspend=n,function(){t.unsuspend=null,clearTimeout(o)}}:null}function Ol(){if(this.count--,this.count===0){if(this.stylesheets)Qd(this,this.stylesheets);else if(this.unsuspend){var t=this.unsuspend;this.unsuspend=null,t()}}}var Rl=null;function Qd(t,n){t.stylesheets=null,t.unsuspend!==null&&(t.count++,Rl=new Map,n.forEach(u4,t),Rl=null,Ol.call(t))}function u4(t,n){if(!(n.state.loading&4)){var o=Rl.get(t);if(o)var l=o.get(null);else{o=new Map,Rl.set(t,o);for(var d=t.querySelectorAll("link[data-precedence],style[data-precedence]"),g=0;g<d.length;g++){var v=d[g];(v.nodeName==="LINK"||v.getAttribute("media")!=="not all")&&(o.set(v.dataset.precedence,v),l=v)}l&&o.set(null,l)}d=n.instance,v=d.getAttribute("data-precedence"),g=o.get(v)||l,g===l&&o.set(null,d),o.set(v,d),this.count++,l=Ol.bind(this),d.addEventListener("load",l),d.addEventListener("error",l),g?g.parentNode.insertBefore(d,g.nextSibling):(t=t.nodeType===9?t.head:t,t.insertBefore(d,t.firstChild)),n.state.loading|=4}}var Co={$$typeof:M,Provider:null,Consumer:null,_currentValue:ee,_currentValue2:ee,_threadCount:0};function d4(t,n,o,l,d,g,v,j){this.tag=1,this.containerInfo=t,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=Gc(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Gc(0),this.hiddenUpdates=Gc(null),this.identifierPrefix=l,this.onUncaughtError=d,this.onCaughtError=g,this.onRecoverableError=v,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=j,this.incompleteTransitions=new Map}function H1(t,n,o,l,d,g,v,j,R,_,I,K){return t=new d4(t,n,o,v,j,R,_,K),n=1,g===!0&&(n|=24),g=Nt(3,null,null,n),t.current=g,g.stateNode=t,n=Mu(),n.refCount++,t.pooledCache=n,n.refCount++,g.memoizedState={element:l,isDehydrated:o,cache:n},Nu(g),t}function V1(t){return t?(t=Ca,t):Ca}function P1(t,n,o,l,d,g){d=V1(d),l.context===null?l.context=d:l.pendingContext=d,l=on(n),l.payload={element:o},g=g===void 0?null:g,g!==null&&(l.callback=g),o=sn(t,l,n),o!==null&&(Pt(o,t,n),io(o,t,n))}function F1(t,n){if(t=t.memoizedState,t!==null&&t.dehydrated!==null){var o=t.retryLane;t.retryLane=o!==0&&o<n?o:n}}function Jd(t,n){F1(t,n),(t=t.alternate)&&F1(t,n)}function U1(t){if(t.tag===13){var n=Ea(t,67108864);n!==null&&Pt(n,t,67108864),Jd(t,67108864)}}var kl=!0;function f4(t,n,o,l){var d=P.T;P.T=null;var g=X.p;try{X.p=2,Wd(t,n,o,l)}finally{X.p=g,P.T=d}}function h4(t,n,o,l){var d=P.T;P.T=null;var g=X.p;try{X.p=8,Wd(t,n,o,l)}finally{X.p=g,P.T=d}}function Wd(t,n,o,l){if(kl){var d=ef(l);if(d===null)Vd(t,n,l,Dl,o),I1(t,l);else if(m4(d,t,n,o,l))l.stopPropagation();else if(I1(t,l),n&4&&-1<p4.indexOf(t)){for(;d!==null;){var g=pa(d);if(g!==null)switch(g.tag){case 3:if(g=g.stateNode,g.current.memoizedState.isDehydrated){var v=zn(g.pendingLanes);if(v!==0){var j=g;for(j.pendingLanes|=2,j.entangledLanes|=2;v;){var R=1<<31-zt(v);j.entanglements[1]|=R,v&=~R}bi(g),(Me&6)===0&&(pl=pi()+500,vo(0))}}break;case 13:j=Ea(g,2),j!==null&&Pt(j,g,2),gl(),Jd(g,2)}if(g=ef(l),g===null&&Vd(t,n,l,Dl,o),g===d)break;d=g}d!==null&&l.stopPropagation()}else Vd(t,n,l,null,o)}}function ef(t){return t=ru(t),tf(t)}var Dl=null;function tf(t){if(Dl=null,t=ha(t),t!==null){var n=c(t);if(n===null)t=null;else{var o=n.tag;if(o===13){if(t=u(n),t!==null)return t;t=null}else if(o===3){if(n.stateNode.current.memoizedState.isDehydrated)return n.tag===3?n.stateNode.containerInfo:null;t=null}else n!==t&&(t=null)}}return Dl=t,null}function q1(t){switch(t){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(W2()){case a0:return 2;case r0:return 8;case Ts:case ew:return 32;case o0:return 268435456;default:return 32}default:return 32}}var nf=!1,vn=null,wn=null,Sn=null,Oo=new Map,Ro=new Map,Tn=[],p4="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function I1(t,n){switch(t){case"focusin":case"focusout":vn=null;break;case"dragenter":case"dragleave":wn=null;break;case"mouseover":case"mouseout":Sn=null;break;case"pointerover":case"pointerout":Oo.delete(n.pointerId);break;case"gotpointercapture":case"lostpointercapture":Ro.delete(n.pointerId)}}function ko(t,n,o,l,d,g){return t===null||t.nativeEvent!==g?(t={blockedOn:n,domEventName:o,eventSystemFlags:l,nativeEvent:g,targetContainers:[d]},n!==null&&(n=pa(n),n!==null&&U1(n)),t):(t.eventSystemFlags|=l,n=t.targetContainers,d!==null&&n.indexOf(d)===-1&&n.push(d),t)}function m4(t,n,o,l,d){switch(n){case"focusin":return vn=ko(vn,t,n,o,l,d),!0;case"dragenter":return wn=ko(wn,t,n,o,l,d),!0;case"mouseover":return Sn=ko(Sn,t,n,o,l,d),!0;case"pointerover":var g=d.pointerId;return Oo.set(g,ko(Oo.get(g)||null,t,n,o,l,d)),!0;case"gotpointercapture":return g=d.pointerId,Ro.set(g,ko(Ro.get(g)||null,t,n,o,l,d)),!0}return!1}function Y1(t){var n=ha(t.target);if(n!==null){var o=c(n);if(o!==null){if(n=o.tag,n===13){if(n=u(o),n!==null){t.blockedOn=n,lw(t.priority,function(){if(o.tag===13){var l=Vt();l=Kc(l);var d=Ea(o,l);d!==null&&Pt(d,o,l),Jd(o,l)}});return}}else if(n===3&&o.stateNode.current.memoizedState.isDehydrated){t.blockedOn=o.tag===3?o.stateNode.containerInfo:null;return}}}t.blockedOn=null}function Ml(t){if(t.blockedOn!==null)return!1;for(var n=t.targetContainers;0<n.length;){var o=ef(t.nativeEvent);if(o===null){o=t.nativeEvent;var l=new o.constructor(o.type,o);au=l,o.target.dispatchEvent(l),au=null}else return n=pa(o),n!==null&&U1(n),t.blockedOn=o,!1;n.shift()}return!0}function G1(t,n,o){Ml(t)&&o.delete(n)}function g4(){nf=!1,vn!==null&&Ml(vn)&&(vn=null),wn!==null&&Ml(wn)&&(wn=null),Sn!==null&&Ml(Sn)&&(Sn=null),Oo.forEach(G1),Ro.forEach(G1)}function Bl(t,n){t.blockedOn===n&&(t.blockedOn=null,nf||(nf=!0,e.unstable_scheduleCallback(e.unstable_NormalPriority,g4)))}var zl=null;function K1(t){zl!==t&&(zl=t,e.unstable_scheduleCallback(e.unstable_NormalPriority,function(){zl===t&&(zl=null);for(var n=0;n<t.length;n+=3){var o=t[n],l=t[n+1],d=t[n+2];if(typeof l!="function"){if(tf(l||o)===null)continue;break}var g=pa(o);g!==null&&(t.splice(n,3),n-=3,td(g,{pending:!0,data:d,method:o.method,action:l},l,d))}}))}function Do(t){function n(R){return Bl(R,t)}vn!==null&&Bl(vn,t),wn!==null&&Bl(wn,t),Sn!==null&&Bl(Sn,t),Oo.forEach(n),Ro.forEach(n);for(var o=0;o<Tn.length;o++){var l=Tn[o];l.blockedOn===t&&(l.blockedOn=null)}for(;0<Tn.length&&(o=Tn[0],o.blockedOn===null);)Y1(o),o.blockedOn===null&&Tn.shift();if(o=(t.ownerDocument||t).$$reactFormReplay,o!=null)for(l=0;l<o.length;l+=3){var d=o[l],g=o[l+1],v=d[At]||null;if(typeof g=="function")v||K1(o);else if(v){var j=null;if(g&&g.hasAttribute("formAction")){if(d=g,v=g[At]||null)j=v.formAction;else if(tf(d)!==null)continue}else j=v.action;typeof j=="function"?o[l+1]=j:(o.splice(l,3),l-=3),K1(o)}}}function af(t){this._internalRoot=t}$l.prototype.render=af.prototype.render=function(t){var n=this._internalRoot;if(n===null)throw Error(r(409));var o=n.current,l=Vt();P1(o,l,t,n,null,null)},$l.prototype.unmount=af.prototype.unmount=function(){var t=this._internalRoot;if(t!==null){this._internalRoot=null;var n=t.containerInfo;P1(t.current,2,null,t,null,null),gl(),n[fa]=null}};function $l(t){this._internalRoot=t}$l.prototype.unstable_scheduleHydration=function(t){if(t){var n=d0();t={blockedOn:null,target:t,priority:n};for(var o=0;o<Tn.length&&n!==0&&n<Tn[o].priority;o++);Tn.splice(o,0,t),o===0&&Y1(t)}};var X1=i.version;if(X1!=="19.1.0")throw Error(r(527,X1,"19.1.0"));X.findDOMNode=function(t){var n=t._reactInternals;if(n===void 0)throw typeof t.render=="function"?Error(r(188)):(t=Object.keys(t).join(","),Error(r(268,t)));return t=p(n),t=t!==null?m(t):null,t=t===null?null:t.stateNode,t};var y4={bundleType:0,version:"19.1.0",rendererPackageName:"react-dom",currentDispatcherRef:P,reconcilerVersion:"19.1.0"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var Nl=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!Nl.isDisabled&&Nl.supportsFiber)try{zr=Nl.inject(y4),Bt=Nl}catch{}}return Bo.createRoot=function(t,n){if(!s(t))throw Error(r(299));var o=!1,l="",d=dg,g=fg,v=hg,j=null;return n!=null&&(n.unstable_strictMode===!0&&(o=!0),n.identifierPrefix!==void 0&&(l=n.identifierPrefix),n.onUncaughtError!==void 0&&(d=n.onUncaughtError),n.onCaughtError!==void 0&&(g=n.onCaughtError),n.onRecoverableError!==void 0&&(v=n.onRecoverableError),n.unstable_transitionCallbacks!==void 0&&(j=n.unstable_transitionCallbacks)),n=H1(t,1,!1,null,null,o,l,d,g,v,j,null),t[fa]=n.current,Hd(t),new af(n)},Bo.hydrateRoot=function(t,n,o){if(!s(t))throw Error(r(299));var l=!1,d="",g=dg,v=fg,j=hg,R=null,_=null;return o!=null&&(o.unstable_strictMode===!0&&(l=!0),o.identifierPrefix!==void 0&&(d=o.identifierPrefix),o.onUncaughtError!==void 0&&(g=o.onUncaughtError),o.onCaughtError!==void 0&&(v=o.onCaughtError),o.onRecoverableError!==void 0&&(j=o.onRecoverableError),o.unstable_transitionCallbacks!==void 0&&(R=o.unstable_transitionCallbacks),o.formState!==void 0&&(_=o.formState)),n=H1(t,1,!0,n,o??null,l,d,g,v,j,R,_),n.context=V1(null),o=n.current,l=Vt(),l=Kc(l),d=on(l),d.callback=null,sn(o,d,l),o=l,n.current.lanes=o,Nr(n,o),bi(n),t[fa]=n.current,Hd(t),new $l(n)},Bo.version="19.1.0",Bo}var ry;function C4(){if(ry)return sf.exports;ry=1;function e(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(e)}catch(i){console.error(i)}}return e(),sf.exports=E4(),sf.exports}var O4=C4();const R4=jr(O4);var zo={},oy;function k4(){if(oy)return zo;oy=1,Object.defineProperty(zo,"__esModule",{value:!0}),zo.parse=u,zo.serialize=m;const e=/^[\u0021-\u003A\u003C\u003E-\u007E]+$/,i=/^[\u0021-\u003A\u003C-\u007E]*$/,a=/^([.]?[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)([.][a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$/i,r=/^[\u0020-\u003A\u003D-\u007E]*$/,s=Object.prototype.toString,c=(()=>{const b=function(){};return b.prototype=Object.create(null),b})();function u(b,T){const A=new c,C=b.length;if(C<2)return A;const B=(T==null?void 0:T.decode)||y;let E=0;do{const k=b.indexOf("=",E);if(k===-1)break;const M=b.indexOf(";",E),F=M===-1?C:M;if(k>F){E=b.lastIndexOf(";",k-1)+1;continue}const D=f(b,E,k),U=p(b,k,D),G=b.slice(D,U);if(A[G]===void 0){let Z=f(b,k+1,F),J=p(b,F,Z);const ie=B(b.slice(Z,J));A[G]=ie}E=F+1}while(E<C);return A}function f(b,T,A){do{const C=b.charCodeAt(T);if(C!==32&&C!==9)return T}while(++T<A);return A}function p(b,T,A){for(;T>A;){const C=b.charCodeAt(--T);if(C!==32&&C!==9)return T+1}return A}function m(b,T,A){const C=(A==null?void 0:A.encode)||encodeURIComponent;if(!e.test(b))throw new TypeError(`argument name is invalid: ${b}`);const B=C(T);if(!i.test(B))throw new TypeError(`argument val is invalid: ${T}`);let E=b+"="+B;if(!A)return E;if(A.maxAge!==void 0){if(!Number.isInteger(A.maxAge))throw new TypeError(`option maxAge is invalid: ${A.maxAge}`);E+="; Max-Age="+A.maxAge}if(A.domain){if(!a.test(A.domain))throw new TypeError(`option domain is invalid: ${A.domain}`);E+="; Domain="+A.domain}if(A.path){if(!r.test(A.path))throw new TypeError(`option path is invalid: ${A.path}`);E+="; Path="+A.path}if(A.expires){if(!x(A.expires)||!Number.isFinite(A.expires.valueOf()))throw new TypeError(`option expires is invalid: ${A.expires}`);E+="; Expires="+A.expires.toUTCString()}if(A.httpOnly&&(E+="; HttpOnly"),A.secure&&(E+="; Secure"),A.partitioned&&(E+="; Partitioned"),A.priority)switch(typeof A.priority=="string"?A.priority.toLowerCase():void 0){case"low":E+="; Priority=Low";break;case"medium":E+="; Priority=Medium";break;case"high":E+="; Priority=High";break;default:throw new TypeError(`option priority is invalid: ${A.priority}`)}if(A.sameSite)switch(typeof A.sameSite=="string"?A.sameSite.toLowerCase():A.sameSite){case!0:case"strict":E+="; SameSite=Strict";break;case"lax":E+="; SameSite=Lax";break;case"none":E+="; SameSite=None";break;default:throw new TypeError(`option sameSite is invalid: ${A.sameSite}`)}return E}function y(b){if(b.indexOf("%")===-1)return b;try{return decodeURIComponent(b)}catch{return b}}function x(b){return s.call(b)==="[object Date]"}return zo}k4();var sy="popstate";function D4(e={}){function i(r,s){let{pathname:c,search:u,hash:f}=r.location;return mh("",{pathname:c,search:u,hash:f},s.state&&s.state.usr||null,s.state&&s.state.key||"default")}function a(r,s){return typeof s=="string"?s:ts(s)}return B4(i,a,null,e)}function qe(e,i){if(e===!1||e===null||typeof e>"u")throw new Error(i)}function ui(e,i){if(!e){typeof console<"u"&&console.warn(i);try{throw new Error(i)}catch{}}}function M4(){return Math.random().toString(36).substring(2,10)}function ly(e,i){return{usr:e.state,key:e.key,idx:i}}function mh(e,i,a=null,r){return{pathname:typeof e=="string"?e:e.pathname,search:"",hash:"",...typeof i=="string"?Ar(i):i,state:a,key:i&&i.key||r||M4()}}function ts({pathname:e="/",search:i="",hash:a=""}){return i&&i!=="?"&&(e+=i.charAt(0)==="?"?i:"?"+i),a&&a!=="#"&&(e+=a.charAt(0)==="#"?a:"#"+a),e}function Ar(e){let i={};if(e){let a=e.indexOf("#");a>=0&&(i.hash=e.substring(a),e=e.substring(0,a));let r=e.indexOf("?");r>=0&&(i.search=e.substring(r),e=e.substring(0,r)),e&&(i.pathname=e)}return i}function B4(e,i,a,r={}){let{window:s=document.defaultView,v5Compat:c=!1}=r,u=s.history,f="POP",p=null,m=y();m==null&&(m=0,u.replaceState({...u.state,idx:m},""));function y(){return(u.state||{idx:null}).idx}function x(){f="POP";let B=y(),E=B==null?null:B-m;m=B,p&&p({action:f,location:C.location,delta:E})}function b(B,E){f="PUSH";let k=mh(C.location,B,E);m=y()+1;let M=ly(k,m),F=C.createHref(k);try{u.pushState(M,"",F)}catch(D){if(D instanceof DOMException&&D.name==="DataCloneError")throw D;s.location.assign(F)}c&&p&&p({action:f,location:C.location,delta:1})}function T(B,E){f="REPLACE";let k=mh(C.location,B,E);m=y();let M=ly(k,m),F=C.createHref(k);u.replaceState(M,"",F),c&&p&&p({action:f,location:C.location,delta:0})}function A(B){return z4(B)}let C={get action(){return f},get location(){return e(s,u)},listen(B){if(p)throw new Error("A history only accepts one active listener");return s.addEventListener(sy,x),p=B,()=>{s.removeEventListener(sy,x),p=null}},createHref(B){return i(s,B)},createURL:A,encodeLocation(B){let E=A(B);return{pathname:E.pathname,search:E.search,hash:E.hash}},push:b,replace:T,go(B){return u.go(B)}};return C}function z4(e,i=!1){let a="http://localhost";typeof window<"u"&&(a=window.location.origin!=="null"?window.location.origin:window.location.href),qe(a,"No window.location.(origin|href) available to create URL");let r=typeof e=="string"?e:ts(e);return r=r.replace(/ $/,"%20"),!i&&r.startsWith("//")&&(r=a+r),new URL(r,a)}function Kb(e,i,a="/"){return $4(e,i,a,!1)}function $4(e,i,a,r){let s=typeof i=="string"?Ar(i):i,c=Zi(s.pathname||"/",a);if(c==null)return null;let u=Xb(e);N4(u);let f=null;for(let p=0;f==null&&p<u.length;++p){let m=G4(c);f=I4(u[p],m,r)}return f}function Xb(e,i=[],a=[],r=""){let s=(c,u,f)=>{let p={relativePath:f===void 0?c.path||"":f,caseSensitive:c.caseSensitive===!0,childrenIndex:u,route:c};p.relativePath.startsWith("/")&&(qe(p.relativePath.startsWith(r),`Absolute route path "${p.relativePath}" nested under path "${r}" is not valid. An absolute child route path must start with the combined path of all its parent routes.`),p.relativePath=p.relativePath.slice(r.length));let m=Xi([r,p.relativePath]),y=a.concat(p);c.children&&c.children.length>0&&(qe(c.index!==!0,`Index routes must not have child routes. Please remove all child routes from route path "${m}".`),Xb(c.children,i,y,m)),!(c.path==null&&!c.index)&&i.push({path:m,score:U4(m,c.index),routesMeta:y})};return e.forEach((c,u)=>{var f;if(c.path===""||!((f=c.path)!=null&&f.includes("?")))s(c,u);else for(let p of Zb(c.path))s(c,u,p)}),i}function Zb(e){let i=e.split("/");if(i.length===0)return[];let[a,...r]=i,s=a.endsWith("?"),c=a.replace(/\?$/,"");if(r.length===0)return s?[c,""]:[c];let u=Zb(r.join("/")),f=[];return f.push(...u.map(p=>p===""?c:[c,p].join("/"))),s&&f.push(...u),f.map(p=>e.startsWith("/")&&p===""?"/":p)}function N4(e){e.sort((i,a)=>i.score!==a.score?a.score-i.score:q4(i.routesMeta.map(r=>r.childrenIndex),a.routesMeta.map(r=>r.childrenIndex)))}var L4=/^:[\w-]+$/,_4=3,H4=2,V4=1,P4=10,F4=-2,cy=e=>e==="*";function U4(e,i){let a=e.split("/"),r=a.length;return a.some(cy)&&(r+=F4),i&&(r+=H4),a.filter(s=>!cy(s)).reduce((s,c)=>s+(L4.test(c)?_4:c===""?V4:P4),r)}function q4(e,i){return e.length===i.length&&e.slice(0,-1).every((r,s)=>r===i[s])?e[e.length-1]-i[i.length-1]:0}function I4(e,i,a=!1){let{routesMeta:r}=e,s={},c="/",u=[];for(let f=0;f<r.length;++f){let p=r[f],m=f===r.length-1,y=c==="/"?i:i.slice(c.length)||"/",x=uc({path:p.relativePath,caseSensitive:p.caseSensitive,end:m},y),b=p.route;if(!x&&m&&a&&!r[r.length-1].route.index&&(x=uc({path:p.relativePath,caseSensitive:p.caseSensitive,end:!1},y)),!x)return null;Object.assign(s,x.params),u.push({params:s,pathname:Xi([c,x.pathname]),pathnameBase:Q4(Xi([c,x.pathnameBase])),route:b}),x.pathnameBase!=="/"&&(c=Xi([c,x.pathnameBase]))}return u}function uc(e,i){typeof e=="string"&&(e={path:e,caseSensitive:!1,end:!0});let[a,r]=Y4(e.path,e.caseSensitive,e.end),s=i.match(a);if(!s)return null;let c=s[0],u=c.replace(/(.)\/+$/,"$1"),f=s.slice(1);return{params:r.reduce((m,{paramName:y,isOptional:x},b)=>{if(y==="*"){let A=f[b]||"";u=c.slice(0,c.length-A.length).replace(/(.)\/+$/,"$1")}const T=f[b];return x&&!T?m[y]=void 0:m[y]=(T||"").replace(/%2F/g,"/"),m},{}),pathname:c,pathnameBase:u,pattern:e}}function Y4(e,i=!1,a=!0){ui(e==="*"||!e.endsWith("*")||e.endsWith("/*"),`Route path "${e}" will be treated as if it were "${e.replace(/\*$/,"/*")}" because the \`*\` character must always follow a \`/\` in the pattern. To get rid of this warning, please change the route path to "${e.replace(/\*$/,"/*")}".`);let r=[],s="^"+e.replace(/\/*\*?$/,"").replace(/^\/*/,"/").replace(/[\\.*+^${}|()[\]]/g,"\\$&").replace(/\/:([\w-]+)(\?)?/g,(u,f,p)=>(r.push({paramName:f,isOptional:p!=null}),p?"/?([^\\/]+)?":"/([^\\/]+)"));return e.endsWith("*")?(r.push({paramName:"*"}),s+=e==="*"||e==="/*"?"(.*)$":"(?:\\/(.+)|\\/*)$"):a?s+="\\/*$":e!==""&&e!=="/"&&(s+="(?:(?=\\/|$))"),[new RegExp(s,i?void 0:"i"),r]}function G4(e){try{return e.split("/").map(i=>decodeURIComponent(i).replace(/\//g,"%2F")).join("/")}catch(i){return ui(!1,`The URL path "${e}" could not be decoded because it is a malformed URL segment. This is probably due to a bad percent encoding (${i}).`),e}}function Zi(e,i){if(i==="/")return e;if(!e.toLowerCase().startsWith(i.toLowerCase()))return null;let a=i.endsWith("/")?i.length-1:i.length,r=e.charAt(a);return r&&r!=="/"?null:e.slice(a)||"/"}function K4(e,i="/"){let{pathname:a,search:r="",hash:s=""}=typeof e=="string"?Ar(e):e;return{pathname:a?a.startsWith("/")?a:X4(a,i):i,search:J4(r),hash:W4(s)}}function X4(e,i){let a=i.replace(/\/+$/,"").split("/");return e.split("/").forEach(s=>{s===".."?a.length>1&&a.pop():s!=="."&&a.push(s)}),a.length>1?a.join("/"):"/"}function df(e,i,a,r){return`Cannot include a '${e}' character in a manually specified \`to.${i}\` field [${JSON.stringify(r)}].  Please separate it out to the \`to.${a}\` field. Alternatively you may provide the full path as a string in <Link to="..."> and the router will parse it for you.`}function Z4(e){return e.filter((i,a)=>a===0||i.route.path&&i.route.path.length>0)}function tp(e){let i=Z4(e);return i.map((a,r)=>r===i.length-1?a.pathname:a.pathnameBase)}function ip(e,i,a,r=!1){let s;typeof e=="string"?s=Ar(e):(s={...e},qe(!s.pathname||!s.pathname.includes("?"),df("?","pathname","search",s)),qe(!s.pathname||!s.pathname.includes("#"),df("#","pathname","hash",s)),qe(!s.search||!s.search.includes("#"),df("#","search","hash",s)));let c=e===""||s.pathname==="",u=c?"/":s.pathname,f;if(u==null)f=a;else{let x=i.length-1;if(!r&&u.startsWith("..")){let b=u.split("/");for(;b[0]==="..";)b.shift(),x-=1;s.pathname=b.join("/")}f=x>=0?i[x]:"/"}let p=K4(s,f),m=u&&u!=="/"&&u.endsWith("/"),y=(c||u===".")&&a.endsWith("/");return!p.pathname.endsWith("/")&&(m||y)&&(p.pathname+="/"),p}var Xi=e=>e.join("/").replace(/\/\/+/g,"/"),Q4=e=>e.replace(/\/+$/,"").replace(/^\/*/,"/"),J4=e=>!e||e==="?"?"":e.startsWith("?")?e:"?"+e,W4=e=>!e||e==="#"?"":e.startsWith("#")?e:"#"+e;function eS(e){return e!=null&&typeof e.status=="number"&&typeof e.statusText=="string"&&typeof e.internal=="boolean"&&"data"in e}var Qb=["POST","PUT","PATCH","DELETE"];new Set(Qb);var tS=["GET",...Qb];new Set(tS);var Er=S.createContext(null);Er.displayName="DataRouter";var kc=S.createContext(null);kc.displayName="DataRouterState";var Jb=S.createContext({isTransitioning:!1});Jb.displayName="ViewTransition";var iS=S.createContext(new Map);iS.displayName="Fetchers";var nS=S.createContext(null);nS.displayName="Await";var di=S.createContext(null);di.displayName="Navigation";var gs=S.createContext(null);gs.displayName="Location";var Oi=S.createContext({outlet:null,matches:[],isDataRoute:!1});Oi.displayName="Route";var np=S.createContext(null);np.displayName="RouteError";function aS(e,{relative:i}={}){qe(Cr(),"useHref() may be used only in the context of a <Router> component.");let{basename:a,navigator:r}=S.useContext(di),{hash:s,pathname:c,search:u}=ys(e,{relative:i}),f=c;return a!=="/"&&(f=c==="/"?a:Xi([a,c])),r.createHref({pathname:f,search:u,hash:s})}function Cr(){return S.useContext(gs)!=null}function fi(){return qe(Cr(),"useLocation() may be used only in the context of a <Router> component."),S.useContext(gs).location}var Wb="You should call navigate() in a React.useEffect(), not when your component is first rendered.";function ev(e){S.useContext(di).static||S.useLayoutEffect(e)}function tv(){let{isDataRoute:e}=S.useContext(Oi);return e?yS():rS()}function rS(){qe(Cr(),"useNavigate() may be used only in the context of a <Router> component.");let e=S.useContext(Er),{basename:i,navigator:a}=S.useContext(di),{matches:r}=S.useContext(Oi),{pathname:s}=fi(),c=JSON.stringify(tp(r)),u=S.useRef(!1);return ev(()=>{u.current=!0}),S.useCallback((p,m={})=>{if(ui(u.current,Wb),!u.current)return;if(typeof p=="number"){a.go(p);return}let y=ip(p,JSON.parse(c),s,m.relative==="path");e==null&&i!=="/"&&(y.pathname=y.pathname==="/"?i:Xi([i,y.pathname])),(m.replace?a.replace:a.push)(y,m.state,m)},[i,a,c,s,e])}S.createContext(null);function ys(e,{relative:i}={}){let{matches:a}=S.useContext(Oi),{pathname:r}=fi(),s=JSON.stringify(tp(a));return S.useMemo(()=>ip(e,JSON.parse(s),r,i==="path"),[e,s,r,i])}function oS(e,i){return iv(e,i)}function iv(e,i,a,r){var k;qe(Cr(),"useRoutes() may be used only in the context of a <Router> component.");let{navigator:s,static:c}=S.useContext(di),{matches:u}=S.useContext(Oi),f=u[u.length-1],p=f?f.params:{},m=f?f.pathname:"/",y=f?f.pathnameBase:"/",x=f&&f.route;{let M=x&&x.path||"";nv(m,!x||M.endsWith("*")||M.endsWith("*?"),`You rendered descendant <Routes> (or called \`useRoutes()\`) at "${m}" (under <Route path="${M}">) but the parent route path has no trailing "*". This means if you navigate deeper, the parent won't match anymore and therefore the child routes will never render.

Please change the parent <Route path="${M}"> to <Route path="${M==="/"?"*":`${M}/*`}">.`)}let b=fi(),T;if(i){let M=typeof i=="string"?Ar(i):i;qe(y==="/"||((k=M.pathname)==null?void 0:k.startsWith(y)),`When overriding the location using \`<Routes location>\` or \`useRoutes(routes, location)\`, the location pathname must begin with the portion of the URL pathname that was matched by all parent routes. The current pathname base is "${y}" but pathname "${M.pathname}" was given in the \`location\` prop.`),T=M}else T=b;let A=T.pathname||"/",C=A;if(y!=="/"){let M=y.replace(/^\//,"").split("/");C="/"+A.replace(/^\//,"").split("/").slice(M.length).join("/")}let B=!c&&a&&a.matches&&a.matches.length>0?a.matches:Kb(e,{pathname:C});ui(x||B!=null,`No routes matched location "${T.pathname}${T.search}${T.hash}" `),ui(B==null||B[B.length-1].route.element!==void 0||B[B.length-1].route.Component!==void 0||B[B.length-1].route.lazy!==void 0,`Matched leaf route at location "${T.pathname}${T.search}${T.hash}" does not have an element or Component. This means it will render an <Outlet /> with a null value by default resulting in an "empty" page.`);let E=dS(B&&B.map(M=>Object.assign({},M,{params:Object.assign({},p,M.params),pathname:Xi([y,s.encodeLocation?s.encodeLocation(M.pathname).pathname:M.pathname]),pathnameBase:M.pathnameBase==="/"?y:Xi([y,s.encodeLocation?s.encodeLocation(M.pathnameBase).pathname:M.pathnameBase])})),u,a,r);return i&&E?S.createElement(gs.Provider,{value:{location:{pathname:"/",search:"",hash:"",state:null,key:"default",...T},navigationType:"POP"}},E):E}function sS(){let e=gS(),i=eS(e)?`${e.status} ${e.statusText}`:e instanceof Error?e.message:JSON.stringify(e),a=e instanceof Error?e.stack:null,r="rgba(200,200,200, 0.5)",s={padding:"0.5rem",backgroundColor:r},c={padding:"2px 4px",backgroundColor:r},u=null;return console.error("Error handled by React Router default ErrorBoundary:",e),u=S.createElement(S.Fragment,null,S.createElement("p",null,"💿 Hey developer 👋"),S.createElement("p",null,"You can provide a way better UX than this when your app throws errors by providing your own ",S.createElement("code",{style:c},"ErrorBoundary")," or"," ",S.createElement("code",{style:c},"errorElement")," prop on your route.")),S.createElement(S.Fragment,null,S.createElement("h2",null,"Unexpected Application Error!"),S.createElement("h3",{style:{fontStyle:"italic"}},i),a?S.createElement("pre",{style:s},a):null,u)}var lS=S.createElement(sS,null),cS=class extends S.Component{constructor(e){super(e),this.state={location:e.location,revalidation:e.revalidation,error:e.error}}static getDerivedStateFromError(e){return{error:e}}static getDerivedStateFromProps(e,i){return i.location!==e.location||i.revalidation!=="idle"&&e.revalidation==="idle"?{error:e.error,location:e.location,revalidation:e.revalidation}:{error:e.error!==void 0?e.error:i.error,location:i.location,revalidation:e.revalidation||i.revalidation}}componentDidCatch(e,i){console.error("React Router caught the following error during render",e,i)}render(){return this.state.error!==void 0?S.createElement(Oi.Provider,{value:this.props.routeContext},S.createElement(np.Provider,{value:this.state.error,children:this.props.component})):this.props.children}};function uS({routeContext:e,match:i,children:a}){let r=S.useContext(Er);return r&&r.static&&r.staticContext&&(i.route.errorElement||i.route.ErrorBoundary)&&(r.staticContext._deepestRenderedBoundaryId=i.route.id),S.createElement(Oi.Provider,{value:e},a)}function dS(e,i=[],a=null,r=null){if(e==null){if(!a)return null;if(a.errors)e=a.matches;else if(i.length===0&&!a.initialized&&a.matches.length>0)e=a.matches;else return null}let s=e,c=a==null?void 0:a.errors;if(c!=null){let p=s.findIndex(m=>m.route.id&&(c==null?void 0:c[m.route.id])!==void 0);qe(p>=0,`Could not find a matching route for errors on route IDs: ${Object.keys(c).join(",")}`),s=s.slice(0,Math.min(s.length,p+1))}let u=!1,f=-1;if(a)for(let p=0;p<s.length;p++){let m=s[p];if((m.route.HydrateFallback||m.route.hydrateFallbackElement)&&(f=p),m.route.id){let{loaderData:y,errors:x}=a,b=m.route.loader&&!y.hasOwnProperty(m.route.id)&&(!x||x[m.route.id]===void 0);if(m.route.lazy||b){u=!0,f>=0?s=s.slice(0,f+1):s=[s[0]];break}}}return s.reduceRight((p,m,y)=>{let x,b=!1,T=null,A=null;a&&(x=c&&m.route.id?c[m.route.id]:void 0,T=m.route.errorElement||lS,u&&(f<0&&y===0?(nv("route-fallback",!1,"No `HydrateFallback` element provided to render during initial hydration"),b=!0,A=null):f===y&&(b=!0,A=m.route.hydrateFallbackElement||null)));let C=i.concat(s.slice(0,y+1)),B=()=>{let E;return x?E=T:b?E=A:m.route.Component?E=S.createElement(m.route.Component,null):m.route.element?E=m.route.element:E=p,S.createElement(uS,{match:m,routeContext:{outlet:p,matches:C,isDataRoute:a!=null},children:E})};return a&&(m.route.ErrorBoundary||m.route.errorElement||y===0)?S.createElement(cS,{location:a.location,revalidation:a.revalidation,component:T,error:x,children:B(),routeContext:{outlet:null,matches:C,isDataRoute:!0}}):B()},null)}function ap(e){return`${e} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`}function fS(e){let i=S.useContext(Er);return qe(i,ap(e)),i}function hS(e){let i=S.useContext(kc);return qe(i,ap(e)),i}function pS(e){let i=S.useContext(Oi);return qe(i,ap(e)),i}function rp(e){let i=pS(e),a=i.matches[i.matches.length-1];return qe(a.route.id,`${e} can only be used on routes that contain a unique "id"`),a.route.id}function mS(){return rp("useRouteId")}function gS(){var r;let e=S.useContext(np),i=hS("useRouteError"),a=rp("useRouteError");return e!==void 0?e:(r=i.errors)==null?void 0:r[a]}function yS(){let{router:e}=fS("useNavigate"),i=rp("useNavigate"),a=S.useRef(!1);return ev(()=>{a.current=!0}),S.useCallback(async(s,c={})=>{ui(a.current,Wb),a.current&&(typeof s=="number"?e.navigate(s):await e.navigate(s,{fromRouteId:i,...c}))},[e,i])}var uy={};function nv(e,i,a){!i&&!uy[e]&&(uy[e]=!0,ui(!1,a))}S.memo(xS);function xS({routes:e,future:i,state:a}){return iv(e,void 0,a,i)}function bS({to:e,replace:i,state:a,relative:r}){qe(Cr(),"<Navigate> may be used only in the context of a <Router> component.");let{static:s}=S.useContext(di);ui(!s,"<Navigate> must not be used on the initial render in a <StaticRouter>. This is a no-op, but you should modify your code so the <Navigate> is only ever rendered in response to some user interaction or state change.");let{matches:c}=S.useContext(Oi),{pathname:u}=fi(),f=tv(),p=ip(e,tp(c),u,r==="path"),m=JSON.stringify(p);return S.useEffect(()=>{f(JSON.parse(m),{replace:i,state:a,relative:r})},[f,m,r,i,a]),null}function An(e){qe(!1,"A <Route> is only ever to be used as the child of <Routes> element, never rendered directly. Please wrap your <Route> in a <Routes>.")}function vS({basename:e="/",children:i=null,location:a,navigationType:r="POP",navigator:s,static:c=!1}){qe(!Cr(),"You cannot render a <Router> inside another <Router>. You should never have more than one in your app.");let u=e.replace(/^\/*/,"/"),f=S.useMemo(()=>({basename:u,navigator:s,static:c,future:{}}),[u,s,c]);typeof a=="string"&&(a=Ar(a));let{pathname:p="/",search:m="",hash:y="",state:x=null,key:b="default"}=a,T=S.useMemo(()=>{let A=Zi(p,u);return A==null?null:{location:{pathname:A,search:m,hash:y,state:x,key:b},navigationType:r}},[u,p,m,y,x,b,r]);return ui(T!=null,`<Router basename="${u}"> is not able to match the URL "${p}${m}${y}" because it does not start with the basename, so the <Router> won't render anything.`),T==null?null:S.createElement(di.Provider,{value:f},S.createElement(gs.Provider,{children:i,value:T}))}function wS({children:e,location:i}){return oS(gh(e),i)}function gh(e,i=[]){let a=[];return S.Children.forEach(e,(r,s)=>{if(!S.isValidElement(r))return;let c=[...i,s];if(r.type===S.Fragment){a.push.apply(a,gh(r.props.children,c));return}qe(r.type===An,`[${typeof r.type=="string"?r.type:r.type.name}] is not a <Route> component. All component children of <Routes> must be a <Route> or <React.Fragment>`),qe(!r.props.index||!r.props.children,"An index route cannot have child routes.");let u={id:r.props.id||c.join("-"),caseSensitive:r.props.caseSensitive,element:r.props.element,Component:r.props.Component,index:r.props.index,path:r.props.path,loader:r.props.loader,action:r.props.action,hydrateFallbackElement:r.props.hydrateFallbackElement,HydrateFallback:r.props.HydrateFallback,errorElement:r.props.errorElement,ErrorBoundary:r.props.ErrorBoundary,hasErrorBoundary:r.props.hasErrorBoundary===!0||r.props.ErrorBoundary!=null||r.props.errorElement!=null,shouldRevalidate:r.props.shouldRevalidate,handle:r.props.handle,lazy:r.props.lazy};r.props.children&&(u.children=gh(r.props.children,c)),a.push(u)}),a}var Zl="get",Ql="application/x-www-form-urlencoded";function Dc(e){return e!=null&&typeof e.tagName=="string"}function SS(e){return Dc(e)&&e.tagName.toLowerCase()==="button"}function TS(e){return Dc(e)&&e.tagName.toLowerCase()==="form"}function jS(e){return Dc(e)&&e.tagName.toLowerCase()==="input"}function AS(e){return!!(e.metaKey||e.altKey||e.ctrlKey||e.shiftKey)}function ES(e,i){return e.button===0&&(!i||i==="_self")&&!AS(e)}var Ll=null;function CS(){if(Ll===null)try{new FormData(document.createElement("form"),0),Ll=!1}catch{Ll=!0}return Ll}var OS=new Set(["application/x-www-form-urlencoded","multipart/form-data","text/plain"]);function ff(e){return e!=null&&!OS.has(e)?(ui(!1,`"${e}" is not a valid \`encType\` for \`<Form>\`/\`<fetcher.Form>\` and will default to "${Ql}"`),null):e}function RS(e,i){let a,r,s,c,u;if(TS(e)){let f=e.getAttribute("action");r=f?Zi(f,i):null,a=e.getAttribute("method")||Zl,s=ff(e.getAttribute("enctype"))||Ql,c=new FormData(e)}else if(SS(e)||jS(e)&&(e.type==="submit"||e.type==="image")){let f=e.form;if(f==null)throw new Error('Cannot submit a <button> or <input type="submit"> without a <form>');let p=e.getAttribute("formaction")||f.getAttribute("action");if(r=p?Zi(p,i):null,a=e.getAttribute("formmethod")||f.getAttribute("method")||Zl,s=ff(e.getAttribute("formenctype"))||ff(f.getAttribute("enctype"))||Ql,c=new FormData(f,e),!CS()){let{name:m,type:y,value:x}=e;if(y==="image"){let b=m?`${m}.`:"";c.append(`${b}x`,"0"),c.append(`${b}y`,"0")}else m&&c.append(m,x)}}else{if(Dc(e))throw new Error('Cannot submit element that is not <form>, <button>, or <input type="submit|image">');a=Zl,r=null,s=Ql,u=e}return c&&s==="text/plain"&&(u=c,c=void 0),{action:r,method:a.toLowerCase(),encType:s,formData:c,body:u}}function op(e,i){if(e===!1||e===null||typeof e>"u")throw new Error(i)}async function kS(e,i){if(e.id in i)return i[e.id];try{let a=await import(e.module);return i[e.id]=a,a}catch(a){return console.error(`Error loading route module \`${e.module}\`, reloading page...`),console.error(a),window.__reactRouterContext&&window.__reactRouterContext.isSpaMode,window.location.reload(),new Promise(()=>{})}}function DS(e){return e==null?!1:e.href==null?e.rel==="preload"&&typeof e.imageSrcSet=="string"&&typeof e.imageSizes=="string":typeof e.rel=="string"&&typeof e.href=="string"}async function MS(e,i,a){let r=await Promise.all(e.map(async s=>{let c=i.routes[s.route.id];if(c){let u=await kS(c,a);return u.links?u.links():[]}return[]}));return NS(r.flat(1).filter(DS).filter(s=>s.rel==="stylesheet"||s.rel==="preload").map(s=>s.rel==="stylesheet"?{...s,rel:"prefetch",as:"style"}:{...s,rel:"prefetch"}))}function dy(e,i,a,r,s,c){let u=(p,m)=>a[m]?p.route.id!==a[m].route.id:!0,f=(p,m)=>{var y;return a[m].pathname!==p.pathname||((y=a[m].route.path)==null?void 0:y.endsWith("*"))&&a[m].params["*"]!==p.params["*"]};return c==="assets"?i.filter((p,m)=>u(p,m)||f(p,m)):c==="data"?i.filter((p,m)=>{var x;let y=r.routes[p.route.id];if(!y||!y.hasLoader)return!1;if(u(p,m)||f(p,m))return!0;if(p.route.shouldRevalidate){let b=p.route.shouldRevalidate({currentUrl:new URL(s.pathname+s.search+s.hash,window.origin),currentParams:((x=a[0])==null?void 0:x.params)||{},nextUrl:new URL(e,window.origin),nextParams:p.params,defaultShouldRevalidate:!0});if(typeof b=="boolean")return b}return!0}):[]}function BS(e,i,{includeHydrateFallback:a}={}){return zS(e.map(r=>{let s=i.routes[r.route.id];if(!s)return[];let c=[s.module];return s.clientActionModule&&(c=c.concat(s.clientActionModule)),s.clientLoaderModule&&(c=c.concat(s.clientLoaderModule)),a&&s.hydrateFallbackModule&&(c=c.concat(s.hydrateFallbackModule)),s.imports&&(c=c.concat(s.imports)),c}).flat(1))}function zS(e){return[...new Set(e)]}function $S(e){let i={},a=Object.keys(e).sort();for(let r of a)i[r]=e[r];return i}function NS(e,i){let a=new Set;return new Set(i),e.reduce((r,s)=>{let c=JSON.stringify($S(s));return a.has(c)||(a.add(c),r.push({key:c,link:s})),r},[])}Object.getOwnPropertyNames(Object.prototype).sort().join("\0");var LS=new Set([100,101,204,205]);function _S(e,i){let a=typeof e=="string"?new URL(e,typeof window>"u"?"server://singlefetch/":window.location.origin):e;return a.pathname==="/"?a.pathname="_root.data":i&&Zi(a.pathname,i)==="/"?a.pathname=`${i.replace(/\/$/,"")}/_root.data`:a.pathname=`${a.pathname.replace(/\/$/,"")}.data`,a}function av(){let e=S.useContext(Er);return op(e,"You must render this element inside a <DataRouterContext.Provider> element"),e}function HS(){let e=S.useContext(kc);return op(e,"You must render this element inside a <DataRouterStateContext.Provider> element"),e}var sp=S.createContext(void 0);sp.displayName="FrameworkContext";function rv(){let e=S.useContext(sp);return op(e,"You must render this element inside a <HydratedRouter> element"),e}function VS(e,i){let a=S.useContext(sp),[r,s]=S.useState(!1),[c,u]=S.useState(!1),{onFocus:f,onBlur:p,onMouseEnter:m,onMouseLeave:y,onTouchStart:x}=i,b=S.useRef(null);S.useEffect(()=>{if(e==="render"&&u(!0),e==="viewport"){let C=E=>{E.forEach(k=>{u(k.isIntersecting)})},B=new IntersectionObserver(C,{threshold:.5});return b.current&&B.observe(b.current),()=>{B.disconnect()}}},[e]),S.useEffect(()=>{if(r){let C=setTimeout(()=>{u(!0)},100);return()=>{clearTimeout(C)}}},[r]);let T=()=>{s(!0)},A=()=>{s(!1),u(!1)};return a?e!=="intent"?[c,b,{}]:[c,b,{onFocus:$o(f,T),onBlur:$o(p,A),onMouseEnter:$o(m,T),onMouseLeave:$o(y,A),onTouchStart:$o(x,T)}]:[!1,b,{}]}function $o(e,i){return a=>{e&&e(a),a.defaultPrevented||i(a)}}function PS({page:e,...i}){let{router:a}=av(),r=S.useMemo(()=>Kb(a.routes,e,a.basename),[a.routes,e,a.basename]);return r?S.createElement(US,{page:e,matches:r,...i}):null}function FS(e){let{manifest:i,routeModules:a}=rv(),[r,s]=S.useState([]);return S.useEffect(()=>{let c=!1;return MS(e,i,a).then(u=>{c||s(u)}),()=>{c=!0}},[e,i,a]),r}function US({page:e,matches:i,...a}){let r=fi(),{manifest:s,routeModules:c}=rv(),{basename:u}=av(),{loaderData:f,matches:p}=HS(),m=S.useMemo(()=>dy(e,i,p,s,r,"data"),[e,i,p,s,r]),y=S.useMemo(()=>dy(e,i,p,s,r,"assets"),[e,i,p,s,r]),x=S.useMemo(()=>{if(e===r.pathname+r.search+r.hash)return[];let A=new Set,C=!1;if(i.forEach(E=>{var M;let k=s.routes[E.route.id];!k||!k.hasLoader||(!m.some(F=>F.route.id===E.route.id)&&E.route.id in f&&((M=c[E.route.id])!=null&&M.shouldRevalidate)||k.hasClientLoader?C=!0:A.add(E.route.id))}),A.size===0)return[];let B=_S(e,u);return C&&A.size>0&&B.searchParams.set("_routes",i.filter(E=>A.has(E.route.id)).map(E=>E.route.id).join(",")),[B.pathname+B.search]},[u,f,r,s,m,i,e,c]),b=S.useMemo(()=>BS(y,s),[y,s]),T=FS(y);return S.createElement(S.Fragment,null,x.map(A=>S.createElement("link",{key:A,rel:"prefetch",as:"fetch",href:A,...a})),b.map(A=>S.createElement("link",{key:A,rel:"modulepreload",href:A,...a})),T.map(({key:A,link:C})=>S.createElement("link",{key:A,...C})))}function qS(...e){return i=>{e.forEach(a=>{typeof a=="function"?a(i):a!=null&&(a.current=i)})}}var ov=typeof window<"u"&&typeof window.document<"u"&&typeof window.document.createElement<"u";try{ov&&(window.__reactRouterVersion="7.6.0")}catch{}function IS({basename:e,children:i,window:a}){let r=S.useRef();r.current==null&&(r.current=D4({window:a,v5Compat:!0}));let s=r.current,[c,u]=S.useState({action:s.action,location:s.location}),f=S.useCallback(p=>{S.startTransition(()=>u(p))},[u]);return S.useLayoutEffect(()=>s.listen(f),[s,f]),S.createElement(vS,{basename:e,children:i,location:c.location,navigationType:c.action,navigator:s})}var sv=/^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,hi=S.forwardRef(function({onClick:i,discover:a="render",prefetch:r="none",relative:s,reloadDocument:c,replace:u,state:f,target:p,to:m,preventScrollReset:y,viewTransition:x,...b},T){let{basename:A}=S.useContext(di),C=typeof m=="string"&&sv.test(m),B,E=!1;if(typeof m=="string"&&C&&(B=m,ov))try{let J=new URL(window.location.href),ie=m.startsWith("//")?new URL(J.protocol+m):new URL(m),oe=Zi(ie.pathname,A);ie.origin===J.origin&&oe!=null?m=oe+ie.search+ie.hash:E=!0}catch{ui(!1,`<Link to="${m}"> contains an invalid URL which will probably break when clicked - please update to a valid URL path.`)}let k=aS(m,{relative:s}),[M,F,D]=VS(r,b),U=XS(m,{replace:u,state:f,target:p,preventScrollReset:y,relative:s,viewTransition:x});function G(J){i&&i(J),J.defaultPrevented||U(J)}let Z=S.createElement("a",{...b,...D,href:B||k,onClick:E||c?i:G,ref:qS(T,F),target:p,"data-discover":!C&&a==="render"?"true":void 0});return M&&!C?S.createElement(S.Fragment,null,Z,S.createElement(PS,{page:k})):Z});hi.displayName="Link";var YS=S.forwardRef(function({"aria-current":i="page",caseSensitive:a=!1,className:r="",end:s=!1,style:c,to:u,viewTransition:f,children:p,...m},y){let x=ys(u,{relative:m.relative}),b=fi(),T=S.useContext(kc),{navigator:A,basename:C}=S.useContext(di),B=T!=null&&e7(x)&&f===!0,E=A.encodeLocation?A.encodeLocation(x).pathname:x.pathname,k=b.pathname,M=T&&T.navigation&&T.navigation.location?T.navigation.location.pathname:null;a||(k=k.toLowerCase(),M=M?M.toLowerCase():null,E=E.toLowerCase()),M&&C&&(M=Zi(M,C)||M);const F=E!=="/"&&E.endsWith("/")?E.length-1:E.length;let D=k===E||!s&&k.startsWith(E)&&k.charAt(F)==="/",U=M!=null&&(M===E||!s&&M.startsWith(E)&&M.charAt(E.length)==="/"),G={isActive:D,isPending:U,isTransitioning:B},Z=D?i:void 0,J;typeof r=="function"?J=r(G):J=[r,D?"active":null,U?"pending":null,B?"transitioning":null].filter(Boolean).join(" ");let ie=typeof c=="function"?c(G):c;return S.createElement(hi,{...m,"aria-current":Z,className:J,ref:y,style:ie,to:u,viewTransition:f},typeof p=="function"?p(G):p)});YS.displayName="NavLink";var GS=S.forwardRef(({discover:e="render",fetcherKey:i,navigate:a,reloadDocument:r,replace:s,state:c,method:u=Zl,action:f,onSubmit:p,relative:m,preventScrollReset:y,viewTransition:x,...b},T)=>{let A=JS(),C=WS(f,{relative:m}),B=u.toLowerCase()==="get"?"get":"post",E=typeof f=="string"&&sv.test(f),k=M=>{if(p&&p(M),M.defaultPrevented)return;M.preventDefault();let F=M.nativeEvent.submitter,D=(F==null?void 0:F.getAttribute("formmethod"))||u;A(F||M.currentTarget,{fetcherKey:i,method:D,navigate:a,replace:s,state:c,relative:m,preventScrollReset:y,viewTransition:x})};return S.createElement("form",{ref:T,method:B,action:C,onSubmit:r?p:k,...b,"data-discover":!E&&e==="render"?"true":void 0})});GS.displayName="Form";function KS(e){return`${e} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`}function lv(e){let i=S.useContext(Er);return qe(i,KS(e)),i}function XS(e,{target:i,replace:a,state:r,preventScrollReset:s,relative:c,viewTransition:u}={}){let f=tv(),p=fi(),m=ys(e,{relative:c});return S.useCallback(y=>{if(ES(y,i)){y.preventDefault();let x=a!==void 0?a:ts(p)===ts(m);f(e,{replace:x,state:r,preventScrollReset:s,relative:c,viewTransition:u})}},[p,f,m,a,r,i,e,s,c,u])}var ZS=0,QS=()=>`__${String(++ZS)}__`;function JS(){let{router:e}=lv("useSubmit"),{basename:i}=S.useContext(di),a=mS();return S.useCallback(async(r,s={})=>{let{action:c,method:u,encType:f,formData:p,body:m}=RS(r,i);if(s.navigate===!1){let y=s.fetcherKey||QS();await e.fetch(y,a,s.action||c,{preventScrollReset:s.preventScrollReset,formData:p,body:m,formMethod:s.method||u,formEncType:s.encType||f,flushSync:s.flushSync})}else await e.navigate(s.action||c,{preventScrollReset:s.preventScrollReset,formData:p,body:m,formMethod:s.method||u,formEncType:s.encType||f,replace:s.replace,state:s.state,fromRouteId:a,flushSync:s.flushSync,viewTransition:s.viewTransition})},[e,i,a])}function WS(e,{relative:i}={}){let{basename:a}=S.useContext(di),r=S.useContext(Oi);qe(r,"useFormAction must be used inside a RouteContext");let[s]=r.matches.slice(-1),c={...ys(e||".",{relative:i})},u=fi();if(e==null){c.search=u.search;let f=new URLSearchParams(c.search),p=f.getAll("index");if(p.some(y=>y==="")){f.delete("index"),p.filter(x=>x).forEach(x=>f.append("index",x));let y=f.toString();c.search=y?`?${y}`:""}}return(!e||e===".")&&s.route.index&&(c.search=c.search?c.search.replace(/^\?/,"?index&"):"?index"),a!=="/"&&(c.pathname=c.pathname==="/"?a:Xi([a,c.pathname])),ts(c)}function e7(e,i={}){let a=S.useContext(Jb);qe(a!=null,"`useViewTransitionState` must be used within `react-router-dom`'s `RouterProvider`.  Did you accidentally import `RouterProvider` from `react-router`?");let{basename:r}=lv("useViewTransitionState"),s=ys(e,{relative:i.relative});if(!a.isTransitioning)return!1;let c=Zi(a.currentLocation.pathname,r)||a.currentLocation.pathname,u=Zi(a.nextLocation.pathname,r)||a.nextLocation.pathname;return uc(s.pathname,u)!=null||uc(s.pathname,c)!=null}[...LS];var dt=function(){return dt=Object.assign||function(i){for(var a,r=1,s=arguments.length;r<s;r++){a=arguments[r];for(var c in a)Object.prototype.hasOwnProperty.call(a,c)&&(i[c]=a[c])}return i},dt.apply(this,arguments)};function mr(e,i,a){if(a||arguments.length===2)for(var r=0,s=i.length,c;r<s;r++)(c||!(r in i))&&(c||(c=Array.prototype.slice.call(i,0,r)),c[r]=i[r]);return e.concat(c||Array.prototype.slice.call(i))}var Ve="-ms-",Go="-moz-",ke="-webkit-",cv="comm",Mc="rule",lp="decl",t7="@import",uv="@keyframes",i7="@layer",dv=Math.abs,cp=String.fromCharCode,yh=Object.assign;function n7(e,i){return ut(e,0)^45?(((i<<2^ut(e,0))<<2^ut(e,1))<<2^ut(e,2))<<2^ut(e,3):0}function fv(e){return e.trim()}function Gi(e,i){return(e=i.exec(e))?e[0]:e}function ye(e,i,a){return e.replace(i,a)}function Jl(e,i,a){return e.indexOf(i,a)}function ut(e,i){return e.charCodeAt(i)|0}function gr(e,i,a){return e.slice(i,a)}function Ti(e){return e.length}function hv(e){return e.length}function Fo(e,i){return i.push(e),e}function a7(e,i){return e.map(i).join("")}function fy(e,i){return e.filter(function(a){return!Gi(a,i)})}var Bc=1,yr=1,pv=0,ni=0,it=0,Or="";function zc(e,i,a,r,s,c,u,f){return{value:e,root:i,parent:a,type:r,props:s,children:c,line:Bc,column:yr,length:u,return:"",siblings:f}}function En(e,i){return yh(zc("",null,null,"",null,null,0,e.siblings),e,{length:-e.length},i)}function Qa(e){for(;e.root;)e=En(e.root,{children:[e]});Fo(e,e.siblings)}function r7(){return it}function o7(){return it=ni>0?ut(Or,--ni):0,yr--,it===10&&(yr=1,Bc--),it}function ci(){return it=ni<pv?ut(Or,ni++):0,yr++,it===10&&(yr=1,Bc++),it}function na(){return ut(Or,ni)}function Wl(){return ni}function $c(e,i){return gr(Or,e,i)}function xh(e){switch(e){case 0:case 9:case 10:case 13:case 32:return 5;case 33:case 43:case 44:case 47:case 62:case 64:case 126:case 59:case 123:case 125:return 4;case 58:return 3;case 34:case 39:case 40:case 91:return 2;case 41:case 93:return 1}return 0}function s7(e){return Bc=yr=1,pv=Ti(Or=e),ni=0,[]}function l7(e){return Or="",e}function hf(e){return fv($c(ni-1,bh(e===91?e+2:e===40?e+1:e)))}function c7(e){for(;(it=na())&&it<33;)ci();return xh(e)>2||xh(it)>3?"":" "}function u7(e,i){for(;--i&&ci()&&!(it<48||it>102||it>57&&it<65||it>70&&it<97););return $c(e,Wl()+(i<6&&na()==32&&ci()==32))}function bh(e){for(;ci();)switch(it){case e:return ni;case 34:case 39:e!==34&&e!==39&&bh(it);break;case 40:e===41&&bh(e);break;case 92:ci();break}return ni}function d7(e,i){for(;ci()&&e+it!==57;)if(e+it===84&&na()===47)break;return"/*"+$c(i,ni-1)+"*"+cp(e===47?e:ci())}function f7(e){for(;!xh(na());)ci();return $c(e,ni)}function h7(e){return l7(ec("",null,null,null,[""],e=s7(e),0,[0],e))}function ec(e,i,a,r,s,c,u,f,p){for(var m=0,y=0,x=u,b=0,T=0,A=0,C=1,B=1,E=1,k=0,M="",F=s,D=c,U=r,G=M;B;)switch(A=k,k=ci()){case 40:if(A!=108&&ut(G,x-1)==58){Jl(G+=ye(hf(k),"&","&\f"),"&\f",dv(m?f[m-1]:0))!=-1&&(E=-1);break}case 34:case 39:case 91:G+=hf(k);break;case 9:case 10:case 13:case 32:G+=c7(A);break;case 92:G+=u7(Wl()-1,7);continue;case 47:switch(na()){case 42:case 47:Fo(p7(d7(ci(),Wl()),i,a,p),p);break;default:G+="/"}break;case 123*C:f[m++]=Ti(G)*E;case 125*C:case 59:case 0:switch(k){case 0:case 125:B=0;case 59+y:E==-1&&(G=ye(G,/\f/g,"")),T>0&&Ti(G)-x&&Fo(T>32?py(G+";",r,a,x-1,p):py(ye(G," ","")+";",r,a,x-2,p),p);break;case 59:G+=";";default:if(Fo(U=hy(G,i,a,m,y,s,f,M,F=[],D=[],x,c),c),k===123)if(y===0)ec(G,i,U,U,F,c,x,f,D);else switch(b===99&&ut(G,3)===110?100:b){case 100:case 108:case 109:case 115:ec(e,U,U,r&&Fo(hy(e,U,U,0,0,s,f,M,s,F=[],x,D),D),s,D,x,f,r?F:D);break;default:ec(G,U,U,U,[""],D,0,f,D)}}m=y=T=0,C=E=1,M=G="",x=u;break;case 58:x=1+Ti(G),T=A;default:if(C<1){if(k==123)--C;else if(k==125&&C++==0&&o7()==125)continue}switch(G+=cp(k),k*C){case 38:E=y>0?1:(G+="\f",-1);break;case 44:f[m++]=(Ti(G)-1)*E,E=1;break;case 64:na()===45&&(G+=hf(ci())),b=na(),y=x=Ti(M=G+=f7(Wl())),k++;break;case 45:A===45&&Ti(G)==2&&(C=0)}}return c}function hy(e,i,a,r,s,c,u,f,p,m,y,x){for(var b=s-1,T=s===0?c:[""],A=hv(T),C=0,B=0,E=0;C<r;++C)for(var k=0,M=gr(e,b+1,b=dv(B=u[C])),F=e;k<A;++k)(F=fv(B>0?T[k]+" "+M:ye(M,/&\f/g,T[k])))&&(p[E++]=F);return zc(e,i,a,s===0?Mc:f,p,m,y,x)}function p7(e,i,a,r){return zc(e,i,a,cv,cp(r7()),gr(e,2,-2),0,r)}function py(e,i,a,r,s){return zc(e,i,a,lp,gr(e,0,r),gr(e,r+1,-1),r,s)}function mv(e,i,a){switch(n7(e,i)){case 5103:return ke+"print-"+e+e;case 5737:case 4201:case 3177:case 3433:case 1641:case 4457:case 2921:case 5572:case 6356:case 5844:case 3191:case 6645:case 3005:case 6391:case 5879:case 5623:case 6135:case 4599:case 4855:case 4215:case 6389:case 5109:case 5365:case 5621:case 3829:return ke+e+e;case 4789:return Go+e+e;case 5349:case 4246:case 4810:case 6968:case 2756:return ke+e+Go+e+Ve+e+e;case 5936:switch(ut(e,i+11)){case 114:return ke+e+Ve+ye(e,/[svh]\w+-[tblr]{2}/,"tb")+e;case 108:return ke+e+Ve+ye(e,/[svh]\w+-[tblr]{2}/,"tb-rl")+e;case 45:return ke+e+Ve+ye(e,/[svh]\w+-[tblr]{2}/,"lr")+e}case 6828:case 4268:case 2903:return ke+e+Ve+e+e;case 6165:return ke+e+Ve+"flex-"+e+e;case 5187:return ke+e+ye(e,/(\w+).+(:[^]+)/,ke+"box-$1$2"+Ve+"flex-$1$2")+e;case 5443:return ke+e+Ve+"flex-item-"+ye(e,/flex-|-self/g,"")+(Gi(e,/flex-|baseline/)?"":Ve+"grid-row-"+ye(e,/flex-|-self/g,""))+e;case 4675:return ke+e+Ve+"flex-line-pack"+ye(e,/align-content|flex-|-self/g,"")+e;case 5548:return ke+e+Ve+ye(e,"shrink","negative")+e;case 5292:return ke+e+Ve+ye(e,"basis","preferred-size")+e;case 6060:return ke+"box-"+ye(e,"-grow","")+ke+e+Ve+ye(e,"grow","positive")+e;case 4554:return ke+ye(e,/([^-])(transform)/g,"$1"+ke+"$2")+e;case 6187:return ye(ye(ye(e,/(zoom-|grab)/,ke+"$1"),/(image-set)/,ke+"$1"),e,"")+e;case 5495:case 3959:return ye(e,/(image-set\([^]*)/,ke+"$1$`$1");case 4968:return ye(ye(e,/(.+:)(flex-)?(.*)/,ke+"box-pack:$3"+Ve+"flex-pack:$3"),/s.+-b[^;]+/,"justify")+ke+e+e;case 4200:if(!Gi(e,/flex-|baseline/))return Ve+"grid-column-align"+gr(e,i)+e;break;case 2592:case 3360:return Ve+ye(e,"template-","")+e;case 4384:case 3616:return a&&a.some(function(r,s){return i=s,Gi(r.props,/grid-\w+-end/)})?~Jl(e+(a=a[i].value),"span",0)?e:Ve+ye(e,"-start","")+e+Ve+"grid-row-span:"+(~Jl(a,"span",0)?Gi(a,/\d+/):+Gi(a,/\d+/)-+Gi(e,/\d+/))+";":Ve+ye(e,"-start","")+e;case 4896:case 4128:return a&&a.some(function(r){return Gi(r.props,/grid-\w+-start/)})?e:Ve+ye(ye(e,"-end","-span"),"span ","")+e;case 4095:case 3583:case 4068:case 2532:return ye(e,/(.+)-inline(.+)/,ke+"$1$2")+e;case 8116:case 7059:case 5753:case 5535:case 5445:case 5701:case 4933:case 4677:case 5533:case 5789:case 5021:case 4765:if(Ti(e)-1-i>6)switch(ut(e,i+1)){case 109:if(ut(e,i+4)!==45)break;case 102:return ye(e,/(.+:)(.+)-([^]+)/,"$1"+ke+"$2-$3$1"+Go+(ut(e,i+3)==108?"$3":"$2-$3"))+e;case 115:return~Jl(e,"stretch",0)?mv(ye(e,"stretch","fill-available"),i,a)+e:e}break;case 5152:case 5920:return ye(e,/(.+?):(\d+)(\s*\/\s*(span)?\s*(\d+))?(.*)/,function(r,s,c,u,f,p,m){return Ve+s+":"+c+m+(u?Ve+s+"-span:"+(f?p:+p-+c)+m:"")+e});case 4949:if(ut(e,i+6)===121)return ye(e,":",":"+ke)+e;break;case 6444:switch(ut(e,ut(e,14)===45?18:11)){case 120:return ye(e,/(.+:)([^;\s!]+)(;|(\s+)?!.+)?/,"$1"+ke+(ut(e,14)===45?"inline-":"")+"box$3$1"+ke+"$2$3$1"+Ve+"$2box$3")+e;case 100:return ye(e,":",":"+Ve)+e}break;case 5719:case 2647:case 2135:case 3927:case 2391:return ye(e,"scroll-","scroll-snap-")+e}return e}function dc(e,i){for(var a="",r=0;r<e.length;r++)a+=i(e[r],r,e,i)||"";return a}function m7(e,i,a,r){switch(e.type){case i7:if(e.children.length)break;case t7:case lp:return e.return=e.return||e.value;case cv:return"";case uv:return e.return=e.value+"{"+dc(e.children,r)+"}";case Mc:if(!Ti(e.value=e.props.join(",")))return""}return Ti(a=dc(e.children,r))?e.return=e.value+"{"+a+"}":""}function g7(e){var i=hv(e);return function(a,r,s,c){for(var u="",f=0;f<i;f++)u+=e[f](a,r,s,c)||"";return u}}function y7(e){return function(i){i.root||(i=i.return)&&e(i)}}function x7(e,i,a,r){if(e.length>-1&&!e.return)switch(e.type){case lp:e.return=mv(e.value,e.length,a);return;case uv:return dc([En(e,{value:ye(e.value,"@","@"+ke)})],r);case Mc:if(e.length)return a7(a=e.props,function(s){switch(Gi(s,r=/(::plac\w+|:read-\w+)/)){case":read-only":case":read-write":Qa(En(e,{props:[ye(s,/:(read-\w+)/,":"+Go+"$1")]})),Qa(En(e,{props:[s]})),yh(e,{props:fy(a,r)});break;case"::placeholder":Qa(En(e,{props:[ye(s,/:(plac\w+)/,":"+ke+"input-$1")]})),Qa(En(e,{props:[ye(s,/:(plac\w+)/,":"+Go+"$1")]})),Qa(En(e,{props:[ye(s,/:(plac\w+)/,Ve+"input-$1")]})),Qa(En(e,{props:[s]})),yh(e,{props:fy(a,r)});break}return""})}}var b7={animationIterationCount:1,aspectRatio:1,borderImageOutset:1,borderImageSlice:1,borderImageWidth:1,boxFlex:1,boxFlexGroup:1,boxOrdinalGroup:1,columnCount:1,columns:1,flex:1,flexGrow:1,flexPositive:1,flexShrink:1,flexNegative:1,flexOrder:1,gridRow:1,gridRowEnd:1,gridRowSpan:1,gridRowStart:1,gridColumn:1,gridColumnEnd:1,gridColumnSpan:1,gridColumnStart:1,msGridRow:1,msGridRowSpan:1,msGridColumn:1,msGridColumnSpan:1,fontWeight:1,lineHeight:1,opacity:1,order:1,orphans:1,tabSize:1,widows:1,zIndex:1,zoom:1,WebkitLineClamp:1,fillOpacity:1,floodOpacity:1,stopOpacity:1,strokeDasharray:1,strokeDashoffset:1,strokeMiterlimit:1,strokeOpacity:1,strokeWidth:1},Ft={},xr=typeof process<"u"&&Ft!==void 0&&(Ft.REACT_APP_SC_ATTR||Ft.SC_ATTR)||"data-styled",gv="active",yv="data-styled-version",Nc="6.1.18",up=`/*!sc*/
`,fc=typeof window<"u"&&typeof document<"u",v7=!!(typeof SC_DISABLE_SPEEDY=="boolean"?SC_DISABLE_SPEEDY:typeof process<"u"&&Ft!==void 0&&Ft.REACT_APP_SC_DISABLE_SPEEDY!==void 0&&Ft.REACT_APP_SC_DISABLE_SPEEDY!==""?Ft.REACT_APP_SC_DISABLE_SPEEDY!=="false"&&Ft.REACT_APP_SC_DISABLE_SPEEDY:typeof process<"u"&&Ft!==void 0&&Ft.SC_DISABLE_SPEEDY!==void 0&&Ft.SC_DISABLE_SPEEDY!==""&&Ft.SC_DISABLE_SPEEDY!=="false"&&Ft.SC_DISABLE_SPEEDY),w7={},Lc=Object.freeze([]),br=Object.freeze({});function xv(e,i,a){return a===void 0&&(a=br),e.theme!==a.theme&&e.theme||i||a.theme}var bv=new Set(["a","abbr","address","area","article","aside","audio","b","base","bdi","bdo","big","blockquote","body","br","button","canvas","caption","cite","code","col","colgroup","data","datalist","dd","del","details","dfn","dialog","div","dl","dt","em","embed","fieldset","figcaption","figure","footer","form","h1","h2","h3","h4","h5","h6","header","hgroup","hr","html","i","iframe","img","input","ins","kbd","keygen","label","legend","li","link","main","map","mark","menu","menuitem","meta","meter","nav","noscript","object","ol","optgroup","option","output","p","param","picture","pre","progress","q","rp","rt","ruby","s","samp","script","section","select","small","source","span","strong","style","sub","summary","sup","table","tbody","td","textarea","tfoot","th","thead","time","tr","track","u","ul","use","var","video","wbr","circle","clipPath","defs","ellipse","foreignObject","g","image","line","linearGradient","marker","mask","path","pattern","polygon","polyline","radialGradient","rect","stop","svg","text","tspan"]),S7=/[!"#$%&'()*+,./:;<=>?@[\\\]^`{|}~-]+/g,T7=/(^-|-$)/g;function my(e){return e.replace(S7,"-").replace(T7,"")}var j7=/(a)(d)/gi,_l=52,gy=function(e){return String.fromCharCode(e+(e>25?39:97))};function vh(e){var i,a="";for(i=Math.abs(e);i>_l;i=i/_l|0)a=gy(i%_l)+a;return(gy(i%_l)+a).replace(j7,"$1-$2")}var pf,vv=5381,sr=function(e,i){for(var a=i.length;a;)e=33*e^i.charCodeAt(--a);return e},wv=function(e){return sr(vv,e)};function dp(e){return vh(wv(e)>>>0)}function A7(e){return e.displayName||e.name||"Component"}function mf(e){return typeof e=="string"&&!0}var Sv=typeof Symbol=="function"&&Symbol.for,Tv=Sv?Symbol.for("react.memo"):60115,E7=Sv?Symbol.for("react.forward_ref"):60112,C7={childContextTypes:!0,contextType:!0,contextTypes:!0,defaultProps:!0,displayName:!0,getDefaultProps:!0,getDerivedStateFromError:!0,getDerivedStateFromProps:!0,mixins:!0,propTypes:!0,type:!0},O7={name:!0,length:!0,prototype:!0,caller:!0,callee:!0,arguments:!0,arity:!0},jv={$$typeof:!0,compare:!0,defaultProps:!0,displayName:!0,propTypes:!0,type:!0},R7=((pf={})[E7]={$$typeof:!0,render:!0,defaultProps:!0,displayName:!0,propTypes:!0},pf[Tv]=jv,pf);function yy(e){return("type"in(i=e)&&i.type.$$typeof)===Tv?jv:"$$typeof"in e?R7[e.$$typeof]:C7;var i}var k7=Object.defineProperty,D7=Object.getOwnPropertyNames,xy=Object.getOwnPropertySymbols,M7=Object.getOwnPropertyDescriptor,B7=Object.getPrototypeOf,by=Object.prototype;function Av(e,i,a){if(typeof i!="string"){if(by){var r=B7(i);r&&r!==by&&Av(e,r,a)}var s=D7(i);xy&&(s=s.concat(xy(i)));for(var c=yy(e),u=yy(i),f=0;f<s.length;++f){var p=s[f];if(!(p in O7||a&&a[p]||u&&p in u||c&&p in c)){var m=M7(i,p);try{k7(e,p,m)}catch{}}}}return e}function la(e){return typeof e=="function"}function fp(e){return typeof e=="object"&&"styledComponentId"in e}function ea(e,i){return e&&i?"".concat(e," ").concat(i):e||i||""}function hc(e,i){if(e.length===0)return"";for(var a=e[0],r=1;r<e.length;r++)a+=e[r];return a}function is(e){return e!==null&&typeof e=="object"&&e.constructor.name===Object.name&&!("props"in e&&e.$$typeof)}function wh(e,i,a){if(a===void 0&&(a=!1),!a&&!is(e)&&!Array.isArray(e))return i;if(Array.isArray(i))for(var r=0;r<i.length;r++)e[r]=wh(e[r],i[r]);else if(is(i))for(var r in i)e[r]=wh(e[r],i[r]);return e}function hp(e,i){Object.defineProperty(e,"toString",{value:i})}function ca(e){for(var i=[],a=1;a<arguments.length;a++)i[a-1]=arguments[a];return new Error("An error occurred. See https://github.com/styled-components/styled-components/blob/main/packages/styled-components/src/utils/errors.md#".concat(e," for more information.").concat(i.length>0?" Args: ".concat(i.join(", ")):""))}var z7=function(){function e(i){this.groupSizes=new Uint32Array(512),this.length=512,this.tag=i}return e.prototype.indexOfGroup=function(i){for(var a=0,r=0;r<i;r++)a+=this.groupSizes[r];return a},e.prototype.insertRules=function(i,a){if(i>=this.groupSizes.length){for(var r=this.groupSizes,s=r.length,c=s;i>=c;)if((c<<=1)<0)throw ca(16,"".concat(i));this.groupSizes=new Uint32Array(c),this.groupSizes.set(r),this.length=c;for(var u=s;u<c;u++)this.groupSizes[u]=0}for(var f=this.indexOfGroup(i+1),p=(u=0,a.length);u<p;u++)this.tag.insertRule(f,a[u])&&(this.groupSizes[i]++,f++)},e.prototype.clearGroup=function(i){if(i<this.length){var a=this.groupSizes[i],r=this.indexOfGroup(i),s=r+a;this.groupSizes[i]=0;for(var c=r;c<s;c++)this.tag.deleteRule(r)}},e.prototype.getGroup=function(i){var a="";if(i>=this.length||this.groupSizes[i]===0)return a;for(var r=this.groupSizes[i],s=this.indexOfGroup(i),c=s+r,u=s;u<c;u++)a+="".concat(this.tag.getRule(u)).concat(up);return a},e}(),tc=new Map,pc=new Map,ic=1,Hl=function(e){if(tc.has(e))return tc.get(e);for(;pc.has(ic);)ic++;var i=ic++;return tc.set(e,i),pc.set(i,e),i},$7=function(e,i){ic=i+1,tc.set(e,i),pc.set(i,e)},N7="style[".concat(xr,"][").concat(yv,'="').concat(Nc,'"]'),L7=new RegExp("^".concat(xr,'\\.g(\\d+)\\[id="([\\w\\d-]+)"\\].*?"([^"]*)')),_7=function(e,i,a){for(var r,s=a.split(","),c=0,u=s.length;c<u;c++)(r=s[c])&&e.registerName(i,r)},H7=function(e,i){for(var a,r=((a=i.textContent)!==null&&a!==void 0?a:"").split(up),s=[],c=0,u=r.length;c<u;c++){var f=r[c].trim();if(f){var p=f.match(L7);if(p){var m=0|parseInt(p[1],10),y=p[2];m!==0&&($7(y,m),_7(e,y,p[3]),e.getTag().insertRules(m,s)),s.length=0}else s.push(f)}}},vy=function(e){for(var i=document.querySelectorAll(N7),a=0,r=i.length;a<r;a++){var s=i[a];s&&s.getAttribute(xr)!==gv&&(H7(e,s),s.parentNode&&s.parentNode.removeChild(s))}};function V7(){return typeof __webpack_nonce__<"u"?__webpack_nonce__:null}var Ev=function(e){var i=document.head,a=e||i,r=document.createElement("style"),s=function(f){var p=Array.from(f.querySelectorAll("style[".concat(xr,"]")));return p[p.length-1]}(a),c=s!==void 0?s.nextSibling:null;r.setAttribute(xr,gv),r.setAttribute(yv,Nc);var u=V7();return u&&r.setAttribute("nonce",u),a.insertBefore(r,c),r},P7=function(){function e(i){this.element=Ev(i),this.element.appendChild(document.createTextNode("")),this.sheet=function(a){if(a.sheet)return a.sheet;for(var r=document.styleSheets,s=0,c=r.length;s<c;s++){var u=r[s];if(u.ownerNode===a)return u}throw ca(17)}(this.element),this.length=0}return e.prototype.insertRule=function(i,a){try{return this.sheet.insertRule(a,i),this.length++,!0}catch{return!1}},e.prototype.deleteRule=function(i){this.sheet.deleteRule(i),this.length--},e.prototype.getRule=function(i){var a=this.sheet.cssRules[i];return a&&a.cssText?a.cssText:""},e}(),F7=function(){function e(i){this.element=Ev(i),this.nodes=this.element.childNodes,this.length=0}return e.prototype.insertRule=function(i,a){if(i<=this.length&&i>=0){var r=document.createTextNode(a);return this.element.insertBefore(r,this.nodes[i]||null),this.length++,!0}return!1},e.prototype.deleteRule=function(i){this.element.removeChild(this.nodes[i]),this.length--},e.prototype.getRule=function(i){return i<this.length?this.nodes[i].textContent:""},e}(),U7=function(){function e(i){this.rules=[],this.length=0}return e.prototype.insertRule=function(i,a){return i<=this.length&&(this.rules.splice(i,0,a),this.length++,!0)},e.prototype.deleteRule=function(i){this.rules.splice(i,1),this.length--},e.prototype.getRule=function(i){return i<this.length?this.rules[i]:""},e}(),wy=fc,q7={isServer:!fc,useCSSOMInjection:!v7},mc=function(){function e(i,a,r){i===void 0&&(i=br),a===void 0&&(a={});var s=this;this.options=dt(dt({},q7),i),this.gs=a,this.names=new Map(r),this.server=!!i.isServer,!this.server&&fc&&wy&&(wy=!1,vy(this)),hp(this,function(){return function(c){for(var u=c.getTag(),f=u.length,p="",m=function(x){var b=function(E){return pc.get(E)}(x);if(b===void 0)return"continue";var T=c.names.get(b),A=u.getGroup(x);if(T===void 0||!T.size||A.length===0)return"continue";var C="".concat(xr,".g").concat(x,'[id="').concat(b,'"]'),B="";T!==void 0&&T.forEach(function(E){E.length>0&&(B+="".concat(E,","))}),p+="".concat(A).concat(C,'{content:"').concat(B,'"}').concat(up)},y=0;y<f;y++)m(y);return p}(s)})}return e.registerId=function(i){return Hl(i)},e.prototype.rehydrate=function(){!this.server&&fc&&vy(this)},e.prototype.reconstructWithOptions=function(i,a){return a===void 0&&(a=!0),new e(dt(dt({},this.options),i),this.gs,a&&this.names||void 0)},e.prototype.allocateGSInstance=function(i){return this.gs[i]=(this.gs[i]||0)+1},e.prototype.getTag=function(){return this.tag||(this.tag=(i=function(a){var r=a.useCSSOMInjection,s=a.target;return a.isServer?new U7(s):r?new P7(s):new F7(s)}(this.options),new z7(i)));var i},e.prototype.hasNameForId=function(i,a){return this.names.has(i)&&this.names.get(i).has(a)},e.prototype.registerName=function(i,a){if(Hl(i),this.names.has(i))this.names.get(i).add(a);else{var r=new Set;r.add(a),this.names.set(i,r)}},e.prototype.insertRules=function(i,a,r){this.registerName(i,a),this.getTag().insertRules(Hl(i),r)},e.prototype.clearNames=function(i){this.names.has(i)&&this.names.get(i).clear()},e.prototype.clearRules=function(i){this.getTag().clearGroup(Hl(i)),this.clearNames(i)},e.prototype.clearTag=function(){this.tag=void 0},e}(),I7=/&/g,Y7=/^\s*\/\/.*$/gm;function Cv(e,i){return e.map(function(a){return a.type==="rule"&&(a.value="".concat(i," ").concat(a.value),a.value=a.value.replaceAll(",",",".concat(i," ")),a.props=a.props.map(function(r){return"".concat(i," ").concat(r)})),Array.isArray(a.children)&&a.type!=="@keyframes"&&(a.children=Cv(a.children,i)),a})}function G7(e){var i,a,r,s=br,c=s.options,u=c===void 0?br:c,f=s.plugins,p=f===void 0?Lc:f,m=function(b,T,A){return A.startsWith(a)&&A.endsWith(a)&&A.replaceAll(a,"").length>0?".".concat(i):b},y=p.slice();y.push(function(b){b.type===Mc&&b.value.includes("&")&&(b.props[0]=b.props[0].replace(I7,a).replace(r,m))}),u.prefix&&y.push(x7),y.push(m7);var x=function(b,T,A,C){T===void 0&&(T=""),A===void 0&&(A=""),C===void 0&&(C="&"),i=C,a=T,r=new RegExp("\\".concat(a,"\\b"),"g");var B=b.replace(Y7,""),E=h7(A||T?"".concat(A," ").concat(T," { ").concat(B," }"):B);u.namespace&&(E=Cv(E,u.namespace));var k=[];return dc(E,g7(y.concat(y7(function(M){return k.push(M)})))),k};return x.hash=p.length?p.reduce(function(b,T){return T.name||ca(15),sr(b,T.name)},vv).toString():"",x}var K7=new mc,Sh=G7(),Ov=Ce.createContext({shouldForwardProp:void 0,styleSheet:K7,stylis:Sh});Ov.Consumer;Ce.createContext(void 0);function Th(){return S.useContext(Ov)}var Rv=function(){function e(i,a){var r=this;this.inject=function(s,c){c===void 0&&(c=Sh);var u=r.name+c.hash;s.hasNameForId(r.id,u)||s.insertRules(r.id,u,c(r.rules,u,"@keyframes"))},this.name=i,this.id="sc-keyframes-".concat(i),this.rules=a,hp(this,function(){throw ca(12,String(r.name))})}return e.prototype.getName=function(i){return i===void 0&&(i=Sh),this.name+i.hash},e}(),X7=function(e){return e>="A"&&e<="Z"};function Sy(e){for(var i="",a=0;a<e.length;a++){var r=e[a];if(a===1&&r==="-"&&e[0]==="-")return e;X7(r)?i+="-"+r.toLowerCase():i+=r}return i.startsWith("ms-")?"-"+i:i}var kv=function(e){return e==null||e===!1||e===""},Dv=function(e){var i,a,r=[];for(var s in e){var c=e[s];e.hasOwnProperty(s)&&!kv(c)&&(Array.isArray(c)&&c.isCss||la(c)?r.push("".concat(Sy(s),":"),c,";"):is(c)?r.push.apply(r,mr(mr(["".concat(s," {")],Dv(c),!1),["}"],!1)):r.push("".concat(Sy(s),": ").concat((i=s,(a=c)==null||typeof a=="boolean"||a===""?"":typeof a!="number"||a===0||i in b7||i.startsWith("--")?String(a).trim():"".concat(a,"px")),";")))}return r};function On(e,i,a,r){if(kv(e))return[];if(fp(e))return[".".concat(e.styledComponentId)];if(la(e)){if(!la(c=e)||c.prototype&&c.prototype.isReactComponent||!i)return[e];var s=e(i);return On(s,i,a,r)}var c;return e instanceof Rv?a?(e.inject(a,r),[e.getName(r)]):[e]:is(e)?Dv(e):Array.isArray(e)?Array.prototype.concat.apply(Lc,e.map(function(u){return On(u,i,a,r)})):[e.toString()]}function Mv(e){for(var i=0;i<e.length;i+=1){var a=e[i];if(la(a)&&!fp(a))return!1}return!0}var Z7=wv(Nc),Q7=function(){function e(i,a,r){this.rules=i,this.staticRulesId="",this.isStatic=(r===void 0||r.isStatic)&&Mv(i),this.componentId=a,this.baseHash=sr(Z7,a),this.baseStyle=r,mc.registerId(a)}return e.prototype.generateAndInjectStyles=function(i,a,r){var s=this.baseStyle?this.baseStyle.generateAndInjectStyles(i,a,r):"";if(this.isStatic&&!r.hash)if(this.staticRulesId&&a.hasNameForId(this.componentId,this.staticRulesId))s=ea(s,this.staticRulesId);else{var c=hc(On(this.rules,i,a,r)),u=vh(sr(this.baseHash,c)>>>0);if(!a.hasNameForId(this.componentId,u)){var f=r(c,".".concat(u),void 0,this.componentId);a.insertRules(this.componentId,u,f)}s=ea(s,u),this.staticRulesId=u}else{for(var p=sr(this.baseHash,r.hash),m="",y=0;y<this.rules.length;y++){var x=this.rules[y];if(typeof x=="string")m+=x;else if(x){var b=hc(On(x,i,a,r));p=sr(p,b+y),m+=b}}if(m){var T=vh(p>>>0);a.hasNameForId(this.componentId,T)||a.insertRules(this.componentId,T,r(m,".".concat(T),void 0,this.componentId)),s=ea(s,T)}}return s},e}(),ns=Ce.createContext(void 0);ns.Consumer;function J7(e){var i=Ce.useContext(ns),a=S.useMemo(function(){return function(r,s){if(!r)throw ca(14);if(la(r)){var c=r(s);return c}if(Array.isArray(r)||typeof r!="object")throw ca(8);return s?dt(dt({},s),r):r}(e.theme,i)},[e.theme,i]);return e.children?Ce.createElement(ns.Provider,{value:a},e.children):null}var gf={};function W7(e,i,a){var r=fp(e),s=e,c=!mf(e),u=i.attrs,f=u===void 0?Lc:u,p=i.componentId,m=p===void 0?function(F,D){var U=typeof F!="string"?"sc":my(F);gf[U]=(gf[U]||0)+1;var G="".concat(U,"-").concat(dp(Nc+U+gf[U]));return D?"".concat(D,"-").concat(G):G}(i.displayName,i.parentComponentId):p,y=i.displayName,x=y===void 0?function(F){return mf(F)?"styled.".concat(F):"Styled(".concat(A7(F),")")}(e):y,b=i.displayName&&i.componentId?"".concat(my(i.displayName),"-").concat(i.componentId):i.componentId||m,T=r&&s.attrs?s.attrs.concat(f).filter(Boolean):f,A=i.shouldForwardProp;if(r&&s.shouldForwardProp){var C=s.shouldForwardProp;if(i.shouldForwardProp){var B=i.shouldForwardProp;A=function(F,D){return C(F,D)&&B(F,D)}}else A=C}var E=new Q7(a,b,r?s.componentStyle:void 0);function k(F,D){return function(U,G,Z){var J=U.attrs,ie=U.componentStyle,oe=U.defaultProps,xe=U.foldedComponentIds,Le=U.styledComponentId,ne=U.target,we=Ce.useContext(ns),P=Th(),X=U.shouldForwardProp||P.shouldForwardProp,ee=xv(G,we,oe)||br,fe=function(ge,le,rt){for(var Oe,gt=dt(dt({},le),{className:void 0,theme:rt}),Bn=0;Bn<ge.length;Bn+=1){var Ri=la(Oe=ge[Bn])?Oe(gt):Oe;for(var qt in Ri)gt[qt]=qt==="className"?ea(gt[qt],Ri[qt]):qt==="style"?dt(dt({},gt[qt]),Ri[qt]):Ri[qt]}return le.className&&(gt.className=ea(gt.className,le.className)),gt}(J,G,ee),z=fe.as||ne,q={};for(var Q in fe)fe[Q]===void 0||Q[0]==="$"||Q==="as"||Q==="theme"&&fe.theme===ee||(Q==="forwardedAs"?q.as=fe.forwardedAs:X&&!X(Q,z)||(q[Q]=fe[Q]));var W=function(ge,le){var rt=Th(),Oe=ge.generateAndInjectStyles(le,rt.styleSheet,rt.stylis);return Oe}(ie,fe),ae=ea(xe,Le);return W&&(ae+=" "+W),fe.className&&(ae+=" "+fe.className),q[mf(z)&&!bv.has(z)?"class":"className"]=ae,Z&&(q.ref=Z),S.createElement(z,q)}(M,F,D)}k.displayName=x;var M=Ce.forwardRef(k);return M.attrs=T,M.componentStyle=E,M.displayName=x,M.shouldForwardProp=A,M.foldedComponentIds=r?ea(s.foldedComponentIds,s.styledComponentId):"",M.styledComponentId=b,M.target=r?s.target:e,Object.defineProperty(M,"defaultProps",{get:function(){return this._foldedDefaultProps},set:function(F){this._foldedDefaultProps=r?function(D){for(var U=[],G=1;G<arguments.length;G++)U[G-1]=arguments[G];for(var Z=0,J=U;Z<J.length;Z++)wh(D,J[Z],!0);return D}({},s.defaultProps,F):F}}),hp(M,function(){return".".concat(M.styledComponentId)}),c&&Av(M,e,{attrs:!0,componentStyle:!0,displayName:!0,foldedComponentIds:!0,shouldForwardProp:!0,styledComponentId:!0,target:!0}),M}function Ty(e,i){for(var a=[e[0]],r=0,s=i.length;r<s;r+=1)a.push(i[r],e[r+1]);return a}var jy=function(e){return Object.assign(e,{isCss:!0})};function pp(e){for(var i=[],a=1;a<arguments.length;a++)i[a-1]=arguments[a];if(la(e)||is(e))return jy(On(Ty(Lc,mr([e],i,!0))));var r=e;return i.length===0&&r.length===1&&typeof r[0]=="string"?On(r):jy(On(Ty(r,i)))}function jh(e,i,a){if(a===void 0&&(a=br),!i)throw ca(1,i);var r=function(s){for(var c=[],u=1;u<arguments.length;u++)c[u-1]=arguments[u];return e(i,a,pp.apply(void 0,mr([s],c,!1)))};return r.attrs=function(s){return jh(e,i,dt(dt({},a),{attrs:Array.prototype.concat(a.attrs,s).filter(Boolean)}))},r.withConfig=function(s){return jh(e,i,dt(dt({},a),s))},r}var Bv=function(e){return jh(W7,e)},w=Bv;bv.forEach(function(e){w[e]=Bv(e)});var e8=function(){function e(i,a){this.rules=i,this.componentId=a,this.isStatic=Mv(i),mc.registerId(this.componentId+1)}return e.prototype.createStyles=function(i,a,r,s){var c=s(hc(On(this.rules,a,r,s)),""),u=this.componentId+i;r.insertRules(u,u,c)},e.prototype.removeStyles=function(i,a){a.clearRules(this.componentId+i)},e.prototype.renderStyles=function(i,a,r,s){i>2&&mc.registerId(this.componentId+i),this.removeStyles(i,r),this.createStyles(i,a,r,s)},e}();function zv(e){for(var i=[],a=1;a<arguments.length;a++)i[a-1]=arguments[a];var r=pp.apply(void 0,mr([e],i,!1)),s="sc-global-".concat(dp(JSON.stringify(r))),c=new e8(r,s),u=function(p){var m=Th(),y=Ce.useContext(ns),x=Ce.useRef(m.styleSheet.allocateGSInstance(s)).current;return m.styleSheet.server&&f(x,p,m.styleSheet,y,m.stylis),Ce.useLayoutEffect(function(){if(!m.styleSheet.server)return f(x,p,m.styleSheet,y,m.stylis),function(){return c.removeStyles(x,m.styleSheet)}},[x,p,m.styleSheet,y,m.stylis]),null};function f(p,m,y,x,b){if(c.isStatic)c.renderStyles(p,w7,y,b);else{var T=dt(dt({},m),{theme:xv(m,x,u.defaultProps)});c.renderStyles(p,T,y,b)}}return Ce.memo(u)}function mp(e){for(var i=[],a=1;a<arguments.length;a++)i[a-1]=arguments[a];var r=hc(pp.apply(void 0,mr([e],i,!1))),s=dp(r);return new Rv(s,r)}const t8=(e,i,a,r)=>{var c,u,f,p;const s=[a,{code:i,...r||{}}];if((u=(c=e==null?void 0:e.services)==null?void 0:c.logger)!=null&&u.forward)return e.services.logger.forward(s,"warn","react-i18next::",!0);aa(s[0])&&(s[0]=`react-i18next:: ${s[0]}`),(p=(f=e==null?void 0:e.services)==null?void 0:f.logger)!=null&&p.warn?e.services.logger.warn(...s):console!=null&&console.warn&&console.warn(...s)},Ay={},Ah=(e,i,a,r)=>{aa(a)&&Ay[a]||(aa(a)&&(Ay[a]=new Date),t8(e,i,a,r))},$v=(e,i)=>()=>{if(e.isInitialized)i();else{const a=()=>{setTimeout(()=>{e.off("initialized",a)},0),i()};e.on("initialized",a)}},Eh=(e,i,a)=>{e.loadNamespaces(i,$v(e,a))},Ey=(e,i,a,r)=>{if(aa(a)&&(a=[a]),e.options.preload&&e.options.preload.indexOf(i)>-1)return Eh(e,a,r);a.forEach(s=>{e.options.ns.indexOf(s)<0&&e.options.ns.push(s)}),e.loadLanguages(i,$v(e,r))},i8=(e,i,a={})=>!i.languages||!i.languages.length?(Ah(i,"NO_LANGUAGES","i18n.languages were undefined or empty",{languages:i.languages}),!0):i.hasLoadedNamespace(e,{lng:a.lng,precheck:(r,s)=>{var c;if(((c=a.bindI18n)==null?void 0:c.indexOf("languageChanging"))>-1&&r.services.backendConnector.backend&&r.isLanguageChangingTo&&!s(r.isLanguageChangingTo,e))return!1}}),aa=e=>typeof e=="string",n8=e=>typeof e=="object"&&e!==null,a8=/&(?:amp|#38|lt|#60|gt|#62|apos|#39|quot|#34|nbsp|#160|copy|#169|reg|#174|hellip|#8230|#x2F|#47);/g,r8={"&amp;":"&","&#38;":"&","&lt;":"<","&#60;":"<","&gt;":">","&#62;":">","&apos;":"'","&#39;":"'","&quot;":'"',"&#34;":'"',"&nbsp;":" ","&#160;":" ","&copy;":"©","&#169;":"©","&reg;":"®","&#174;":"®","&hellip;":"…","&#8230;":"…","&#x2F;":"/","&#47;":"/"},o8=e=>r8[e],s8=e=>e.replace(a8,o8);let Ch={bindI18n:"languageChanged",bindI18nStore:"",transEmptyNodeValue:"",transSupportBasicHtmlNodes:!0,transWrapTextNodes:"",transKeepBasicHtmlNodesFor:["br","strong","i","p"],useSuspense:!0,unescape:s8};const l8=(e={})=>{Ch={...Ch,...e}},c8=()=>Ch;let Nv;const u8=e=>{Nv=e},d8=()=>Nv,f8={type:"3rdParty",init(e){l8(e.options.react),u8(e)}},h8=S.createContext();class p8{constructor(){this.usedNamespaces={}}addUsedNamespaces(i){i.forEach(a=>{this.usedNamespaces[a]||(this.usedNamespaces[a]=!0)})}getUsedNamespaces(){return Object.keys(this.usedNamespaces)}}const m8=(e,i)=>{const a=S.useRef();return S.useEffect(()=>{a.current=e},[e,i]),a.current},Lv=(e,i,a,r)=>e.getFixedT(i,a,r),g8=(e,i,a,r)=>S.useCallback(Lv(e,i,a,r),[e,i,a,r]),De=(e,i={})=>{var F,D,U,G;const{i18n:a}=i,{i18n:r,defaultNS:s}=S.useContext(h8)||{},c=a||r||d8();if(c&&!c.reportNamespaces&&(c.reportNamespaces=new p8),!c){Ah(c,"NO_I18NEXT_INSTANCE","useTranslation: You will need to pass in an i18next instance by using initReactI18next");const Z=(ie,oe)=>aa(oe)?oe:n8(oe)&&aa(oe.defaultValue)?oe.defaultValue:Array.isArray(ie)?ie[ie.length-1]:ie,J=[Z,{},!1];return J.t=Z,J.i18n={},J.ready=!1,J}(F=c.options.react)!=null&&F.wait&&Ah(c,"DEPRECATED_OPTION","useTranslation: It seems you are still using the old wait option, you may migrate to the new useSuspense behaviour.");const u={...c8(),...c.options.react,...i},{useSuspense:f,keyPrefix:p}=u;let m=s||((D=c.options)==null?void 0:D.defaultNS);m=aa(m)?[m]:m||["translation"],(G=(U=c.reportNamespaces).addUsedNamespaces)==null||G.call(U,m);const y=(c.isInitialized||c.initializedStoreOnce)&&m.every(Z=>i8(Z,c,u)),x=g8(c,i.lng||null,u.nsMode==="fallback"?m:m[0],p),b=()=>x,T=()=>Lv(c,i.lng||null,u.nsMode==="fallback"?m:m[0],p),[A,C]=S.useState(b);let B=m.join();i.lng&&(B=`${i.lng}${B}`);const E=m8(B),k=S.useRef(!0);S.useEffect(()=>{const{bindI18n:Z,bindI18nStore:J}=u;k.current=!0,!y&&!f&&(i.lng?Ey(c,i.lng,m,()=>{k.current&&C(T)}):Eh(c,m,()=>{k.current&&C(T)})),y&&E&&E!==B&&k.current&&C(T);const ie=()=>{k.current&&C(T)};return Z&&(c==null||c.on(Z,ie)),J&&(c==null||c.store.on(J,ie)),()=>{k.current=!1,c&&(Z==null||Z.split(" ").forEach(oe=>c.off(oe,ie))),J&&c&&J.split(" ").forEach(oe=>c.store.off(oe,ie))}},[c,B]),S.useEffect(()=>{k.current&&y&&C(b)},[c,p,y]);const M=[A,c,y];if(M.t=A,M.i18n=c,M.ready=y,y||!y&&!f)return M;throw new Promise(Z=>{i.lng?Ey(c,i.lng,m,()=>Z()):Eh(c,m,()=>Z())})},y8=zv`
  /* Импортируем шрифт KAIF */
  @font-face {
    font-family: 'KAIF';
    src: url('/src/assets/fonts/kaif.ttf') format('truetype');
    font-weight: normal;
    font-style: normal;
    font-display: swap;
  }

  /* Применяем Playfair Display ко всем элементам */
  body, 
  h1, h2, h3, h4, h5, h6,
  p, span, div, button, input, textarea, select, label, li {
    font-family: 'Playfair Display', Georgia, serif !important;
  }
  
  /* Специальные стили для навигации в хедере */
  header nav a {
    font-family: 'KAIF', 'Playfair Display', Georgia, serif !important;
  }
  
  /* Языковые настройки размера шрифта для хедера */
  /* Для русского и английского языков - уменьшенный шрифт */
  html[lang='ru'] header nav a,
  html[lang='en'] header nav a {
    font-size: 0.85rem !important;
  }
  
  /* Для тайского языка - увеличенный шрифт */
  html[lang='th'] header nav a {
    font-size: 1.05rem !important;
  }
  
  /* Настройки для мобильной навигации */
  html[lang='ru'] div[class*='MobileNavContainer'] a,
  html[lang='en'] div[class*='MobileNavContainer'] a {
    font-size: 1rem !important;
  }
  
  html[lang='th'] div[class*='MobileNavContainer'] a {
    font-size: 1.2rem !important;
  }
  
  /* Усиливаем вес для заголовков */
  h1, h2, h3, h4, h5, h6 {
    font-weight: 600;
  }
  
  /* Настраиваем вес для обычного текста */
  p, span, div, li {
    font-weight: 400;
  }
  
  /* Кнопки и интерактивные элементы */
  button, a, input, textarea, select, label {
    font-weight: 500;
  }
  
  /* Исключаем монолитные шрифты для кода */
  code, pre {
    font-family: 'JetBrains Mono', Consolas, monospace !important;
  }
`,x8="/assets/kaif-BKIoexQO.ttf",b8=zv`
  /* KAIF brand font */
  @font-face {
    font-family: 'KAIF';
    src: url(${x8}) format('truetype');
    font-weight: normal;
    font-style: normal;
    font-display: swap;
  }

  /* Стиль для исправления проблем с переходами между страницами */
  .route-transition {
    transform: translateZ(0);
    backface-visibility: hidden;
    perspective: 1000px;
    will-change: transform;
    contain: layout paint style;
    animation: fadeIn 0.5s ease forwards;
  }
  
  @keyframes fadeIn {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }

  /* Глобальное правило для сохранения стилей между страницами */
  * {
    box-sizing: border-box;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    transition: background-color 0.3s ease, border-color 0.3s ease, color 0.3s ease;
  }
  
  /* Базовые стили для всего сайта, основанные на теме */
  body {
    font-family: ${({theme:e})=>e.fonts.primary||'"Inter", sans-serif'};
    background-color: ${({theme:e})=>e.colors.background||"#FFFFFF"};
    color: ${({theme:e})=>e.colors.text.primary||"#2C3E2D"};
    margin: 0;
    padding: 0;
    overflow-x: hidden;
  }
  
  /* Типография */
  h1, h2, h3, h4, h5, h6 {
    font-family: ${({theme:e})=>e.fonts.heading||'"Playfair Display", serif'};
    font-weight: 600;
    color: ${({theme:e})=>e.colors.text.dark||"#1A2B1D"};
  }
  
  h1 {
    font-size: clamp(2.5rem, 6vw, 4rem);
    line-height: 1.2;
  }
  
  h2 {
    font-size: clamp(2rem, 5vw, 3rem);
    line-height: 1.25;
  }
  
  h3 {
    font-size: clamp(1.5rem, 4vw, 2.25rem);
    line-height: 1.3;
  }
  
  h4 {
    font-size: clamp(1.25rem, 3vw, 1.75rem);
    line-height: 1.35;
  }
  
  p {
    margin-bottom: 1rem;
    font-size: 1rem;
    line-height: 1.6;
  }
  
  a {
    color: ${({theme:e})=>e.colors.primary||"#90B3A7"};
    text-decoration: none;
    transition: color 0.3s ease;
    
    &:hover {
      color: ${({theme:e})=>e.colors.secondary||"#D4A574"};
    }
  }
  
  button {
    font-family: ${({theme:e})=>e.fonts.primary||'"Inter", sans-serif'};
    cursor: pointer;
    transition: all 0.3s ease;
  }
  
  /* Контейнеры */
  .container {
    width: 100%;
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 1rem;
  }
  
  section {
    padding: 5rem 0;
  }
  
  /* Особые стили для страниц СПА, спорт и контакты */
  /* СПА страница */
  .spa-page {
    .hero-section {
      background: linear-gradient(135deg, #90B3A7 0%, #A8C5B8 100%);
    }
    
    .feature-card {
      background: #FFFFFF;
      border-radius: 8px;
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.05);
    }
  }
  
  /* Спорт страница */
  .sports-page {
    .hero-section {
      background: linear-gradient(135deg, #E8734A 0%, #F28A5F 100%);
    }
    
    .schedule-item {
      border-bottom: 1px solid rgba(0, 0, 0, 0.08);
    }
  }
  
  /* Контакты страница */
  .contacts-page {
    .contact-info {
      background: #FFFFFF;
      border-radius: 8px;
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.05);
    }
    
    .contact-form {
      background: #F9F7F4;
      border-radius: 8px;
    }
  }
  
  /* Устранение оранжевой подсветки при нажатии */
  a, button, input, textarea, select {
    -webkit-tap-highlight-color: transparent;
  }
  
  /* Специальные стили для кнопки бронирования */
  .booking-button {
    background: linear-gradient(135deg, #90B3A7 0%, #A8C5B8 100%);
    color: white;
    padding: 0.75rem 1.5rem;
    border-radius: 4px;
    font-weight: 500;
    letter-spacing: 0.5px;
    transition: all 0.3s ease;
    
    &:hover, &:active, &:focus {
      background: linear-gradient(135deg, #7C9D93 0%, #94B1A4 100%);
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(144, 179, 167, 0.3);
    }
  }
`,_v=S.createContext(),Hv=()=>S.useContext(_v),v8=({children:e})=>{const[i,a]=S.useState(!1),[r,s]=S.useState(!0),c=S.useRef(!1),u=S.useRef(!1),f=(m=2e3)=>c.current||u.current?Promise.resolve():(c.current=!0,u.current=!0,s(!1),a(!0),new Promise(y=>{setTimeout(()=>{a(!1),setTimeout(()=>{s(!0),c.current=!1,y()},400)},m)})),p=()=>{u.current=!1,c.current=!1,a(!1),s(!0)};return h.jsx(_v.Provider,{value:{isLoading:i,isContentReady:r,showLoading:f,resetLoading:p},children:e})},gp=S.createContext({});function yp(e){const i=S.useRef(null);return i.current===null&&(i.current=e()),i.current}const xp=typeof window<"u",Vv=xp?S.useLayoutEffect:S.useEffect,_c=S.createContext(null);function bp(e,i){e.indexOf(i)===-1&&e.push(i)}function vp(e,i){const a=e.indexOf(i);a>-1&&e.splice(a,1)}const Qi=(e,i,a)=>a>i?i:a<e?e:a;let wp=()=>{};const Ji={},Pv=e=>/^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(e);function Fv(e){return typeof e=="object"&&e!==null}const Uv=e=>/^0[^.\s]+$/u.test(e);function Sp(e){let i;return()=>(i===void 0&&(i=e()),i)}const ii=e=>e,w8=(e,i)=>a=>i(e(a)),xs=(...e)=>e.reduce(w8),as=(e,i,a)=>{const r=i-e;return r===0?1:(a-e)/r};class Tp{constructor(){this.subscriptions=[]}add(i){return bp(this.subscriptions,i),()=>vp(this.subscriptions,i)}notify(i,a,r){const s=this.subscriptions.length;if(s)if(s===1)this.subscriptions[0](i,a,r);else for(let c=0;c<s;c++){const u=this.subscriptions[c];u&&u(i,a,r)}}getSize(){return this.subscriptions.length}clear(){this.subscriptions.length=0}}const Ai=e=>e*1e3,Ei=e=>e/1e3;function qv(e,i){return i?e*(1e3/i):0}const Iv=(e,i,a)=>(((1-3*a+3*i)*e+(3*a-6*i))*e+3*i)*e,S8=1e-7,T8=12;function j8(e,i,a,r,s){let c,u,f=0;do u=i+(a-i)/2,c=Iv(u,r,s)-e,c>0?a=u:i=u;while(Math.abs(c)>S8&&++f<T8);return u}function bs(e,i,a,r){if(e===i&&a===r)return ii;const s=c=>j8(c,0,1,e,a);return c=>c===0||c===1?c:Iv(s(c),i,r)}const Yv=e=>i=>i<=.5?e(2*i)/2:(2-e(2*(1-i)))/2,Gv=e=>i=>1-e(1-i),Kv=bs(.33,1.53,.69,.99),jp=Gv(Kv),Xv=Yv(jp),Zv=e=>(e*=2)<1?.5*jp(e):.5*(2-Math.pow(2,-10*(e-1))),Ap=e=>1-Math.sin(Math.acos(e)),Qv=Gv(Ap),Jv=Yv(Ap),A8=bs(.42,0,1,1),E8=bs(0,0,.58,1),Wv=bs(.42,0,.58,1),C8=e=>Array.isArray(e)&&typeof e[0]!="number",e5=e=>Array.isArray(e)&&typeof e[0]=="number",O8={linear:ii,easeIn:A8,easeInOut:Wv,easeOut:E8,circIn:Ap,circInOut:Jv,circOut:Qv,backIn:jp,backInOut:Xv,backOut:Kv,anticipate:Zv},R8=e=>typeof e=="string",Cy=e=>{if(e5(e)){wp(e.length===4);const[i,a,r,s]=e;return bs(i,a,r,s)}else if(R8(e))return O8[e];return e},Vl=["setup","read","resolveKeyframes","preUpdate","update","preRender","render","postRender"],Oy={value:null};function k8(e,i){let a=new Set,r=new Set,s=!1,c=!1;const u=new WeakSet;let f={delta:0,timestamp:0,isProcessing:!1},p=0;function m(x){u.has(x)&&(y.schedule(x),e()),p++,x(f)}const y={schedule:(x,b=!1,T=!1)=>{const C=T&&s?a:r;return b&&u.add(x),C.has(x)||C.add(x),x},cancel:x=>{r.delete(x),u.delete(x)},process:x=>{if(f=x,s){c=!0;return}s=!0,[a,r]=[r,a],a.forEach(m),i&&Oy.value&&Oy.value.frameloop[i].push(p),p=0,a.clear(),s=!1,c&&(c=!1,y.process(x))}};return y}const D8=40;function t5(e,i){let a=!1,r=!0;const s={delta:0,timestamp:0,isProcessing:!1},c=()=>a=!0,u=Vl.reduce((M,F)=>(M[F]=k8(c,i?F:void 0),M),{}),{setup:f,read:p,resolveKeyframes:m,preUpdate:y,update:x,preRender:b,render:T,postRender:A}=u,C=()=>{const M=Ji.useManualTiming?s.timestamp:performance.now();a=!1,Ji.useManualTiming||(s.delta=r?1e3/60:Math.max(Math.min(M-s.timestamp,D8),1)),s.timestamp=M,s.isProcessing=!0,f.process(s),p.process(s),m.process(s),y.process(s),x.process(s),b.process(s),T.process(s),A.process(s),s.isProcessing=!1,a&&i&&(r=!1,e(C))},B=()=>{a=!0,r=!0,s.isProcessing||e(C)};return{schedule:Vl.reduce((M,F)=>{const D=u[F];return M[F]=(U,G=!1,Z=!1)=>(a||B(),D.schedule(U,G,Z)),M},{}),cancel:M=>{for(let F=0;F<Vl.length;F++)u[Vl[F]].cancel(M)},state:s,steps:u}}const{schedule:Ge,cancel:kn,state:mt,steps:yf}=t5(typeof requestAnimationFrame<"u"?requestAnimationFrame:ii,!0);let nc;function M8(){nc=void 0}const Mt={now:()=>(nc===void 0&&Mt.set(mt.isProcessing||Ji.useManualTiming?mt.timestamp:performance.now()),nc),set:e=>{nc=e,queueMicrotask(M8)}},i5=e=>i=>typeof i=="string"&&i.startsWith(e),Ep=i5("--"),B8=i5("var(--"),Cp=e=>B8(e)?z8.test(e.split("/*")[0].trim()):!1,z8=/var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu,Rr={test:e=>typeof e=="number",parse:parseFloat,transform:e=>e},rs={...Rr,transform:e=>Qi(0,1,e)},Pl={...Rr,default:1},Ko=e=>Math.round(e*1e5)/1e5,Op=/-?(?:\d+(?:\.\d+)?|\.\d+)/gu;function $8(e){return e==null}const N8=/^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu,Rp=(e,i)=>a=>!!(typeof a=="string"&&N8.test(a)&&a.startsWith(e)||i&&!$8(a)&&Object.prototype.hasOwnProperty.call(a,i)),n5=(e,i,a)=>r=>{if(typeof r!="string")return r;const[s,c,u,f]=r.match(Op);return{[e]:parseFloat(s),[i]:parseFloat(c),[a]:parseFloat(u),alpha:f!==void 0?parseFloat(f):1}},L8=e=>Qi(0,255,e),xf={...Rr,transform:e=>Math.round(L8(e))},ta={test:Rp("rgb","red"),parse:n5("red","green","blue"),transform:({red:e,green:i,blue:a,alpha:r=1})=>"rgba("+xf.transform(e)+", "+xf.transform(i)+", "+xf.transform(a)+", "+Ko(rs.transform(r))+")"};function _8(e){let i="",a="",r="",s="";return e.length>5?(i=e.substring(1,3),a=e.substring(3,5),r=e.substring(5,7),s=e.substring(7,9)):(i=e.substring(1,2),a=e.substring(2,3),r=e.substring(3,4),s=e.substring(4,5),i+=i,a+=a,r+=r,s+=s),{red:parseInt(i,16),green:parseInt(a,16),blue:parseInt(r,16),alpha:s?parseInt(s,16)/255:1}}const Oh={test:Rp("#"),parse:_8,transform:ta.transform},vs=e=>({test:i=>typeof i=="string"&&i.endsWith(e)&&i.split(" ").length===1,parse:parseFloat,transform:i=>`${i}${e}`}),Cn=vs("deg"),Ci=vs("%"),de=vs("px"),H8=vs("vh"),V8=vs("vw"),Ry={...Ci,parse:e=>Ci.parse(e)/100,transform:e=>Ci.transform(e*100)},lr={test:Rp("hsl","hue"),parse:n5("hue","saturation","lightness"),transform:({hue:e,saturation:i,lightness:a,alpha:r=1})=>"hsla("+Math.round(e)+", "+Ci.transform(Ko(i))+", "+Ci.transform(Ko(a))+", "+Ko(rs.transform(r))+")"},vt={test:e=>ta.test(e)||Oh.test(e)||lr.test(e),parse:e=>ta.test(e)?ta.parse(e):lr.test(e)?lr.parse(e):Oh.parse(e),transform:e=>typeof e=="string"?e:e.hasOwnProperty("red")?ta.transform(e):lr.transform(e)},P8=/(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu;function F8(e){var i,a;return isNaN(e)&&typeof e=="string"&&(((i=e.match(Op))==null?void 0:i.length)||0)+(((a=e.match(P8))==null?void 0:a.length)||0)>0}const a5="number",r5="color",U8="var",q8="var(",ky="${}",I8=/var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;function os(e){const i=e.toString(),a=[],r={color:[],number:[],var:[]},s=[];let c=0;const f=i.replace(I8,p=>(vt.test(p)?(r.color.push(c),s.push(r5),a.push(vt.parse(p))):p.startsWith(q8)?(r.var.push(c),s.push(U8),a.push(p)):(r.number.push(c),s.push(a5),a.push(parseFloat(p))),++c,ky)).split(ky);return{values:a,split:f,indexes:r,types:s}}function o5(e){return os(e).values}function s5(e){const{split:i,types:a}=os(e),r=i.length;return s=>{let c="";for(let u=0;u<r;u++)if(c+=i[u],s[u]!==void 0){const f=a[u];f===a5?c+=Ko(s[u]):f===r5?c+=vt.transform(s[u]):c+=s[u]}return c}}const Y8=e=>typeof e=="number"?0:e;function G8(e){const i=o5(e);return s5(e)(i.map(Y8))}const Dn={test:F8,parse:o5,createTransformer:s5,getAnimatableNone:G8};function bf(e,i,a){return a<0&&(a+=1),a>1&&(a-=1),a<1/6?e+(i-e)*6*a:a<1/2?i:a<2/3?e+(i-e)*(2/3-a)*6:e}function K8({hue:e,saturation:i,lightness:a,alpha:r}){e/=360,i/=100,a/=100;let s=0,c=0,u=0;if(!i)s=c=u=a;else{const f=a<.5?a*(1+i):a+i-a*i,p=2*a-f;s=bf(p,f,e+1/3),c=bf(p,f,e),u=bf(p,f,e-1/3)}return{red:Math.round(s*255),green:Math.round(c*255),blue:Math.round(u*255),alpha:r}}function gc(e,i){return a=>a>0?i:e}const Ye=(e,i,a)=>e+(i-e)*a,vf=(e,i,a)=>{const r=e*e,s=a*(i*i-r)+r;return s<0?0:Math.sqrt(s)},X8=[Oh,ta,lr],Z8=e=>X8.find(i=>i.test(e));function Dy(e){const i=Z8(e);if(!i)return!1;let a=i.parse(e);return i===lr&&(a=K8(a)),a}const My=(e,i)=>{const a=Dy(e),r=Dy(i);if(!a||!r)return gc(e,i);const s={...a};return c=>(s.red=vf(a.red,r.red,c),s.green=vf(a.green,r.green,c),s.blue=vf(a.blue,r.blue,c),s.alpha=Ye(a.alpha,r.alpha,c),ta.transform(s))},Rh=new Set(["none","hidden"]);function Q8(e,i){return Rh.has(e)?a=>a<=0?e:i:a=>a>=1?i:e}function J8(e,i){return a=>Ye(e,i,a)}function kp(e){return typeof e=="number"?J8:typeof e=="string"?Cp(e)?gc:vt.test(e)?My:t6:Array.isArray(e)?l5:typeof e=="object"?vt.test(e)?My:W8:gc}function l5(e,i){const a=[...e],r=a.length,s=e.map((c,u)=>kp(c)(c,i[u]));return c=>{for(let u=0;u<r;u++)a[u]=s[u](c);return a}}function W8(e,i){const a={...e,...i},r={};for(const s in a)e[s]!==void 0&&i[s]!==void 0&&(r[s]=kp(e[s])(e[s],i[s]));return s=>{for(const c in r)a[c]=r[c](s);return a}}function e6(e,i){const a=[],r={color:0,var:0,number:0};for(let s=0;s<i.values.length;s++){const c=i.types[s],u=e.indexes[c][r[c]],f=e.values[u]??0;a[s]=f,r[c]++}return a}const t6=(e,i)=>{const a=Dn.createTransformer(i),r=os(e),s=os(i);return r.indexes.var.length===s.indexes.var.length&&r.indexes.color.length===s.indexes.color.length&&r.indexes.number.length>=s.indexes.number.length?Rh.has(e)&&!s.values.length||Rh.has(i)&&!r.values.length?Q8(e,i):xs(l5(e6(r,s),s.values),a):gc(e,i)};function c5(e,i,a){return typeof e=="number"&&typeof i=="number"&&typeof a=="number"?Ye(e,i,a):kp(e)(e,i)}const i6=e=>{const i=({timestamp:a})=>e(a);return{start:(a=!0)=>Ge.update(i,a),stop:()=>kn(i),now:()=>mt.isProcessing?mt.timestamp:Mt.now()}},u5=(e,i,a=10)=>{let r="";const s=Math.max(Math.round(i/a),2);for(let c=0;c<s;c++)r+=e(c/(s-1))+", ";return`linear(${r.substring(0,r.length-2)})`},yc=2e4;function Dp(e){let i=0;const a=50;let r=e.next(i);for(;!r.done&&i<yc;)i+=a,r=e.next(i);return i>=yc?1/0:i}function n6(e,i=100,a){const r=a({...e,keyframes:[0,i]}),s=Math.min(Dp(r),yc);return{type:"keyframes",ease:c=>r.next(s*c).value/i,duration:Ei(s)}}const a6=5;function d5(e,i,a){const r=Math.max(i-a6,0);return qv(a-e(r),i-r)}const Ze={stiffness:100,damping:10,mass:1,velocity:0,duration:800,bounce:.3,visualDuration:.3,restSpeed:{granular:.01,default:2},restDelta:{granular:.005,default:.5},minDuration:.01,maxDuration:10,minDamping:.05,maxDamping:1},By=.001;function r6({duration:e=Ze.duration,bounce:i=Ze.bounce,velocity:a=Ze.velocity,mass:r=Ze.mass}){let s,c,u=1-i;u=Qi(Ze.minDamping,Ze.maxDamping,u),e=Qi(Ze.minDuration,Ze.maxDuration,Ei(e)),u<1?(s=m=>{const y=m*u,x=y*e,b=y-a,T=kh(m,u),A=Math.exp(-x);return By-b/T*A},c=m=>{const x=m*u*e,b=x*a+a,T=Math.pow(u,2)*Math.pow(m,2)*e,A=Math.exp(-x),C=kh(Math.pow(m,2),u);return(-s(m)+By>0?-1:1)*((b-T)*A)/C}):(s=m=>{const y=Math.exp(-m*e),x=(m-a)*e+1;return-.001+y*x},c=m=>{const y=Math.exp(-m*e),x=(a-m)*(e*e);return y*x});const f=5/e,p=s6(s,c,f);if(e=Ai(e),isNaN(p))return{stiffness:Ze.stiffness,damping:Ze.damping,duration:e};{const m=Math.pow(p,2)*r;return{stiffness:m,damping:u*2*Math.sqrt(r*m),duration:e}}}const o6=12;function s6(e,i,a){let r=a;for(let s=1;s<o6;s++)r=r-e(r)/i(r);return r}function kh(e,i){return e*Math.sqrt(1-i*i)}const l6=["duration","bounce"],c6=["stiffness","damping","mass"];function zy(e,i){return i.some(a=>e[a]!==void 0)}function u6(e){let i={velocity:Ze.velocity,stiffness:Ze.stiffness,damping:Ze.damping,mass:Ze.mass,isResolvedFromDuration:!1,...e};if(!zy(e,c6)&&zy(e,l6))if(e.visualDuration){const a=e.visualDuration,r=2*Math.PI/(a*1.2),s=r*r,c=2*Qi(.05,1,1-(e.bounce||0))*Math.sqrt(s);i={...i,mass:Ze.mass,stiffness:s,damping:c}}else{const a=r6(e);i={...i,...a,mass:Ze.mass},i.isResolvedFromDuration=!0}return i}function xc(e=Ze.visualDuration,i=Ze.bounce){const a=typeof e!="object"?{visualDuration:e,keyframes:[0,1],bounce:i}:e;let{restSpeed:r,restDelta:s}=a;const c=a.keyframes[0],u=a.keyframes[a.keyframes.length-1],f={done:!1,value:c},{stiffness:p,damping:m,mass:y,duration:x,velocity:b,isResolvedFromDuration:T}=u6({...a,velocity:-Ei(a.velocity||0)}),A=b||0,C=m/(2*Math.sqrt(p*y)),B=u-c,E=Ei(Math.sqrt(p/y)),k=Math.abs(B)<5;r||(r=k?Ze.restSpeed.granular:Ze.restSpeed.default),s||(s=k?Ze.restDelta.granular:Ze.restDelta.default);let M;if(C<1){const D=kh(E,C);M=U=>{const G=Math.exp(-C*E*U);return u-G*((A+C*E*B)/D*Math.sin(D*U)+B*Math.cos(D*U))}}else if(C===1)M=D=>u-Math.exp(-E*D)*(B+(A+E*B)*D);else{const D=E*Math.sqrt(C*C-1);M=U=>{const G=Math.exp(-C*E*U),Z=Math.min(D*U,300);return u-G*((A+C*E*B)*Math.sinh(Z)+D*B*Math.cosh(Z))/D}}const F={calculatedDuration:T&&x||null,next:D=>{const U=M(D);if(T)f.done=D>=x;else{let G=D===0?A:0;C<1&&(G=D===0?Ai(A):d5(M,D,U));const Z=Math.abs(G)<=r,J=Math.abs(u-U)<=s;f.done=Z&&J}return f.value=f.done?u:U,f},toString:()=>{const D=Math.min(Dp(F),yc),U=u5(G=>F.next(D*G).value,D,30);return D+"ms "+U},toTransition:()=>{}};return F}xc.applyToOptions=e=>{const i=n6(e,100,xc);return e.ease=i.ease,e.duration=Ai(i.duration),e.type="keyframes",e};function Dh({keyframes:e,velocity:i=0,power:a=.8,timeConstant:r=325,bounceDamping:s=10,bounceStiffness:c=500,modifyTarget:u,min:f,max:p,restDelta:m=.5,restSpeed:y}){const x=e[0],b={done:!1,value:x},T=Z=>f!==void 0&&Z<f||p!==void 0&&Z>p,A=Z=>f===void 0?p:p===void 0||Math.abs(f-Z)<Math.abs(p-Z)?f:p;let C=a*i;const B=x+C,E=u===void 0?B:u(B);E!==B&&(C=E-x);const k=Z=>-C*Math.exp(-Z/r),M=Z=>E+k(Z),F=Z=>{const J=k(Z),ie=M(Z);b.done=Math.abs(J)<=m,b.value=b.done?E:ie};let D,U;const G=Z=>{T(b.value)&&(D=Z,U=xc({keyframes:[b.value,A(b.value)],velocity:d5(M,Z,b.value),damping:s,stiffness:c,restDelta:m,restSpeed:y}))};return G(0),{calculatedDuration:null,next:Z=>{let J=!1;return!U&&D===void 0&&(J=!0,F(Z),G(Z)),D!==void 0&&Z>=D?U.next(Z-D):(!J&&F(Z),b)}}}function d6(e,i,a){const r=[],s=a||Ji.mix||c5,c=e.length-1;for(let u=0;u<c;u++){let f=s(e[u],e[u+1]);if(i){const p=Array.isArray(i)?i[u]||ii:i;f=xs(p,f)}r.push(f)}return r}function f6(e,i,{clamp:a=!0,ease:r,mixer:s}={}){const c=e.length;if(wp(c===i.length),c===1)return()=>i[0];if(c===2&&i[0]===i[1])return()=>i[1];const u=e[0]===e[1];e[0]>e[c-1]&&(e=[...e].reverse(),i=[...i].reverse());const f=d6(i,r,s),p=f.length,m=y=>{if(u&&y<e[0])return i[0];let x=0;if(p>1)for(;x<e.length-2&&!(y<e[x+1]);x++);const b=as(e[x],e[x+1],y);return f[x](b)};return a?y=>m(Qi(e[0],e[c-1],y)):m}function h6(e,i){const a=e[e.length-1];for(let r=1;r<=i;r++){const s=as(0,i,r);e.push(Ye(a,1,s))}}function p6(e){const i=[0];return h6(i,e.length-1),i}function m6(e,i){return e.map(a=>a*i)}function g6(e,i){return e.map(()=>i||Wv).splice(0,e.length-1)}function Xo({duration:e=300,keyframes:i,times:a,ease:r="easeInOut"}){const s=C8(r)?r.map(Cy):Cy(r),c={done:!1,value:i[0]},u=m6(a&&a.length===i.length?a:p6(i),e),f=f6(u,i,{ease:Array.isArray(s)?s:g6(i,s)});return{calculatedDuration:e,next:p=>(c.value=f(p),c.done=p>=e,c)}}const y6=e=>e!==null;function Mp(e,{repeat:i,repeatType:a="loop"},r,s=1){const c=e.filter(y6),f=s<0||i&&a!=="loop"&&i%2===1?0:c.length-1;return!f||r===void 0?c[f]:r}const x6={decay:Dh,inertia:Dh,tween:Xo,keyframes:Xo,spring:xc};function f5(e){typeof e.type=="string"&&(e.type=x6[e.type])}class Bp{constructor(){this.updateFinished()}get finished(){return this._finished}updateFinished(){this._finished=new Promise(i=>{this.resolve=i})}notifyFinished(){this.resolve()}then(i,a){return this.finished.then(i,a)}}const b6=e=>e/100;class zp extends Bp{constructor(i){super(),this.state="idle",this.startTime=null,this.isStopped=!1,this.currentTime=0,this.holdTime=null,this.playbackSpeed=1,this.stop=()=>{var r,s;const{motionValue:a}=this.options;a&&a.updatedAt!==Mt.now()&&this.tick(Mt.now()),this.isStopped=!0,this.state!=="idle"&&(this.teardown(),(s=(r=this.options).onStop)==null||s.call(r))},this.options=i,this.initAnimation(),this.play(),i.autoplay===!1&&this.pause()}initAnimation(){const{options:i}=this;f5(i);const{type:a=Xo,repeat:r=0,repeatDelay:s=0,repeatType:c,velocity:u=0}=i;let{keyframes:f}=i;const p=a||Xo;p!==Xo&&typeof f[0]!="number"&&(this.mixKeyframes=xs(b6,c5(f[0],f[1])),f=[0,100]);const m=p({...i,keyframes:f});c==="mirror"&&(this.mirroredGenerator=p({...i,keyframes:[...f].reverse(),velocity:-u})),m.calculatedDuration===null&&(m.calculatedDuration=Dp(m));const{calculatedDuration:y}=m;this.calculatedDuration=y,this.resolvedDuration=y+s,this.totalDuration=this.resolvedDuration*(r+1)-s,this.generator=m}updateTime(i){const a=Math.round(i-this.startTime)*this.playbackSpeed;this.holdTime!==null?this.currentTime=this.holdTime:this.currentTime=a}tick(i,a=!1){const{generator:r,totalDuration:s,mixKeyframes:c,mirroredGenerator:u,resolvedDuration:f,calculatedDuration:p}=this;if(this.startTime===null)return r.next(0);const{delay:m=0,keyframes:y,repeat:x,repeatType:b,repeatDelay:T,type:A,onUpdate:C,finalKeyframe:B}=this.options;this.speed>0?this.startTime=Math.min(this.startTime,i):this.speed<0&&(this.startTime=Math.min(i-s/this.speed,this.startTime)),a?this.currentTime=i:this.updateTime(i);const E=this.currentTime-m*(this.playbackSpeed>=0?1:-1),k=this.playbackSpeed>=0?E<0:E>s;this.currentTime=Math.max(E,0),this.state==="finished"&&this.holdTime===null&&(this.currentTime=s);let M=this.currentTime,F=r;if(x){const Z=Math.min(this.currentTime,s)/f;let J=Math.floor(Z),ie=Z%1;!ie&&Z>=1&&(ie=1),ie===1&&J--,J=Math.min(J,x+1),!!(J%2)&&(b==="reverse"?(ie=1-ie,T&&(ie-=T/f)):b==="mirror"&&(F=u)),M=Qi(0,1,ie)*f}const D=k?{done:!1,value:y[0]}:F.next(M);c&&(D.value=c(D.value));let{done:U}=D;!k&&p!==null&&(U=this.playbackSpeed>=0?this.currentTime>=s:this.currentTime<=0);const G=this.holdTime===null&&(this.state==="finished"||this.state==="running"&&U);return G&&A!==Dh&&(D.value=Mp(y,this.options,B,this.speed)),C&&C(D.value),G&&this.finish(),D}then(i,a){return this.finished.then(i,a)}get duration(){return Ei(this.calculatedDuration)}get time(){return Ei(this.currentTime)}set time(i){var a;i=Ai(i),this.currentTime=i,this.startTime===null||this.holdTime!==null||this.playbackSpeed===0?this.holdTime=i:this.driver&&(this.startTime=this.driver.now()-i/this.playbackSpeed),(a=this.driver)==null||a.start(!1)}get speed(){return this.playbackSpeed}set speed(i){this.updateTime(Mt.now());const a=this.playbackSpeed!==i;this.playbackSpeed=i,a&&(this.time=Ei(this.currentTime))}play(){var s,c;if(this.isStopped)return;const{driver:i=i6,startTime:a}=this.options;this.driver||(this.driver=i(u=>this.tick(u))),(c=(s=this.options).onPlay)==null||c.call(s);const r=this.driver.now();this.state==="finished"?(this.updateFinished(),this.startTime=r):this.holdTime!==null?this.startTime=r-this.holdTime:this.startTime||(this.startTime=a??r),this.state==="finished"&&this.speed<0&&(this.startTime+=this.calculatedDuration),this.holdTime=null,this.state="running",this.driver.start()}pause(){this.state="paused",this.updateTime(Mt.now()),this.holdTime=this.currentTime}complete(){this.state!=="running"&&this.play(),this.state="finished",this.holdTime=null}finish(){var i,a;this.notifyFinished(),this.teardown(),this.state="finished",(a=(i=this.options).onComplete)==null||a.call(i)}cancel(){var i,a;this.holdTime=null,this.startTime=0,this.tick(0),this.teardown(),(a=(i=this.options).onCancel)==null||a.call(i)}teardown(){this.state="idle",this.stopDriver(),this.startTime=this.holdTime=null}stopDriver(){this.driver&&(this.driver.stop(),this.driver=void 0)}sample(i){return this.startTime=0,this.tick(i,!0)}attachTimeline(i){var a;return this.options.allowFlatten&&(this.options.type="keyframes",this.options.ease="linear",this.initAnimation()),(a=this.driver)==null||a.stop(),i.observe(this)}}function v6(e){for(let i=1;i<e.length;i++)e[i]??(e[i]=e[i-1])}const ia=e=>e*180/Math.PI,Mh=e=>{const i=ia(Math.atan2(e[1],e[0]));return Bh(i)},w6={x:4,y:5,translateX:4,translateY:5,scaleX:0,scaleY:3,scale:e=>(Math.abs(e[0])+Math.abs(e[3]))/2,rotate:Mh,rotateZ:Mh,skewX:e=>ia(Math.atan(e[1])),skewY:e=>ia(Math.atan(e[2])),skew:e=>(Math.abs(e[1])+Math.abs(e[2]))/2},Bh=e=>(e=e%360,e<0&&(e+=360),e),$y=Mh,Ny=e=>Math.sqrt(e[0]*e[0]+e[1]*e[1]),Ly=e=>Math.sqrt(e[4]*e[4]+e[5]*e[5]),S6={x:12,y:13,z:14,translateX:12,translateY:13,translateZ:14,scaleX:Ny,scaleY:Ly,scale:e=>(Ny(e)+Ly(e))/2,rotateX:e=>Bh(ia(Math.atan2(e[6],e[5]))),rotateY:e=>Bh(ia(Math.atan2(-e[2],e[0]))),rotateZ:$y,rotate:$y,skewX:e=>ia(Math.atan(e[4])),skewY:e=>ia(Math.atan(e[1])),skew:e=>(Math.abs(e[1])+Math.abs(e[4]))/2};function zh(e){return e.includes("scale")?1:0}function $h(e,i){if(!e||e==="none")return zh(i);const a=e.match(/^matrix3d\(([-\d.e\s,]+)\)$/u);let r,s;if(a)r=S6,s=a;else{const f=e.match(/^matrix\(([-\d.e\s,]+)\)$/u);r=w6,s=f}if(!s)return zh(i);const c=r[i],u=s[1].split(",").map(j6);return typeof c=="function"?c(u):u[c]}const T6=(e,i)=>{const{transform:a="none"}=getComputedStyle(e);return $h(a,i)};function j6(e){return parseFloat(e.trim())}const kr=["transformPerspective","x","y","z","translateX","translateY","translateZ","scale","scaleX","scaleY","rotate","rotateX","rotateY","rotateZ","skew","skewX","skewY"],Dr=new Set(kr),_y=e=>e===Rr||e===de,A6=new Set(["x","y","z"]),E6=kr.filter(e=>!A6.has(e));function C6(e){const i=[];return E6.forEach(a=>{const r=e.getValue(a);r!==void 0&&(i.push([a,r.get()]),r.set(a.startsWith("scale")?1:0))}),i}const ra={width:({x:e},{paddingLeft:i="0",paddingRight:a="0"})=>e.max-e.min-parseFloat(i)-parseFloat(a),height:({y:e},{paddingTop:i="0",paddingBottom:a="0"})=>e.max-e.min-parseFloat(i)-parseFloat(a),top:(e,{top:i})=>parseFloat(i),left:(e,{left:i})=>parseFloat(i),bottom:({y:e},{top:i})=>parseFloat(i)+(e.max-e.min),right:({x:e},{left:i})=>parseFloat(i)+(e.max-e.min),x:(e,{transform:i})=>$h(i,"x"),y:(e,{transform:i})=>$h(i,"y")};ra.translateX=ra.x;ra.translateY=ra.y;const oa=new Set;let Nh=!1,Lh=!1,_h=!1;function h5(){if(Lh){const e=Array.from(oa).filter(r=>r.needsMeasurement),i=new Set(e.map(r=>r.element)),a=new Map;i.forEach(r=>{const s=C6(r);s.length&&(a.set(r,s),r.render())}),e.forEach(r=>r.measureInitialState()),i.forEach(r=>{r.render();const s=a.get(r);s&&s.forEach(([c,u])=>{var f;(f=r.getValue(c))==null||f.set(u)})}),e.forEach(r=>r.measureEndState()),e.forEach(r=>{r.suspendedScrollY!==void 0&&window.scrollTo(0,r.suspendedScrollY)})}Lh=!1,Nh=!1,oa.forEach(e=>e.complete(_h)),oa.clear()}function p5(){oa.forEach(e=>{e.readKeyframes(),e.needsMeasurement&&(Lh=!0)})}function O6(){_h=!0,p5(),h5(),_h=!1}class $p{constructor(i,a,r,s,c,u=!1){this.state="pending",this.isAsync=!1,this.needsMeasurement=!1,this.unresolvedKeyframes=[...i],this.onComplete=a,this.name=r,this.motionValue=s,this.element=c,this.isAsync=u}scheduleResolve(){this.state="scheduled",this.isAsync?(oa.add(this),Nh||(Nh=!0,Ge.read(p5),Ge.resolveKeyframes(h5))):(this.readKeyframes(),this.complete())}readKeyframes(){const{unresolvedKeyframes:i,name:a,element:r,motionValue:s}=this;if(i[0]===null){const c=s==null?void 0:s.get(),u=i[i.length-1];if(c!==void 0)i[0]=c;else if(r&&a){const f=r.readValue(a,u);f!=null&&(i[0]=f)}i[0]===void 0&&(i[0]=u),s&&c===void 0&&s.set(i[0])}v6(i)}setFinalKeyframe(){}measureInitialState(){}renderEndStyles(){}measureEndState(){}complete(i=!1){this.state="complete",this.onComplete(this.unresolvedKeyframes,this.finalKeyframe,i),oa.delete(this)}cancel(){this.state==="scheduled"&&(oa.delete(this),this.state="pending")}resume(){this.state==="pending"&&this.scheduleResolve()}}const R6=e=>e.startsWith("--");function k6(e,i,a){R6(i)?e.style.setProperty(i,a):e.style[i]=a}const D6=Sp(()=>window.ScrollTimeline!==void 0),M6={};function B6(e,i){const a=Sp(e);return()=>M6[i]??a()}const m5=B6(()=>{try{document.createElement("div").animate({opacity:0},{easing:"linear(0, 1)"})}catch{return!1}return!0},"linearEasing"),Uo=([e,i,a,r])=>`cubic-bezier(${e}, ${i}, ${a}, ${r})`,Hy={linear:"linear",ease:"ease",easeIn:"ease-in",easeOut:"ease-out",easeInOut:"ease-in-out",circIn:Uo([0,.65,.55,1]),circOut:Uo([.55,0,1,.45]),backIn:Uo([.31,.01,.66,-.59]),backOut:Uo([.33,1.53,.69,.99])};function g5(e,i){if(e)return typeof e=="function"?m5()?u5(e,i):"ease-out":e5(e)?Uo(e):Array.isArray(e)?e.map(a=>g5(a,i)||Hy.easeOut):Hy[e]}function z6(e,i,a,{delay:r=0,duration:s=300,repeat:c=0,repeatType:u="loop",ease:f="easeOut",times:p}={},m=void 0){const y={[i]:a};p&&(y.offset=p);const x=g5(f,s);Array.isArray(x)&&(y.easing=x);const b={delay:r,duration:s,easing:Array.isArray(x)?"linear":x,fill:"both",iterations:c+1,direction:u==="reverse"?"alternate":"normal"};return m&&(b.pseudoElement=m),e.animate(y,b)}function y5(e){return typeof e=="function"&&"applyToOptions"in e}function $6({type:e,...i}){return y5(e)&&m5()?e.applyToOptions(i):(i.duration??(i.duration=300),i.ease??(i.ease="easeOut"),i)}class N6 extends Bp{constructor(i){if(super(),this.finishedTime=null,this.isStopped=!1,!i)return;const{element:a,name:r,keyframes:s,pseudoElement:c,allowFlatten:u=!1,finalKeyframe:f,onComplete:p}=i;this.isPseudoElement=!!c,this.allowFlatten=u,this.options=i,wp(typeof i.type!="string");const m=$6(i);this.animation=z6(a,r,s,m,c),m.autoplay===!1&&this.animation.pause(),this.animation.onfinish=()=>{if(this.finishedTime=this.time,!c){const y=Mp(s,this.options,f,this.speed);this.updateMotionValue?this.updateMotionValue(y):k6(a,r,y),this.animation.cancel()}p==null||p(),this.notifyFinished()}}play(){this.isStopped||(this.animation.play(),this.state==="finished"&&this.updateFinished())}pause(){this.animation.pause()}complete(){var i,a;(a=(i=this.animation).finish)==null||a.call(i)}cancel(){try{this.animation.cancel()}catch{}}stop(){if(this.isStopped)return;this.isStopped=!0;const{state:i}=this;i==="idle"||i==="finished"||(this.updateMotionValue?this.updateMotionValue():this.commitStyles(),this.isPseudoElement||this.cancel())}commitStyles(){var i,a;this.isPseudoElement||(a=(i=this.animation).commitStyles)==null||a.call(i)}get duration(){var a,r;const i=((r=(a=this.animation.effect)==null?void 0:a.getComputedTiming)==null?void 0:r.call(a).duration)||0;return Ei(Number(i))}get time(){return Ei(Number(this.animation.currentTime)||0)}set time(i){this.finishedTime=null,this.animation.currentTime=Ai(i)}get speed(){return this.animation.playbackRate}set speed(i){i<0&&(this.finishedTime=null),this.animation.playbackRate=i}get state(){return this.finishedTime!==null?"finished":this.animation.playState}get startTime(){return Number(this.animation.startTime)}set startTime(i){this.animation.startTime=i}attachTimeline({timeline:i,observe:a}){var r;return this.allowFlatten&&((r=this.animation.effect)==null||r.updateTiming({easing:"linear"})),this.animation.onfinish=null,i&&D6()?(this.animation.timeline=i,ii):a(this)}}const x5={anticipate:Zv,backInOut:Xv,circInOut:Jv};function L6(e){return e in x5}function _6(e){typeof e.ease=="string"&&L6(e.ease)&&(e.ease=x5[e.ease])}const Vy=10;class H6 extends N6{constructor(i){_6(i),f5(i),super(i),i.startTime&&(this.startTime=i.startTime),this.options=i}updateMotionValue(i){const{motionValue:a,onUpdate:r,onComplete:s,element:c,...u}=this.options;if(!a)return;if(i!==void 0){a.set(i);return}const f=new zp({...u,autoplay:!1}),p=Ai(this.finishedTime??this.time);a.setWithVelocity(f.sample(p-Vy).value,f.sample(p).value,Vy),f.stop()}}const Py=(e,i)=>i==="zIndex"?!1:!!(typeof e=="number"||Array.isArray(e)||typeof e=="string"&&(Dn.test(e)||e==="0")&&!e.startsWith("url("));function V6(e){const i=e[0];if(e.length===1)return!0;for(let a=0;a<e.length;a++)if(e[a]!==i)return!0}function P6(e,i,a,r){const s=e[0];if(s===null)return!1;if(i==="display"||i==="visibility")return!0;const c=e[e.length-1],u=Py(s,i),f=Py(c,i);return!u||!f?!1:V6(e)||(a==="spring"||y5(a))&&r}function Np(e){return Fv(e)&&"offsetHeight"in e}const F6=new Set(["opacity","clipPath","filter","transform"]),U6=Sp(()=>Object.hasOwnProperty.call(Element.prototype,"animate"));function q6(e){var m;const{motionValue:i,name:a,repeatDelay:r,repeatType:s,damping:c,type:u}=e;if(!Np((m=i==null?void 0:i.owner)==null?void 0:m.current))return!1;const{onUpdate:f,transformTemplate:p}=i.owner.getProps();return U6()&&a&&F6.has(a)&&(a!=="transform"||!p)&&!f&&!r&&s!=="mirror"&&c!==0&&u!=="inertia"}const I6=40;class Y6 extends Bp{constructor({autoplay:i=!0,delay:a=0,type:r="keyframes",repeat:s=0,repeatDelay:c=0,repeatType:u="loop",keyframes:f,name:p,motionValue:m,element:y,...x}){var A;super(),this.stop=()=>{var C,B;this._animation&&(this._animation.stop(),(C=this.stopTimeline)==null||C.call(this)),(B=this.keyframeResolver)==null||B.cancel()},this.createdAt=Mt.now();const b={autoplay:i,delay:a,type:r,repeat:s,repeatDelay:c,repeatType:u,name:p,motionValue:m,element:y,...x},T=(y==null?void 0:y.KeyframeResolver)||$p;this.keyframeResolver=new T(f,(C,B,E)=>this.onKeyframesResolved(C,B,b,!E),p,m,y),(A=this.keyframeResolver)==null||A.scheduleResolve()}onKeyframesResolved(i,a,r,s){this.keyframeResolver=void 0;const{name:c,type:u,velocity:f,delay:p,isHandoff:m,onUpdate:y}=r;this.resolvedAt=Mt.now(),P6(i,c,u,f)||((Ji.instantAnimations||!p)&&(y==null||y(Mp(i,r,a))),i[0]=i[i.length-1],r.duration=0,r.repeat=0);const b={startTime:s?this.resolvedAt?this.resolvedAt-this.createdAt>I6?this.resolvedAt:this.createdAt:this.createdAt:void 0,finalKeyframe:a,...r,keyframes:i},T=!m&&q6(b)?new H6({...b,element:b.motionValue.owner.current}):new zp(b);T.finished.then(()=>this.notifyFinished()).catch(ii),this.pendingTimeline&&(this.stopTimeline=T.attachTimeline(this.pendingTimeline),this.pendingTimeline=void 0),this._animation=T}get finished(){return this._animation?this.animation.finished:this._finished}then(i,a){return this.finished.finally(i).then(()=>{})}get animation(){var i;return this._animation||((i=this.keyframeResolver)==null||i.resume(),O6()),this._animation}get duration(){return this.animation.duration}get time(){return this.animation.time}set time(i){this.animation.time=i}get speed(){return this.animation.speed}get state(){return this.animation.state}set speed(i){this.animation.speed=i}get startTime(){return this.animation.startTime}attachTimeline(i){return this._animation?this.stopTimeline=this.animation.attachTimeline(i):this.pendingTimeline=i,()=>this.stop()}play(){this.animation.play()}pause(){this.animation.pause()}complete(){this.animation.complete()}cancel(){var i;this._animation&&this.animation.cancel(),(i=this.keyframeResolver)==null||i.cancel()}}const G6=/^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;function K6(e){const i=G6.exec(e);if(!i)return[,];const[,a,r,s]=i;return[`--${a??r}`,s]}function b5(e,i,a=1){const[r,s]=K6(e);if(!r)return;const c=window.getComputedStyle(i).getPropertyValue(r);if(c){const u=c.trim();return Pv(u)?parseFloat(u):u}return Cp(s)?b5(s,i,a+1):s}function Lp(e,i){return(e==null?void 0:e[i])??(e==null?void 0:e.default)??e}const v5=new Set(["width","height","top","left","right","bottom",...kr]),X6={test:e=>e==="auto",parse:e=>e},w5=e=>i=>i.test(e),S5=[Rr,de,Ci,Cn,V8,H8,X6],Fy=e=>S5.find(w5(e));function Z6(e){return typeof e=="number"?e===0:e!==null?e==="none"||e==="0"||Uv(e):!0}const Q6=new Set(["brightness","contrast","saturate","opacity"]);function J6(e){const[i,a]=e.slice(0,-1).split("(");if(i==="drop-shadow")return e;const[r]=a.match(Op)||[];if(!r)return e;const s=a.replace(r,"");let c=Q6.has(i)?1:0;return r!==a&&(c*=100),i+"("+c+s+")"}const W6=/\b([a-z-]*)\(.*?\)/gu,Hh={...Dn,getAnimatableNone:e=>{const i=e.match(W6);return i?i.map(J6).join(" "):e}},Uy={...Rr,transform:Math.round},eT={rotate:Cn,rotateX:Cn,rotateY:Cn,rotateZ:Cn,scale:Pl,scaleX:Pl,scaleY:Pl,scaleZ:Pl,skew:Cn,skewX:Cn,skewY:Cn,distance:de,translateX:de,translateY:de,translateZ:de,x:de,y:de,z:de,perspective:de,transformPerspective:de,opacity:rs,originX:Ry,originY:Ry,originZ:de},_p={borderWidth:de,borderTopWidth:de,borderRightWidth:de,borderBottomWidth:de,borderLeftWidth:de,borderRadius:de,radius:de,borderTopLeftRadius:de,borderTopRightRadius:de,borderBottomRightRadius:de,borderBottomLeftRadius:de,width:de,maxWidth:de,height:de,maxHeight:de,top:de,right:de,bottom:de,left:de,padding:de,paddingTop:de,paddingRight:de,paddingBottom:de,paddingLeft:de,margin:de,marginTop:de,marginRight:de,marginBottom:de,marginLeft:de,backgroundPositionX:de,backgroundPositionY:de,...eT,zIndex:Uy,fillOpacity:rs,strokeOpacity:rs,numOctaves:Uy},tT={..._p,color:vt,backgroundColor:vt,outlineColor:vt,fill:vt,stroke:vt,borderColor:vt,borderTopColor:vt,borderRightColor:vt,borderBottomColor:vt,borderLeftColor:vt,filter:Hh,WebkitFilter:Hh},T5=e=>tT[e];function j5(e,i){let a=T5(e);return a!==Hh&&(a=Dn),a.getAnimatableNone?a.getAnimatableNone(i):void 0}const iT=new Set(["auto","none","0"]);function nT(e,i,a){let r=0,s;for(;r<e.length&&!s;){const c=e[r];typeof c=="string"&&!iT.has(c)&&os(c).values.length&&(s=e[r]),r++}if(s&&a)for(const c of i)e[c]=j5(a,s)}class aT extends $p{constructor(i,a,r,s,c){super(i,a,r,s,c,!0)}readKeyframes(){const{unresolvedKeyframes:i,element:a,name:r}=this;if(!a||!a.current)return;super.readKeyframes();for(let p=0;p<i.length;p++){let m=i[p];if(typeof m=="string"&&(m=m.trim(),Cp(m))){const y=b5(m,a.current);y!==void 0&&(i[p]=y),p===i.length-1&&(this.finalKeyframe=m)}}if(this.resolveNoneKeyframes(),!v5.has(r)||i.length!==2)return;const[s,c]=i,u=Fy(s),f=Fy(c);if(u!==f)if(_y(u)&&_y(f))for(let p=0;p<i.length;p++){const m=i[p];typeof m=="string"&&(i[p]=parseFloat(m))}else ra[r]&&(this.needsMeasurement=!0)}resolveNoneKeyframes(){const{unresolvedKeyframes:i,name:a}=this,r=[];for(let s=0;s<i.length;s++)(i[s]===null||Z6(i[s]))&&r.push(s);r.length&&nT(i,r,a)}measureInitialState(){const{element:i,unresolvedKeyframes:a,name:r}=this;if(!i||!i.current)return;r==="height"&&(this.suspendedScrollY=window.pageYOffset),this.measuredOrigin=ra[r](i.measureViewportBox(),window.getComputedStyle(i.current)),a[0]=this.measuredOrigin;const s=a[a.length-1];s!==void 0&&i.getValue(r,s).jump(s,!1)}measureEndState(){var f;const{element:i,name:a,unresolvedKeyframes:r}=this;if(!i||!i.current)return;const s=i.getValue(a);s&&s.jump(this.measuredOrigin,!1);const c=r.length-1,u=r[c];r[c]=ra[a](i.measureViewportBox(),window.getComputedStyle(i.current)),u!==null&&this.finalKeyframe===void 0&&(this.finalKeyframe=u),(f=this.removedTransforms)!=null&&f.length&&this.removedTransforms.forEach(([p,m])=>{i.getValue(p).set(m)}),this.resolveNoneKeyframes()}}function A5(e,i,a){if(e instanceof EventTarget)return[e];if(typeof e=="string"){const s=document.querySelectorAll(e);return s?Array.from(s):[]}return Array.from(e)}const E5=(e,i)=>i&&typeof e=="number"?i.transform(e):e,qy=30,rT=e=>!isNaN(parseFloat(e));class oT{constructor(i,a={}){this.canTrackVelocity=null,this.events={},this.updateAndNotify=(r,s=!0)=>{var u,f;const c=Mt.now();if(this.updatedAt!==c&&this.setPrevFrameValue(),this.prev=this.current,this.setCurrent(r),this.current!==this.prev&&((u=this.events.change)==null||u.notify(this.current),this.dependents))for(const p of this.dependents)p.dirty();s&&((f=this.events.renderRequest)==null||f.notify(this.current))},this.hasAnimated=!1,this.setCurrent(i),this.owner=a.owner}setCurrent(i){this.current=i,this.updatedAt=Mt.now(),this.canTrackVelocity===null&&i!==void 0&&(this.canTrackVelocity=rT(this.current))}setPrevFrameValue(i=this.current){this.prevFrameValue=i,this.prevUpdatedAt=this.updatedAt}onChange(i){return this.on("change",i)}on(i,a){this.events[i]||(this.events[i]=new Tp);const r=this.events[i].add(a);return i==="change"?()=>{r(),Ge.read(()=>{this.events.change.getSize()||this.stop()})}:r}clearListeners(){for(const i in this.events)this.events[i].clear()}attach(i,a){this.passiveEffect=i,this.stopPassiveEffect=a}set(i,a=!0){!a||!this.passiveEffect?this.updateAndNotify(i,a):this.passiveEffect(i,this.updateAndNotify)}setWithVelocity(i,a,r){this.set(a),this.prev=void 0,this.prevFrameValue=i,this.prevUpdatedAt=this.updatedAt-r}jump(i,a=!0){this.updateAndNotify(i),this.prev=i,this.prevUpdatedAt=this.prevFrameValue=void 0,a&&this.stop(),this.stopPassiveEffect&&this.stopPassiveEffect()}dirty(){var i;(i=this.events.change)==null||i.notify(this.current)}addDependent(i){this.dependents||(this.dependents=new Set),this.dependents.add(i)}removeDependent(i){this.dependents&&this.dependents.delete(i)}get(){return this.current}getPrevious(){return this.prev}getVelocity(){const i=Mt.now();if(!this.canTrackVelocity||this.prevFrameValue===void 0||i-this.updatedAt>qy)return 0;const a=Math.min(this.updatedAt-this.prevUpdatedAt,qy);return qv(parseFloat(this.current)-parseFloat(this.prevFrameValue),a)}start(i){return this.stop(),new Promise(a=>{this.hasAnimated=!0,this.animation=i(a),this.events.animationStart&&this.events.animationStart.notify()}).then(()=>{this.events.animationComplete&&this.events.animationComplete.notify(),this.clearAnimation()})}stop(){this.animation&&(this.animation.stop(),this.events.animationCancel&&this.events.animationCancel.notify()),this.clearAnimation()}isAnimating(){return!!this.animation}clearAnimation(){delete this.animation}destroy(){var i,a;(i=this.dependents)==null||i.clear(),(a=this.events.destroy)==null||a.notify(),this.clearListeners(),this.stop(),this.stopPassiveEffect&&this.stopPassiveEffect()}}function vr(e,i){return new oT(e,i)}const{schedule:Hp}=t5(queueMicrotask,!1),si={x:!1,y:!1};function C5(){return si.x||si.y}function sT(e){return e==="x"||e==="y"?si[e]?null:(si[e]=!0,()=>{si[e]=!1}):si.x||si.y?null:(si.x=si.y=!0,()=>{si.x=si.y=!1})}function O5(e,i){const a=A5(e),r=new AbortController,s={passive:!0,...i,signal:r.signal};return[a,s,()=>r.abort()]}function Iy(e){return!(e.pointerType==="touch"||C5())}function lT(e,i,a={}){const[r,s,c]=O5(e,a),u=f=>{if(!Iy(f))return;const{target:p}=f,m=i(p,f);if(typeof m!="function"||!p)return;const y=x=>{Iy(x)&&(m(x),p.removeEventListener("pointerleave",y))};p.addEventListener("pointerleave",y,s)};return r.forEach(f=>{f.addEventListener("pointerenter",u,s)}),c}const R5=(e,i)=>i?e===i?!0:R5(e,i.parentElement):!1,Vp=e=>e.pointerType==="mouse"?typeof e.button!="number"||e.button<=0:e.isPrimary!==!1,cT=new Set(["BUTTON","INPUT","SELECT","TEXTAREA","A"]);function uT(e){return cT.has(e.tagName)||e.tabIndex!==-1}const ac=new WeakSet;function Yy(e){return i=>{i.key==="Enter"&&e(i)}}function wf(e,i){e.dispatchEvent(new PointerEvent("pointer"+i,{isPrimary:!0,bubbles:!0}))}const dT=(e,i)=>{const a=e.currentTarget;if(!a)return;const r=Yy(()=>{if(ac.has(a))return;wf(a,"down");const s=Yy(()=>{wf(a,"up")}),c=()=>wf(a,"cancel");a.addEventListener("keyup",s,i),a.addEventListener("blur",c,i)});a.addEventListener("keydown",r,i),a.addEventListener("blur",()=>a.removeEventListener("keydown",r),i)};function Gy(e){return Vp(e)&&!C5()}function fT(e,i,a={}){const[r,s,c]=O5(e,a),u=f=>{const p=f.currentTarget;if(!Gy(f))return;ac.add(p);const m=i(p,f),y=(T,A)=>{window.removeEventListener("pointerup",x),window.removeEventListener("pointercancel",b),ac.has(p)&&ac.delete(p),Gy(T)&&typeof m=="function"&&m(T,{success:A})},x=T=>{y(T,p===window||p===document||a.useGlobalTarget||R5(p,T.target))},b=T=>{y(T,!1)};window.addEventListener("pointerup",x,s),window.addEventListener("pointercancel",b,s)};return r.forEach(f=>{(a.useGlobalTarget?window:f).addEventListener("pointerdown",u,s),Np(f)&&(f.addEventListener("focus",m=>dT(m,s)),!uT(f)&&!f.hasAttribute("tabindex")&&(f.tabIndex=0))}),c}function k5(e){return Fv(e)&&"ownerSVGElement"in e}function hT(e){return k5(e)&&e.tagName==="svg"}const wt=e=>!!(e&&e.getVelocity),pT=[...S5,vt,Dn],mT=e=>pT.find(w5(e)),Pp=S.createContext({transformPagePoint:e=>e,isStatic:!1,reducedMotion:"never"});class gT extends S.Component{getSnapshotBeforeUpdate(i){const a=this.props.childRef.current;if(a&&i.isPresent&&!this.props.isPresent){const r=a.offsetParent,s=Np(r)&&r.offsetWidth||0,c=this.props.sizeRef.current;c.height=a.offsetHeight||0,c.width=a.offsetWidth||0,c.top=a.offsetTop,c.left=a.offsetLeft,c.right=s-c.width-c.left}return null}componentDidUpdate(){}render(){return this.props.children}}function yT({children:e,isPresent:i,anchorX:a}){const r=S.useId(),s=S.useRef(null),c=S.useRef({width:0,height:0,top:0,left:0,right:0}),{nonce:u}=S.useContext(Pp);return S.useInsertionEffect(()=>{const{width:f,height:p,top:m,left:y,right:x}=c.current;if(i||!s.current||!f||!p)return;const b=a==="left"?`left: ${y}`:`right: ${x}`;s.current.dataset.motionPopId=r;const T=document.createElement("style");return u&&(T.nonce=u),document.head.appendChild(T),T.sheet&&T.sheet.insertRule(`
          [data-motion-pop-id="${r}"] {
            position: absolute !important;
            width: ${f}px !important;
            height: ${p}px !important;
            ${b}px !important;
            top: ${m}px !important;
          }
        `),()=>{document.head.contains(T)&&document.head.removeChild(T)}},[i]),h.jsx(gT,{isPresent:i,childRef:s,sizeRef:c,children:S.cloneElement(e,{ref:s})})}const xT=({children:e,initial:i,isPresent:a,onExitComplete:r,custom:s,presenceAffectsLayout:c,mode:u,anchorX:f})=>{const p=yp(bT),m=S.useId();let y=!0,x=S.useMemo(()=>(y=!1,{id:m,initial:i,isPresent:a,custom:s,onExitComplete:b=>{p.set(b,!0);for(const T of p.values())if(!T)return;r&&r()},register:b=>(p.set(b,!1),()=>p.delete(b))}),[a,p,r]);return c&&y&&(x={...x}),S.useMemo(()=>{p.forEach((b,T)=>p.set(T,!1))},[a]),S.useEffect(()=>{!a&&!p.size&&r&&r()},[a]),u==="popLayout"&&(e=h.jsx(yT,{isPresent:a,anchorX:f,children:e})),h.jsx(_c.Provider,{value:x,children:e})};function bT(){return new Map}function D5(e=!0){const i=S.useContext(_c);if(i===null)return[!0,null];const{isPresent:a,onExitComplete:r,register:s}=i,c=S.useId();S.useEffect(()=>{if(e)return s(c)},[e]);const u=S.useCallback(()=>e&&r&&r(c),[c,r,e]);return!a&&r?[!1,u]:[!0]}const Fl=e=>e.key||"";function Ky(e){const i=[];return S.Children.forEach(e,a=>{S.isValidElement(a)&&i.push(a)}),i}const ua=({children:e,custom:i,initial:a=!0,onExitComplete:r,presenceAffectsLayout:s=!0,mode:c="sync",propagate:u=!1,anchorX:f="left"})=>{const[p,m]=D5(u),y=S.useMemo(()=>Ky(e),[e]),x=u&&!p?[]:y.map(Fl),b=S.useRef(!0),T=S.useRef(y),A=yp(()=>new Map),[C,B]=S.useState(y),[E,k]=S.useState(y);Vv(()=>{b.current=!1,T.current=y;for(let D=0;D<E.length;D++){const U=Fl(E[D]);x.includes(U)?A.delete(U):A.get(U)!==!0&&A.set(U,!1)}},[E,x.length,x.join("-")]);const M=[];if(y!==C){let D=[...y];for(let U=0;U<E.length;U++){const G=E[U],Z=Fl(G);x.includes(Z)||(D.splice(U,0,G),M.push(G))}return c==="wait"&&M.length&&(D=M),k(Ky(D)),B(y),null}const{forceRender:F}=S.useContext(gp);return h.jsx(h.Fragment,{children:E.map(D=>{const U=Fl(D),G=u&&!p?!1:y===E||x.includes(U),Z=()=>{if(A.has(U))A.set(U,!0);else return;let J=!0;A.forEach(ie=>{ie||(J=!1)}),J&&(F==null||F(),k(T.current),u&&(m==null||m()),r&&r())};return h.jsx(xT,{isPresent:G,initial:!b.current||a?void 0:!1,custom:i,presenceAffectsLayout:s,mode:c,onExitComplete:G?void 0:Z,anchorX:f,children:D},U)})})},M5=S.createContext({strict:!1}),Xy={animation:["animate","variants","whileHover","whileTap","exit","whileInView","whileFocus","whileDrag"],exit:["exit"],drag:["drag","dragControls"],focus:["whileFocus"],hover:["whileHover","onHoverStart","onHoverEnd"],tap:["whileTap","onTap","onTapStart","onTapCancel"],pan:["onPan","onPanStart","onPanSessionStart","onPanEnd"],inView:["whileInView","onViewportEnter","onViewportLeave"],layout:["layout","layoutId"]},wr={};for(const e in Xy)wr[e]={isEnabled:i=>Xy[e].some(a=>!!i[a])};function vT(e){for(const i in e)wr[i]={...wr[i],...e[i]}}const wT=new Set(["animate","exit","variants","initial","style","values","variants","transition","transformTemplate","custom","inherit","onBeforeLayoutMeasure","onAnimationStart","onAnimationComplete","onUpdate","onDragStart","onDrag","onDragEnd","onMeasureDragConstraints","onDirectionLock","onDragTransitionEnd","_dragX","_dragY","onHoverStart","onHoverEnd","onViewportEnter","onViewportLeave","globalTapTarget","ignoreStrict","viewport"]);function bc(e){return e.startsWith("while")||e.startsWith("drag")&&e!=="draggable"||e.startsWith("layout")||e.startsWith("onTap")||e.startsWith("onPan")||e.startsWith("onLayout")||wT.has(e)}let B5=e=>!bc(e);function ST(e){e&&(B5=i=>i.startsWith("on")?!bc(i):e(i))}try{ST(require("@emotion/is-prop-valid").default)}catch{}function TT(e,i,a){const r={};for(const s in e)s==="values"&&typeof e.values=="object"||(B5(s)||a===!0&&bc(s)||!i&&!bc(s)||e.draggable&&s.startsWith("onDrag"))&&(r[s]=e[s]);return r}function jT(e){if(typeof Proxy>"u")return e;const i=new Map,a=(...r)=>e(...r);return new Proxy(a,{get:(r,s)=>s==="create"?e:(i.has(s)||i.set(s,e(s)),i.get(s))})}const Hc=S.createContext({});function Vc(e){return e!==null&&typeof e=="object"&&typeof e.start=="function"}function ss(e){return typeof e=="string"||Array.isArray(e)}const Fp=["animate","whileInView","whileFocus","whileHover","whileTap","whileDrag","exit"],Up=["initial",...Fp];function Pc(e){return Vc(e.animate)||Up.some(i=>ss(e[i]))}function z5(e){return!!(Pc(e)||e.variants)}function AT(e,i){if(Pc(e)){const{initial:a,animate:r}=e;return{initial:a===!1||ss(a)?a:void 0,animate:ss(r)?r:void 0}}return e.inherit!==!1?i:{}}function ET(e){const{initial:i,animate:a}=AT(e,S.useContext(Hc));return S.useMemo(()=>({initial:i,animate:a}),[Zy(i),Zy(a)])}function Zy(e){return Array.isArray(e)?e.join(" "):e}const CT=Symbol.for("motionComponentSymbol");function cr(e){return e&&typeof e=="object"&&Object.prototype.hasOwnProperty.call(e,"current")}function OT(e,i,a){return S.useCallback(r=>{r&&e.onMount&&e.onMount(r),i&&(r?i.mount(r):i.unmount()),a&&(typeof a=="function"?a(r):cr(a)&&(a.current=r))},[i])}const qp=e=>e.replace(/([a-z])([A-Z])/gu,"$1-$2").toLowerCase(),RT="framerAppearId",$5="data-"+qp(RT),N5=S.createContext({});function kT(e,i,a,r,s){var C,B;const{visualElement:c}=S.useContext(Hc),u=S.useContext(M5),f=S.useContext(_c),p=S.useContext(Pp).reducedMotion,m=S.useRef(null);r=r||u.renderer,!m.current&&r&&(m.current=r(e,{visualState:i,parent:c,props:a,presenceContext:f,blockInitialAnimation:f?f.initial===!1:!1,reducedMotionConfig:p}));const y=m.current,x=S.useContext(N5);y&&!y.projection&&s&&(y.type==="html"||y.type==="svg")&&DT(m.current,a,s,x);const b=S.useRef(!1);S.useInsertionEffect(()=>{y&&b.current&&y.update(a,f)});const T=a[$5],A=S.useRef(!!T&&!((C=window.MotionHandoffIsComplete)!=null&&C.call(window,T))&&((B=window.MotionHasOptimisedAnimation)==null?void 0:B.call(window,T)));return Vv(()=>{y&&(b.current=!0,window.MotionIsMounted=!0,y.updateFeatures(),Hp.render(y.render),A.current&&y.animationState&&y.animationState.animateChanges())}),S.useEffect(()=>{y&&(!A.current&&y.animationState&&y.animationState.animateChanges(),A.current&&(queueMicrotask(()=>{var E;(E=window.MotionHandoffMarkAsComplete)==null||E.call(window,T)}),A.current=!1))}),y}function DT(e,i,a,r){const{layoutId:s,layout:c,drag:u,dragConstraints:f,layoutScroll:p,layoutRoot:m,layoutCrossfade:y}=i;e.projection=new a(e.latestValues,i["data-framer-portal-id"]?void 0:L5(e.parent)),e.projection.setOptions({layoutId:s,layout:c,alwaysMeasureLayout:!!u||f&&cr(f),visualElement:e,animationType:typeof c=="string"?c:"both",initialPromotionConfig:r,crossfade:y,layoutScroll:p,layoutRoot:m})}function L5(e){if(e)return e.options.allowProjection!==!1?e.projection:L5(e.parent)}function MT({preloadedFeatures:e,createVisualElement:i,useRender:a,useVisualState:r,Component:s}){e&&vT(e);function c(f,p){let m;const y={...S.useContext(Pp),...f,layoutId:BT(f)},{isStatic:x}=y,b=ET(f),T=r(f,x);if(!x&&xp){zT();const A=$T(y);m=A.MeasureLayout,b.visualElement=kT(s,T,y,i,A.ProjectionNode)}return h.jsxs(Hc.Provider,{value:b,children:[m&&b.visualElement?h.jsx(m,{visualElement:b.visualElement,...y}):null,a(s,f,OT(T,b.visualElement,p),T,x,b.visualElement)]})}c.displayName=`motion.${typeof s=="string"?s:`create(${s.displayName??s.name??""})`}`;const u=S.forwardRef(c);return u[CT]=s,u}function BT({layoutId:e}){const i=S.useContext(gp).id;return i&&e!==void 0?i+"-"+e:e}function zT(e,i){S.useContext(M5).strict}function $T(e){const{drag:i,layout:a}=wr;if(!i&&!a)return{};const r={...i,...a};return{MeasureLayout:i!=null&&i.isEnabled(e)||a!=null&&a.isEnabled(e)?r.MeasureLayout:void 0,ProjectionNode:r.ProjectionNode}}const ls={};function NT(e){for(const i in e)ls[i]=e[i],Ep(i)&&(ls[i].isCSSVariable=!0)}function _5(e,{layout:i,layoutId:a}){return Dr.has(e)||e.startsWith("origin")||(i||a!==void 0)&&(!!ls[e]||e==="opacity")}const LT={x:"translateX",y:"translateY",z:"translateZ",transformPerspective:"perspective"},_T=kr.length;function HT(e,i,a){let r="",s=!0;for(let c=0;c<_T;c++){const u=kr[c],f=e[u];if(f===void 0)continue;let p=!0;if(typeof f=="number"?p=f===(u.startsWith("scale")?1:0):p=parseFloat(f)===0,!p||a){const m=E5(f,_p[u]);if(!p){s=!1;const y=LT[u]||u;r+=`${y}(${m}) `}a&&(i[u]=m)}}return r=r.trim(),a?r=a(i,s?"":r):s&&(r="none"),r}function Ip(e,i,a){const{style:r,vars:s,transformOrigin:c}=e;let u=!1,f=!1;for(const p in i){const m=i[p];if(Dr.has(p)){u=!0;continue}else if(Ep(p)){s[p]=m;continue}else{const y=E5(m,_p[p]);p.startsWith("origin")?(f=!0,c[p]=y):r[p]=y}}if(i.transform||(u||a?r.transform=HT(i,e.transform,a):r.transform&&(r.transform="none")),f){const{originX:p="50%",originY:m="50%",originZ:y=0}=c;r.transformOrigin=`${p} ${m} ${y}`}}const Yp=()=>({style:{},transform:{},transformOrigin:{},vars:{}});function H5(e,i,a){for(const r in i)!wt(i[r])&&!_5(r,a)&&(e[r]=i[r])}function VT({transformTemplate:e},i){return S.useMemo(()=>{const a=Yp();return Ip(a,i,e),Object.assign({},a.vars,a.style)},[i])}function PT(e,i){const a=e.style||{},r={};return H5(r,a,e),Object.assign(r,VT(e,i)),r}function FT(e,i){const a={},r=PT(e,i);return e.drag&&e.dragListener!==!1&&(a.draggable=!1,r.userSelect=r.WebkitUserSelect=r.WebkitTouchCallout="none",r.touchAction=e.drag===!0?"none":`pan-${e.drag==="x"?"y":"x"}`),e.tabIndex===void 0&&(e.onTap||e.onTapStart||e.whileTap)&&(a.tabIndex=0),a.style=r,a}const UT={offset:"stroke-dashoffset",array:"stroke-dasharray"},qT={offset:"strokeDashoffset",array:"strokeDasharray"};function IT(e,i,a=1,r=0,s=!0){e.pathLength=1;const c=s?UT:qT;e[c.offset]=de.transform(-r);const u=de.transform(i),f=de.transform(a);e[c.array]=`${u} ${f}`}function V5(e,{attrX:i,attrY:a,attrScale:r,pathLength:s,pathSpacing:c=1,pathOffset:u=0,...f},p,m,y){if(Ip(e,f,m),p){e.style.viewBox&&(e.attrs.viewBox=e.style.viewBox);return}e.attrs=e.style,e.style={};const{attrs:x,style:b}=e;x.transform&&(b.transform=x.transform,delete x.transform),(b.transform||x.transformOrigin)&&(b.transformOrigin=x.transformOrigin??"50% 50%",delete x.transformOrigin),b.transform&&(b.transformBox=(y==null?void 0:y.transformBox)??"fill-box",delete x.transformBox),i!==void 0&&(x.x=i),a!==void 0&&(x.y=a),r!==void 0&&(x.scale=r),s!==void 0&&IT(x,s,c,u,!1)}const P5=()=>({...Yp(),attrs:{}}),F5=e=>typeof e=="string"&&e.toLowerCase()==="svg";function YT(e,i,a,r){const s=S.useMemo(()=>{const c=P5();return V5(c,i,F5(r),e.transformTemplate,e.style),{...c.attrs,style:{...c.style}}},[i]);if(e.style){const c={};H5(c,e.style,e),s.style={...c,...s.style}}return s}const GT=["animate","circle","defs","desc","ellipse","g","image","line","filter","marker","mask","metadata","path","pattern","polygon","polyline","rect","stop","switch","symbol","svg","text","tspan","use","view"];function Gp(e){return typeof e!="string"||e.includes("-")?!1:!!(GT.indexOf(e)>-1||/[A-Z]/u.test(e))}function KT(e=!1){return(a,r,s,{latestValues:c},u)=>{const p=(Gp(a)?YT:FT)(r,c,u,a),m=TT(r,typeof a=="string",e),y=a!==S.Fragment?{...m,...p,ref:s}:{},{children:x}=r,b=S.useMemo(()=>wt(x)?x.get():x,[x]);return S.createElement(a,{...y,children:b})}}function Qy(e){const i=[{},{}];return e==null||e.values.forEach((a,r)=>{i[0][r]=a.get(),i[1][r]=a.getVelocity()}),i}function Kp(e,i,a,r){if(typeof i=="function"){const[s,c]=Qy(r);i=i(a!==void 0?a:e.custom,s,c)}if(typeof i=="string"&&(i=e.variants&&e.variants[i]),typeof i=="function"){const[s,c]=Qy(r);i=i(a!==void 0?a:e.custom,s,c)}return i}function rc(e){return wt(e)?e.get():e}function XT({scrapeMotionValuesFromProps:e,createRenderState:i},a,r,s){return{latestValues:ZT(a,r,s,e),renderState:i()}}const U5=e=>(i,a)=>{const r=S.useContext(Hc),s=S.useContext(_c),c=()=>XT(e,i,r,s);return a?c():yp(c)};function ZT(e,i,a,r){const s={},c=r(e,{});for(const b in c)s[b]=rc(c[b]);let{initial:u,animate:f}=e;const p=Pc(e),m=z5(e);i&&m&&!p&&e.inherit!==!1&&(u===void 0&&(u=i.initial),f===void 0&&(f=i.animate));let y=a?a.initial===!1:!1;y=y||u===!1;const x=y?f:u;if(x&&typeof x!="boolean"&&!Vc(x)){const b=Array.isArray(x)?x:[x];for(let T=0;T<b.length;T++){const A=Kp(e,b[T]);if(A){const{transitionEnd:C,transition:B,...E}=A;for(const k in E){let M=E[k];if(Array.isArray(M)){const F=y?M.length-1:0;M=M[F]}M!==null&&(s[k]=M)}for(const k in C)s[k]=C[k]}}}return s}function Xp(e,i,a){var c;const{style:r}=e,s={};for(const u in r)(wt(r[u])||i.style&&wt(i.style[u])||_5(u,e)||((c=a==null?void 0:a.getValue(u))==null?void 0:c.liveStyle)!==void 0)&&(s[u]=r[u]);return s}const QT={useVisualState:U5({scrapeMotionValuesFromProps:Xp,createRenderState:Yp})};function q5(e,i,a){const r=Xp(e,i,a);for(const s in e)if(wt(e[s])||wt(i[s])){const c=kr.indexOf(s)!==-1?"attr"+s.charAt(0).toUpperCase()+s.substring(1):s;r[c]=e[s]}return r}const JT={useVisualState:U5({scrapeMotionValuesFromProps:q5,createRenderState:P5})};function WT(e,i){return function(r,{forwardMotionProps:s}={forwardMotionProps:!1}){const u={...Gp(r)?JT:QT,preloadedFeatures:e,useRender:KT(s),createVisualElement:i,Component:r};return MT(u)}}function cs(e,i,a){const r=e.getProps();return Kp(r,i,a!==void 0?a:r.custom,e)}const Vh=e=>Array.isArray(e);function e9(e,i,a){e.hasValue(i)?e.getValue(i).set(a):e.addValue(i,vr(a))}function t9(e){return Vh(e)?e[e.length-1]||0:e}function i9(e,i){const a=cs(e,i);let{transitionEnd:r={},transition:s={},...c}=a||{};c={...c,...r};for(const u in c){const f=t9(c[u]);e9(e,u,f)}}function n9(e){return!!(wt(e)&&e.add)}function Ph(e,i){const a=e.getValue("willChange");if(n9(a))return a.add(i);if(!a&&Ji.WillChange){const r=new Ji.WillChange("auto");e.addValue("willChange",r),r.add(i)}}function I5(e){return e.props[$5]}const a9=e=>e!==null;function r9(e,{repeat:i,repeatType:a="loop"},r){const s=e.filter(a9),c=i&&a!=="loop"&&i%2===1?0:s.length-1;return s[c]}const o9={type:"spring",stiffness:500,damping:25,restSpeed:10},s9=e=>({type:"spring",stiffness:550,damping:e===0?2*Math.sqrt(550):30,restSpeed:10}),l9={type:"keyframes",duration:.8},c9={type:"keyframes",ease:[.25,.1,.35,1],duration:.3},u9=(e,{keyframes:i})=>i.length>2?l9:Dr.has(e)?e.startsWith("scale")?s9(i[1]):o9:c9;function d9({when:e,delay:i,delayChildren:a,staggerChildren:r,staggerDirection:s,repeat:c,repeatType:u,repeatDelay:f,from:p,elapsed:m,...y}){return!!Object.keys(y).length}const Zp=(e,i,a,r={},s,c)=>u=>{const f=Lp(r,e)||{},p=f.delay||r.delay||0;let{elapsed:m=0}=r;m=m-Ai(p);const y={keyframes:Array.isArray(a)?a:[null,a],ease:"easeOut",velocity:i.getVelocity(),...f,delay:-m,onUpdate:b=>{i.set(b),f.onUpdate&&f.onUpdate(b)},onComplete:()=>{u(),f.onComplete&&f.onComplete()},name:e,motionValue:i,element:c?void 0:s};d9(f)||Object.assign(y,u9(e,y)),y.duration&&(y.duration=Ai(y.duration)),y.repeatDelay&&(y.repeatDelay=Ai(y.repeatDelay)),y.from!==void 0&&(y.keyframes[0]=y.from);let x=!1;if((y.type===!1||y.duration===0&&!y.repeatDelay)&&(y.duration=0,y.delay===0&&(x=!0)),(Ji.instantAnimations||Ji.skipAnimations)&&(x=!0,y.duration=0,y.delay=0),y.allowFlatten=!f.type&&!f.ease,x&&!c&&i.get()!==void 0){const b=r9(y.keyframes,f);if(b!==void 0){Ge.update(()=>{y.onUpdate(b),y.onComplete()});return}}return f.isSync?new zp(y):new Y6(y)};function f9({protectedKeys:e,needsAnimating:i},a){const r=e.hasOwnProperty(a)&&i[a]!==!0;return i[a]=!1,r}function Y5(e,i,{delay:a=0,transitionOverride:r,type:s}={}){let{transition:c=e.getDefaultTransition(),transitionEnd:u,...f}=i;r&&(c=r);const p=[],m=s&&e.animationState&&e.animationState.getState()[s];for(const y in f){const x=e.getValue(y,e.latestValues[y]??null),b=f[y];if(b===void 0||m&&f9(m,y))continue;const T={delay:a,...Lp(c||{},y)},A=x.get();if(A!==void 0&&!x.isAnimating&&!Array.isArray(b)&&b===A&&!T.velocity)continue;let C=!1;if(window.MotionHandoffAnimation){const E=I5(e);if(E){const k=window.MotionHandoffAnimation(E,y,Ge);k!==null&&(T.startTime=k,C=!0)}}Ph(e,y),x.start(Zp(y,x,b,e.shouldReduceMotion&&v5.has(y)?{type:!1}:T,e,C));const B=x.animation;B&&p.push(B)}return u&&Promise.all(p).then(()=>{Ge.update(()=>{u&&i9(e,u)})}),p}function Fh(e,i,a={}){var p;const r=cs(e,i,a.type==="exit"?(p=e.presenceContext)==null?void 0:p.custom:void 0);let{transition:s=e.getDefaultTransition()||{}}=r||{};a.transitionOverride&&(s=a.transitionOverride);const c=r?()=>Promise.all(Y5(e,r,a)):()=>Promise.resolve(),u=e.variantChildren&&e.variantChildren.size?(m=0)=>{const{delayChildren:y=0,staggerChildren:x,staggerDirection:b}=s;return h9(e,i,y+m,x,b,a)}:()=>Promise.resolve(),{when:f}=s;if(f){const[m,y]=f==="beforeChildren"?[c,u]:[u,c];return m().then(()=>y())}else return Promise.all([c(),u(a.delay)])}function h9(e,i,a=0,r=0,s=1,c){const u=[],f=(e.variantChildren.size-1)*r,p=s===1?(m=0)=>m*r:(m=0)=>f-m*r;return Array.from(e.variantChildren).sort(p9).forEach((m,y)=>{m.notify("AnimationStart",i),u.push(Fh(m,i,{...c,delay:a+p(y)}).then(()=>m.notify("AnimationComplete",i)))}),Promise.all(u)}function p9(e,i){return e.sortNodePosition(i)}function m9(e,i,a={}){e.notify("AnimationStart",i);let r;if(Array.isArray(i)){const s=i.map(c=>Fh(e,c,a));r=Promise.all(s)}else if(typeof i=="string")r=Fh(e,i,a);else{const s=typeof i=="function"?cs(e,i,a.custom):i;r=Promise.all(Y5(e,s,a))}return r.then(()=>{e.notify("AnimationComplete",i)})}function G5(e,i){if(!Array.isArray(i))return!1;const a=i.length;if(a!==e.length)return!1;for(let r=0;r<a;r++)if(i[r]!==e[r])return!1;return!0}const g9=Up.length;function K5(e){if(!e)return;if(!e.isControllingVariants){const a=e.parent?K5(e.parent)||{}:{};return e.props.initial!==void 0&&(a.initial=e.props.initial),a}const i={};for(let a=0;a<g9;a++){const r=Up[a],s=e.props[r];(ss(s)||s===!1)&&(i[r]=s)}return i}const y9=[...Fp].reverse(),x9=Fp.length;function b9(e){return i=>Promise.all(i.map(({animation:a,options:r})=>m9(e,a,r)))}function v9(e){let i=b9(e),a=Jy(),r=!0;const s=p=>(m,y)=>{var b;const x=cs(e,y,p==="exit"?(b=e.presenceContext)==null?void 0:b.custom:void 0);if(x){const{transition:T,transitionEnd:A,...C}=x;m={...m,...C,...A}}return m};function c(p){i=p(e)}function u(p){const{props:m}=e,y=K5(e.parent)||{},x=[],b=new Set;let T={},A=1/0;for(let B=0;B<x9;B++){const E=y9[B],k=a[E],M=m[E]!==void 0?m[E]:y[E],F=ss(M),D=E===p?k.isActive:null;D===!1&&(A=B);let U=M===y[E]&&M!==m[E]&&F;if(U&&r&&e.manuallyAnimateOnMount&&(U=!1),k.protectedKeys={...T},!k.isActive&&D===null||!M&&!k.prevProp||Vc(M)||typeof M=="boolean")continue;const G=w9(k.prevProp,M);let Z=G||E===p&&k.isActive&&!U&&F||B>A&&F,J=!1;const ie=Array.isArray(M)?M:[M];let oe=ie.reduce(s(E),{});D===!1&&(oe={});const{prevResolvedValues:xe={}}=k,Le={...xe,...oe},ne=X=>{Z=!0,b.has(X)&&(J=!0,b.delete(X)),k.needsAnimating[X]=!0;const ee=e.getValue(X);ee&&(ee.liveStyle=!1)};for(const X in Le){const ee=oe[X],fe=xe[X];if(T.hasOwnProperty(X))continue;let z=!1;Vh(ee)&&Vh(fe)?z=!G5(ee,fe):z=ee!==fe,z?ee!=null?ne(X):b.add(X):ee!==void 0&&b.has(X)?ne(X):k.protectedKeys[X]=!0}k.prevProp=M,k.prevResolvedValues=oe,k.isActive&&(T={...T,...oe}),r&&e.blockInitialAnimation&&(Z=!1),Z&&(!(U&&G)||J)&&x.push(...ie.map(X=>({animation:X,options:{type:E}})))}if(b.size){const B={};if(typeof m.initial!="boolean"){const E=cs(e,Array.isArray(m.initial)?m.initial[0]:m.initial);E&&E.transition&&(B.transition=E.transition)}b.forEach(E=>{const k=e.getBaseTarget(E),M=e.getValue(E);M&&(M.liveStyle=!0),B[E]=k??null}),x.push({animation:B})}let C=!!x.length;return r&&(m.initial===!1||m.initial===m.animate)&&!e.manuallyAnimateOnMount&&(C=!1),r=!1,C?i(x):Promise.resolve()}function f(p,m){var x;if(a[p].isActive===m)return Promise.resolve();(x=e.variantChildren)==null||x.forEach(b=>{var T;return(T=b.animationState)==null?void 0:T.setActive(p,m)}),a[p].isActive=m;const y=u(p);for(const b in a)a[b].protectedKeys={};return y}return{animateChanges:u,setActive:f,setAnimateFunction:c,getState:()=>a,reset:()=>{a=Jy(),r=!0}}}function w9(e,i){return typeof i=="string"?i!==e:Array.isArray(i)?!G5(i,e):!1}function Jn(e=!1){return{isActive:e,protectedKeys:{},needsAnimating:{},prevResolvedValues:{}}}function Jy(){return{animate:Jn(!0),whileInView:Jn(),whileHover:Jn(),whileTap:Jn(),whileDrag:Jn(),whileFocus:Jn(),exit:Jn()}}class Mn{constructor(i){this.isMounted=!1,this.node=i}update(){}}class S9 extends Mn{constructor(i){super(i),i.animationState||(i.animationState=v9(i))}updateAnimationControlsSubscription(){const{animate:i}=this.node.getProps();Vc(i)&&(this.unmountControls=i.subscribe(this.node))}mount(){this.updateAnimationControlsSubscription()}update(){const{animate:i}=this.node.getProps(),{animate:a}=this.node.prevProps||{};i!==a&&this.updateAnimationControlsSubscription()}unmount(){var i;this.node.animationState.reset(),(i=this.unmountControls)==null||i.call(this)}}let T9=0;class j9 extends Mn{constructor(){super(...arguments),this.id=T9++}update(){if(!this.node.presenceContext)return;const{isPresent:i,onExitComplete:a}=this.node.presenceContext,{isPresent:r}=this.node.prevPresenceContext||{};if(!this.node.animationState||i===r)return;const s=this.node.animationState.setActive("exit",!i);a&&!i&&s.then(()=>{a(this.id)})}mount(){const{register:i,onExitComplete:a}=this.node.presenceContext||{};a&&a(this.id),i&&(this.unmount=i(this.id))}unmount(){}}const A9={animation:{Feature:S9},exit:{Feature:j9}};function us(e,i,a,r={passive:!0}){return e.addEventListener(i,a,r),()=>e.removeEventListener(i,a)}function ws(e){return{point:{x:e.pageX,y:e.pageY}}}const E9=e=>i=>Vp(i)&&e(i,ws(i));function Zo(e,i,a,r){return us(e,i,E9(a),r)}function X5({top:e,left:i,right:a,bottom:r}){return{x:{min:i,max:a},y:{min:e,max:r}}}function C9({x:e,y:i}){return{top:i.min,right:e.max,bottom:i.max,left:e.min}}function O9(e,i){if(!i)return e;const a=i({x:e.left,y:e.top}),r=i({x:e.right,y:e.bottom});return{top:a.y,left:a.x,bottom:r.y,right:r.x}}const Z5=1e-4,R9=1-Z5,k9=1+Z5,Q5=.01,D9=0-Q5,M9=0+Q5;function jt(e){return e.max-e.min}function B9(e,i,a){return Math.abs(e-i)<=a}function Wy(e,i,a,r=.5){e.origin=r,e.originPoint=Ye(i.min,i.max,e.origin),e.scale=jt(a)/jt(i),e.translate=Ye(a.min,a.max,e.origin)-e.originPoint,(e.scale>=R9&&e.scale<=k9||isNaN(e.scale))&&(e.scale=1),(e.translate>=D9&&e.translate<=M9||isNaN(e.translate))&&(e.translate=0)}function Qo(e,i,a,r){Wy(e.x,i.x,a.x,r?r.originX:void 0),Wy(e.y,i.y,a.y,r?r.originY:void 0)}function ex(e,i,a){e.min=a.min+i.min,e.max=e.min+jt(i)}function z9(e,i,a){ex(e.x,i.x,a.x),ex(e.y,i.y,a.y)}function tx(e,i,a){e.min=i.min-a.min,e.max=e.min+jt(i)}function Jo(e,i,a){tx(e.x,i.x,a.x),tx(e.y,i.y,a.y)}const ix=()=>({translate:0,scale:1,origin:0,originPoint:0}),ur=()=>({x:ix(),y:ix()}),nx=()=>({min:0,max:0}),We=()=>({x:nx(),y:nx()});function ti(e){return[e("x"),e("y")]}function Sf(e){return e===void 0||e===1}function Uh({scale:e,scaleX:i,scaleY:a}){return!Sf(e)||!Sf(i)||!Sf(a)}function Wn(e){return Uh(e)||J5(e)||e.z||e.rotate||e.rotateX||e.rotateY||e.skewX||e.skewY}function J5(e){return ax(e.x)||ax(e.y)}function ax(e){return e&&e!=="0%"}function vc(e,i,a){const r=e-a,s=i*r;return a+s}function rx(e,i,a,r,s){return s!==void 0&&(e=vc(e,s,r)),vc(e,a,r)+i}function qh(e,i=0,a=1,r,s){e.min=rx(e.min,i,a,r,s),e.max=rx(e.max,i,a,r,s)}function W5(e,{x:i,y:a}){qh(e.x,i.translate,i.scale,i.originPoint),qh(e.y,a.translate,a.scale,a.originPoint)}const ox=.999999999999,sx=1.0000000000001;function $9(e,i,a,r=!1){const s=a.length;if(!s)return;i.x=i.y=1;let c,u;for(let f=0;f<s;f++){c=a[f],u=c.projectionDelta;const{visualElement:p}=c.options;p&&p.props.style&&p.props.style.display==="contents"||(r&&c.options.layoutScroll&&c.scroll&&c!==c.root&&fr(e,{x:-c.scroll.offset.x,y:-c.scroll.offset.y}),u&&(i.x*=u.x.scale,i.y*=u.y.scale,W5(e,u)),r&&Wn(c.latestValues)&&fr(e,c.latestValues))}i.x<sx&&i.x>ox&&(i.x=1),i.y<sx&&i.y>ox&&(i.y=1)}function dr(e,i){e.min=e.min+i,e.max=e.max+i}function lx(e,i,a,r,s=.5){const c=Ye(e.min,e.max,s);qh(e,i,a,c,r)}function fr(e,i){lx(e.x,i.x,i.scaleX,i.scale,i.originX),lx(e.y,i.y,i.scaleY,i.scale,i.originY)}function e2(e,i){return X5(O9(e.getBoundingClientRect(),i))}function N9(e,i,a){const r=e2(e,a),{scroll:s}=i;return s&&(dr(r.x,s.offset.x),dr(r.y,s.offset.y)),r}const t2=({current:e})=>e?e.ownerDocument.defaultView:null,cx=(e,i)=>Math.abs(e-i);function L9(e,i){const a=cx(e.x,i.x),r=cx(e.y,i.y);return Math.sqrt(a**2+r**2)}class i2{constructor(i,a,{transformPagePoint:r,contextWindow:s,dragSnapToOrigin:c=!1}={}){if(this.startEvent=null,this.lastMoveEvent=null,this.lastMoveEventInfo=null,this.handlers={},this.contextWindow=window,this.updatePoint=()=>{if(!(this.lastMoveEvent&&this.lastMoveEventInfo))return;const x=jf(this.lastMoveEventInfo,this.history),b=this.startEvent!==null,T=L9(x.offset,{x:0,y:0})>=3;if(!b&&!T)return;const{point:A}=x,{timestamp:C}=mt;this.history.push({...A,timestamp:C});const{onStart:B,onMove:E}=this.handlers;b||(B&&B(this.lastMoveEvent,x),this.startEvent=this.lastMoveEvent),E&&E(this.lastMoveEvent,x)},this.handlePointerMove=(x,b)=>{this.lastMoveEvent=x,this.lastMoveEventInfo=Tf(b,this.transformPagePoint),Ge.update(this.updatePoint,!0)},this.handlePointerUp=(x,b)=>{this.end();const{onEnd:T,onSessionEnd:A,resumeAnimation:C}=this.handlers;if(this.dragSnapToOrigin&&C&&C(),!(this.lastMoveEvent&&this.lastMoveEventInfo))return;const B=jf(x.type==="pointercancel"?this.lastMoveEventInfo:Tf(b,this.transformPagePoint),this.history);this.startEvent&&T&&T(x,B),A&&A(x,B)},!Vp(i))return;this.dragSnapToOrigin=c,this.handlers=a,this.transformPagePoint=r,this.contextWindow=s||window;const u=ws(i),f=Tf(u,this.transformPagePoint),{point:p}=f,{timestamp:m}=mt;this.history=[{...p,timestamp:m}];const{onSessionStart:y}=a;y&&y(i,jf(f,this.history)),this.removeListeners=xs(Zo(this.contextWindow,"pointermove",this.handlePointerMove),Zo(this.contextWindow,"pointerup",this.handlePointerUp),Zo(this.contextWindow,"pointercancel",this.handlePointerUp))}updateHandlers(i){this.handlers=i}end(){this.removeListeners&&this.removeListeners(),kn(this.updatePoint)}}function Tf(e,i){return i?{point:i(e.point)}:e}function ux(e,i){return{x:e.x-i.x,y:e.y-i.y}}function jf({point:e},i){return{point:e,delta:ux(e,n2(i)),offset:ux(e,_9(i)),velocity:H9(i,.1)}}function _9(e){return e[0]}function n2(e){return e[e.length-1]}function H9(e,i){if(e.length<2)return{x:0,y:0};let a=e.length-1,r=null;const s=n2(e);for(;a>=0&&(r=e[a],!(s.timestamp-r.timestamp>Ai(i)));)a--;if(!r)return{x:0,y:0};const c=Ei(s.timestamp-r.timestamp);if(c===0)return{x:0,y:0};const u={x:(s.x-r.x)/c,y:(s.y-r.y)/c};return u.x===1/0&&(u.x=0),u.y===1/0&&(u.y=0),u}function V9(e,{min:i,max:a},r){return i!==void 0&&e<i?e=r?Ye(i,e,r.min):Math.max(e,i):a!==void 0&&e>a&&(e=r?Ye(a,e,r.max):Math.min(e,a)),e}function dx(e,i,a){return{min:i!==void 0?e.min+i:void 0,max:a!==void 0?e.max+a-(e.max-e.min):void 0}}function P9(e,{top:i,left:a,bottom:r,right:s}){return{x:dx(e.x,a,s),y:dx(e.y,i,r)}}function fx(e,i){let a=i.min-e.min,r=i.max-e.max;return i.max-i.min<e.max-e.min&&([a,r]=[r,a]),{min:a,max:r}}function F9(e,i){return{x:fx(e.x,i.x),y:fx(e.y,i.y)}}function U9(e,i){let a=.5;const r=jt(e),s=jt(i);return s>r?a=as(i.min,i.max-r,e.min):r>s&&(a=as(e.min,e.max-s,i.min)),Qi(0,1,a)}function q9(e,i){const a={};return i.min!==void 0&&(a.min=i.min-e.min),i.max!==void 0&&(a.max=i.max-e.min),a}const Ih=.35;function I9(e=Ih){return e===!1?e=0:e===!0&&(e=Ih),{x:hx(e,"left","right"),y:hx(e,"top","bottom")}}function hx(e,i,a){return{min:px(e,i),max:px(e,a)}}function px(e,i){return typeof e=="number"?e:e[i]||0}const Y9=new WeakMap;class G9{constructor(i){this.openDragLock=null,this.isDragging=!1,this.currentDirection=null,this.originPoint={x:0,y:0},this.constraints=!1,this.hasMutatedConstraints=!1,this.elastic=We(),this.visualElement=i}start(i,{snapToCursor:a=!1}={}){const{presenceContext:r}=this.visualElement;if(r&&r.isPresent===!1)return;const s=y=>{const{dragSnapToOrigin:x}=this.getProps();x?this.pauseAnimation():this.stopAnimation(),a&&this.snapToCursor(ws(y).point)},c=(y,x)=>{const{drag:b,dragPropagation:T,onDragStart:A}=this.getProps();if(b&&!T&&(this.openDragLock&&this.openDragLock(),this.openDragLock=sT(b),!this.openDragLock))return;this.isDragging=!0,this.currentDirection=null,this.resolveConstraints(),this.visualElement.projection&&(this.visualElement.projection.isAnimationBlocked=!0,this.visualElement.projection.target=void 0),ti(B=>{let E=this.getAxisMotionValue(B).get()||0;if(Ci.test(E)){const{projection:k}=this.visualElement;if(k&&k.layout){const M=k.layout.layoutBox[B];M&&(E=jt(M)*(parseFloat(E)/100))}}this.originPoint[B]=E}),A&&Ge.postRender(()=>A(y,x)),Ph(this.visualElement,"transform");const{animationState:C}=this.visualElement;C&&C.setActive("whileDrag",!0)},u=(y,x)=>{const{dragPropagation:b,dragDirectionLock:T,onDirectionLock:A,onDrag:C}=this.getProps();if(!b&&!this.openDragLock)return;const{offset:B}=x;if(T&&this.currentDirection===null){this.currentDirection=K9(B),this.currentDirection!==null&&A&&A(this.currentDirection);return}this.updateAxis("x",x.point,B),this.updateAxis("y",x.point,B),this.visualElement.render(),C&&C(y,x)},f=(y,x)=>this.stop(y,x),p=()=>ti(y=>{var x;return this.getAnimationState(y)==="paused"&&((x=this.getAxisMotionValue(y).animation)==null?void 0:x.play())}),{dragSnapToOrigin:m}=this.getProps();this.panSession=new i2(i,{onSessionStart:s,onStart:c,onMove:u,onSessionEnd:f,resumeAnimation:p},{transformPagePoint:this.visualElement.getTransformPagePoint(),dragSnapToOrigin:m,contextWindow:t2(this.visualElement)})}stop(i,a){const r=this.isDragging;if(this.cancel(),!r)return;const{velocity:s}=a;this.startAnimation(s);const{onDragEnd:c}=this.getProps();c&&Ge.postRender(()=>c(i,a))}cancel(){this.isDragging=!1;const{projection:i,animationState:a}=this.visualElement;i&&(i.isAnimationBlocked=!1),this.panSession&&this.panSession.end(),this.panSession=void 0;const{dragPropagation:r}=this.getProps();!r&&this.openDragLock&&(this.openDragLock(),this.openDragLock=null),a&&a.setActive("whileDrag",!1)}updateAxis(i,a,r){const{drag:s}=this.getProps();if(!r||!Ul(i,s,this.currentDirection))return;const c=this.getAxisMotionValue(i);let u=this.originPoint[i]+r[i];this.constraints&&this.constraints[i]&&(u=V9(u,this.constraints[i],this.elastic[i])),c.set(u)}resolveConstraints(){var c;const{dragConstraints:i,dragElastic:a}=this.getProps(),r=this.visualElement.projection&&!this.visualElement.projection.layout?this.visualElement.projection.measure(!1):(c=this.visualElement.projection)==null?void 0:c.layout,s=this.constraints;i&&cr(i)?this.constraints||(this.constraints=this.resolveRefConstraints()):i&&r?this.constraints=P9(r.layoutBox,i):this.constraints=!1,this.elastic=I9(a),s!==this.constraints&&r&&this.constraints&&!this.hasMutatedConstraints&&ti(u=>{this.constraints!==!1&&this.getAxisMotionValue(u)&&(this.constraints[u]=q9(r.layoutBox[u],this.constraints[u]))})}resolveRefConstraints(){const{dragConstraints:i,onMeasureDragConstraints:a}=this.getProps();if(!i||!cr(i))return!1;const r=i.current,{projection:s}=this.visualElement;if(!s||!s.layout)return!1;const c=N9(r,s.root,this.visualElement.getTransformPagePoint());let u=F9(s.layout.layoutBox,c);if(a){const f=a(C9(u));this.hasMutatedConstraints=!!f,f&&(u=X5(f))}return u}startAnimation(i){const{drag:a,dragMomentum:r,dragElastic:s,dragTransition:c,dragSnapToOrigin:u,onDragTransitionEnd:f}=this.getProps(),p=this.constraints||{},m=ti(y=>{if(!Ul(y,a,this.currentDirection))return;let x=p&&p[y]||{};u&&(x={min:0,max:0});const b=s?200:1e6,T=s?40:1e7,A={type:"inertia",velocity:r?i[y]:0,bounceStiffness:b,bounceDamping:T,timeConstant:750,restDelta:1,restSpeed:10,...c,...x};return this.startAxisValueAnimation(y,A)});return Promise.all(m).then(f)}startAxisValueAnimation(i,a){const r=this.getAxisMotionValue(i);return Ph(this.visualElement,i),r.start(Zp(i,r,0,a,this.visualElement,!1))}stopAnimation(){ti(i=>this.getAxisMotionValue(i).stop())}pauseAnimation(){ti(i=>{var a;return(a=this.getAxisMotionValue(i).animation)==null?void 0:a.pause()})}getAnimationState(i){var a;return(a=this.getAxisMotionValue(i).animation)==null?void 0:a.state}getAxisMotionValue(i){const a=`_drag${i.toUpperCase()}`,r=this.visualElement.getProps(),s=r[a];return s||this.visualElement.getValue(i,(r.initial?r.initial[i]:void 0)||0)}snapToCursor(i){ti(a=>{const{drag:r}=this.getProps();if(!Ul(a,r,this.currentDirection))return;const{projection:s}=this.visualElement,c=this.getAxisMotionValue(a);if(s&&s.layout){const{min:u,max:f}=s.layout.layoutBox[a];c.set(i[a]-Ye(u,f,.5))}})}scalePositionWithinConstraints(){if(!this.visualElement.current)return;const{drag:i,dragConstraints:a}=this.getProps(),{projection:r}=this.visualElement;if(!cr(a)||!r||!this.constraints)return;this.stopAnimation();const s={x:0,y:0};ti(u=>{const f=this.getAxisMotionValue(u);if(f&&this.constraints!==!1){const p=f.get();s[u]=U9({min:p,max:p},this.constraints[u])}});const{transformTemplate:c}=this.visualElement.getProps();this.visualElement.current.style.transform=c?c({},""):"none",r.root&&r.root.updateScroll(),r.updateLayout(),this.resolveConstraints(),ti(u=>{if(!Ul(u,i,null))return;const f=this.getAxisMotionValue(u),{min:p,max:m}=this.constraints[u];f.set(Ye(p,m,s[u]))})}addListeners(){if(!this.visualElement.current)return;Y9.set(this.visualElement,this);const i=this.visualElement.current,a=Zo(i,"pointerdown",p=>{const{drag:m,dragListener:y=!0}=this.getProps();m&&y&&this.start(p)}),r=()=>{const{dragConstraints:p}=this.getProps();cr(p)&&p.current&&(this.constraints=this.resolveRefConstraints())},{projection:s}=this.visualElement,c=s.addEventListener("measure",r);s&&!s.layout&&(s.root&&s.root.updateScroll(),s.updateLayout()),Ge.read(r);const u=us(window,"resize",()=>this.scalePositionWithinConstraints()),f=s.addEventListener("didUpdate",({delta:p,hasLayoutChanged:m})=>{this.isDragging&&m&&(ti(y=>{const x=this.getAxisMotionValue(y);x&&(this.originPoint[y]+=p[y].translate,x.set(x.get()+p[y].translate))}),this.visualElement.render())});return()=>{u(),a(),c(),f&&f()}}getProps(){const i=this.visualElement.getProps(),{drag:a=!1,dragDirectionLock:r=!1,dragPropagation:s=!1,dragConstraints:c=!1,dragElastic:u=Ih,dragMomentum:f=!0}=i;return{...i,drag:a,dragDirectionLock:r,dragPropagation:s,dragConstraints:c,dragElastic:u,dragMomentum:f}}}function Ul(e,i,a){return(i===!0||i===e)&&(a===null||a===e)}function K9(e,i=10){let a=null;return Math.abs(e.y)>i?a="y":Math.abs(e.x)>i&&(a="x"),a}class X9 extends Mn{constructor(i){super(i),this.removeGroupControls=ii,this.removeListeners=ii,this.controls=new G9(i)}mount(){const{dragControls:i}=this.node.getProps();i&&(this.removeGroupControls=i.subscribe(this.controls)),this.removeListeners=this.controls.addListeners()||ii}unmount(){this.removeGroupControls(),this.removeListeners()}}const mx=e=>(i,a)=>{e&&Ge.postRender(()=>e(i,a))};class Z9 extends Mn{constructor(){super(...arguments),this.removePointerDownListener=ii}onPointerDown(i){this.session=new i2(i,this.createPanHandlers(),{transformPagePoint:this.node.getTransformPagePoint(),contextWindow:t2(this.node)})}createPanHandlers(){const{onPanSessionStart:i,onPanStart:a,onPan:r,onPanEnd:s}=this.node.getProps();return{onSessionStart:mx(i),onStart:mx(a),onMove:r,onEnd:(c,u)=>{delete this.session,s&&Ge.postRender(()=>s(c,u))}}}mount(){this.removePointerDownListener=Zo(this.node.current,"pointerdown",i=>this.onPointerDown(i))}update(){this.session&&this.session.updateHandlers(this.createPanHandlers())}unmount(){this.removePointerDownListener(),this.session&&this.session.end()}}const oc={hasAnimatedSinceResize:!0,hasEverUpdated:!1};function gx(e,i){return i.max===i.min?0:e/(i.max-i.min)*100}const No={correct:(e,i)=>{if(!i.target)return e;if(typeof e=="string")if(de.test(e))e=parseFloat(e);else return e;const a=gx(e,i.target.x),r=gx(e,i.target.y);return`${a}% ${r}%`}},Q9={correct:(e,{treeScale:i,projectionDelta:a})=>{const r=e,s=Dn.parse(e);if(s.length>5)return r;const c=Dn.createTransformer(e),u=typeof s[0]!="number"?1:0,f=a.x.scale*i.x,p=a.y.scale*i.y;s[0+u]/=f,s[1+u]/=p;const m=Ye(f,p,.5);return typeof s[2+u]=="number"&&(s[2+u]/=m),typeof s[3+u]=="number"&&(s[3+u]/=m),c(s)}};class J9 extends S.Component{componentDidMount(){const{visualElement:i,layoutGroup:a,switchLayoutGroup:r,layoutId:s}=this.props,{projection:c}=i;NT(W9),c&&(a.group&&a.group.add(c),r&&r.register&&s&&r.register(c),c.root.didUpdate(),c.addEventListener("animationComplete",()=>{this.safeToRemove()}),c.setOptions({...c.options,onExitComplete:()=>this.safeToRemove()})),oc.hasEverUpdated=!0}getSnapshotBeforeUpdate(i){const{layoutDependency:a,visualElement:r,drag:s,isPresent:c}=this.props,{projection:u}=r;return u&&(u.isPresent=c,s||i.layoutDependency!==a||a===void 0||i.isPresent!==c?u.willUpdate():this.safeToRemove(),i.isPresent!==c&&(c?u.promote():u.relegate()||Ge.postRender(()=>{const f=u.getStack();(!f||!f.members.length)&&this.safeToRemove()}))),null}componentDidUpdate(){const{projection:i}=this.props.visualElement;i&&(i.root.didUpdate(),Hp.postRender(()=>{!i.currentAnimation&&i.isLead()&&this.safeToRemove()}))}componentWillUnmount(){const{visualElement:i,layoutGroup:a,switchLayoutGroup:r}=this.props,{projection:s}=i;s&&(s.scheduleCheckAfterUnmount(),a&&a.group&&a.group.remove(s),r&&r.deregister&&r.deregister(s))}safeToRemove(){const{safeToRemove:i}=this.props;i&&i()}render(){return null}}function a2(e){const[i,a]=D5(),r=S.useContext(gp);return h.jsx(J9,{...e,layoutGroup:r,switchLayoutGroup:S.useContext(N5),isPresent:i,safeToRemove:a})}const W9={borderRadius:{...No,applyTo:["borderTopLeftRadius","borderTopRightRadius","borderBottomLeftRadius","borderBottomRightRadius"]},borderTopLeftRadius:No,borderTopRightRadius:No,borderBottomLeftRadius:No,borderBottomRightRadius:No,boxShadow:Q9};function ej(e,i,a){const r=wt(e)?e:vr(e);return r.start(Zp("",r,i,a)),r.animation}const tj=(e,i)=>e.depth-i.depth;class ij{constructor(){this.children=[],this.isDirty=!1}add(i){bp(this.children,i),this.isDirty=!0}remove(i){vp(this.children,i),this.isDirty=!0}forEach(i){this.isDirty&&this.children.sort(tj),this.isDirty=!1,this.children.forEach(i)}}function nj(e,i){const a=Mt.now(),r=({timestamp:s})=>{const c=s-a;c>=i&&(kn(r),e(c-i))};return Ge.setup(r,!0),()=>kn(r)}const r2=["TopLeft","TopRight","BottomLeft","BottomRight"],aj=r2.length,yx=e=>typeof e=="string"?parseFloat(e):e,xx=e=>typeof e=="number"||de.test(e);function rj(e,i,a,r,s,c){s?(e.opacity=Ye(0,a.opacity??1,oj(r)),e.opacityExit=Ye(i.opacity??1,0,sj(r))):c&&(e.opacity=Ye(i.opacity??1,a.opacity??1,r));for(let u=0;u<aj;u++){const f=`border${r2[u]}Radius`;let p=bx(i,f),m=bx(a,f);if(p===void 0&&m===void 0)continue;p||(p=0),m||(m=0),p===0||m===0||xx(p)===xx(m)?(e[f]=Math.max(Ye(yx(p),yx(m),r),0),(Ci.test(m)||Ci.test(p))&&(e[f]+="%")):e[f]=m}(i.rotate||a.rotate)&&(e.rotate=Ye(i.rotate||0,a.rotate||0,r))}function bx(e,i){return e[i]!==void 0?e[i]:e.borderRadius}const oj=o2(0,.5,Qv),sj=o2(.5,.95,ii);function o2(e,i,a){return r=>r<e?0:r>i?1:a(as(e,i,r))}function vx(e,i){e.min=i.min,e.max=i.max}function ei(e,i){vx(e.x,i.x),vx(e.y,i.y)}function wx(e,i){e.translate=i.translate,e.scale=i.scale,e.originPoint=i.originPoint,e.origin=i.origin}function Sx(e,i,a,r,s){return e-=i,e=vc(e,1/a,r),s!==void 0&&(e=vc(e,1/s,r)),e}function lj(e,i=0,a=1,r=.5,s,c=e,u=e){if(Ci.test(i)&&(i=parseFloat(i),i=Ye(u.min,u.max,i/100)-u.min),typeof i!="number")return;let f=Ye(c.min,c.max,r);e===c&&(f-=i),e.min=Sx(e.min,i,a,f,s),e.max=Sx(e.max,i,a,f,s)}function Tx(e,i,[a,r,s],c,u){lj(e,i[a],i[r],i[s],i.scale,c,u)}const cj=["x","scaleX","originX"],uj=["y","scaleY","originY"];function jx(e,i,a,r){Tx(e.x,i,cj,a?a.x:void 0,r?r.x:void 0),Tx(e.y,i,uj,a?a.y:void 0,r?r.y:void 0)}function Ax(e){return e.translate===0&&e.scale===1}function s2(e){return Ax(e.x)&&Ax(e.y)}function Ex(e,i){return e.min===i.min&&e.max===i.max}function dj(e,i){return Ex(e.x,i.x)&&Ex(e.y,i.y)}function Cx(e,i){return Math.round(e.min)===Math.round(i.min)&&Math.round(e.max)===Math.round(i.max)}function l2(e,i){return Cx(e.x,i.x)&&Cx(e.y,i.y)}function Ox(e){return jt(e.x)/jt(e.y)}function Rx(e,i){return e.translate===i.translate&&e.scale===i.scale&&e.originPoint===i.originPoint}class fj{constructor(){this.members=[]}add(i){bp(this.members,i),i.scheduleRender()}remove(i){if(vp(this.members,i),i===this.prevLead&&(this.prevLead=void 0),i===this.lead){const a=this.members[this.members.length-1];a&&this.promote(a)}}relegate(i){const a=this.members.findIndex(s=>i===s);if(a===0)return!1;let r;for(let s=a;s>=0;s--){const c=this.members[s];if(c.isPresent!==!1){r=c;break}}return r?(this.promote(r),!0):!1}promote(i,a){const r=this.lead;if(i!==r&&(this.prevLead=r,this.lead=i,i.show(),r)){r.instance&&r.scheduleRender(),i.scheduleRender(),i.resumeFrom=r,a&&(i.resumeFrom.preserveOpacity=!0),r.snapshot&&(i.snapshot=r.snapshot,i.snapshot.latestValues=r.animationValues||r.latestValues),i.root&&i.root.isUpdating&&(i.isLayoutDirty=!0);const{crossfade:s}=i.options;s===!1&&r.hide()}}exitAnimationComplete(){this.members.forEach(i=>{const{options:a,resumingFrom:r}=i;a.onExitComplete&&a.onExitComplete(),r&&r.options.onExitComplete&&r.options.onExitComplete()})}scheduleRender(){this.members.forEach(i=>{i.instance&&i.scheduleRender(!1)})}removeLeadSnapshot(){this.lead&&this.lead.snapshot&&(this.lead.snapshot=void 0)}}function hj(e,i,a){let r="";const s=e.x.translate/i.x,c=e.y.translate/i.y,u=(a==null?void 0:a.z)||0;if((s||c||u)&&(r=`translate3d(${s}px, ${c}px, ${u}px) `),(i.x!==1||i.y!==1)&&(r+=`scale(${1/i.x}, ${1/i.y}) `),a){const{transformPerspective:m,rotate:y,rotateX:x,rotateY:b,skewX:T,skewY:A}=a;m&&(r=`perspective(${m}px) ${r}`),y&&(r+=`rotate(${y}deg) `),x&&(r+=`rotateX(${x}deg) `),b&&(r+=`rotateY(${b}deg) `),T&&(r+=`skewX(${T}deg) `),A&&(r+=`skewY(${A}deg) `)}const f=e.x.scale*i.x,p=e.y.scale*i.y;return(f!==1||p!==1)&&(r+=`scale(${f}, ${p})`),r||"none"}const Af=["","X","Y","Z"],pj={visibility:"hidden"},mj=1e3;let gj=0;function Ef(e,i,a,r){const{latestValues:s}=i;s[e]&&(a[e]=s[e],i.setStaticValue(e,0),r&&(r[e]=0))}function c2(e){if(e.hasCheckedOptimisedAppear=!0,e.root===e)return;const{visualElement:i}=e.options;if(!i)return;const a=I5(i);if(window.MotionHasOptimisedAnimation(a,"transform")){const{layout:s,layoutId:c}=e.options;window.MotionCancelOptimisedAnimation(a,"transform",Ge,!(s||c))}const{parent:r}=e;r&&!r.hasCheckedOptimisedAppear&&c2(r)}function u2({attachResizeListener:e,defaultParent:i,measureScroll:a,checkIsScrollRoot:r,resetTransform:s}){return class{constructor(u={},f=i==null?void 0:i()){this.id=gj++,this.animationId=0,this.children=new Set,this.options={},this.isTreeAnimating=!1,this.isAnimationBlocked=!1,this.isLayoutDirty=!1,this.isProjectionDirty=!1,this.isSharedProjectionDirty=!1,this.isTransformDirty=!1,this.updateManuallyBlocked=!1,this.updateBlockedByResize=!1,this.isUpdating=!1,this.isSVG=!1,this.needsReset=!1,this.shouldResetTransform=!1,this.hasCheckedOptimisedAppear=!1,this.treeScale={x:1,y:1},this.eventHandlers=new Map,this.hasTreeAnimated=!1,this.updateScheduled=!1,this.scheduleUpdate=()=>this.update(),this.projectionUpdateScheduled=!1,this.checkUpdateFailed=()=>{this.isUpdating&&(this.isUpdating=!1,this.clearAllSnapshots())},this.updateProjection=()=>{this.projectionUpdateScheduled=!1,this.nodes.forEach(bj),this.nodes.forEach(jj),this.nodes.forEach(Aj),this.nodes.forEach(vj)},this.resolvedRelativeTargetAt=0,this.hasProjected=!1,this.isVisible=!0,this.animationProgress=0,this.sharedNodes=new Map,this.latestValues=u,this.root=f?f.root||f:this,this.path=f?[...f.path,f]:[],this.parent=f,this.depth=f?f.depth+1:0;for(let p=0;p<this.path.length;p++)this.path[p].shouldResetTransform=!0;this.root===this&&(this.nodes=new ij)}addEventListener(u,f){return this.eventHandlers.has(u)||this.eventHandlers.set(u,new Tp),this.eventHandlers.get(u).add(f)}notifyListeners(u,...f){const p=this.eventHandlers.get(u);p&&p.notify(...f)}hasListeners(u){return this.eventHandlers.has(u)}mount(u){if(this.instance)return;this.isSVG=k5(u)&&!hT(u),this.instance=u;const{layoutId:f,layout:p,visualElement:m}=this.options;if(m&&!m.current&&m.mount(u),this.root.nodes.add(this),this.parent&&this.parent.children.add(this),this.root.hasTreeAnimated&&(p||f)&&(this.isLayoutDirty=!0),e){let y;const x=()=>this.root.updateBlockedByResize=!1;e(u,()=>{this.root.updateBlockedByResize=!0,y&&y(),y=nj(x,250),oc.hasAnimatedSinceResize&&(oc.hasAnimatedSinceResize=!1,this.nodes.forEach(Dx))})}f&&this.root.registerSharedNode(f,this),this.options.animate!==!1&&m&&(f||p)&&this.addEventListener("didUpdate",({delta:y,hasLayoutChanged:x,hasRelativeLayoutChanged:b,layout:T})=>{if(this.isTreeAnimationBlocked()){this.target=void 0,this.relativeTarget=void 0;return}const A=this.options.transition||m.getDefaultTransition()||kj,{onLayoutAnimationStart:C,onLayoutAnimationComplete:B}=m.getProps(),E=!this.targetLayout||!l2(this.targetLayout,T),k=!x&&b;if(this.options.layoutRoot||this.resumeFrom||k||x&&(E||!this.currentAnimation)){this.resumeFrom&&(this.resumingFrom=this.resumeFrom,this.resumingFrom.resumingFrom=void 0);const M={...Lp(A,"layout"),onPlay:C,onComplete:B};(m.shouldReduceMotion||this.options.layoutRoot)&&(M.delay=0,M.type=!1),this.startAnimation(M),this.setAnimationOrigin(y,k)}else x||Dx(this),this.isLead()&&this.options.onExitComplete&&this.options.onExitComplete();this.targetLayout=T})}unmount(){this.options.layoutId&&this.willUpdate(),this.root.nodes.remove(this);const u=this.getStack();u&&u.remove(this),this.parent&&this.parent.children.delete(this),this.instance=void 0,this.eventHandlers.clear(),kn(this.updateProjection)}blockUpdate(){this.updateManuallyBlocked=!0}unblockUpdate(){this.updateManuallyBlocked=!1}isUpdateBlocked(){return this.updateManuallyBlocked||this.updateBlockedByResize}isTreeAnimationBlocked(){return this.isAnimationBlocked||this.parent&&this.parent.isTreeAnimationBlocked()||!1}startUpdate(){this.isUpdateBlocked()||(this.isUpdating=!0,this.nodes&&this.nodes.forEach(Ej),this.animationId++)}getTransformTemplate(){const{visualElement:u}=this.options;return u&&u.getProps().transformTemplate}willUpdate(u=!0){if(this.root.hasTreeAnimated=!0,this.root.isUpdateBlocked()){this.options.onExitComplete&&this.options.onExitComplete();return}if(window.MotionCancelOptimisedAnimation&&!this.hasCheckedOptimisedAppear&&c2(this),!this.root.isUpdating&&this.root.startUpdate(),this.isLayoutDirty)return;this.isLayoutDirty=!0;for(let y=0;y<this.path.length;y++){const x=this.path[y];x.shouldResetTransform=!0,x.updateScroll("snapshot"),x.options.layoutRoot&&x.willUpdate(!1)}const{layoutId:f,layout:p}=this.options;if(f===void 0&&!p)return;const m=this.getTransformTemplate();this.prevTransformTemplateValue=m?m(this.latestValues,""):void 0,this.updateSnapshot(),u&&this.notifyListeners("willUpdate")}update(){if(this.updateScheduled=!1,this.isUpdateBlocked()){this.unblockUpdate(),this.clearAllSnapshots(),this.nodes.forEach(kx);return}this.isUpdating||this.nodes.forEach(Sj),this.isUpdating=!1,this.nodes.forEach(Tj),this.nodes.forEach(yj),this.nodes.forEach(xj),this.clearAllSnapshots();const f=Mt.now();mt.delta=Qi(0,1e3/60,f-mt.timestamp),mt.timestamp=f,mt.isProcessing=!0,yf.update.process(mt),yf.preRender.process(mt),yf.render.process(mt),mt.isProcessing=!1}didUpdate(){this.updateScheduled||(this.updateScheduled=!0,Hp.read(this.scheduleUpdate))}clearAllSnapshots(){this.nodes.forEach(wj),this.sharedNodes.forEach(Cj)}scheduleUpdateProjection(){this.projectionUpdateScheduled||(this.projectionUpdateScheduled=!0,Ge.preRender(this.updateProjection,!1,!0))}scheduleCheckAfterUnmount(){Ge.postRender(()=>{this.isLayoutDirty?this.root.didUpdate():this.root.checkUpdateFailed()})}updateSnapshot(){this.snapshot||!this.instance||(this.snapshot=this.measure(),this.snapshot&&!jt(this.snapshot.measuredBox.x)&&!jt(this.snapshot.measuredBox.y)&&(this.snapshot=void 0))}updateLayout(){if(!this.instance||(this.updateScroll(),!(this.options.alwaysMeasureLayout&&this.isLead())&&!this.isLayoutDirty))return;if(this.resumeFrom&&!this.resumeFrom.instance)for(let p=0;p<this.path.length;p++)this.path[p].updateScroll();const u=this.layout;this.layout=this.measure(!1),this.layoutCorrected=We(),this.isLayoutDirty=!1,this.projectionDelta=void 0,this.notifyListeners("measure",this.layout.layoutBox);const{visualElement:f}=this.options;f&&f.notify("LayoutMeasure",this.layout.layoutBox,u?u.layoutBox:void 0)}updateScroll(u="measure"){let f=!!(this.options.layoutScroll&&this.instance);if(this.scroll&&this.scroll.animationId===this.root.animationId&&this.scroll.phase===u&&(f=!1),f&&this.instance){const p=r(this.instance);this.scroll={animationId:this.root.animationId,phase:u,isRoot:p,offset:a(this.instance),wasRoot:this.scroll?this.scroll.isRoot:p}}}resetTransform(){if(!s)return;const u=this.isLayoutDirty||this.shouldResetTransform||this.options.alwaysMeasureLayout,f=this.projectionDelta&&!s2(this.projectionDelta),p=this.getTransformTemplate(),m=p?p(this.latestValues,""):void 0,y=m!==this.prevTransformTemplateValue;u&&this.instance&&(f||Wn(this.latestValues)||y)&&(s(this.instance,m),this.shouldResetTransform=!1,this.scheduleRender())}measure(u=!0){const f=this.measurePageBox();let p=this.removeElementScroll(f);return u&&(p=this.removeTransform(p)),Dj(p),{animationId:this.root.animationId,measuredBox:f,layoutBox:p,latestValues:{},source:this.id}}measurePageBox(){var m;const{visualElement:u}=this.options;if(!u)return We();const f=u.measureViewportBox();if(!(((m=this.scroll)==null?void 0:m.wasRoot)||this.path.some(Mj))){const{scroll:y}=this.root;y&&(dr(f.x,y.offset.x),dr(f.y,y.offset.y))}return f}removeElementScroll(u){var p;const f=We();if(ei(f,u),(p=this.scroll)!=null&&p.wasRoot)return f;for(let m=0;m<this.path.length;m++){const y=this.path[m],{scroll:x,options:b}=y;y!==this.root&&x&&b.layoutScroll&&(x.wasRoot&&ei(f,u),dr(f.x,x.offset.x),dr(f.y,x.offset.y))}return f}applyTransform(u,f=!1){const p=We();ei(p,u);for(let m=0;m<this.path.length;m++){const y=this.path[m];!f&&y.options.layoutScroll&&y.scroll&&y!==y.root&&fr(p,{x:-y.scroll.offset.x,y:-y.scroll.offset.y}),Wn(y.latestValues)&&fr(p,y.latestValues)}return Wn(this.latestValues)&&fr(p,this.latestValues),p}removeTransform(u){const f=We();ei(f,u);for(let p=0;p<this.path.length;p++){const m=this.path[p];if(!m.instance||!Wn(m.latestValues))continue;Uh(m.latestValues)&&m.updateSnapshot();const y=We(),x=m.measurePageBox();ei(y,x),jx(f,m.latestValues,m.snapshot?m.snapshot.layoutBox:void 0,y)}return Wn(this.latestValues)&&jx(f,this.latestValues),f}setTargetDelta(u){this.targetDelta=u,this.root.scheduleUpdateProjection(),this.isProjectionDirty=!0}setOptions(u){this.options={...this.options,...u,crossfade:u.crossfade!==void 0?u.crossfade:!0}}clearMeasurements(){this.scroll=void 0,this.layout=void 0,this.snapshot=void 0,this.prevTransformTemplateValue=void 0,this.targetDelta=void 0,this.target=void 0,this.isLayoutDirty=!1}forceRelativeParentToResolveTarget(){this.relativeParent&&this.relativeParent.resolvedRelativeTargetAt!==mt.timestamp&&this.relativeParent.resolveTargetDelta(!0)}resolveTargetDelta(u=!1){var b;const f=this.getLead();this.isProjectionDirty||(this.isProjectionDirty=f.isProjectionDirty),this.isTransformDirty||(this.isTransformDirty=f.isTransformDirty),this.isSharedProjectionDirty||(this.isSharedProjectionDirty=f.isSharedProjectionDirty);const p=!!this.resumingFrom||this!==f;if(!(u||p&&this.isSharedProjectionDirty||this.isProjectionDirty||(b=this.parent)!=null&&b.isProjectionDirty||this.attemptToResolveRelativeTarget||this.root.updateBlockedByResize))return;const{layout:y,layoutId:x}=this.options;if(!(!this.layout||!(y||x))){if(this.resolvedRelativeTargetAt=mt.timestamp,!this.targetDelta&&!this.relativeTarget){const T=this.getClosestProjectingParent();T&&T.layout&&this.animationProgress!==1?(this.relativeParent=T,this.forceRelativeParentToResolveTarget(),this.relativeTarget=We(),this.relativeTargetOrigin=We(),Jo(this.relativeTargetOrigin,this.layout.layoutBox,T.layout.layoutBox),ei(this.relativeTarget,this.relativeTargetOrigin)):this.relativeParent=this.relativeTarget=void 0}if(!(!this.relativeTarget&&!this.targetDelta)&&(this.target||(this.target=We(),this.targetWithTransforms=We()),this.relativeTarget&&this.relativeTargetOrigin&&this.relativeParent&&this.relativeParent.target?(this.forceRelativeParentToResolveTarget(),z9(this.target,this.relativeTarget,this.relativeParent.target)):this.targetDelta?(this.resumingFrom?this.target=this.applyTransform(this.layout.layoutBox):ei(this.target,this.layout.layoutBox),W5(this.target,this.targetDelta)):ei(this.target,this.layout.layoutBox),this.attemptToResolveRelativeTarget)){this.attemptToResolveRelativeTarget=!1;const T=this.getClosestProjectingParent();T&&!!T.resumingFrom==!!this.resumingFrom&&!T.options.layoutScroll&&T.target&&this.animationProgress!==1?(this.relativeParent=T,this.forceRelativeParentToResolveTarget(),this.relativeTarget=We(),this.relativeTargetOrigin=We(),Jo(this.relativeTargetOrigin,this.target,T.target),ei(this.relativeTarget,this.relativeTargetOrigin)):this.relativeParent=this.relativeTarget=void 0}}}getClosestProjectingParent(){if(!(!this.parent||Uh(this.parent.latestValues)||J5(this.parent.latestValues)))return this.parent.isProjecting()?this.parent:this.parent.getClosestProjectingParent()}isProjecting(){return!!((this.relativeTarget||this.targetDelta||this.options.layoutRoot)&&this.layout)}calcProjection(){var A;const u=this.getLead(),f=!!this.resumingFrom||this!==u;let p=!0;if((this.isProjectionDirty||(A=this.parent)!=null&&A.isProjectionDirty)&&(p=!1),f&&(this.isSharedProjectionDirty||this.isTransformDirty)&&(p=!1),this.resolvedRelativeTargetAt===mt.timestamp&&(p=!1),p)return;const{layout:m,layoutId:y}=this.options;if(this.isTreeAnimating=!!(this.parent&&this.parent.isTreeAnimating||this.currentAnimation||this.pendingAnimation),this.isTreeAnimating||(this.targetDelta=this.relativeTarget=void 0),!this.layout||!(m||y))return;ei(this.layoutCorrected,this.layout.layoutBox);const x=this.treeScale.x,b=this.treeScale.y;$9(this.layoutCorrected,this.treeScale,this.path,f),u.layout&&!u.target&&(this.treeScale.x!==1||this.treeScale.y!==1)&&(u.target=u.layout.layoutBox,u.targetWithTransforms=We());const{target:T}=u;if(!T){this.prevProjectionDelta&&(this.createProjectionDeltas(),this.scheduleRender());return}!this.projectionDelta||!this.prevProjectionDelta?this.createProjectionDeltas():(wx(this.prevProjectionDelta.x,this.projectionDelta.x),wx(this.prevProjectionDelta.y,this.projectionDelta.y)),Qo(this.projectionDelta,this.layoutCorrected,T,this.latestValues),(this.treeScale.x!==x||this.treeScale.y!==b||!Rx(this.projectionDelta.x,this.prevProjectionDelta.x)||!Rx(this.projectionDelta.y,this.prevProjectionDelta.y))&&(this.hasProjected=!0,this.scheduleRender(),this.notifyListeners("projectionUpdate",T))}hide(){this.isVisible=!1}show(){this.isVisible=!0}scheduleRender(u=!0){var f;if((f=this.options.visualElement)==null||f.scheduleRender(),u){const p=this.getStack();p&&p.scheduleRender()}this.resumingFrom&&!this.resumingFrom.instance&&(this.resumingFrom=void 0)}createProjectionDeltas(){this.prevProjectionDelta=ur(),this.projectionDelta=ur(),this.projectionDeltaWithTransform=ur()}setAnimationOrigin(u,f=!1){const p=this.snapshot,m=p?p.latestValues:{},y={...this.latestValues},x=ur();(!this.relativeParent||!this.relativeParent.options.layoutRoot)&&(this.relativeTarget=this.relativeTargetOrigin=void 0),this.attemptToResolveRelativeTarget=!f;const b=We(),T=p?p.source:void 0,A=this.layout?this.layout.source:void 0,C=T!==A,B=this.getStack(),E=!B||B.members.length<=1,k=!!(C&&!E&&this.options.crossfade===!0&&!this.path.some(Rj));this.animationProgress=0;let M;this.mixTargetDelta=F=>{const D=F/1e3;Mx(x.x,u.x,D),Mx(x.y,u.y,D),this.setTargetDelta(x),this.relativeTarget&&this.relativeTargetOrigin&&this.layout&&this.relativeParent&&this.relativeParent.layout&&(Jo(b,this.layout.layoutBox,this.relativeParent.layout.layoutBox),Oj(this.relativeTarget,this.relativeTargetOrigin,b,D),M&&dj(this.relativeTarget,M)&&(this.isProjectionDirty=!1),M||(M=We()),ei(M,this.relativeTarget)),C&&(this.animationValues=y,rj(y,m,this.latestValues,D,k,E)),this.root.scheduleUpdateProjection(),this.scheduleRender(),this.animationProgress=D},this.mixTargetDelta(this.options.layoutRoot?1e3:0)}startAnimation(u){var f,p,m;this.notifyListeners("animationStart"),(f=this.currentAnimation)==null||f.stop(),(m=(p=this.resumingFrom)==null?void 0:p.currentAnimation)==null||m.stop(),this.pendingAnimation&&(kn(this.pendingAnimation),this.pendingAnimation=void 0),this.pendingAnimation=Ge.update(()=>{oc.hasAnimatedSinceResize=!0,this.motionValue||(this.motionValue=vr(0)),this.currentAnimation=ej(this.motionValue,[0,1e3],{...u,velocity:0,isSync:!0,onUpdate:y=>{this.mixTargetDelta(y),u.onUpdate&&u.onUpdate(y)},onStop:()=>{},onComplete:()=>{u.onComplete&&u.onComplete(),this.completeAnimation()}}),this.resumingFrom&&(this.resumingFrom.currentAnimation=this.currentAnimation),this.pendingAnimation=void 0})}completeAnimation(){this.resumingFrom&&(this.resumingFrom.currentAnimation=void 0,this.resumingFrom.preserveOpacity=void 0);const u=this.getStack();u&&u.exitAnimationComplete(),this.resumingFrom=this.currentAnimation=this.animationValues=void 0,this.notifyListeners("animationComplete")}finishAnimation(){this.currentAnimation&&(this.mixTargetDelta&&this.mixTargetDelta(mj),this.currentAnimation.stop()),this.completeAnimation()}applyTransformsToTarget(){const u=this.getLead();let{targetWithTransforms:f,target:p,layout:m,latestValues:y}=u;if(!(!f||!p||!m)){if(this!==u&&this.layout&&m&&d2(this.options.animationType,this.layout.layoutBox,m.layoutBox)){p=this.target||We();const x=jt(this.layout.layoutBox.x);p.x.min=u.target.x.min,p.x.max=p.x.min+x;const b=jt(this.layout.layoutBox.y);p.y.min=u.target.y.min,p.y.max=p.y.min+b}ei(f,p),fr(f,y),Qo(this.projectionDeltaWithTransform,this.layoutCorrected,f,y)}}registerSharedNode(u,f){this.sharedNodes.has(u)||this.sharedNodes.set(u,new fj),this.sharedNodes.get(u).add(f);const m=f.options.initialPromotionConfig;f.promote({transition:m?m.transition:void 0,preserveFollowOpacity:m&&m.shouldPreserveFollowOpacity?m.shouldPreserveFollowOpacity(f):void 0})}isLead(){const u=this.getStack();return u?u.lead===this:!0}getLead(){var f;const{layoutId:u}=this.options;return u?((f=this.getStack())==null?void 0:f.lead)||this:this}getPrevLead(){var f;const{layoutId:u}=this.options;return u?(f=this.getStack())==null?void 0:f.prevLead:void 0}getStack(){const{layoutId:u}=this.options;if(u)return this.root.sharedNodes.get(u)}promote({needsReset:u,transition:f,preserveFollowOpacity:p}={}){const m=this.getStack();m&&m.promote(this,p),u&&(this.projectionDelta=void 0,this.needsReset=!0),f&&this.setOptions({transition:f})}relegate(){const u=this.getStack();return u?u.relegate(this):!1}resetSkewAndRotation(){const{visualElement:u}=this.options;if(!u)return;let f=!1;const{latestValues:p}=u;if((p.z||p.rotate||p.rotateX||p.rotateY||p.rotateZ||p.skewX||p.skewY)&&(f=!0),!f)return;const m={};p.z&&Ef("z",u,m,this.animationValues);for(let y=0;y<Af.length;y++)Ef(`rotate${Af[y]}`,u,m,this.animationValues),Ef(`skew${Af[y]}`,u,m,this.animationValues);u.render();for(const y in m)u.setStaticValue(y,m[y]),this.animationValues&&(this.animationValues[y]=m[y]);u.scheduleRender()}getProjectionStyles(u){if(!this.instance||this.isSVG)return;if(!this.isVisible)return pj;const f={visibility:""},p=this.getTransformTemplate();if(this.needsReset)return this.needsReset=!1,f.opacity="",f.pointerEvents=rc(u==null?void 0:u.pointerEvents)||"",f.transform=p?p(this.latestValues,""):"none",f;const m=this.getLead();if(!this.projectionDelta||!this.layout||!m.target){const T={};return this.options.layoutId&&(T.opacity=this.latestValues.opacity!==void 0?this.latestValues.opacity:1,T.pointerEvents=rc(u==null?void 0:u.pointerEvents)||""),this.hasProjected&&!Wn(this.latestValues)&&(T.transform=p?p({},""):"none",this.hasProjected=!1),T}const y=m.animationValues||m.latestValues;this.applyTransformsToTarget(),f.transform=hj(this.projectionDeltaWithTransform,this.treeScale,y),p&&(f.transform=p(y,f.transform));const{x,y:b}=this.projectionDelta;f.transformOrigin=`${x.origin*100}% ${b.origin*100}% 0`,m.animationValues?f.opacity=m===this?y.opacity??this.latestValues.opacity??1:this.preserveOpacity?this.latestValues.opacity:y.opacityExit:f.opacity=m===this?y.opacity!==void 0?y.opacity:"":y.opacityExit!==void 0?y.opacityExit:0;for(const T in ls){if(y[T]===void 0)continue;const{correct:A,applyTo:C,isCSSVariable:B}=ls[T],E=f.transform==="none"?y[T]:A(y[T],m);if(C){const k=C.length;for(let M=0;M<k;M++)f[C[M]]=E}else B?this.options.visualElement.renderState.vars[T]=E:f[T]=E}return this.options.layoutId&&(f.pointerEvents=m===this?rc(u==null?void 0:u.pointerEvents)||"":"none"),f}clearSnapshot(){this.resumeFrom=this.snapshot=void 0}resetTree(){this.root.nodes.forEach(u=>{var f;return(f=u.currentAnimation)==null?void 0:f.stop()}),this.root.nodes.forEach(kx),this.root.sharedNodes.clear()}}}function yj(e){e.updateLayout()}function xj(e){var a;const i=((a=e.resumeFrom)==null?void 0:a.snapshot)||e.snapshot;if(e.isLead()&&e.layout&&i&&e.hasListeners("didUpdate")){const{layoutBox:r,measuredBox:s}=e.layout,{animationType:c}=e.options,u=i.source!==e.layout.source;c==="size"?ti(x=>{const b=u?i.measuredBox[x]:i.layoutBox[x],T=jt(b);b.min=r[x].min,b.max=b.min+T}):d2(c,i.layoutBox,r)&&ti(x=>{const b=u?i.measuredBox[x]:i.layoutBox[x],T=jt(r[x]);b.max=b.min+T,e.relativeTarget&&!e.currentAnimation&&(e.isProjectionDirty=!0,e.relativeTarget[x].max=e.relativeTarget[x].min+T)});const f=ur();Qo(f,r,i.layoutBox);const p=ur();u?Qo(p,e.applyTransform(s,!0),i.measuredBox):Qo(p,r,i.layoutBox);const m=!s2(f);let y=!1;if(!e.resumeFrom){const x=e.getClosestProjectingParent();if(x&&!x.resumeFrom){const{snapshot:b,layout:T}=x;if(b&&T){const A=We();Jo(A,i.layoutBox,b.layoutBox);const C=We();Jo(C,r,T.layoutBox),l2(A,C)||(y=!0),x.options.layoutRoot&&(e.relativeTarget=C,e.relativeTargetOrigin=A,e.relativeParent=x)}}}e.notifyListeners("didUpdate",{layout:r,snapshot:i,delta:p,layoutDelta:f,hasLayoutChanged:m,hasRelativeLayoutChanged:y})}else if(e.isLead()){const{onExitComplete:r}=e.options;r&&r()}e.options.transition=void 0}function bj(e){e.parent&&(e.isProjecting()||(e.isProjectionDirty=e.parent.isProjectionDirty),e.isSharedProjectionDirty||(e.isSharedProjectionDirty=!!(e.isProjectionDirty||e.parent.isProjectionDirty||e.parent.isSharedProjectionDirty)),e.isTransformDirty||(e.isTransformDirty=e.parent.isTransformDirty))}function vj(e){e.isProjectionDirty=e.isSharedProjectionDirty=e.isTransformDirty=!1}function wj(e){e.clearSnapshot()}function kx(e){e.clearMeasurements()}function Sj(e){e.isLayoutDirty=!1}function Tj(e){const{visualElement:i}=e.options;i&&i.getProps().onBeforeLayoutMeasure&&i.notify("BeforeLayoutMeasure"),e.resetTransform()}function Dx(e){e.finishAnimation(),e.targetDelta=e.relativeTarget=e.target=void 0,e.isProjectionDirty=!0}function jj(e){e.resolveTargetDelta()}function Aj(e){e.calcProjection()}function Ej(e){e.resetSkewAndRotation()}function Cj(e){e.removeLeadSnapshot()}function Mx(e,i,a){e.translate=Ye(i.translate,0,a),e.scale=Ye(i.scale,1,a),e.origin=i.origin,e.originPoint=i.originPoint}function Bx(e,i,a,r){e.min=Ye(i.min,a.min,r),e.max=Ye(i.max,a.max,r)}function Oj(e,i,a,r){Bx(e.x,i.x,a.x,r),Bx(e.y,i.y,a.y,r)}function Rj(e){return e.animationValues&&e.animationValues.opacityExit!==void 0}const kj={duration:.45,ease:[.4,0,.1,1]},zx=e=>typeof navigator<"u"&&navigator.userAgent&&navigator.userAgent.toLowerCase().includes(e),$x=zx("applewebkit/")&&!zx("chrome/")?Math.round:ii;function Nx(e){e.min=$x(e.min),e.max=$x(e.max)}function Dj(e){Nx(e.x),Nx(e.y)}function d2(e,i,a){return e==="position"||e==="preserve-aspect"&&!B9(Ox(i),Ox(a),.2)}function Mj(e){var i;return e!==e.root&&((i=e.scroll)==null?void 0:i.wasRoot)}const Bj=u2({attachResizeListener:(e,i)=>us(e,"resize",i),measureScroll:()=>({x:document.documentElement.scrollLeft||document.body.scrollLeft,y:document.documentElement.scrollTop||document.body.scrollTop}),checkIsScrollRoot:()=>!0}),Cf={current:void 0},f2=u2({measureScroll:e=>({x:e.scrollLeft,y:e.scrollTop}),defaultParent:()=>{if(!Cf.current){const e=new Bj({});e.mount(window),e.setOptions({layoutScroll:!0}),Cf.current=e}return Cf.current},resetTransform:(e,i)=>{e.style.transform=i!==void 0?i:"none"},checkIsScrollRoot:e=>window.getComputedStyle(e).position==="fixed"}),zj={pan:{Feature:Z9},drag:{Feature:X9,ProjectionNode:f2,MeasureLayout:a2}};function Lx(e,i,a){const{props:r}=e;e.animationState&&r.whileHover&&e.animationState.setActive("whileHover",a==="Start");const s="onHover"+a,c=r[s];c&&Ge.postRender(()=>c(i,ws(i)))}class $j extends Mn{mount(){const{current:i}=this.node;i&&(this.unmount=lT(i,(a,r)=>(Lx(this.node,r,"Start"),s=>Lx(this.node,s,"End"))))}unmount(){}}class Nj extends Mn{constructor(){super(...arguments),this.isActive=!1}onFocus(){let i=!1;try{i=this.node.current.matches(":focus-visible")}catch{i=!0}!i||!this.node.animationState||(this.node.animationState.setActive("whileFocus",!0),this.isActive=!0)}onBlur(){!this.isActive||!this.node.animationState||(this.node.animationState.setActive("whileFocus",!1),this.isActive=!1)}mount(){this.unmount=xs(us(this.node.current,"focus",()=>this.onFocus()),us(this.node.current,"blur",()=>this.onBlur()))}unmount(){}}function _x(e,i,a){const{props:r}=e;if(e.current instanceof HTMLButtonElement&&e.current.disabled)return;e.animationState&&r.whileTap&&e.animationState.setActive("whileTap",a==="Start");const s="onTap"+(a==="End"?"":a),c=r[s];c&&Ge.postRender(()=>c(i,ws(i)))}class Lj extends Mn{mount(){const{current:i}=this.node;i&&(this.unmount=fT(i,(a,r)=>(_x(this.node,r,"Start"),(s,{success:c})=>_x(this.node,s,c?"End":"Cancel")),{useGlobalTarget:this.node.props.globalTapTarget}))}unmount(){}}const Yh=new WeakMap,Of=new WeakMap,_j=e=>{const i=Yh.get(e.target);i&&i(e)},Hj=e=>{e.forEach(_j)};function Vj({root:e,...i}){const a=e||document;Of.has(a)||Of.set(a,{});const r=Of.get(a),s=JSON.stringify(i);return r[s]||(r[s]=new IntersectionObserver(Hj,{root:e,...i})),r[s]}function Pj(e,i,a){const r=Vj(i);return Yh.set(e,a),r.observe(e),()=>{Yh.delete(e),r.unobserve(e)}}const Fj={some:0,all:1};class Uj extends Mn{constructor(){super(...arguments),this.hasEnteredView=!1,this.isInView=!1}startObserver(){this.unmount();const{viewport:i={}}=this.node.getProps(),{root:a,margin:r,amount:s="some",once:c}=i,u={root:a?a.current:void 0,rootMargin:r,threshold:typeof s=="number"?s:Fj[s]},f=p=>{const{isIntersecting:m}=p;if(this.isInView===m||(this.isInView=m,c&&!m&&this.hasEnteredView))return;m&&(this.hasEnteredView=!0),this.node.animationState&&this.node.animationState.setActive("whileInView",m);const{onViewportEnter:y,onViewportLeave:x}=this.node.getProps(),b=m?y:x;b&&b(p)};return Pj(this.node.current,u,f)}mount(){this.startObserver()}update(){if(typeof IntersectionObserver>"u")return;const{props:i,prevProps:a}=this.node;["amount","margin","root"].some(qj(i,a))&&this.startObserver()}unmount(){}}function qj({viewport:e={}},{viewport:i={}}={}){return a=>e[a]!==i[a]}const Ij={inView:{Feature:Uj},tap:{Feature:Lj},focus:{Feature:Nj},hover:{Feature:$j}},Yj={layout:{ProjectionNode:f2,MeasureLayout:a2}},Gh={current:null},h2={current:!1};function Gj(){if(h2.current=!0,!!xp)if(window.matchMedia){const e=window.matchMedia("(prefers-reduced-motion)"),i=()=>Gh.current=e.matches;e.addListener(i),i()}else Gh.current=!1}const Kj=new WeakMap;function Xj(e,i,a){for(const r in i){const s=i[r],c=a[r];if(wt(s))e.addValue(r,s);else if(wt(c))e.addValue(r,vr(s,{owner:e}));else if(c!==s)if(e.hasValue(r)){const u=e.getValue(r);u.liveStyle===!0?u.jump(s):u.hasAnimated||u.set(s)}else{const u=e.getStaticValue(r);e.addValue(r,vr(u!==void 0?u:s,{owner:e}))}}for(const r in a)i[r]===void 0&&e.removeValue(r);return i}const Hx=["AnimationStart","AnimationComplete","Update","BeforeLayoutMeasure","LayoutMeasure","LayoutAnimationStart","LayoutAnimationComplete"];class Zj{scrapeMotionValuesFromProps(i,a,r){return{}}constructor({parent:i,props:a,presenceContext:r,reducedMotionConfig:s,blockInitialAnimation:c,visualState:u},f={}){this.current=null,this.children=new Set,this.isVariantNode=!1,this.isControllingVariants=!1,this.shouldReduceMotion=null,this.values=new Map,this.KeyframeResolver=$p,this.features={},this.valueSubscriptions=new Map,this.prevMotionValues={},this.events={},this.propEventSubscriptions={},this.notifyUpdate=()=>this.notify("Update",this.latestValues),this.render=()=>{this.current&&(this.triggerBuild(),this.renderInstance(this.current,this.renderState,this.props.style,this.projection))},this.renderScheduledAt=0,this.scheduleRender=()=>{const b=Mt.now();this.renderScheduledAt<b&&(this.renderScheduledAt=b,Ge.render(this.render,!1,!0))};const{latestValues:p,renderState:m}=u;this.latestValues=p,this.baseTarget={...p},this.initialValues=a.initial?{...p}:{},this.renderState=m,this.parent=i,this.props=a,this.presenceContext=r,this.depth=i?i.depth+1:0,this.reducedMotionConfig=s,this.options=f,this.blockInitialAnimation=!!c,this.isControllingVariants=Pc(a),this.isVariantNode=z5(a),this.isVariantNode&&(this.variantChildren=new Set),this.manuallyAnimateOnMount=!!(i&&i.current);const{willChange:y,...x}=this.scrapeMotionValuesFromProps(a,{},this);for(const b in x){const T=x[b];p[b]!==void 0&&wt(T)&&T.set(p[b],!1)}}mount(i){this.current=i,Kj.set(i,this),this.projection&&!this.projection.instance&&this.projection.mount(i),this.parent&&this.isVariantNode&&!this.isControllingVariants&&(this.removeFromVariantTree=this.parent.addVariantChild(this)),this.values.forEach((a,r)=>this.bindToMotionValue(r,a)),h2.current||Gj(),this.shouldReduceMotion=this.reducedMotionConfig==="never"?!1:this.reducedMotionConfig==="always"?!0:Gh.current,this.parent&&this.parent.children.add(this),this.update(this.props,this.presenceContext)}unmount(){this.projection&&this.projection.unmount(),kn(this.notifyUpdate),kn(this.render),this.valueSubscriptions.forEach(i=>i()),this.valueSubscriptions.clear(),this.removeFromVariantTree&&this.removeFromVariantTree(),this.parent&&this.parent.children.delete(this);for(const i in this.events)this.events[i].clear();for(const i in this.features){const a=this.features[i];a&&(a.unmount(),a.isMounted=!1)}this.current=null}bindToMotionValue(i,a){this.valueSubscriptions.has(i)&&this.valueSubscriptions.get(i)();const r=Dr.has(i);r&&this.onBindTransform&&this.onBindTransform();const s=a.on("change",f=>{this.latestValues[i]=f,this.props.onUpdate&&Ge.preRender(this.notifyUpdate),r&&this.projection&&(this.projection.isTransformDirty=!0)}),c=a.on("renderRequest",this.scheduleRender);let u;window.MotionCheckAppearSync&&(u=window.MotionCheckAppearSync(this,i,a)),this.valueSubscriptions.set(i,()=>{s(),c(),u&&u(),a.owner&&a.stop()})}sortNodePosition(i){return!this.current||!this.sortInstanceNodePosition||this.type!==i.type?0:this.sortInstanceNodePosition(this.current,i.current)}updateFeatures(){let i="animation";for(i in wr){const a=wr[i];if(!a)continue;const{isEnabled:r,Feature:s}=a;if(!this.features[i]&&s&&r(this.props)&&(this.features[i]=new s(this)),this.features[i]){const c=this.features[i];c.isMounted?c.update():(c.mount(),c.isMounted=!0)}}}triggerBuild(){this.build(this.renderState,this.latestValues,this.props)}measureViewportBox(){return this.current?this.measureInstanceViewportBox(this.current,this.props):We()}getStaticValue(i){return this.latestValues[i]}setStaticValue(i,a){this.latestValues[i]=a}update(i,a){(i.transformTemplate||this.props.transformTemplate)&&this.scheduleRender(),this.prevProps=this.props,this.props=i,this.prevPresenceContext=this.presenceContext,this.presenceContext=a;for(let r=0;r<Hx.length;r++){const s=Hx[r];this.propEventSubscriptions[s]&&(this.propEventSubscriptions[s](),delete this.propEventSubscriptions[s]);const c="on"+s,u=i[c];u&&(this.propEventSubscriptions[s]=this.on(s,u))}this.prevMotionValues=Xj(this,this.scrapeMotionValuesFromProps(i,this.prevProps,this),this.prevMotionValues),this.handleChildMotionValue&&this.handleChildMotionValue()}getProps(){return this.props}getVariant(i){return this.props.variants?this.props.variants[i]:void 0}getDefaultTransition(){return this.props.transition}getTransformPagePoint(){return this.props.transformPagePoint}getClosestVariantNode(){return this.isVariantNode?this:this.parent?this.parent.getClosestVariantNode():void 0}addVariantChild(i){const a=this.getClosestVariantNode();if(a)return a.variantChildren&&a.variantChildren.add(i),()=>a.variantChildren.delete(i)}addValue(i,a){const r=this.values.get(i);a!==r&&(r&&this.removeValue(i),this.bindToMotionValue(i,a),this.values.set(i,a),this.latestValues[i]=a.get())}removeValue(i){this.values.delete(i);const a=this.valueSubscriptions.get(i);a&&(a(),this.valueSubscriptions.delete(i)),delete this.latestValues[i],this.removeValueFromRenderState(i,this.renderState)}hasValue(i){return this.values.has(i)}getValue(i,a){if(this.props.values&&this.props.values[i])return this.props.values[i];let r=this.values.get(i);return r===void 0&&a!==void 0&&(r=vr(a===null?void 0:a,{owner:this}),this.addValue(i,r)),r}readValue(i,a){let r=this.latestValues[i]!==void 0||!this.current?this.latestValues[i]:this.getBaseTargetFromProps(this.props,i)??this.readValueFromInstance(this.current,i,this.options);return r!=null&&(typeof r=="string"&&(Pv(r)||Uv(r))?r=parseFloat(r):!mT(r)&&Dn.test(a)&&(r=j5(i,a)),this.setBaseTarget(i,wt(r)?r.get():r)),wt(r)?r.get():r}setBaseTarget(i,a){this.baseTarget[i]=a}getBaseTarget(i){var c;const{initial:a}=this.props;let r;if(typeof a=="string"||typeof a=="object"){const u=Kp(this.props,a,(c=this.presenceContext)==null?void 0:c.custom);u&&(r=u[i])}if(a&&r!==void 0)return r;const s=this.getBaseTargetFromProps(this.props,i);return s!==void 0&&!wt(s)?s:this.initialValues[i]!==void 0&&r===void 0?void 0:this.baseTarget[i]}on(i,a){return this.events[i]||(this.events[i]=new Tp),this.events[i].add(a)}notify(i,...a){this.events[i]&&this.events[i].notify(...a)}}class p2 extends Zj{constructor(){super(...arguments),this.KeyframeResolver=aT}sortInstanceNodePosition(i,a){return i.compareDocumentPosition(a)&2?1:-1}getBaseTargetFromProps(i,a){return i.style?i.style[a]:void 0}removeValueFromRenderState(i,{vars:a,style:r}){delete a[i],delete r[i]}handleChildMotionValue(){this.childSubscription&&(this.childSubscription(),delete this.childSubscription);const{children:i}=this.props;wt(i)&&(this.childSubscription=i.on("change",a=>{this.current&&(this.current.textContent=`${a}`)}))}}function m2(e,{style:i,vars:a},r,s){Object.assign(e.style,i,s&&s.getProjectionStyles(r));for(const c in a)e.style.setProperty(c,a[c])}function Qj(e){return window.getComputedStyle(e)}class Jj extends p2{constructor(){super(...arguments),this.type="html",this.renderInstance=m2}readValueFromInstance(i,a){var r;if(Dr.has(a))return(r=this.projection)!=null&&r.isProjecting?zh(a):T6(i,a);{const s=Qj(i),c=(Ep(a)?s.getPropertyValue(a):s[a])||0;return typeof c=="string"?c.trim():c}}measureInstanceViewportBox(i,{transformPagePoint:a}){return e2(i,a)}build(i,a,r){Ip(i,a,r.transformTemplate)}scrapeMotionValuesFromProps(i,a,r){return Xp(i,a,r)}}const g2=new Set(["baseFrequency","diffuseConstant","kernelMatrix","kernelUnitLength","keySplines","keyTimes","limitingConeAngle","markerHeight","markerWidth","numOctaves","targetX","targetY","surfaceScale","specularConstant","specularExponent","stdDeviation","tableValues","viewBox","gradientTransform","pathLength","startOffset","textLength","lengthAdjust"]);function Wj(e,i,a,r){m2(e,i,void 0,r);for(const s in i.attrs)e.setAttribute(g2.has(s)?s:qp(s),i.attrs[s])}class eA extends p2{constructor(){super(...arguments),this.type="svg",this.isSVGTag=!1,this.measureInstanceViewportBox=We}getBaseTargetFromProps(i,a){return i[a]}readValueFromInstance(i,a){if(Dr.has(a)){const r=T5(a);return r&&r.default||0}return a=g2.has(a)?a:qp(a),i.getAttribute(a)}scrapeMotionValuesFromProps(i,a,r){return q5(i,a,r)}build(i,a,r){V5(i,a,this.isSVGTag,r.transformTemplate,r.style)}renderInstance(i,a,r,s){Wj(i,a,r,s)}mount(i){this.isSVGTag=F5(i.tagName),super.mount(i)}}const tA=(e,i)=>Gp(e)?new eA(i):new Jj(i,{allowProjection:e!==S.Fragment}),iA=WT({...A9,...Ij,...zj,...Yj},tA),O=jT(iA),nA={some:0,all:1};function aA(e,i,{root:a,margin:r,amount:s="some"}={}){const c=A5(e),u=new WeakMap,f=m=>{m.forEach(y=>{const x=u.get(y.target);if(y.isIntersecting!==!!x)if(y.isIntersecting){const b=i(y.target,y);typeof b=="function"?u.set(y.target,b):p.unobserve(y.target)}else typeof x=="function"&&(x(y),u.delete(y.target))})},p=new IntersectionObserver(f,{root:a,rootMargin:r,threshold:typeof s=="number"?s:nA[s]});return c.forEach(m=>p.observe(m)),()=>p.disconnect()}function rA(e,{root:i,margin:a,amount:r,once:s=!1,initial:c=!1}={}){const[u,f]=S.useState(c);return S.useEffect(()=>{if(!e.current||s&&u)return;const p=()=>(f(!0),s?void 0:()=>f(!1)),m={root:i&&i.current||void 0,margin:a,amount:r};return aA(e.current,p,m)},[i,e,a,s,r]),u}const oA="/assets/logo-header-7WTZC_mL.png",sA=mp`
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
`,lA=mp`
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
  }
`,cA=mp`
  0% {
    opacity: 0;
    transform: translateY(30px) scale(0.8);
  }
  100% {
    opacity: 1;
    transform: translateY(0) scale(1);
  }
`,uA=w.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background: #ffffff;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999;
  
  /* CSS анимация появления */
  animation: ${sA} 0.3s ease-out forwards;
  
  /* Когда компонент исчезает */
  &.exiting {
    animation: ${lA} 0.4s ease-in forwards;
  }
  
  /* Улучшаем производительность */
  will-change: opacity;
  transform: translateZ(0);
  -webkit-transform: translateZ(0);
  backface-visibility: hidden;
  -webkit-backface-visibility: hidden;
`,dA=w.div`
  display: flex;
  align-items: center;
  justify-content: center;
`,fA=w.img`
  width: 200px;
  height: auto;
  object-fit: contain;
  
  /* CSS анимация логотипа */
  animation: ${cA} 1s cubic-bezier(0.16, 1, 0.3, 1) 0.1s both;
  
  /* Улучшаем качество и производительность */
  image-rendering: -webkit-optimize-contrast;
  image-rendering: crisp-edges;
  will-change: transform, opacity;
  transform: translateZ(0);
  -webkit-transform: translateZ(0);
  backface-visibility: hidden;
  -webkit-backface-visibility: hidden;
  
  @media (min-width: 768px) {
    width: 250px;
  }
  
  @media (min-width: 1024px) {
    width: 300px;
  }
`,hA=({isVisible:e})=>{const[i,a]=Ce.useState(e),[r,s]=Ce.useState(!1);return Ce.useEffect(()=>{if(e)a(!0),s(!1);else if(i){s(!0);const c=setTimeout(()=>{a(!1),s(!1)},400);return()=>clearTimeout(c)}},[e,i]),i?h.jsx(uA,{className:r?"exiting":"",children:h.jsx(dA,{children:h.jsx(fA,{src:oA,alt:"KAIF"})})}):null},he=e=>typeof e=="string",Lo=()=>{let e,i;const a=new Promise((r,s)=>{e=r,i=s});return a.resolve=e,a.reject=i,a},Vx=e=>e==null?"":""+e,pA=(e,i,a)=>{e.forEach(r=>{i[r]&&(a[r]=i[r])})},mA=/###/g,Px=e=>e&&e.indexOf("###")>-1?e.replace(mA,"."):e,Fx=e=>!e||he(e),Wo=(e,i,a)=>{const r=he(i)?i.split("."):i;let s=0;for(;s<r.length-1;){if(Fx(e))return{};const c=Px(r[s]);!e[c]&&a&&(e[c]=new a),Object.prototype.hasOwnProperty.call(e,c)?e=e[c]:e={},++s}return Fx(e)?{}:{obj:e,k:Px(r[s])}},Ux=(e,i,a)=>{const{obj:r,k:s}=Wo(e,i,Object);if(r!==void 0||i.length===1){r[s]=a;return}let c=i[i.length-1],u=i.slice(0,i.length-1),f=Wo(e,u,Object);for(;f.obj===void 0&&u.length;)c=`${u[u.length-1]}.${c}`,u=u.slice(0,u.length-1),f=Wo(e,u,Object),f!=null&&f.obj&&typeof f.obj[`${f.k}.${c}`]<"u"&&(f.obj=void 0);f.obj[`${f.k}.${c}`]=a},gA=(e,i,a,r)=>{const{obj:s,k:c}=Wo(e,i,Object);s[c]=s[c]||[],s[c].push(a)},wc=(e,i)=>{const{obj:a,k:r}=Wo(e,i);if(a&&Object.prototype.hasOwnProperty.call(a,r))return a[r]},yA=(e,i,a)=>{const r=wc(e,a);return r!==void 0?r:wc(i,a)},y2=(e,i,a)=>{for(const r in i)r!=="__proto__"&&r!=="constructor"&&(r in e?he(e[r])||e[r]instanceof String||he(i[r])||i[r]instanceof String?a&&(e[r]=i[r]):y2(e[r],i[r],a):e[r]=i[r]);return e},Ja=e=>e.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g,"\\$&");var xA={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;","/":"&#x2F;"};const bA=e=>he(e)?e.replace(/[&<>"'\/]/g,i=>xA[i]):e;class vA{constructor(i){this.capacity=i,this.regExpMap=new Map,this.regExpQueue=[]}getRegExp(i){const a=this.regExpMap.get(i);if(a!==void 0)return a;const r=new RegExp(i);return this.regExpQueue.length===this.capacity&&this.regExpMap.delete(this.regExpQueue.shift()),this.regExpMap.set(i,r),this.regExpQueue.push(i),r}}const wA=[" ",",","?","!",";"],SA=new vA(20),TA=(e,i,a)=>{i=i||"",a=a||"";const r=wA.filter(u=>i.indexOf(u)<0&&a.indexOf(u)<0);if(r.length===0)return!0;const s=SA.getRegExp(`(${r.map(u=>u==="?"?"\\?":u).join("|")})`);let c=!s.test(e);if(!c){const u=e.indexOf(a);u>0&&!s.test(e.substring(0,u))&&(c=!0)}return c},Kh=(e,i,a=".")=>{if(!e)return;if(e[i])return Object.prototype.hasOwnProperty.call(e,i)?e[i]:void 0;const r=i.split(a);let s=e;for(let c=0;c<r.length;){if(!s||typeof s!="object")return;let u,f="";for(let p=c;p<r.length;++p)if(p!==c&&(f+=a),f+=r[p],u=s[f],u!==void 0){if(["string","number","boolean"].indexOf(typeof u)>-1&&p<r.length-1)continue;c+=p-c+1;break}s=u}return s},ds=e=>e==null?void 0:e.replace("_","-"),jA={type:"logger",log(e){this.output("log",e)},warn(e){this.output("warn",e)},error(e){this.output("error",e)},output(e,i){var a,r;(r=(a=console==null?void 0:console[e])==null?void 0:a.apply)==null||r.call(a,console,i)}};class Sc{constructor(i,a={}){this.init(i,a)}init(i,a={}){this.prefix=a.prefix||"i18next:",this.logger=i||jA,this.options=a,this.debug=a.debug}log(...i){return this.forward(i,"log","",!0)}warn(...i){return this.forward(i,"warn","",!0)}error(...i){return this.forward(i,"error","")}deprecate(...i){return this.forward(i,"warn","WARNING DEPRECATED: ",!0)}forward(i,a,r,s){return s&&!this.debug?null:(he(i[0])&&(i[0]=`${r}${this.prefix} ${i[0]}`),this.logger[a](i))}create(i){return new Sc(this.logger,{prefix:`${this.prefix}:${i}:`,...this.options})}clone(i){return i=i||this.options,i.prefix=i.prefix||this.prefix,new Sc(this.logger,i)}}var ji=new Sc;class Fc{constructor(){this.observers={}}on(i,a){return i.split(" ").forEach(r=>{this.observers[r]||(this.observers[r]=new Map);const s=this.observers[r].get(a)||0;this.observers[r].set(a,s+1)}),this}off(i,a){if(this.observers[i]){if(!a){delete this.observers[i];return}this.observers[i].delete(a)}}emit(i,...a){this.observers[i]&&Array.from(this.observers[i].entries()).forEach(([s,c])=>{for(let u=0;u<c;u++)s(...a)}),this.observers["*"]&&Array.from(this.observers["*"].entries()).forEach(([s,c])=>{for(let u=0;u<c;u++)s.apply(s,[i,...a])})}}class qx extends Fc{constructor(i,a={ns:["translation"],defaultNS:"translation"}){super(),this.data=i||{},this.options=a,this.options.keySeparator===void 0&&(this.options.keySeparator="."),this.options.ignoreJSONStructure===void 0&&(this.options.ignoreJSONStructure=!0)}addNamespaces(i){this.options.ns.indexOf(i)<0&&this.options.ns.push(i)}removeNamespaces(i){const a=this.options.ns.indexOf(i);a>-1&&this.options.ns.splice(a,1)}getResource(i,a,r,s={}){var m,y;const c=s.keySeparator!==void 0?s.keySeparator:this.options.keySeparator,u=s.ignoreJSONStructure!==void 0?s.ignoreJSONStructure:this.options.ignoreJSONStructure;let f;i.indexOf(".")>-1?f=i.split("."):(f=[i,a],r&&(Array.isArray(r)?f.push(...r):he(r)&&c?f.push(...r.split(c)):f.push(r)));const p=wc(this.data,f);return!p&&!a&&!r&&i.indexOf(".")>-1&&(i=f[0],a=f[1],r=f.slice(2).join(".")),p||!u||!he(r)?p:Kh((y=(m=this.data)==null?void 0:m[i])==null?void 0:y[a],r,c)}addResource(i,a,r,s,c={silent:!1}){const u=c.keySeparator!==void 0?c.keySeparator:this.options.keySeparator;let f=[i,a];r&&(f=f.concat(u?r.split(u):r)),i.indexOf(".")>-1&&(f=i.split("."),s=a,a=f[1]),this.addNamespaces(a),Ux(this.data,f,s),c.silent||this.emit("added",i,a,r,s)}addResources(i,a,r,s={silent:!1}){for(const c in r)(he(r[c])||Array.isArray(r[c]))&&this.addResource(i,a,c,r[c],{silent:!0});s.silent||this.emit("added",i,a,r)}addResourceBundle(i,a,r,s,c,u={silent:!1,skipCopy:!1}){let f=[i,a];i.indexOf(".")>-1&&(f=i.split("."),s=r,r=a,a=f[1]),this.addNamespaces(a);let p=wc(this.data,f)||{};u.skipCopy||(r=JSON.parse(JSON.stringify(r))),s?y2(p,r,c):p={...p,...r},Ux(this.data,f,p),u.silent||this.emit("added",i,a,r)}removeResourceBundle(i,a){this.hasResourceBundle(i,a)&&delete this.data[i][a],this.removeNamespaces(a),this.emit("removed",i,a)}hasResourceBundle(i,a){return this.getResource(i,a)!==void 0}getResourceBundle(i,a){return a||(a=this.options.defaultNS),this.getResource(i,a)}getDataByLanguage(i){return this.data[i]}hasLanguageSomeTranslations(i){const a=this.getDataByLanguage(i);return!!(a&&Object.keys(a)||[]).find(s=>a[s]&&Object.keys(a[s]).length>0)}toJSON(){return this.data}}var x2={processors:{},addPostProcessor(e){this.processors[e.name]=e},handle(e,i,a,r,s){return e.forEach(c=>{var u;i=((u=this.processors[c])==null?void 0:u.process(i,a,r,s))??i}),i}};const Ix={},Yx=e=>!he(e)&&typeof e!="boolean"&&typeof e!="number";class Tc extends Fc{constructor(i,a={}){super(),pA(["resourceStore","languageUtils","pluralResolver","interpolator","backendConnector","i18nFormat","utils"],i,this),this.options=a,this.options.keySeparator===void 0&&(this.options.keySeparator="."),this.logger=ji.create("translator")}changeLanguage(i){i&&(this.language=i)}exists(i,a={interpolation:{}}){const r={...a};if(i==null)return!1;const s=this.resolve(i,r);return(s==null?void 0:s.res)!==void 0}extractFromKey(i,a){let r=a.nsSeparator!==void 0?a.nsSeparator:this.options.nsSeparator;r===void 0&&(r=":");const s=a.keySeparator!==void 0?a.keySeparator:this.options.keySeparator;let c=a.ns||this.options.defaultNS||[];const u=r&&i.indexOf(r)>-1,f=!this.options.userDefinedKeySeparator&&!a.keySeparator&&!this.options.userDefinedNsSeparator&&!a.nsSeparator&&!TA(i,r,s);if(u&&!f){const p=i.match(this.interpolator.nestingRegexp);if(p&&p.length>0)return{key:i,namespaces:he(c)?[c]:c};const m=i.split(r);(r!==s||r===s&&this.options.ns.indexOf(m[0])>-1)&&(c=m.shift()),i=m.join(s)}return{key:i,namespaces:he(c)?[c]:c}}translate(i,a,r){let s=typeof a=="object"?{...a}:a;if(typeof s!="object"&&this.options.overloadTranslationOptionHandler&&(s=this.options.overloadTranslationOptionHandler(arguments)),typeof options=="object"&&(s={...s}),s||(s={}),i==null)return"";Array.isArray(i)||(i=[String(i)]);const c=s.returnDetails!==void 0?s.returnDetails:this.options.returnDetails,u=s.keySeparator!==void 0?s.keySeparator:this.options.keySeparator,{key:f,namespaces:p}=this.extractFromKey(i[i.length-1],s),m=p[p.length-1];let y=s.nsSeparator!==void 0?s.nsSeparator:this.options.nsSeparator;y===void 0&&(y=":");const x=s.lng||this.language,b=s.appendNamespaceToCIMode||this.options.appendNamespaceToCIMode;if((x==null?void 0:x.toLowerCase())==="cimode")return b?c?{res:`${m}${y}${f}`,usedKey:f,exactUsedKey:f,usedLng:x,usedNS:m,usedParams:this.getUsedParamsDetails(s)}:`${m}${y}${f}`:c?{res:f,usedKey:f,exactUsedKey:f,usedLng:x,usedNS:m,usedParams:this.getUsedParamsDetails(s)}:f;const T=this.resolve(i,s);let A=T==null?void 0:T.res;const C=(T==null?void 0:T.usedKey)||f,B=(T==null?void 0:T.exactUsedKey)||f,E=["[object Number]","[object Function]","[object RegExp]"],k=s.joinArrays!==void 0?s.joinArrays:this.options.joinArrays,M=!this.i18nFormat||this.i18nFormat.handleAsObject,F=s.count!==void 0&&!he(s.count),D=Tc.hasDefaultValue(s),U=F?this.pluralResolver.getSuffix(x,s.count,s):"",G=s.ordinal&&F?this.pluralResolver.getSuffix(x,s.count,{ordinal:!1}):"",Z=F&&!s.ordinal&&s.count===0,J=Z&&s[`defaultValue${this.options.pluralSeparator}zero`]||s[`defaultValue${U}`]||s[`defaultValue${G}`]||s.defaultValue;let ie=A;M&&!A&&D&&(ie=J);const oe=Yx(ie),xe=Object.prototype.toString.apply(ie);if(M&&ie&&oe&&E.indexOf(xe)<0&&!(he(k)&&Array.isArray(ie))){if(!s.returnObjects&&!this.options.returnObjects){this.options.returnedObjectHandler||this.logger.warn("accessing an object - but returnObjects options is not enabled!");const Le=this.options.returnedObjectHandler?this.options.returnedObjectHandler(C,ie,{...s,ns:p}):`key '${f} (${this.language})' returned an object instead of string.`;return c?(T.res=Le,T.usedParams=this.getUsedParamsDetails(s),T):Le}if(u){const Le=Array.isArray(ie),ne=Le?[]:{},we=Le?B:C;for(const P in ie)if(Object.prototype.hasOwnProperty.call(ie,P)){const X=`${we}${u}${P}`;D&&!A?ne[P]=this.translate(X,{...s,defaultValue:Yx(J)?J[P]:void 0,joinArrays:!1,ns:p}):ne[P]=this.translate(X,{...s,joinArrays:!1,ns:p}),ne[P]===X&&(ne[P]=ie[P])}A=ne}}else if(M&&he(k)&&Array.isArray(A))A=A.join(k),A&&(A=this.extendTranslation(A,i,s,r));else{let Le=!1,ne=!1;!this.isValidLookup(A)&&D&&(Le=!0,A=J),this.isValidLookup(A)||(ne=!0,A=f);const P=(s.missingKeyNoValueFallbackToKey||this.options.missingKeyNoValueFallbackToKey)&&ne?void 0:A,X=D&&J!==A&&this.options.updateMissing;if(ne||Le||X){if(this.logger.log(X?"updateKey":"missingKey",x,m,f,X?J:A),u){const q=this.resolve(f,{...s,keySeparator:!1});q&&q.res&&this.logger.warn("Seems the loaded translations were in flat JSON format instead of nested. Either set keySeparator: false on init or make sure your translations are published in nested format.")}let ee=[];const fe=this.languageUtils.getFallbackCodes(this.options.fallbackLng,s.lng||this.language);if(this.options.saveMissingTo==="fallback"&&fe&&fe[0])for(let q=0;q<fe.length;q++)ee.push(fe[q]);else this.options.saveMissingTo==="all"?ee=this.languageUtils.toResolveHierarchy(s.lng||this.language):ee.push(s.lng||this.language);const z=(q,Q,W)=>{var ge;const ae=D&&W!==A?W:P;this.options.missingKeyHandler?this.options.missingKeyHandler(q,m,Q,ae,X,s):(ge=this.backendConnector)!=null&&ge.saveMissing&&this.backendConnector.saveMissing(q,m,Q,ae,X,s),this.emit("missingKey",q,m,Q,A)};this.options.saveMissing&&(this.options.saveMissingPlurals&&F?ee.forEach(q=>{const Q=this.pluralResolver.getSuffixes(q,s);Z&&s[`defaultValue${this.options.pluralSeparator}zero`]&&Q.indexOf(`${this.options.pluralSeparator}zero`)<0&&Q.push(`${this.options.pluralSeparator}zero`),Q.forEach(W=>{z([q],f+W,s[`defaultValue${W}`]||J)})}):z(ee,f,J))}A=this.extendTranslation(A,i,s,T,r),ne&&A===f&&this.options.appendNamespaceToMissingKey&&(A=`${m}${y}${f}`),(ne||Le)&&this.options.parseMissingKeyHandler&&(A=this.options.parseMissingKeyHandler(this.options.appendNamespaceToMissingKey?`${m}${y}${f}`:f,Le?A:void 0,s))}return c?(T.res=A,T.usedParams=this.getUsedParamsDetails(s),T):A}extendTranslation(i,a,r,s,c){var p,m;if((p=this.i18nFormat)!=null&&p.parse)i=this.i18nFormat.parse(i,{...this.options.interpolation.defaultVariables,...r},r.lng||this.language||s.usedLng,s.usedNS,s.usedKey,{resolved:s});else if(!r.skipInterpolation){r.interpolation&&this.interpolator.init({...r,interpolation:{...this.options.interpolation,...r.interpolation}});const y=he(i)&&(((m=r==null?void 0:r.interpolation)==null?void 0:m.skipOnVariables)!==void 0?r.interpolation.skipOnVariables:this.options.interpolation.skipOnVariables);let x;if(y){const T=i.match(this.interpolator.nestingRegexp);x=T&&T.length}let b=r.replace&&!he(r.replace)?r.replace:r;if(this.options.interpolation.defaultVariables&&(b={...this.options.interpolation.defaultVariables,...b}),i=this.interpolator.interpolate(i,b,r.lng||this.language||s.usedLng,r),y){const T=i.match(this.interpolator.nestingRegexp),A=T&&T.length;x<A&&(r.nest=!1)}!r.lng&&s&&s.res&&(r.lng=this.language||s.usedLng),r.nest!==!1&&(i=this.interpolator.nest(i,(...T)=>(c==null?void 0:c[0])===T[0]&&!r.context?(this.logger.warn(`It seems you are nesting recursively key: ${T[0]} in key: ${a[0]}`),null):this.translate(...T,a),r)),r.interpolation&&this.interpolator.reset()}const u=r.postProcess||this.options.postProcess,f=he(u)?[u]:u;return i!=null&&(f!=null&&f.length)&&r.applyPostProcessor!==!1&&(i=x2.handle(f,i,a,this.options&&this.options.postProcessPassResolved?{i18nResolved:{...s,usedParams:this.getUsedParamsDetails(r)},...r}:r,this)),i}resolve(i,a={}){let r,s,c,u,f;return he(i)&&(i=[i]),i.forEach(p=>{if(this.isValidLookup(r))return;const m=this.extractFromKey(p,a),y=m.key;s=y;let x=m.namespaces;this.options.fallbackNS&&(x=x.concat(this.options.fallbackNS));const b=a.count!==void 0&&!he(a.count),T=b&&!a.ordinal&&a.count===0,A=a.context!==void 0&&(he(a.context)||typeof a.context=="number")&&a.context!=="",C=a.lngs?a.lngs:this.languageUtils.toResolveHierarchy(a.lng||this.language,a.fallbackLng);x.forEach(B=>{var E,k;this.isValidLookup(r)||(f=B,!Ix[`${C[0]}-${B}`]&&((E=this.utils)!=null&&E.hasLoadedNamespace)&&!((k=this.utils)!=null&&k.hasLoadedNamespace(f))&&(Ix[`${C[0]}-${B}`]=!0,this.logger.warn(`key "${s}" for languages "${C.join(", ")}" won't get resolved as namespace "${f}" was not yet loaded`,"This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!")),C.forEach(M=>{var U;if(this.isValidLookup(r))return;u=M;const F=[y];if((U=this.i18nFormat)!=null&&U.addLookupKeys)this.i18nFormat.addLookupKeys(F,y,M,B,a);else{let G;b&&(G=this.pluralResolver.getSuffix(M,a.count,a));const Z=`${this.options.pluralSeparator}zero`,J=`${this.options.pluralSeparator}ordinal${this.options.pluralSeparator}`;if(b&&(F.push(y+G),a.ordinal&&G.indexOf(J)===0&&F.push(y+G.replace(J,this.options.pluralSeparator)),T&&F.push(y+Z)),A){const ie=`${y}${this.options.contextSeparator}${a.context}`;F.push(ie),b&&(F.push(ie+G),a.ordinal&&G.indexOf(J)===0&&F.push(ie+G.replace(J,this.options.pluralSeparator)),T&&F.push(ie+Z))}}let D;for(;D=F.pop();)this.isValidLookup(r)||(c=D,r=this.getResource(M,B,D,a))}))})}),{res:r,usedKey:s,exactUsedKey:c,usedLng:u,usedNS:f}}isValidLookup(i){return i!==void 0&&!(!this.options.returnNull&&i===null)&&!(!this.options.returnEmptyString&&i==="")}getResource(i,a,r,s={}){var c;return(c=this.i18nFormat)!=null&&c.getResource?this.i18nFormat.getResource(i,a,r,s):this.resourceStore.getResource(i,a,r,s)}getUsedParamsDetails(i={}){const a=["defaultValue","ordinal","context","replace","lng","lngs","fallbackLng","ns","keySeparator","nsSeparator","returnObjects","returnDetails","joinArrays","postProcess","interpolation"],r=i.replace&&!he(i.replace);let s=r?i.replace:i;if(r&&typeof i.count<"u"&&(s.count=i.count),this.options.interpolation.defaultVariables&&(s={...this.options.interpolation.defaultVariables,...s}),!r){s={...s};for(const c of a)delete s[c]}return s}static hasDefaultValue(i){const a="defaultValue";for(const r in i)if(Object.prototype.hasOwnProperty.call(i,r)&&a===r.substring(0,a.length)&&i[r]!==void 0)return!0;return!1}}class Gx{constructor(i){this.options=i,this.supportedLngs=this.options.supportedLngs||!1,this.logger=ji.create("languageUtils")}getScriptPartFromCode(i){if(i=ds(i),!i||i.indexOf("-")<0)return null;const a=i.split("-");return a.length===2||(a.pop(),a[a.length-1].toLowerCase()==="x")?null:this.formatLanguageCode(a.join("-"))}getLanguagePartFromCode(i){if(i=ds(i),!i||i.indexOf("-")<0)return i;const a=i.split("-");return this.formatLanguageCode(a[0])}formatLanguageCode(i){if(he(i)&&i.indexOf("-")>-1){let a;try{a=Intl.getCanonicalLocales(i)[0]}catch{}return a&&this.options.lowerCaseLng&&(a=a.toLowerCase()),a||(this.options.lowerCaseLng?i.toLowerCase():i)}return this.options.cleanCode||this.options.lowerCaseLng?i.toLowerCase():i}isSupportedCode(i){return(this.options.load==="languageOnly"||this.options.nonExplicitSupportedLngs)&&(i=this.getLanguagePartFromCode(i)),!this.supportedLngs||!this.supportedLngs.length||this.supportedLngs.indexOf(i)>-1}getBestMatchFromCodes(i){if(!i)return null;let a;return i.forEach(r=>{if(a)return;const s=this.formatLanguageCode(r);(!this.options.supportedLngs||this.isSupportedCode(s))&&(a=s)}),!a&&this.options.supportedLngs&&i.forEach(r=>{if(a)return;const s=this.getScriptPartFromCode(r);if(this.isSupportedCode(s))return a=s;const c=this.getLanguagePartFromCode(r);if(this.isSupportedCode(c))return a=c;a=this.options.supportedLngs.find(u=>{if(u===c)return u;if(!(u.indexOf("-")<0&&c.indexOf("-")<0)&&(u.indexOf("-")>0&&c.indexOf("-")<0&&u.substring(0,u.indexOf("-"))===c||u.indexOf(c)===0&&c.length>1))return u})}),a||(a=this.getFallbackCodes(this.options.fallbackLng)[0]),a}getFallbackCodes(i,a){if(!i)return[];if(typeof i=="function"&&(i=i(a)),he(i)&&(i=[i]),Array.isArray(i))return i;if(!a)return i.default||[];let r=i[a];return r||(r=i[this.getScriptPartFromCode(a)]),r||(r=i[this.formatLanguageCode(a)]),r||(r=i[this.getLanguagePartFromCode(a)]),r||(r=i.default),r||[]}toResolveHierarchy(i,a){const r=this.getFallbackCodes(a||this.options.fallbackLng||[],i),s=[],c=u=>{u&&(this.isSupportedCode(u)?s.push(u):this.logger.warn(`rejecting language code not found in supportedLngs: ${u}`))};return he(i)&&(i.indexOf("-")>-1||i.indexOf("_")>-1)?(this.options.load!=="languageOnly"&&c(this.formatLanguageCode(i)),this.options.load!=="languageOnly"&&this.options.load!=="currentOnly"&&c(this.getScriptPartFromCode(i)),this.options.load!=="currentOnly"&&c(this.getLanguagePartFromCode(i))):he(i)&&c(this.formatLanguageCode(i)),r.forEach(u=>{s.indexOf(u)<0&&c(this.formatLanguageCode(u))}),s}}const Kx={zero:0,one:1,two:2,few:3,many:4,other:5},Xx={select:e=>e===1?"one":"other",resolvedOptions:()=>({pluralCategories:["one","other"]})};class AA{constructor(i,a={}){this.languageUtils=i,this.options=a,this.logger=ji.create("pluralResolver"),this.pluralRulesCache={}}addRule(i,a){this.rules[i]=a}clearCache(){this.pluralRulesCache={}}getRule(i,a={}){const r=ds(i==="dev"?"en":i),s=a.ordinal?"ordinal":"cardinal",c=JSON.stringify({cleanedCode:r,type:s});if(c in this.pluralRulesCache)return this.pluralRulesCache[c];let u;try{u=new Intl.PluralRules(r,{type:s})}catch{if(!Intl)return this.logger.error("No Intl support, please use an Intl polyfill!"),Xx;if(!i.match(/-|_/))return Xx;const p=this.languageUtils.getLanguagePartFromCode(i);u=this.getRule(p,a)}return this.pluralRulesCache[c]=u,u}needsPlural(i,a={}){let r=this.getRule(i,a);return r||(r=this.getRule("dev",a)),(r==null?void 0:r.resolvedOptions().pluralCategories.length)>1}getPluralFormsOfKey(i,a,r={}){return this.getSuffixes(i,r).map(s=>`${a}${s}`)}getSuffixes(i,a={}){let r=this.getRule(i,a);return r||(r=this.getRule("dev",a)),r?r.resolvedOptions().pluralCategories.sort((s,c)=>Kx[s]-Kx[c]).map(s=>`${this.options.prepend}${a.ordinal?`ordinal${this.options.prepend}`:""}${s}`):[]}getSuffix(i,a,r={}){const s=this.getRule(i,r);return s?`${this.options.prepend}${r.ordinal?`ordinal${this.options.prepend}`:""}${s.select(a)}`:(this.logger.warn(`no plural rule found for: ${i}`),this.getSuffix("dev",a,r))}}const Zx=(e,i,a,r=".",s=!0)=>{let c=yA(e,i,a);return!c&&s&&he(a)&&(c=Kh(e,a,r),c===void 0&&(c=Kh(i,a,r))),c},Rf=e=>e.replace(/\$/g,"$$$$");class EA{constructor(i={}){var a;this.logger=ji.create("interpolator"),this.options=i,this.format=((a=i==null?void 0:i.interpolation)==null?void 0:a.format)||(r=>r),this.init(i)}init(i={}){i.interpolation||(i.interpolation={escapeValue:!0});const{escape:a,escapeValue:r,useRawValueToEscape:s,prefix:c,prefixEscaped:u,suffix:f,suffixEscaped:p,formatSeparator:m,unescapeSuffix:y,unescapePrefix:x,nestingPrefix:b,nestingPrefixEscaped:T,nestingSuffix:A,nestingSuffixEscaped:C,nestingOptionsSeparator:B,maxReplaces:E,alwaysFormat:k}=i.interpolation;this.escape=a!==void 0?a:bA,this.escapeValue=r!==void 0?r:!0,this.useRawValueToEscape=s!==void 0?s:!1,this.prefix=c?Ja(c):u||"{{",this.suffix=f?Ja(f):p||"}}",this.formatSeparator=m||",",this.unescapePrefix=y?"":x||"-",this.unescapeSuffix=this.unescapePrefix?"":y||"",this.nestingPrefix=b?Ja(b):T||Ja("$t("),this.nestingSuffix=A?Ja(A):C||Ja(")"),this.nestingOptionsSeparator=B||",",this.maxReplaces=E||1e3,this.alwaysFormat=k!==void 0?k:!1,this.resetRegExp()}reset(){this.options&&this.init(this.options)}resetRegExp(){const i=(a,r)=>(a==null?void 0:a.source)===r?(a.lastIndex=0,a):new RegExp(r,"g");this.regexp=i(this.regexp,`${this.prefix}(.+?)${this.suffix}`),this.regexpUnescape=i(this.regexpUnescape,`${this.prefix}${this.unescapePrefix}(.+?)${this.unescapeSuffix}${this.suffix}`),this.nestingRegexp=i(this.nestingRegexp,`${this.nestingPrefix}(.+?)${this.nestingSuffix}`)}interpolate(i,a,r,s){var T;let c,u,f;const p=this.options&&this.options.interpolation&&this.options.interpolation.defaultVariables||{},m=A=>{if(A.indexOf(this.formatSeparator)<0){const k=Zx(a,p,A,this.options.keySeparator,this.options.ignoreJSONStructure);return this.alwaysFormat?this.format(k,void 0,r,{...s,...a,interpolationkey:A}):k}const C=A.split(this.formatSeparator),B=C.shift().trim(),E=C.join(this.formatSeparator).trim();return this.format(Zx(a,p,B,this.options.keySeparator,this.options.ignoreJSONStructure),E,r,{...s,...a,interpolationkey:B})};this.resetRegExp();const y=(s==null?void 0:s.missingInterpolationHandler)||this.options.missingInterpolationHandler,x=((T=s==null?void 0:s.interpolation)==null?void 0:T.skipOnVariables)!==void 0?s.interpolation.skipOnVariables:this.options.interpolation.skipOnVariables;return[{regex:this.regexpUnescape,safeValue:A=>Rf(A)},{regex:this.regexp,safeValue:A=>this.escapeValue?Rf(this.escape(A)):Rf(A)}].forEach(A=>{for(f=0;c=A.regex.exec(i);){const C=c[1].trim();if(u=m(C),u===void 0)if(typeof y=="function"){const E=y(i,c,s);u=he(E)?E:""}else if(s&&Object.prototype.hasOwnProperty.call(s,C))u="";else if(x){u=c[0];continue}else this.logger.warn(`missed to pass in variable ${C} for interpolating ${i}`),u="";else!he(u)&&!this.useRawValueToEscape&&(u=Vx(u));const B=A.safeValue(u);if(i=i.replace(c[0],B),x?(A.regex.lastIndex+=u.length,A.regex.lastIndex-=c[0].length):A.regex.lastIndex=0,f++,f>=this.maxReplaces)break}}),i}nest(i,a,r={}){let s,c,u;const f=(p,m)=>{const y=this.nestingOptionsSeparator;if(p.indexOf(y)<0)return p;const x=p.split(new RegExp(`${y}[ ]*{`));let b=`{${x[1]}`;p=x[0],b=this.interpolate(b,u);const T=b.match(/'/g),A=b.match(/"/g);(((T==null?void 0:T.length)??0)%2===0&&!A||A.length%2!==0)&&(b=b.replace(/'/g,'"'));try{u=JSON.parse(b),m&&(u={...m,...u})}catch(C){return this.logger.warn(`failed parsing options string in nesting for key ${p}`,C),`${p}${y}${b}`}return u.defaultValue&&u.defaultValue.indexOf(this.prefix)>-1&&delete u.defaultValue,p};for(;s=this.nestingRegexp.exec(i);){let p=[];u={...r},u=u.replace&&!he(u.replace)?u.replace:u,u.applyPostProcessor=!1,delete u.defaultValue;let m=!1;if(s[0].indexOf(this.formatSeparator)!==-1&&!/{.*}/.test(s[1])){const y=s[1].split(this.formatSeparator).map(x=>x.trim());s[1]=y.shift(),p=y,m=!0}if(c=a(f.call(this,s[1].trim(),u),u),c&&s[0]===i&&!he(c))return c;he(c)||(c=Vx(c)),c||(this.logger.warn(`missed to resolve ${s[1]} for nesting ${i}`),c=""),m&&(c=p.reduce((y,x)=>this.format(y,x,r.lng,{...r,interpolationkey:s[1].trim()}),c.trim())),i=i.replace(s[0],c),this.regexp.lastIndex=0}return i}}const CA=e=>{let i=e.toLowerCase().trim();const a={};if(e.indexOf("(")>-1){const r=e.split("(");i=r[0].toLowerCase().trim();const s=r[1].substring(0,r[1].length-1);i==="currency"&&s.indexOf(":")<0?a.currency||(a.currency=s.trim()):i==="relativetime"&&s.indexOf(":")<0?a.range||(a.range=s.trim()):s.split(";").forEach(u=>{if(u){const[f,...p]=u.split(":"),m=p.join(":").trim().replace(/^'+|'+$/g,""),y=f.trim();a[y]||(a[y]=m),m==="false"&&(a[y]=!1),m==="true"&&(a[y]=!0),isNaN(m)||(a[y]=parseInt(m,10))}})}return{formatName:i,formatOptions:a}},Qx=e=>{const i={};return(a,r,s)=>{let c=s;s&&s.interpolationkey&&s.formatParams&&s.formatParams[s.interpolationkey]&&s[s.interpolationkey]&&(c={...c,[s.interpolationkey]:void 0});const u=r+JSON.stringify(c);let f=i[u];return f||(f=e(ds(r),s),i[u]=f),f(a)}},OA=e=>(i,a,r)=>e(ds(a),r)(i);class RA{constructor(i={}){this.logger=ji.create("formatter"),this.options=i,this.init(i)}init(i,a={interpolation:{}}){this.formatSeparator=a.interpolation.formatSeparator||",";const r=a.cacheInBuiltFormats?Qx:OA;this.formats={number:r((s,c)=>{const u=new Intl.NumberFormat(s,{...c});return f=>u.format(f)}),currency:r((s,c)=>{const u=new Intl.NumberFormat(s,{...c,style:"currency"});return f=>u.format(f)}),datetime:r((s,c)=>{const u=new Intl.DateTimeFormat(s,{...c});return f=>u.format(f)}),relativetime:r((s,c)=>{const u=new Intl.RelativeTimeFormat(s,{...c});return f=>u.format(f,c.range||"day")}),list:r((s,c)=>{const u=new Intl.ListFormat(s,{...c});return f=>u.format(f)})}}add(i,a){this.formats[i.toLowerCase().trim()]=a}addCached(i,a){this.formats[i.toLowerCase().trim()]=Qx(a)}format(i,a,r,s={}){const c=a.split(this.formatSeparator);if(c.length>1&&c[0].indexOf("(")>1&&c[0].indexOf(")")<0&&c.find(f=>f.indexOf(")")>-1)){const f=c.findIndex(p=>p.indexOf(")")>-1);c[0]=[c[0],...c.splice(1,f)].join(this.formatSeparator)}return c.reduce((f,p)=>{var x;const{formatName:m,formatOptions:y}=CA(p);if(this.formats[m]){let b=f;try{const T=((x=s==null?void 0:s.formatParams)==null?void 0:x[s.interpolationkey])||{},A=T.locale||T.lng||s.locale||s.lng||r;b=this.formats[m](f,A,{...y,...s,...T})}catch(T){this.logger.warn(T)}return b}else this.logger.warn(`there was no format function for ${m}`);return f},i)}}const kA=(e,i)=>{e.pending[i]!==void 0&&(delete e.pending[i],e.pendingCount--)};class DA extends Fc{constructor(i,a,r,s={}){var c,u;super(),this.backend=i,this.store=a,this.services=r,this.languageUtils=r.languageUtils,this.options=s,this.logger=ji.create("backendConnector"),this.waitingReads=[],this.maxParallelReads=s.maxParallelReads||10,this.readingCalls=0,this.maxRetries=s.maxRetries>=0?s.maxRetries:5,this.retryTimeout=s.retryTimeout>=1?s.retryTimeout:350,this.state={},this.queue=[],(u=(c=this.backend)==null?void 0:c.init)==null||u.call(c,r,s.backend,s)}queueLoad(i,a,r,s){const c={},u={},f={},p={};return i.forEach(m=>{let y=!0;a.forEach(x=>{const b=`${m}|${x}`;!r.reload&&this.store.hasResourceBundle(m,x)?this.state[b]=2:this.state[b]<0||(this.state[b]===1?u[b]===void 0&&(u[b]=!0):(this.state[b]=1,y=!1,u[b]===void 0&&(u[b]=!0),c[b]===void 0&&(c[b]=!0),p[x]===void 0&&(p[x]=!0)))}),y||(f[m]=!0)}),(Object.keys(c).length||Object.keys(u).length)&&this.queue.push({pending:u,pendingCount:Object.keys(u).length,loaded:{},errors:[],callback:s}),{toLoad:Object.keys(c),pending:Object.keys(u),toLoadLanguages:Object.keys(f),toLoadNamespaces:Object.keys(p)}}loaded(i,a,r){const s=i.split("|"),c=s[0],u=s[1];a&&this.emit("failedLoading",c,u,a),!a&&r&&this.store.addResourceBundle(c,u,r,void 0,void 0,{skipCopy:!0}),this.state[i]=a?-1:2,a&&r&&(this.state[i]=0);const f={};this.queue.forEach(p=>{gA(p.loaded,[c],u),kA(p,i),a&&p.errors.push(a),p.pendingCount===0&&!p.done&&(Object.keys(p.loaded).forEach(m=>{f[m]||(f[m]={});const y=p.loaded[m];y.length&&y.forEach(x=>{f[m][x]===void 0&&(f[m][x]=!0)})}),p.done=!0,p.errors.length?p.callback(p.errors):p.callback())}),this.emit("loaded",f),this.queue=this.queue.filter(p=>!p.done)}read(i,a,r,s=0,c=this.retryTimeout,u){if(!i.length)return u(null,{});if(this.readingCalls>=this.maxParallelReads){this.waitingReads.push({lng:i,ns:a,fcName:r,tried:s,wait:c,callback:u});return}this.readingCalls++;const f=(m,y)=>{if(this.readingCalls--,this.waitingReads.length>0){const x=this.waitingReads.shift();this.read(x.lng,x.ns,x.fcName,x.tried,x.wait,x.callback)}if(m&&y&&s<this.maxRetries){setTimeout(()=>{this.read.call(this,i,a,r,s+1,c*2,u)},c);return}u(m,y)},p=this.backend[r].bind(this.backend);if(p.length===2){try{const m=p(i,a);m&&typeof m.then=="function"?m.then(y=>f(null,y)).catch(f):f(null,m)}catch(m){f(m)}return}return p(i,a,f)}prepareLoading(i,a,r={},s){if(!this.backend)return this.logger.warn("No backend was added via i18next.use. Will not load resources."),s&&s();he(i)&&(i=this.languageUtils.toResolveHierarchy(i)),he(a)&&(a=[a]);const c=this.queueLoad(i,a,r,s);if(!c.toLoad.length)return c.pending.length||s(),null;c.toLoad.forEach(u=>{this.loadOne(u)})}load(i,a,r){this.prepareLoading(i,a,{},r)}reload(i,a,r){this.prepareLoading(i,a,{reload:!0},r)}loadOne(i,a=""){const r=i.split("|"),s=r[0],c=r[1];this.read(s,c,"read",void 0,void 0,(u,f)=>{u&&this.logger.warn(`${a}loading namespace ${c} for language ${s} failed`,u),!u&&f&&this.logger.log(`${a}loaded namespace ${c} for language ${s}`,f),this.loaded(i,u,f)})}saveMissing(i,a,r,s,c,u={},f=()=>{}){var p,m,y,x,b;if((m=(p=this.services)==null?void 0:p.utils)!=null&&m.hasLoadedNamespace&&!((x=(y=this.services)==null?void 0:y.utils)!=null&&x.hasLoadedNamespace(a))){this.logger.warn(`did not save key "${r}" as the namespace "${a}" was not yet loaded`,"This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!");return}if(!(r==null||r==="")){if((b=this.backend)!=null&&b.create){const T={...u,isUpdate:c},A=this.backend.create.bind(this.backend);if(A.length<6)try{let C;A.length===5?C=A(i,a,r,s,T):C=A(i,a,r,s),C&&typeof C.then=="function"?C.then(B=>f(null,B)).catch(f):f(null,C)}catch(C){f(C)}else A(i,a,r,s,f,T)}!i||!i[0]||this.store.addResource(i[0],a,r,s)}}}const Jx=()=>({debug:!1,initAsync:!0,ns:["translation"],defaultNS:["translation"],fallbackLng:["dev"],fallbackNS:!1,supportedLngs:!1,nonExplicitSupportedLngs:!1,load:"all",preload:!1,simplifyPluralSuffix:!0,keySeparator:".",nsSeparator:":",pluralSeparator:"_",contextSeparator:"_",partialBundledLanguages:!1,saveMissing:!1,updateMissing:!1,saveMissingTo:"fallback",saveMissingPlurals:!0,missingKeyHandler:!1,missingInterpolationHandler:!1,postProcess:!1,postProcessPassResolved:!1,returnNull:!1,returnEmptyString:!0,returnObjects:!1,joinArrays:!1,returnedObjectHandler:!1,parseMissingKeyHandler:!1,appendNamespaceToMissingKey:!1,appendNamespaceToCIMode:!1,overloadTranslationOptionHandler:e=>{let i={};if(typeof e[1]=="object"&&(i=e[1]),he(e[1])&&(i.defaultValue=e[1]),he(e[2])&&(i.tDescription=e[2]),typeof e[2]=="object"||typeof e[3]=="object"){const a=e[3]||e[2];Object.keys(a).forEach(r=>{i[r]=a[r]})}return i},interpolation:{escapeValue:!0,format:e=>e,prefix:"{{",suffix:"}}",formatSeparator:",",unescapePrefix:"-",nestingPrefix:"$t(",nestingSuffix:")",nestingOptionsSeparator:",",maxReplaces:1e3,skipOnVariables:!0},cacheInBuiltFormats:!0}),Wx=e=>{var i,a;return he(e.ns)&&(e.ns=[e.ns]),he(e.fallbackLng)&&(e.fallbackLng=[e.fallbackLng]),he(e.fallbackNS)&&(e.fallbackNS=[e.fallbackNS]),((a=(i=e.supportedLngs)==null?void 0:i.indexOf)==null?void 0:a.call(i,"cimode"))<0&&(e.supportedLngs=e.supportedLngs.concat(["cimode"])),typeof e.initImmediate=="boolean"&&(e.initAsync=e.initImmediate),e},ql=()=>{},MA=e=>{Object.getOwnPropertyNames(Object.getPrototypeOf(e)).forEach(a=>{typeof e[a]=="function"&&(e[a]=e[a].bind(e))})};class fs extends Fc{constructor(i={},a){if(super(),this.options=Wx(i),this.services={},this.logger=ji,this.modules={external:[]},MA(this),a&&!this.isInitialized&&!i.isClone){if(!this.options.initAsync)return this.init(i,a),this;setTimeout(()=>{this.init(i,a)},0)}}init(i={},a){this.isInitializing=!0,typeof i=="function"&&(a=i,i={}),i.defaultNS==null&&i.ns&&(he(i.ns)?i.defaultNS=i.ns:i.ns.indexOf("translation")<0&&(i.defaultNS=i.ns[0]));const r=Jx();this.options={...r,...this.options,...Wx(i)},this.options.interpolation={...r.interpolation,...this.options.interpolation},i.keySeparator!==void 0&&(this.options.userDefinedKeySeparator=i.keySeparator),i.nsSeparator!==void 0&&(this.options.userDefinedNsSeparator=i.nsSeparator);const s=m=>m?typeof m=="function"?new m:m:null;if(!this.options.isClone){this.modules.logger?ji.init(s(this.modules.logger),this.options):ji.init(null,this.options);let m;this.modules.formatter?m=this.modules.formatter:m=RA;const y=new Gx(this.options);this.store=new qx(this.options.resources,this.options);const x=this.services;x.logger=ji,x.resourceStore=this.store,x.languageUtils=y,x.pluralResolver=new AA(y,{prepend:this.options.pluralSeparator,simplifyPluralSuffix:this.options.simplifyPluralSuffix}),m&&(!this.options.interpolation.format||this.options.interpolation.format===r.interpolation.format)&&(x.formatter=s(m),x.formatter.init(x,this.options),this.options.interpolation.format=x.formatter.format.bind(x.formatter)),x.interpolator=new EA(this.options),x.utils={hasLoadedNamespace:this.hasLoadedNamespace.bind(this)},x.backendConnector=new DA(s(this.modules.backend),x.resourceStore,x,this.options),x.backendConnector.on("*",(b,...T)=>{this.emit(b,...T)}),this.modules.languageDetector&&(x.languageDetector=s(this.modules.languageDetector),x.languageDetector.init&&x.languageDetector.init(x,this.options.detection,this.options)),this.modules.i18nFormat&&(x.i18nFormat=s(this.modules.i18nFormat),x.i18nFormat.init&&x.i18nFormat.init(this)),this.translator=new Tc(this.services,this.options),this.translator.on("*",(b,...T)=>{this.emit(b,...T)}),this.modules.external.forEach(b=>{b.init&&b.init(this)})}if(this.format=this.options.interpolation.format,a||(a=ql),this.options.fallbackLng&&!this.services.languageDetector&&!this.options.lng){const m=this.services.languageUtils.getFallbackCodes(this.options.fallbackLng);m.length>0&&m[0]!=="dev"&&(this.options.lng=m[0])}!this.services.languageDetector&&!this.options.lng&&this.logger.warn("init: no languageDetector is used and no lng is defined"),["getResource","hasResourceBundle","getResourceBundle","getDataByLanguage"].forEach(m=>{this[m]=(...y)=>this.store[m](...y)}),["addResource","addResources","addResourceBundle","removeResourceBundle"].forEach(m=>{this[m]=(...y)=>(this.store[m](...y),this)});const f=Lo(),p=()=>{const m=(y,x)=>{this.isInitializing=!1,this.isInitialized&&!this.initializedStoreOnce&&this.logger.warn("init: i18next is already initialized. You should call init just once!"),this.isInitialized=!0,this.options.isClone||this.logger.log("initialized",this.options),this.emit("initialized",this.options),f.resolve(x),a(y,x)};if(this.languages&&!this.isInitialized)return m(null,this.t.bind(this));this.changeLanguage(this.options.lng,m)};return this.options.resources||!this.options.initAsync?p():setTimeout(p,0),f}loadResources(i,a=ql){var c,u;let r=a;const s=he(i)?i:this.language;if(typeof i=="function"&&(r=i),!this.options.resources||this.options.partialBundledLanguages){if((s==null?void 0:s.toLowerCase())==="cimode"&&(!this.options.preload||this.options.preload.length===0))return r();const f=[],p=m=>{if(!m||m==="cimode")return;this.services.languageUtils.toResolveHierarchy(m).forEach(x=>{x!=="cimode"&&f.indexOf(x)<0&&f.push(x)})};s?p(s):this.services.languageUtils.getFallbackCodes(this.options.fallbackLng).forEach(y=>p(y)),(u=(c=this.options.preload)==null?void 0:c.forEach)==null||u.call(c,m=>p(m)),this.services.backendConnector.load(f,this.options.ns,m=>{!m&&!this.resolvedLanguage&&this.language&&this.setResolvedLanguage(this.language),r(m)})}else r(null)}reloadResources(i,a,r){const s=Lo();return typeof i=="function"&&(r=i,i=void 0),typeof a=="function"&&(r=a,a=void 0),i||(i=this.languages),a||(a=this.options.ns),r||(r=ql),this.services.backendConnector.reload(i,a,c=>{s.resolve(),r(c)}),s}use(i){if(!i)throw new Error("You are passing an undefined module! Please check the object you are passing to i18next.use()");if(!i.type)throw new Error("You are passing a wrong module! Please check the object you are passing to i18next.use()");return i.type==="backend"&&(this.modules.backend=i),(i.type==="logger"||i.log&&i.warn&&i.error)&&(this.modules.logger=i),i.type==="languageDetector"&&(this.modules.languageDetector=i),i.type==="i18nFormat"&&(this.modules.i18nFormat=i),i.type==="postProcessor"&&x2.addPostProcessor(i),i.type==="formatter"&&(this.modules.formatter=i),i.type==="3rdParty"&&this.modules.external.push(i),this}setResolvedLanguage(i){if(!(!i||!this.languages)&&!(["cimode","dev"].indexOf(i)>-1)){for(let a=0;a<this.languages.length;a++){const r=this.languages[a];if(!(["cimode","dev"].indexOf(r)>-1)&&this.store.hasLanguageSomeTranslations(r)){this.resolvedLanguage=r;break}}!this.resolvedLanguage&&this.languages.indexOf(i)<0&&this.store.hasLanguageSomeTranslations(i)&&(this.resolvedLanguage=i,this.languages.unshift(i))}}changeLanguage(i,a){this.isLanguageChangingTo=i;const r=Lo();this.emit("languageChanging",i);const s=f=>{this.language=f,this.languages=this.services.languageUtils.toResolveHierarchy(f),this.resolvedLanguage=void 0,this.setResolvedLanguage(f)},c=(f,p)=>{p?this.isLanguageChangingTo===i&&(s(p),this.translator.changeLanguage(p),this.isLanguageChangingTo=void 0,this.emit("languageChanged",p),this.logger.log("languageChanged",p)):this.isLanguageChangingTo=void 0,r.resolve((...m)=>this.t(...m)),a&&a(f,(...m)=>this.t(...m))},u=f=>{var y,x;!i&&!f&&this.services.languageDetector&&(f=[]);const p=he(f)?f:f&&f[0],m=this.store.hasLanguageSomeTranslations(p)?p:this.services.languageUtils.getBestMatchFromCodes(he(f)?[f]:f);m&&(this.language||s(m),this.translator.language||this.translator.changeLanguage(m),(x=(y=this.services.languageDetector)==null?void 0:y.cacheUserLanguage)==null||x.call(y,m)),this.loadResources(m,b=>{c(b,m)})};return!i&&this.services.languageDetector&&!this.services.languageDetector.async?u(this.services.languageDetector.detect()):!i&&this.services.languageDetector&&this.services.languageDetector.async?this.services.languageDetector.detect.length===0?this.services.languageDetector.detect().then(u):this.services.languageDetector.detect(u):u(i),r}getFixedT(i,a,r){const s=(c,u,...f)=>{let p;typeof u!="object"?p=this.options.overloadTranslationOptionHandler([c,u].concat(f)):p={...u},p.lng=p.lng||s.lng,p.lngs=p.lngs||s.lngs,p.ns=p.ns||s.ns,p.keyPrefix!==""&&(p.keyPrefix=p.keyPrefix||r||s.keyPrefix);const m=this.options.keySeparator||".";let y;return p.keyPrefix&&Array.isArray(c)?y=c.map(x=>`${p.keyPrefix}${m}${x}`):y=p.keyPrefix?`${p.keyPrefix}${m}${c}`:c,this.t(y,p)};return he(i)?s.lng=i:s.lngs=i,s.ns=a,s.keyPrefix=r,s}t(...i){var a;return(a=this.translator)==null?void 0:a.translate(...i)}exists(...i){var a;return(a=this.translator)==null?void 0:a.exists(...i)}setDefaultNamespace(i){this.options.defaultNS=i}hasLoadedNamespace(i,a={}){if(!this.isInitialized)return this.logger.warn("hasLoadedNamespace: i18next was not initialized",this.languages),!1;if(!this.languages||!this.languages.length)return this.logger.warn("hasLoadedNamespace: i18n.languages were undefined or empty",this.languages),!1;const r=a.lng||this.resolvedLanguage||this.languages[0],s=this.options?this.options.fallbackLng:!1,c=this.languages[this.languages.length-1];if(r.toLowerCase()==="cimode")return!0;const u=(f,p)=>{const m=this.services.backendConnector.state[`${f}|${p}`];return m===-1||m===0||m===2};if(a.precheck){const f=a.precheck(this,u);if(f!==void 0)return f}return!!(this.hasResourceBundle(r,i)||!this.services.backendConnector.backend||this.options.resources&&!this.options.partialBundledLanguages||u(r,i)&&(!s||u(c,i)))}loadNamespaces(i,a){const r=Lo();return this.options.ns?(he(i)&&(i=[i]),i.forEach(s=>{this.options.ns.indexOf(s)<0&&this.options.ns.push(s)}),this.loadResources(s=>{r.resolve(),a&&a(s)}),r):(a&&a(),Promise.resolve())}loadLanguages(i,a){const r=Lo();he(i)&&(i=[i]);const s=this.options.preload||[],c=i.filter(u=>s.indexOf(u)<0&&this.services.languageUtils.isSupportedCode(u));return c.length?(this.options.preload=s.concat(c),this.loadResources(u=>{r.resolve(),a&&a(u)}),r):(a&&a(),Promise.resolve())}dir(i){var s,c;if(i||(i=this.resolvedLanguage||(((s=this.languages)==null?void 0:s.length)>0?this.languages[0]:this.language)),!i)return"rtl";const a=["ar","shu","sqr","ssh","xaa","yhd","yud","aao","abh","abv","acm","acq","acw","acx","acy","adf","ads","aeb","aec","afb","ajp","apc","apd","arb","arq","ars","ary","arz","auz","avl","ayh","ayl","ayn","ayp","bbz","pga","he","iw","ps","pbt","pbu","pst","prp","prd","ug","ur","ydd","yds","yih","ji","yi","hbo","men","xmn","fa","jpr","peo","pes","prs","dv","sam","ckb"],r=((c=this.services)==null?void 0:c.languageUtils)||new Gx(Jx());return a.indexOf(r.getLanguagePartFromCode(i))>-1||i.toLowerCase().indexOf("-arab")>1?"rtl":"ltr"}static createInstance(i={},a){return new fs(i,a)}cloneInstance(i={},a=ql){const r=i.forkResourceStore;r&&delete i.forkResourceStore;const s={...this.options,...i,isClone:!0},c=new fs(s);if((i.debug!==void 0||i.prefix!==void 0)&&(c.logger=c.logger.clone(i)),["store","services","language"].forEach(f=>{c[f]=this[f]}),c.services={...this.services},c.services.utils={hasLoadedNamespace:c.hasLoadedNamespace.bind(c)},r){const f=Object.keys(this.store.data).reduce((p,m)=>(p[m]={...this.store.data[m]},p[m]=Object.keys(p[m]).reduce((y,x)=>(y[x]={...p[m][x]},y),p[m]),p),{});c.store=new qx(f,s),c.services.resourceStore=c.store}return c.translator=new Tc(c.services,s),c.translator.on("*",(f,...p)=>{c.emit(f,...p)}),c.init(s,a),c.translator.options=s,c.translator.backendConnector.services.utils={hasLoadedNamespace:c.hasLoadedNamespace.bind(c)},c}toJSON(){return{options:this.options,store:this.store,language:this.language,languages:this.languages,resolvedLanguage:this.resolvedLanguage}}}const St=fs.createInstance();St.createInstance=fs.createInstance;St.createInstance;St.dir;St.init;St.loadResources;St.reloadResources;St.use;St.changeLanguage;St.getFixedT;St.t;St.exists;St.setDefaultNamespace;St.hasLoadedNamespace;St.loadNamespaces;St.loadLanguages;const{slice:BA,forEach:zA}=[];function $A(e){return zA.call(BA.call(arguments,1),i=>{if(i)for(const a in i)e[a]===void 0&&(e[a]=i[a])}),e}function NA(e){return typeof e!="string"?!1:[/<\s*script.*?>/i,/<\s*\/\s*script\s*>/i,/<\s*img.*?on\w+\s*=/i,/<\s*\w+\s*on\w+\s*=.*?>/i,/javascript\s*:/i,/vbscript\s*:/i,/expression\s*\(/i,/eval\s*\(/i,/alert\s*\(/i,/document\.cookie/i,/document\.write\s*\(/i,/window\.location/i,/innerHTML/i].some(a=>a.test(e))}const eb=/^[\u0009\u0020-\u007e\u0080-\u00ff]+$/,LA=function(e,i){const r=arguments.length>2&&arguments[2]!==void 0?arguments[2]:{path:"/"},s=encodeURIComponent(i);let c=`${e}=${s}`;if(r.maxAge>0){const u=r.maxAge-0;if(Number.isNaN(u))throw new Error("maxAge should be a Number");c+=`; Max-Age=${Math.floor(u)}`}if(r.domain){if(!eb.test(r.domain))throw new TypeError("option domain is invalid");c+=`; Domain=${r.domain}`}if(r.path){if(!eb.test(r.path))throw new TypeError("option path is invalid");c+=`; Path=${r.path}`}if(r.expires){if(typeof r.expires.toUTCString!="function")throw new TypeError("option expires is invalid");c+=`; Expires=${r.expires.toUTCString()}`}if(r.httpOnly&&(c+="; HttpOnly"),r.secure&&(c+="; Secure"),r.sameSite)switch(typeof r.sameSite=="string"?r.sameSite.toLowerCase():r.sameSite){case!0:c+="; SameSite=Strict";break;case"lax":c+="; SameSite=Lax";break;case"strict":c+="; SameSite=Strict";break;case"none":c+="; SameSite=None";break;default:throw new TypeError("option sameSite is invalid")}return r.partitioned&&(c+="; Partitioned"),c},tb={create(e,i,a,r){let s=arguments.length>4&&arguments[4]!==void 0?arguments[4]:{path:"/",sameSite:"strict"};a&&(s.expires=new Date,s.expires.setTime(s.expires.getTime()+a*60*1e3)),r&&(s.domain=r),document.cookie=LA(e,encodeURIComponent(i),s)},read(e){const i=`${e}=`,a=document.cookie.split(";");for(let r=0;r<a.length;r++){let s=a[r];for(;s.charAt(0)===" ";)s=s.substring(1,s.length);if(s.indexOf(i)===0)return s.substring(i.length,s.length)}return null},remove(e){this.create(e,"",-1)}};var _A={name:"cookie",lookup(e){let{lookupCookie:i}=e;if(i&&typeof document<"u")return tb.read(i)||void 0},cacheUserLanguage(e,i){let{lookupCookie:a,cookieMinutes:r,cookieDomain:s,cookieOptions:c}=i;a&&typeof document<"u"&&tb.create(a,e,r,s,c)}},HA={name:"querystring",lookup(e){var r;let{lookupQuerystring:i}=e,a;if(typeof window<"u"){let{search:s}=window.location;!window.location.search&&((r=window.location.hash)==null?void 0:r.indexOf("?"))>-1&&(s=window.location.hash.substring(window.location.hash.indexOf("?")));const u=s.substring(1).split("&");for(let f=0;f<u.length;f++){const p=u[f].indexOf("=");p>0&&u[f].substring(0,p)===i&&(a=u[f].substring(p+1))}}return a}};let Wa=null;const ib=()=>{if(Wa!==null)return Wa;try{if(Wa=typeof window<"u"&&window.localStorage!==null,!Wa)return!1;const e="i18next.translate.boo";window.localStorage.setItem(e,"foo"),window.localStorage.removeItem(e)}catch{Wa=!1}return Wa};var VA={name:"localStorage",lookup(e){let{lookupLocalStorage:i}=e;if(i&&ib())return window.localStorage.getItem(i)||void 0},cacheUserLanguage(e,i){let{lookupLocalStorage:a}=i;a&&ib()&&window.localStorage.setItem(a,e)}};let er=null;const nb=()=>{if(er!==null)return er;try{if(er=typeof window<"u"&&window.sessionStorage!==null,!er)return!1;const e="i18next.translate.boo";window.sessionStorage.setItem(e,"foo"),window.sessionStorage.removeItem(e)}catch{er=!1}return er};var PA={name:"sessionStorage",lookup(e){let{lookupSessionStorage:i}=e;if(i&&nb())return window.sessionStorage.getItem(i)||void 0},cacheUserLanguage(e,i){let{lookupSessionStorage:a}=i;a&&nb()&&window.sessionStorage.setItem(a,e)}},FA={name:"navigator",lookup(e){const i=[];if(typeof navigator<"u"){const{languages:a,userLanguage:r,language:s}=navigator;if(a)for(let c=0;c<a.length;c++)i.push(a[c]);r&&i.push(r),s&&i.push(s)}return i.length>0?i:void 0}},UA={name:"htmlTag",lookup(e){let{htmlTag:i}=e,a;const r=i||(typeof document<"u"?document.documentElement:null);return r&&typeof r.getAttribute=="function"&&(a=r.getAttribute("lang")),a}},qA={name:"path",lookup(e){var s;let{lookupFromPathIndex:i}=e;if(typeof window>"u")return;const a=window.location.pathname.match(/\/([a-zA-Z-]*)/g);return Array.isArray(a)?(s=a[typeof i=="number"?i:0])==null?void 0:s.replace("/",""):void 0}},IA={name:"subdomain",lookup(e){var s,c;let{lookupFromSubdomainIndex:i}=e;const a=typeof i=="number"?i+1:1,r=typeof window<"u"&&((c=(s=window.location)==null?void 0:s.hostname)==null?void 0:c.match(/^(\w{2,5})\.(([a-z0-9-]{1,63}\.[a-z]{2,6})|localhost)/i));if(r)return r[a]}};let b2=!1;try{document.cookie,b2=!0}catch{}const v2=["querystring","cookie","localStorage","sessionStorage","navigator","htmlTag"];b2||v2.splice(1,1);const YA=()=>({order:v2,lookupQuerystring:"lng",lookupCookie:"i18next",lookupLocalStorage:"i18nextLng",lookupSessionStorage:"i18nextLng",caches:["localStorage"],excludeCacheFor:["cimode"],convertDetectedLanguage:e=>e});class w2{constructor(i){let a=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{};this.type="languageDetector",this.detectors={},this.init(i,a)}init(){let i=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{languageUtils:{}},a=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},r=arguments.length>2&&arguments[2]!==void 0?arguments[2]:{};this.services=i,this.options=$A(a,this.options||{},YA()),typeof this.options.convertDetectedLanguage=="string"&&this.options.convertDetectedLanguage.indexOf("15897")>-1&&(this.options.convertDetectedLanguage=s=>s.replace("-","_")),this.options.lookupFromUrlIndex&&(this.options.lookupFromPathIndex=this.options.lookupFromUrlIndex),this.i18nOptions=r,this.addDetector(_A),this.addDetector(HA),this.addDetector(VA),this.addDetector(PA),this.addDetector(FA),this.addDetector(UA),this.addDetector(qA),this.addDetector(IA)}addDetector(i){return this.detectors[i.name]=i,this}detect(){let i=arguments.length>0&&arguments[0]!==void 0?arguments[0]:this.options.order,a=[];return i.forEach(r=>{if(this.detectors[r]){let s=this.detectors[r].lookup(this.options);s&&typeof s=="string"&&(s=[s]),s&&(a=a.concat(s))}}),a=a.filter(r=>r!=null&&!NA(r)).map(r=>this.options.convertDetectedLanguage(r)),this.services&&this.services.languageUtils&&this.services.languageUtils.getBestMatchFromCodes?a:a.length>0?a[0]:null}cacheUserLanguage(i){let a=arguments.length>1&&arguments[1]!==void 0?arguments[1]:this.options.caches;a&&(this.options.excludeCacheFor&&this.options.excludeCacheFor.indexOf(i)>-1||a.forEach(r=>{this.detectors[r]&&this.detectors[r].cacheUserLanguage(i,this.options)}))}}w2.type="languageDetector";const GA={home:"Home",restaurant:"Restaurant",spa:"SPA",sports:"Sports",banya:"Russian Banya",about:"About Us",promotions:"Promotions",contacts:"Contacts"},KA={book:"Book Now",book_now:"Book Now",learn_more:"Learn More",view_all:"View All",read_more:"Read More",submit:"Submit",scroll_down:"Scroll",name:"Name",email:"Email",phone:"Phone",message:"Message",date:"Date",time:"Time",people:"People",special_requests:"Special Requests",address:"73, Baan Chalekiri Village, 6 Pra Phuket Keaw Road, Kathu",phone_number:"+66 62 480 5877",select_language:"Select Language",photo_placeholder:"Photo will be added"},XA={hero:{title:"KAIF - Jungle Club & Spa",subtitle:"Unique relaxation and wellness experience in Phuket",cta:"Our Services",overline:"Premium Wellness Complex",bookNow:"Book Now",virtualTour:"Virtual Tour",slideAlt:"KAIF - Jungle Club & Spa"},philosophy:{overline:"OUR PHILOSOPHY",title:"A Space for Harmony and Self-Development",paragraph1:"We create a space where life becomes brighter. Our mission is to make rest and self-care not an obligation, but a pleasure. KAIF is a place where you restore your strength, recharge your batteries and enjoy every moment.",paragraph2:"Everything here is designed so that you want to come back: workouts that inspire, relaxation that fills you up, and an atmosphere that gives you a real buzz. We believe that harmony is not a luxury, but a necessity, and we make it available to you.",quote:"Health is not just the absence of disease, but a state of complete physical, mental and social well-being",imageAlt:"KAIF - a space for harmony and self-development"},services:{title:"Our Services",restaurant:{title:"Restaurant",description:"Experience 5 different cuisines in our exceptional restaurant"},spa:{title:"SPA",description:"Rejuvenate yourself in Thailand's largest sauna"},sports:{title:"Sports Facilities",description:"Stay fit with our 70+ equipment gym and specialized areas"},banya:{title:"Russian Banya",description:"Traditional Russian bath and wellness rituals"}},promotions:{title:"Special Offers",day_pass:{title:"Day in Complex",price:"390 THB",description:"Access to gym, pool, ice bath and sauna"},charity:{title:"Charity Workout",price:"200 THB",description:"Saturday training with professional athletes, proceeds go to Child Watch Phuket Foundation"}},about_preview:{title:"About KAIF",description:"KAIF is Phuket's premier wellness complex offering world-class facilities for mind, body and soul",features:{largest_sauna:"Thailand's largest sauna (50m²)",hammams:"Thai and Turkish hammams",restaurant:"Restaurant with 5 cuisines",gym:"70+ equipment gym",pool:"25m swimming pool",fight_club:"Professional fight club"}},location:{title:"Find Us",description:"Conveniently located in Kathu, just minutes away from Patong"}},ZA={title:"Restaurant",description:"Experience the exceptional flavors from five different cuisines in our restaurant",menu:{title:"Our Menu",description:"Discover a variety of flavors in our menu created by talented chefs",coming_soon:"Our menu with detailed dish information will be available here soon",categories:{breakfast:"Breakfast",soups:"Soups",salads:"Salads & Appetizers",main:"Main Courses"}},booking:{title:"Book a Table",description:"Reserve your table to guarantee your spot",coming_soon:"Online booking will be available soon. For now, please call us for reservations."},cuisines:{title:"Our Cuisines",description:"Experience culinary delights from around the world"},chef:"Chef's Recommendations",slider:{slide1:{title:"Exquisite Cuisine",description:"Discover unique flavors from five different world cuisines in our restaurant"},slide2:{title:"Comfortable Atmosphere",description:"Enjoy your meal in a cozy atmosphere with a view of the tropical garden"},slide3:{title:"Fresh Ingredients",description:"We use only fresh and quality ingredients to prepare our dishes"}},bookTable:"Book a Table",dish_details:{ingredients:"Ingredients",nutritional_info:"Nutritional Information"}},QA={title:"SPA",description:"Rejuvenate your mind and body in Thailand's largest sauna",services:{title:"Our Services",categories:{sauna:"Sauna",hammam:"Hammam",massage:"Massage",treatments:"SPA Treatments"}},booking:{title:"Book a Treatment",description:"Reserve your SPA experience"},facility:{title:"Our Facilities",largest_sauna:"Largest sauna in Thailand (50m²)",hammams:"Thai and Turkish hammams"}},JA={title:"Sports Facilities",description:"State-of-the-art exercise facilities for everyone",hero:{tag:"Fitness & Sports",title:"Reach new <span>sports heights</span> with KAIF",subtitle:"Our premium sports facilities are designed to accommodate various fitness levels and goals.",cta:"Explore Facilities",primary_cta:"Book a training",secondary_cta:"Learn more",stats:{facilities:"Sports Facilities",trainers:"Professional Trainers",access:"Access for Residents"}},gym:{tag:"Our Services",facility_tag:"Fitness",section_title:"Premium Sports Facilities",section_subtitle:"Discover the world of fitness and sports at KAIF Jungle Club. Our modern services are designed to give you the opportunity to train with pleasure and reach new heights.",title:"Gym",description1:"Spacious modern gym with cardio and strength equipment of high class. The gym is equipped with everything necessary for full-fledged training and maintaining physical fitness.",description2:"Guests have access to personal lockers, showers, as well as personal trainer services by appointment."},dance:{facility_tag:"Dancing",title:"Dance Studio",description1:"Spacious dance studio with professional parquet flooring, mirrored walls and modern audio system.",description2:"The studio offers group and individual lessons in various directions: modern dance, ballroom dancing, yoga, stretching, pilates and other directions.",schedule_button:"Schedule"},gallery:{tag:"Our Moments",title:"Gallery",subtitle:"Captured moments of sports life at KAIF Jungle Club & SPA. Join our community and share your own achievements",yoga:"Sunset Yoga",subtitle_yoga:"Daily classes",training:"Training with a personal trainer",subtitle_training:"Individual approach",swimming:"Swimming Pool",subtitle_swimming:"Relaxation and recovery"},schedule:{tag:"Planning",title:"Class Schedule",description:"Weekly class schedule with professional instructors",coming_soon:"Training schedule will be available soon. For current information, please contact us.",contact_button:"Contact Us"},facilities:{tag:"Our facilities",subtitle:"KAIF offers a wide selection of premium sports spaces with cutting-edge equipment and professional trainers to help you achieve your fitness goals.",title:"Our Facilities",gym:{title:"Gym",description:"Over 70 pieces of professional equipment",hours:"06:00 - 23:00",capacity:"Up to 40 people",description1:"Our gym is equipped with modern premium equipment from leading manufacturers. Here you will find everything you need for effective workouts - from free weights to the latest generation of cardio machines.",description2:"The spacious room with panoramic windows creates the perfect atmosphere for training, and professional trainers are always ready to help create an individual program.",feature1:"Premium Technogym and Life Fitness equipment",feature2:"Functional training area",feature3:"Individual training with certified trainers"},book_button:"Book a training session",fight:{title:"Fight Club",description:"Professional boxing and MMA facility",hours:"07:00 - 22:00",capacity:"Up to 25 people",description1:"KAIF Fighting Club is a modern space for training in various martial arts. Professional ring, punching bags, heavy bags, and special flooring create ideal conditions for both beginners and experienced fighters.",description2:"Our trainers are experienced fighters and champions who will help you master techniques and achieve high results in your chosen martial art.",feature1:"Professional boxing ring",feature2:"Boxing, Muay Thai, and MMA training",feature3:"Trainers with international certifications"},fight_club:{title:"Fight Club",description:"Professional boxing and MMA facility",hours:"07:00 - 22:00",capacity:"Up to 25 people",description1:"KAIF Fighting Club is a modern space for training in various martial arts. Professional ring, punching bags, heavy bags, and special flooring create ideal conditions for both beginners and experienced fighters.",description2:"Our trainers are experienced fighters and champions who will help you master techniques and achieve high results in your chosen martial art.",feature1:"Professional boxing ring",feature2:"Boxing, Muay Thai, and MMA training",feature3:"Trainers with international certifications"},dance:{title:"Dance Studio",description:"For yoga and dance classes",hours:"09:00 - 21:00",capacity:"Up to 30 people",description1:"Spacious dance studio with professional flooring, mirrored walls and advanced audio system creates ideal conditions for various dance styles and group classes.",description2:"Classes in modern and classical dance styles are held here, as well as group fitness training under the guidance of experienced instructors.",feature4:"Flexible schedule for group and individual classes",schedule_title:"Classes and Schedule",schedule_subtitle:"Find the right class",filter_label:"Filter:",filter_all:"All",filter_group:"Group",filter_personal:"Personal",filter_events:"Events"}},membership:{title:"Membership Options",description:"Choose the plan that works for you"},charity:{title:"Charity Workouts",description:"Saturday workouts with professional athletes, all proceeds go to Child Watch Phuket Foundation"}},WA={title:"About Us",description:"KAIF - Jungle Club & Spa is Phuket's premier wellness complex",overview:{title:"Complex Overview",description:"Detailed information about all our facilities"},features:{title:"Key Features",largest_sauna:"Thailand's largest sauna (50m²)",hammams:"Thai and Turkish hammams",restaurant:"Restaurant with 5 cuisines",dance_studio:"Dance and yoga studio (available for rent)",gym:"Fitness center with 70+ equipment",pool:"25m swimming pool",massage:"Various massage techniques",fight_club:"Fight club",kids_room:"Kids room (ages 3-14)"},gallery:{title:"Gallery",description:"High-quality photos of all facilities"},mission:{title:"Our Mission",description:"To provide an exceptional wellness experience in Phuket"}},eE={title:"Promotions",description:"Special offers and deals",day_pass:{title:"Day in Complex",price:"390 THB",description:"Access to gym, pool, ice bath and sauna",terms:"Terms and conditions apply"},charity:{title:"Charity Workout",price:"200 THB",description:"Saturday training with professional athletes",foundation:"All proceeds go to Child Watch Phuket Foundation"},seasonal:{title:"Seasonal Offers",description:"Limited-time offers"},loyalty:{title:"Loyalty Program",description:"Rewards for our regular customers"}},tE={title:"Contact Us",form:{title:"Get in Touch",success:"Your message has been sent successfully!",error:"An error occurred. Please try again."},info:{title:"Contact Information",hours:"Opening Hours: 7:00 - 22:00 daily"},feedback:{title:"Feedback",description:"We value your opinion"}},iE={navigation:GA,common:KA,home:XA,restaurant:ZA,spa:QA,sports:JA,about:WA,promotions:eE,contacts:tE},nE={home:"Главная",restaurant:"Ресторан",spa:"СПА",sports:"Спорт",banya:"Баня",about:"О нас",promotions:"Акции",contacts:"Контакты"},aE={book:"Забронировать",learn_more:"Узнать больше",view_all:"Смотреть всё",read_more:"Читать далее",submit:"Отправить",scroll_down:"Прокрутить вниз",scrollDown:"Прокрутить вниз",name:"Имя",email:"Email",phone:"Телефон",message:"Сообщение",date:"Дата",time:"Время",people:"Количество человек",special_requests:"Особые пожелания",address:"73, Baan Chalekiri Village, 6 Pra Phuket Keaw Road, Kathu",phone_number:"+66 62 480 5877",select_language:"Выбрать язык"},rE={hero:{title:"KAIF - Jungle Club & Spa",subtitle:"Уникальный опыт релаксации и оздоровления на Пхукете",cta:"Наши услуги",overline:"Премиальный оздоровительный комплекс",bookNow:"Забронировать",virtualTour:"Виртуальный тур",slideAlt:"KAIF - Jungle Club & Spa"},philosophy:{overline:"НАША ФИЛОСОФИЯ",title:"Пространство для гармонии и саморазвития",paragraph1:"Мы создаем пространство, где жизнь становится ярче. Наша миссия – сделать отдых и заботу о себе не обязанностью, а удовольствием. KAIF – это место, где вы восстанавливаете силы, заряжаетесь энергией и наслаждаетесь каждым моментом.",paragraph2:"Здесь всё устроено так, чтобы вам хотелось возвращаться: тренировки, которые вдохновляют, отдых, который наполняет, и атмосфера, которая дарит настоящий кайф. Мы верим, что гармония – это не роскошь, а необходимость, и делаем её доступной для вас.",quote:"Здоровье – это не просто отсутствие болезней, а состояние полного физического, душевного и социального благополучия",imageAlt:"KAIF - пространство для гармонии и саморазвития"},services:{title:"Наши услуги",restaurant:{title:"Ресторан",description:"Попробуйте 5 различных кухонь в нашем исключительном ресторане"},spa:{title:"СПА",description:"Восстановите силы в самой большой сауне Таиланда"},sports:{title:"Спортивный комплекс",description:"Поддерживайте форму в нашем зале с более чем 70 тренажерами"},banya:{title:"Русская баня",description:"Традиционные банные процедуры и оздоровление"}},promotions:{title:"Специальные предложения",day_pass:{title:"День в комплексе",price:"390 THB",description:"Доступ к тренажерному залу, бассейну, ледяной купели и сауне"},charity:{title:"Благотворительная тренировка",price:"200 THB",description:"Субботняя тренировка с профессиональными спортсменами, сборы идут в фонд Child Watch Phuket Foundation"}},about_preview:{title:"О KAIF",description:"KAIF - это премиальный оздоровительный комплекс на Пхукете, предлагающий услуги мирового класса для ума, тела и души",features:{largest_sauna:"Самая большая сауна в Таиланде (50м²)",hammams:"Тайский и турецкий хаммам",restaurant:"Ресторан с 5 кухнями",gym:"Тренажерный зал с более чем 70 тренажерами",pool:"Бассейн 25м",fight_club:"Профессиональный бойцовский клуб"}},location:{title:"Как нас найти",description:"Удобно расположены в Кату, всего в нескольких минутах от Патонга"}},oE={title:"Ресторан",description:"Погрузитесь в исключительные вкусы пяти различных кухонь в нашем ресторане",menu:{title:"Наше меню",description:"Откройте для себя разнообразие вкусов в нашем меню, созданном талантливыми шеф-поварами",coming_soon:"Скоро здесь появится наше меню с возможностью просмотра каждого блюда",categories:{breakfast:"Завтраки",soups:"Супы",salads:"Салаты и закуски",main:"Основные блюда"}},booking:{title:"Забронировать стол",description:"Заранее зарезервируйте столик для гарантированного места",coming_soon:"Онлайн-бронирование скоро будет доступно. Пока что, пожалуйста, позвоните нам для резервации."},cuisines:{title:"Наши кухни",description:"Попробуйте кулинарные изыски со всего мира"},chef:"Рекомендации шеф-повара",slider:{slide1:{title:"Изысканная кухня",description:"Откройте для себя уникальные вкусы пяти разных кухонь мира в нашем ресторане"},slide2:{title:"Атмосфера комфорта",description:"Наслаждайтесь едой в уютной атмосфере с видом на тропический сад"},slide3:{title:"Свежие ингредиенты",description:"Мы используем только свежие и качественные ингредиенты для приготовления наших блюд"}},bookTable:"Забронировать стол",dish_details:{ingredients:"Ингредиенты",nutritional_info:"Пищевая ценность"}},sE={title:"СПА",description:"Восстановите свои силы в самой большой сауне Таиланда",services:{title:"Наши услуги",categories:{sauna:"Сауна",hammam:"Хаммам",massage:"Массаж",treatments:"СПА-процедуры"}},booking:{title:"Записаться на процедуру",description:"Забронируйте СПА-процедуру"},facility:{title:"Наши объекты",largest_sauna:"Крупнейшая сауна в Таиланде (50м²)",hammams:"Тайский и турецкий хаммам"}},lE={title:"Спортивный комплекс",description:"Современные тренировочные объекты для всех",facilities:{title:"Наши объекты",gym:{title:"Тренажерный зал",description:"Более 70 единиц профессионального оборудования"},fight_club:{title:"Бойцовский клуб",description:"Профессиональное оборудование для бокса и ММА"},swimming:{title:"Центр плавания",description:"Плавательная дорожка 25м"},dance:{title:"Танцевальная студия",description:"Для занятий йогой и танцами"}},schedule:{title:"Расписание занятий",description:"Еженедельное расписание с профессиональными инструкторами"},membership:{title:"Варианты членства",description:"Выберите план, который подходит именно вам"},charity:{title:"Благотворительные тренировки",description:"Субботние тренировки с профессиональными спортсменами, все сборы идут в фонд Child Watch Phuket Foundation"}},cE={title:"О нас",description:"KAIF - Jungle Club & Spa — премиальный оздоровительный комплекс на Пхукете",overview:{title:"Обзор комплекса",description:"Подробная информация о всех наших объектах"},features:{title:"Ключевые особенности",largest_sauna:"Самая большая сауна в Таиланде (50м²)",hammams:"Тайский и турецкий хаммам",restaurant:"Ресторан с 5 кухнями",dance_studio:"Студия танцев и йоги (доступна для аренды)",gym:"Фитнес-центр с более чем 70 тренажерами",pool:"Бассейн 25м",massage:"Различные техники массажа",fight_club:"Бойцовский клуб",kids_room:"Детская комната (от 3 до 14 лет)"},gallery:{title:"Галерея",description:"Высококачественные фотографии всех объектов"},mission:{title:"Наша миссия",description:"Предоставить исключительный опыт оздоровления на Пхукете"}},uE={title:"Акции",description:"Специальные предложения",day_pass:{title:"День в комплексе",price:"390 THB",description:"Доступ к тренажерному залу, бассейну, ледяной купели и сауне",terms:"Применяются условия и положения"},charity:{title:"Благотворительная тренировка",price:"200 THB",description:"Субботняя тренировка с профессиональными спортсменами",foundation:"Все сборы идут в фонд Child Watch Phuket Foundation"},seasonal:{title:"Сезонные предложения",description:"Предложения с ограниченным сроком действия"},loyalty:{title:"Программа лояльности",description:"Бонусы для наших постоянных клиентов"}},dE={title:"Контакты",hero:{title:"Свяжитесь с нами",subtitle:"Мы всегда готовы ответить на ваши вопросы и помочь с бронированием"},form:{title:"Написать нам",subtitle:"Заполните форму ниже, и мы свяжемся с вами в ближайшее время",success:"Ваше сообщение успешно отправлено!",error:"Произошла ошибка. Пожалуйста, попробуйте снова.",sending:"Отправка...",submit:"Отправить сообщение"},info:{title:"Контактная информация",subtitle:"Найдите всю необходимую информацию для связи с нами",address:{title:"Адрес",directions:"Построить маршрут"},phone:{title:"Телефон",hours:"Доступен 24/7"},email:{title:"Email",response:"Ответим в течение 24 часов"},hours:{title:"Часы работы",weekdays:"Пн-Пт: 7:00 - 22:00",weekends:"Сб-Вс: 8:00 - 22:00"},social:{title:"Социальные сети"}},map:{title:"Как нас найти",subtitle:"Мы находимся в самом сердце Пхукета"},feedback:{title:"Обратная связь",description:"Нам важно ваше мнение"}},fE={submit:"Отправить",privacyInfo:"Отправляя форму, вы соглашаетесь с нашей",privacyLink:"политикой конфиденциальности"},hE={navigation:nE,common:aE,home:rE,restaurant:oE,spa:sE,sports:lE,about:cE,promotions:uE,contacts:dE,booking:fE},pE={home:"หน้าแรก",restaurant:"ร้านอาหาร",spa:"สปา",sports:"กีฬา",banya:"บันยารัสเซีย",about:"เกี่ยวกับเรา",promotions:"โปรโมชั่น",contacts:"ติดต่อ"},mE={book:"จองตอนนี้",learn_more:"เรียนรู้เพิ่มเติม",view_all:"ดูทั้งหมด",read_more:"อ่านเพิ่มเติม",submit:"ส่ง",scroll_down:"เลื่อน",name:"ชื่อ",email:"อีเมล",phone:"โทรศัพท์",message:"ข้อความ",date:"วันที่",time:"เวลา",people:"จำนวนคน",special_requests:"คำขอพิเศษ",address:"73, Baan Chalekiri Village, 6 Pra Phuket Keaw Road, Kathu",phone_number:"+66 62 480 5877",select_language:"เลือกภาษา"},gE={hero:{title:"KAIF - Jungle Club & Spa",subtitle:"ประสบการณ์การผ่อนคลายและความเป็นอยู่ที่ดีที่สุดในภูเก็ต",cta:"สำรวจบริการของเรา",overline:"คอมเพล็กซ์เพื่อสุขภาพระดับพรีเมียม",bookNow:"จองตอนนี้",virtualTour:"ทัวร์เสมือนจริง",slideAlt:"KAIF - Jungle Club & Spa"},philosophy:{overline:"ปรัชญาของเรา",title:"พื้นที่แห่งความสมดุลและการพัฒนาตนเอง",paragraph1:"เราสร้างพื้นที่ที่ทำให้ชีวิตสดใสขึ้น พันธกิจของเราคือการทำให้การพักผ่อนและการดูแลตัวเองเป็นความสุข ไม่ใช่ภาระ KAIF เป็นสถานที่ที่คุณได้ฟื้นฟูพลัง เติมพลังงาน และเพลิดเพลินกับทุกช่วงเวลา",paragraph2:"ทุกอย่างที่นี่ออกแบบมาเพื่อให้คุณอยากกลับมา: การออกกำลังกายที่สร้างแรงบันดาลใจ การพักผ่อนที่เติมเต็ม และบรรยากาศที่มอบความรู้สึกดีๆ เราเชื่อว่าความสมดุลไม่ใช่ความหรูหรา แต่เป็นสิ่งจำเป็น และเราทำให้สิ่งนี้เข้าถึงได้สำหรับคุณ",quote:"สุขภาพไม่ใช่เพียงการปราศจากโรคภัย แต่คือสภาวะแห่งความสมบูรณ์ทั้งทางร่างกาย จิตใจ และสังคม",imageAlt:"KAIF - พื้นที่แห่งความสมดุลและการพัฒนาตนเอง"},services:{title:"บริการของเรา",restaurant:{title:"ร้านอาหาร",description:"สัมผัสประสบการณ์อาหาร 5 สัญชาติในร้านอาหารพิเศษของเรา"},spa:{title:"สปา",description:"ฟื้นฟูร่างกายในซาวน่าที่ใหญ่ที่สุดในประเทศไทย"},sports:{title:"สิ่งอำนวยความสะดวกด้านกีฬา",description:"ออกกำลังกายกับอุปกรณ์กว่า 70 ชิ้นและพื้นที่เฉพาะทาง"},banya:{title:"บันยารัสเซีย",description:"อาบน้ำแบบดั้งเดิมของรัสเซียและพิธีกรรมเพื่อสุขภาพ"}},promotions:{title:"ข้อเสนอพิเศษ",day_pass:{title:"วันในคอมเพล็กซ์",price:"390 บาท",description:"เข้าถึงยิม สระว่ายน้ำ อ่างน้ำแข็ง และซาวน่า"},charity:{title:"การออกกำลังกายเพื่อการกุศล",price:"200 บาท",description:"การฝึกวันเสาร์กับนักกีฬามืออาชีพ รายได้มอบให้กับมูลนิธิ Child Watch Phuket"}},about_preview:{title:"เกี่ยวกับ KAIF",description:"KAIF คือคอมเพล็กซ์เพื่อสุขภาพชั้นนำของภูเก็ตที่นำเสนอสิ่งอำนวยความสะดวกระดับโลกสำหรับจิตใจ ร่างกาย และจิตวิญญาณ",features:{largest_sauna:"ซาวน่าที่ใหญ่ที่สุดในประเทศไทย (50ตร.ม.)",hammams:"หอบไอน้ำแบบไทยและตุรกี",restaurant:"ร้านอาหาร 5 สัญชาติ",gym:"ยิมพร้อมอุปกรณ์กว่า 70 ชิ้น",pool:"สระว่ายน้ำขนาด 25 เมตร",fight_club:"คลับมวยมืออาชีพ"}},location:{title:"ค้นหาเรา",description:"ตั้งอยู่อย่างสะดวกในกะทู้ ห่างจากป่าตองเพียงไม่กี่นาที"}},yE={title:"ร้านอาหาร",description:"สัมผัสรสชาติที่พิเศษจากห้าสัญชาติอาหารในร้านอาหารของเรา",menu:{title:"เมนูของเรา",description:"ค้นพบความหลากหลายของรสชาติในเมนูของเราที่สร้างสรรค์โดยเชฟที่มีพรสวรรค์",coming_soon:"เมนูของเราพร้อมข้อมูลอาหารโดยละเอียดจะพร้อมให้บริการในเร็วๆนี้",categories:{breakfast:"อาหารเช้า",soups:"ซุป",salads:"สลัดและอาหารเรียกน้ำย่อย",main:"อาหารจานหลัก"}},booking:{title:"จองโต๊ะ",description:"สำรองที่นั่งของคุณเพื่อการันตีที่นั่ง",coming_soon:"การจองออนไลน์จะพร้อมให้บริการในเร็วๆนี้ ในขณะนี้ โปรดโทรหาเราเพื่อจอง"},cuisines:{title:"อาหารของเรา",description:"สัมผัสความอร่อยจากทั่วโลก"},chef:"คำแนะนำจากเชฟ",slider:{slide1:{title:"อาหารชั้นเลิศ",description:"ค้นพบรสชาติที่ไม่เหมือนใครจากห้าสัญชาติอาหารที่แตกต่างกันในร้านอาหารของเรา"},slide2:{title:"บรรยากาศที่สบาย",description:"เพลิดเพลินกับอาหารในบรรยากาศที่อบอุ่นพร้อมวิวสวนเขตร้อน"},slide3:{title:"วัตถุดิบที่สดใหม่",description:"เราใช้เฉพาะวัตถุดิบที่สดและมีคุณภาพในการปรุงอาหารของเรา"}},bookTable:"จองโต๊ะ",dish_details:{ingredients:"ส่วนประกอบ",nutritional_info:"ข้อมูลทางโภชนาการ"}},xE={title:"สปา",description:"ฟื้นฟูจิตใจและร่างกายในซาวน่าที่ใหญ่ที่สุดในประเทศไทย",services:{title:"บริการของเรา",categories:{sauna:"ซาวน่า",hammam:"หอบไอน้ำ",massage:"นวด",treatments:"ทรีทเมนต์สปา"}},booking:{title:"จองทรีทเมนต์",description:"สำรองประสบการณ์สปาของคุณ"},facility:{title:"สิ่งอำนวยความสะดวกของเรา",largest_sauna:"ซาวน่าที่ใหญ่ที่สุดในประเทศไทย (50ตร.ม.)",hammams:"หอบไอน้ำแบบไทยและตุรกี"}},bE={title:"สิ่งอำนวยความสะดวกด้านกีฬา",description:"สิ่งอำนวยความสะดวกในการออกกำลังกายที่ทันสมัยสำหรับทุกคน",facilities:{title:"สิ่งอำนวยความสะดวกของเรา",gym:{title:"ยิม",description:"อุปกรณ์มืออาชีพกว่า 70 ชิ้น"},fight_club:{title:"คลับมวย",description:"สิ่งอำนวยความสะดวกมวยและ MMA มืออาชีพ"},swimming:{title:"ศูนย์ว่ายน้ำ",description:"ทางว่ายน้ำขนาด 25 เมตร"},dance:{title:"สตูดิโอเต้นรำ",description:"สำหรับคลาสโยคะและเต้นรำ"}},schedule:{title:"ตารางเรียน",description:"ตารางเรียนรายสัปดาห์กับผู้ฝึกสอนมืออาชีพ"},membership:{title:"ตัวเลือกสมาชิก",description:"เลือกแผนที่เหมาะกับคุณ"},charity:{title:"การออกกำลังกายเพื่อการกุศล",description:"การออกกำลังกายวันเสาร์กับนักกีฬามืออาชีพ รายได้ทั้งหมดมอบให้กับมูลนิธิ Child Watch Phuket"}},vE={title:"เกี่ยวกับเรา",description:"KAIF - Jungle Club & Spa คือคอมเพล็กซ์เพื่อสุขภาพชั้นนำของภูเก็ต",overview:{title:"ภาพรวมคอมเพล็กซ์",description:"ข้อมูลโดยละเอียดเกี่ยวกับสิ่งอำนวยความสะดวกทั้งหมดของเรา"},features:{title:"คุณสมบัติหลัก",largest_sauna:"ซาวน่าที่ใหญ่ที่สุดในประเทศไทย (50ตร.ม.)",hammams:"หอบไอน้ำแบบไทยและตุรกี",restaurant:"ร้านอาหาร 5 สัญชาติ",dance_studio:"สตูดิโอเต้นรำและโยคะ (มีให้เช่า)",gym:"ศูนย์ฟิตเนสพร้อมอุปกรณ์กว่า 70 ชิ้น",pool:"สระว่ายน้ำขนาด 25 เมตร",massage:"เทคนิคการนวดหลากหลาย",fight_club:"คลับมวย",kids_room:"ห้องเด็ก (อายุ 3-14 ปี)"},gallery:{title:"แกลเลอรี",description:"ภาพคุณภาพสูงของสิ่งอำนวยความสะดวกทั้งหมด"},mission:{title:"พันธกิจของเรา",description:"เพื่อมอบประสบการณ์ด้านสุขภาพที่ยอดเยี่ยมในภูเก็ต"}},wE={title:"โปรโมชั่น",description:"ข้อเสนอและดีลพิเศษ",day_pass:{title:"วันในคอมเพล็กซ์",price:"390 บาท",description:"เข้าถึงยิม สระว่ายน้ำ อ่างน้ำแข็ง และซาวน่า",terms:"เงื่อนไขและข้อกำหนดนำมาใช้"},charity:{title:"การออกกำลังกายเพื่อการกุศล",price:"200 บาท",description:"การฝึกวันเสาร์กับนักกีฬามืออาชีพ",foundation:"รายได้ทั้งหมดมอบให้กับมูลนิธิ Child Watch Phuket"},seasonal:{title:"ข้อเสนอตามฤดูกาล",description:"ข้อเสนอระยะเวลาจำกัด"},loyalty:{title:"โปรแกรมลูกค้าประจำ",description:"รางวัลสำหรับลูกค้าประจำของเรา"}},SE={title:"ติดต่อเรา",form:{title:"ติดต่อ",success:"ส่งข้อความของคุณเรียบร้อยแล้ว!",error:"เกิดข้อผิดพลาด โปรดลองอีกครั้ง"},info:{title:"ข้อมูลติดต่อ",hours:"เวลาทำการ: 7:00 - 22:00 ทุกวัน"},feedback:{title:"ข้อเสนอแนะ",description:"เราให้ความสำคัญกับความคิดเห็นของคุณ"}},TE={navigation:pE,common:mE,home:gE,restaurant:yE,spa:xE,sports:bE,about:vE,promotions:wE,contacts:SE};St.use(w2).use(f8).init({resources:{en:{translation:iE},ru:{translation:hE},th:{translation:TE}},fallbackLng:"en",debug:!1,interpolation:{escapeValue:!1}});const jE={colors:{primary:"#90B3A7",secondary:"#D4A574",tertiary:"#B8C4A8",energy:"#E8734A",power:"#2D5B69",fresh:"#4A90B8",background:"#FFFFFF",surface:"#FFFFFF",surfaceSecondary:"#FDFCFA",text:{primary:"#2C3E2D",secondary:"#5A6B5D",light:"#8B9A8E",white:"#FFFFFF",dark:"#1A2B1D"},zones:{spa:"#90B3A7",restaurant:"#D4A574",fitness:"#E8734A",combat:"#2D5B69",pool:"#4A90B8",banya:"#8B4513",sauna:"#8B7355"},success:"#5CB3CC",warning:"#FFD166",error:"#EF476F",info:"#4A90B8",gradients:{primary:"linear-gradient(135deg, #90B3A7 0%, #A8C5B8 100%)",secondary:"linear-gradient(135deg, #D4A574 0%, #E1B885 100%)",energy:"linear-gradient(135deg, #E8734A 0%, #F28A5F 100%)",power:"linear-gradient(135deg, #2D5B69 0%, #3D7084 100%)",fresh:"linear-gradient(135deg, #4A90B8 0%, #5FA3CC 100%)",spa:"linear-gradient(135deg, #90B3A7 0%, #A8C5B8 100%)",restaurant:"linear-gradient(135deg, #D4A574 0%, #E1B885 100%)",fitness:"linear-gradient(135deg, #E8734A 0%, #F28A5F 100%)",combat:"linear-gradient(135deg, #2D5B69 0%, #3D7084 100%)",pool:"linear-gradient(135deg, #4A90B8 0%, #5FA3CC 100%)",banya:"linear-gradient(135deg, #8B4513 0%, #CD853F 100%)",sauna:"linear-gradient(135deg, #8B7355 0%, #A18A6D 100%)"}},fonts:{primary:'"Inter", -apple-system, BlinkMacSystemFont, sans-serif',heading:'"Playfair Display", Georgia, serif',accent:'"Montserrat", Arial, sans-serif',mono:'"JetBrains Mono", monospace'},fontSizes:{xs:"0.75rem",sm:"0.875rem",base:"1rem",md:"1.125rem",lg:"1.25rem",xl:"1.5rem","2xl":"1.875rem","3xl":"2.25rem","4xl":"3rem","5xl":"3.75rem","6xl":"4.5rem"},fontWeights:{thin:100,extralight:200,light:300,normal:400,medium:500,semibold:600,bold:700,extrabold:800,black:900},space:{0:"0","0.5":"0.125rem",1:"0.25rem",2:"0.5rem",3:"0.75rem",4:"1rem",5:"1.25rem",6:"1.5rem",8:"2rem",10:"2.5rem",12:"3rem",16:"4rem",20:"5rem",24:"6rem",32:"8rem",40:"10rem",48:"12rem",56:"14rem",64:"16rem"},lineHeights:{none:1,tight:1.25,snug:1.375,normal:1.5,relaxed:1.625,loose:2},sizes:{container:{sm:"640px",md:"768px",lg:"1024px",xl:"1280px","2xl":"1400px"}},breakpoints:{xs:"480px",sm:"640px",md:"768px",lg:"1024px",xl:"1280px","2xl":"1400px"},radii:{none:"0",sm:"0.125rem",default:"0.25rem",md:"0.375rem",lg:"0.5rem",xl:"0.75rem","2xl":"1rem","3xl":"1.5rem",full:"9999px"},borders:{none:"none",thin:"1px solid",default:"2px solid",thick:"4px solid"},shadows:{none:"none",xs:"0 1px 2px 0 rgba(0, 0, 0, 0.05)",sm:"0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06)",md:"0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)",lg:"0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)",xl:"0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)","2xl":"0 25px 50px -12px rgba(0, 0, 0, 0.25)",inner:"inset 0 2px 4px 0 rgba(0, 0, 0, 0.06)",outline:"0 0 0 3px rgba(144, 179, 167, 0.5)",softGlow:"0 5px 15px rgba(144, 179, 167, 0.3)"},zIndex:{hide:-1,auto:"auto",base:0,docked:10,dropdown:1e3,sticky:1100,banner:1200,overlay:1300,modal:1400,popover:1500,skipLink:1600,toast:1700,tooltip:1800},transitions:{default:"all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",fast:"all 0.15s cubic-bezier(0.4, 0, 0.2, 1)",slow:"all 0.5s cubic-bezier(0.4, 0, 0.2, 1)",bounce:"all 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55)",elegant:"all 0.6s cubic-bezier(0.25, 0.46, 0.45, 0.94)"},animations:{fadeIn:"fadeIn 0.3s cubic-bezier(0.4, 0, 0.2, 1)",fadeOut:"fadeOut 0.3s cubic-bezier(0.4, 0, 0.2, 1)",slideUp:"slideUp 0.4s cubic-bezier(0.4, 0, 0.2, 1)",slideDown:"slideDown 0.4s cubic-bezier(0.4, 0, 0.2, 1)",pulse:"pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite"}},AE="/assets/logo-header-7WTZC_mL.png",EE=w(O.header)`
  position: fixed;
  width: 100%;
  top: 0;
  left: 0;
  z-index: 1000;
  background: rgba(255, 255, 255, 0.8);
  backdrop-filter: blur(15px);
  -webkit-backdrop-filter: blur(15px);
  transition: all 0.3s ease;
`,CE=w.div`
  display: flex;
  align-items: stretch;
  justify-content: space-between;
  max-width: 1600px;
  margin: 0 auto;
  padding: 0.6rem 2rem;
  position: relative;
  min-height: 48px;
  
  @media (max-width: 768px) {
    padding: 0.5rem 1.25rem;
    min-height: 42px;
  }
  
  & > * {
    display: flex;
    align-items: center;
  }
`,OE=w(hi)`
  display: flex;
  align-items: center;
  text-decoration: none;
  z-index: 10;
  margin-left: 1.5rem;
  height: 100%;
  
  @media (max-width: 768px) {
    margin-left: 0.5rem;
  }
`,RE=w.img`
  height: auto;
  max-height: 42px;
  width: auto;
  transition: all 0.3s ease;
  
  &:hover {
    transform: scale(1.05);
  }
  
  @media (max-width: 768px) {
    max-height: 36px;
  }
`,kE=w.nav`
  display: none;
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  
  @media (min-width: 1024px) {
    display: flex;
    align-items: center;
    gap: 2rem;
    height: 100%;
  }
`,_o=w(hi)`
  color: #374151;
  text-decoration: none;
  font-weight: 400;
  font-size: 0.8rem;
  letter-spacing: 0.01em;
  position: relative;
  padding: 0.3rem 0;
  transition: all 0.3s ease;
  text-transform: uppercase;
  cursor: pointer;
  display: flex;
  align-items: center;
  height: 34px;
  
  &::before {
    content: '';
    position: absolute;
    bottom: 0;
    left: 50%;
    width: 0;
    height: 1px;
    background: #90B3A7;
    transition: all 0.3s ease;
    transform: translateX(-50%);
  }
  
  &:hover {
    color: #90B3A7;
    
    &::before {
      width: 100%;
    }
  }
  
  &:active {
    transform: translateY(1px);
    color: #7a9d93;
  }
  
  &.active {
    color: #90B3A7;
    font-weight: 500;
    
    &::before {
      width: 100%;
    }
  }
`,DE=w.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1rem;
  z-index: 10;
  height: 100%;
  margin-right: 0.5rem;
  position: relative;
  
  @media (max-width: 768px) {
    margin-right: 0;
  }
`,ME=w.div`
  position: relative;
  display: flex;
  align-items: center;
  height: 100%;
  
  @media (max-width: 768px) {
    display: none;
  }
`,BE=w(O.button)`
  padding: 0.5rem 0.9rem;
  background: rgba(255, 255, 255, 0.6);
  border: 1px solid rgba(0, 0, 0, 0.08);
  border-radius: 10px;
  color: #374151;
  font-size: 0.8rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.25s cubic-bezier(0.4, 0.0, 0.2, 1);
  text-transform: uppercase;
  letter-spacing: 0.08em;
  min-width: 48px;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 34px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
  margin: auto 0;
  
  &:hover {
    background: rgba(255, 255, 255, 0.9);
    border-color: rgba(144, 179, 167, 0.25);
    color: #2d3748;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
    transform: translateY(-1px);
  }
  
  &:active {
    transform: translateY(0);
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
  }
`,zE=w(O.div)`
  position: absolute;
  top: calc(100% + 0.75rem);
  right: 0;
  min-width: 120px;
  background: rgba(255, 255, 255, 0.98);
  backdrop-filter: blur(25px);
  border: none;
  border-radius: 14px;
  padding: 0.6rem;
  box-shadow: 
    0 10px 40px rgba(0, 0, 0, 0.12),
    0 4px 12px rgba(0, 0, 0, 0.05),
    0 0 0 1px rgba(255, 255, 255, 0.3);
  z-index: 1001;
  overflow: hidden;
`,$E=w(O.button)`
  display: block;
  width: 100%;
  padding: 0.7rem 0.8rem;
  margin-bottom: 0.2rem;
  background: transparent;
  border: none;
  border-radius: 10px;
  color: ${({$active:e})=>e?"#374151":"#6b7280"};
  font-size: 0.8rem;
  font-weight: ${({$active:e})=>e?"600":"500"};
  cursor: pointer;
  transition: all 0.25s cubic-bezier(0.4, 0.0, 0.2, 1);
  text-align: left;
  text-transform: capitalize;
  letter-spacing: 0.02em;
  line-height: 1.2;
  
  &:last-child {
    margin-bottom: 0;
  }
  
  &:hover {
    background: rgba(144, 179, 167, 0.08);
    color: #374151;
    transform: translateX(2px);
  }
  
  ${({$active:e})=>e&&`
    background: rgba(144, 179, 167, 0.12);
    color: #374151;
    font-weight: 600;
  `}
`,NE=w(O.button)`
  display: none;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 1.75rem;
  height: 1.75rem;
  background: transparent;
  border: none;
  cursor: pointer;
  padding: 0;
  transition: all 0.3s ease;
  
  @media (max-width: 1023px) {
    display: flex;
  }
  
  &:hover {
    opacity: 0.7;
  }
`,kf=w(O.div)`
  width: 1rem;
  height: 1px;
  background: #6b7280;
  margin: 2px 0;
  transition: all 0.3s ease;
  transform-origin: center;
  
  &:nth-child(1) {
    transform: ${e=>e.$isOpen?"translateY(5px) rotate(45deg)":"translateY(0) rotate(0)"};
  }
  
  &:nth-child(2) {
    opacity: ${e=>e.$isOpen?"0":"1"};
    transform: ${e=>e.$isOpen?"translateX(10px)":"translateX(0)"};
  }
  
  &:nth-child(3) {
    transform: ${e=>e.$isOpen?"translateY(-5px) rotate(-45deg)":"translateY(0) rotate(0)"};
  }
`,LE=w(O.div)`
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background: rgba(0, 0, 0, 0.4);
  z-index: 998;
`,_E=w(O.div)`
  position: fixed;
  top: 0;
  right: 0;
  width: 320px;
  height: 100vh;
  background: #ffffff;
  z-index: 999;
  display: flex;
  flex-direction: column;
  padding: 0;
  box-shadow: -8px 0 32px rgba(0, 0, 0, 0.12);
  
  @media (max-width: 360px) {
    width: 280px;
  }
`,HE=w.div`
  display: flex;
  justify-content: flex-end;
  align-items: center;
  padding: 1.5rem 1.5rem 0 1.5rem;
  min-height: 80px;
`,VE=w(O.button)`
  width: 2.5rem;
  height: 2.5rem;
  background: transparent;
  border: none;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.25rem;
  color: #9ca3af;
  cursor: pointer;
  transition: all 0.3s ease-out;
  
  &:hover {
    color: #374151;
    background: rgba(0, 0, 0, 0.04);
    transform: rotate(90deg);
  }
`,PE=w.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  padding: 2rem 0 0 0;
  position: relative;
`,FE=w.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding: 0 1.5rem;
  gap: 1rem;
  padding-bottom: 120px; /* Освобождаем место для фиксированных кнопок языков */
`,Ho=w(O(hi))`
  color: #374151;
  text-decoration: none;
  font-weight: 500;
  font-size: 1.1rem;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  transition: all 0.3s ease-out;
  padding: 1.25rem 0;
  border-radius: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  text-align: center;
  
  &::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 0;
    height: 1px;
    background: #e5e7eb;
    transition: all 0.3s ease-out;
  }
  
  &:hover {
    color: #1f2937;
    transform: translateY(-1px);
    
    &::after {
      width: 70%;
    }
  }
  
  &.active {
    color: #90B3A7;
    
    &::after {
      width: 65%;
      height: 3px;
      background: #90B3A7;
    }
  }
`;w.div`
  height: 1px;
  background: #f3f4f6;
  margin: 2rem 1.5rem;
`;const UE=w(O.div)`
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  padding: 1.5rem 1.5rem 2rem 1.5rem;
  background: #ffffff;
  border-top: 1px solid #f3f4f6;
`,qE=w.h3`
  font-size: 0.75rem;
  color: #9ca3af;
  margin-bottom: 1.2rem;
  text-transform: uppercase;
  letter-spacing: 0.1em;
  font-weight: 600;
`,IE=w.div`
  display: flex;
  gap: 1rem;
  justify-content: center;
  align-items: center;
`,YE=w(O.button)`
  padding: 0.75rem 1.4rem;
  background: transparent;
  border: 2px solid ${({$active:e})=>e?"#90B3A7":"#e5e7eb"};
  border-radius: 10px;
  color: ${({$active:e})=>e?"#90B3A7":"#6b7280"};
  font-size: 0.9rem;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.3s ease-out;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  min-width: 64px;
  position: relative;
  
  ${({$active:e})=>e&&`
    &::after {
      content: '';
      position: absolute;
      bottom: -2px;
      left: 50%;
      transform: translateX(-50%);
      width: 60%;
      height: 3px;
      background: #90B3A7;
      border-radius: 2px;
    }
  `}
  
  &:hover {
    border-color: #90B3A7;
    color: #90B3A7;
    background: rgba(144, 179, 167, 0.05);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(144, 179, 167, 0.2);
  }
  
  &:active {
    transform: translateY(-1px);
  }
`,GE=()=>{const[e,i]=S.useState(!1),[a,r]=S.useState(!1),{t:s,i18n:c}=De(),u=fi(),f=b=>!!(b==="/"&&u.pathname==="/"||b!=="/"&&u.pathname.startsWith(b)),p=b=>{setTimeout(()=>{i(!1),r(!1)},100)},m=b=>{c.changeLanguage(b),r(!1),i(!1)},y=[{code:"ru",name:"Русский"},{code:"en",name:"English"},{code:"th",name:"ไทย"}],x=y.find(b=>b.code===c.language)||y[0];return S.useEffect(()=>{const b=T=>{T.target.closest(".language-selector")||r(!1)};return document.addEventListener("click",b),()=>document.removeEventListener("click",b)},[]),S.useEffect(()=>(e?document.body.style.overflow="hidden":document.body.style.overflow="unset",()=>{document.body.style.overflow="unset"}),[e]),S.useEffect(()=>{i(!1),r(!1),window.scrollTo(0,0)},[u.pathname]),h.jsxs(h.Fragment,{children:[h.jsx(EE,{initial:{y:-80},animate:{y:0},transition:{duration:.5,ease:[.25,.46,.45,.94]},children:h.jsxs(CE,{children:[h.jsx(OE,{to:"/",children:h.jsx(RE,{src:AE,alt:"KAIF"})}),h.jsxs(kE,{children:[h.jsx(_o,{to:"/",className:f("/")?"active":"",onClick:()=>p(),children:"Главная"}),h.jsx(_o,{to:"/restaurant",className:f("/restaurant")?"active":"",onClick:()=>p(),children:"Ресторан"}),h.jsx(_o,{to:"/spa",className:f("/spa")?"active":"",onClick:()=>p(),children:"СПА"}),h.jsx(_o,{to:"/sports",className:f("/sports")?"active":"",onClick:()=>p(),children:"Спорт"}),h.jsx(_o,{to:"/banya",className:f("/banya")?"active":"",onClick:()=>p(),children:"Баня"})]}),h.jsxs(DE,{children:[h.jsxs(ME,{className:"language-selector",children:[h.jsx(BE,{whileHover:{scale:1.05},whileTap:{scale:.95},onClick:()=>r(!a),children:x.code}),a&&h.jsx(zE,{initial:{opacity:0,y:-12,scale:.9},animate:{opacity:1,y:0,scale:1},exit:{opacity:0,y:-8,scale:.95},transition:{duration:.3,ease:[.4,0,.2,1],opacity:{duration:.25},y:{duration:.3},scale:{duration:.25}},children:y.map(b=>h.jsx($E,{$active:c.language===b.code,whileHover:{x:3,scale:1.02},whileTap:{scale:.98},initial:{opacity:0,x:-10},animate:{opacity:1,x:0},transition:{delay:.1+y.findIndex(T=>T.code===b.code)*.05,duration:.25,ease:[.4,0,.2,1]},onClick:()=>m(b.code),children:b.name},b.code))})]}),h.jsxs(NE,{whileHover:{scale:1.05},whileTap:{scale:.95},onClick:()=>i(!e),children:[h.jsx(kf,{$isOpen:e}),h.jsx(kf,{$isOpen:e}),h.jsx(kf,{$isOpen:e})]})]})]})}),h.jsx(ua,{children:e&&h.jsxs(h.Fragment,{children:[h.jsx(LE,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},transition:{duration:.3,ease:"easeOut"},onClick:()=>i(!1)},"backdrop"),h.jsxs(_E,{initial:{x:"100%"},animate:{x:0},exit:{x:"110%",transition:{duration:.4,ease:[.68,-.55,.265,1.55]}},transition:{duration:.3,ease:"easeOut"},children:[h.jsx(HE,{children:h.jsx(VE,{whileHover:{scale:1.15,rotate:90},whileTap:{scale:.9},initial:{opacity:0,rotate:-90,scale:.8},animate:{opacity:1,rotate:0,scale:1},transition:{delay:.1,duration:.3,ease:[.25,.46,.45,.94]},onClick:()=>i(!1),children:"×"})}),h.jsxs(PE,{children:[h.jsxs(FE,{children:[h.jsx(Ho,{to:"/",className:f("/")?"active":"",onClick:()=>p(),initial:{opacity:0,y:30,scale:.9},animate:{opacity:1,y:0,scale:1},transition:{delay:.1,duration:.4,ease:[.25,.46,.45,.94],type:"spring",staggerChildren:.1},whileHover:{scale:1.02,y:-2},whileTap:{scale:.98},children:"Главная"}),h.jsx(Ho,{to:"/restaurant",className:f("/restaurant")?"active":"",onClick:()=>p(),initial:{opacity:0,y:30,scale:.9},animate:{opacity:1,y:0,scale:1},transition:{delay:.2,duration:.4,ease:[.25,.46,.45,.94],type:"spring"},whileHover:{scale:1.02,y:-2},whileTap:{scale:.98},children:"Ресторан"}),h.jsx(Ho,{to:"/spa",className:f("/spa")?"active":"",onClick:()=>p(),initial:{opacity:0,y:30,scale:.9},animate:{opacity:1,y:0,scale:1},transition:{delay:.3,duration:.4,ease:[.25,.46,.45,.94],type:"spring"},whileHover:{scale:1.02,y:-2},whileTap:{scale:.98},children:"СПА"}),h.jsx(Ho,{to:"/sports",className:f("/sports")?"active":"",onClick:()=>p(),initial:{opacity:0,y:30,scale:.9},animate:{opacity:1,y:0,scale:1},transition:{delay:.4,duration:.4,ease:[.25,.46,.45,.94],type:"spring"},whileHover:{scale:1.02,y:-2},whileTap:{scale:.98},children:"Спорт"}),h.jsx(Ho,{to:"/banya",className:f("/banya")?"active":"",onClick:()=>p(),initial:{opacity:0,y:30,scale:.9},animate:{opacity:1,y:0,scale:1},transition:{delay:.6,duration:.4,ease:[.25,.46,.45,.94],type:"spring"},whileHover:{scale:1.02,y:-2},whileTap:{scale:.98},children:"Баня"})]}),h.jsxs(UE,{initial:{opacity:0,y:30},animate:{opacity:1,y:0},transition:{delay:.7,duration:.4,ease:[.25,.46,.45,.94],type:"spring"},children:[h.jsx(qE,{children:"Язык / Language"}),h.jsx(IE,{children:y.map((b,T)=>h.jsx(YE,{$active:c.language===b.code,whileHover:{scale:1.08,y:-3},whileTap:{scale:.95},initial:{opacity:0,scale:.7,y:20},animate:{opacity:1,scale:1,y:0},transition:{delay:.8+T*.1,duration:.4,ease:[.25,.46,.45,.94],type:"spring"},onClick:()=>m(b.code),children:b.code},b.code))})]})]})]},"menu")]})})]})};function KE({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{fillRule:"evenodd",d:"M12.97 3.97a.75.75 0 0 1 1.06 0l7.5 7.5a.75.75 0 0 1 0 1.06l-7.5 7.5a.75.75 0 1 1-1.06-1.06l6.22-6.22H3a.75.75 0 0 1 0-1.5h16.19l-6.22-6.22a.75.75 0 0 1 0-1.06Z",clipRule:"evenodd"}))}const Sr=S.forwardRef(KE);function XE({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{fillRule:"evenodd",d:"M10.5 3.798v5.02a3 3 0 0 1-.879 2.121l-2.377 2.377a9.845 9.845 0 0 1 5.091 1.013 8.315 8.315 0 0 0 5.713.636l.285-.071-3.954-3.955a3 3 0 0 1-.879-2.121v-5.02a23.614 23.614 0 0 0-3 0Zm4.5.138a.75.75 0 0 0 .093-1.495A24.837 24.837 0 0 0 12 2.25a25.048 25.048 0 0 0-3.093.191A.75.75 0 0 0 9 3.936v4.882a1.5 1.5 0 0 1-.44 1.06l-6.293 6.294c-1.62 1.621-.903 4.475 1.471 4.88 2.686.46 5.447.698 8.262.698 2.816 0 5.576-.239 8.262-.697 2.373-.406 3.092-3.26 1.47-4.881L15.44 9.879A1.5 1.5 0 0 1 15 8.818V3.936Z",clipRule:"evenodd"}))}const ab=S.forwardRef(XE);function ZE({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{fillRule:"evenodd",d:"M6.75 2.25A.75.75 0 0 1 7.5 3v1.5h9V3A.75.75 0 0 1 18 3v1.5h.75a3 3 0 0 1 3 3v11.25a3 3 0 0 1-3 3H5.25a3 3 0 0 1-3-3V7.5a3 3 0 0 1 3-3H6V3a.75.75 0 0 1 .75-.75Zm13.5 9a1.5 1.5 0 0 0-1.5-1.5H5.25a1.5 1.5 0 0 0-1.5 1.5v7.5a1.5 1.5 0 0 0 1.5 1.5h13.5a1.5 1.5 0 0 0 1.5-1.5v-7.5Z",clipRule:"evenodd"}))}const rb=S.forwardRef(ZE);function QE({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{d:"M4.913 2.658c2.075-.27 4.19-.408 6.337-.408 2.147 0 4.262.139 6.337.408 1.922.25 3.291 1.861 3.405 3.727a4.403 4.403 0 0 0-1.032-.211 50.89 50.89 0 0 0-8.42 0c-2.358.196-4.04 2.19-4.04 4.434v4.286a4.47 4.47 0 0 0 2.433 3.984L7.28 21.53A.75.75 0 0 1 6 21v-4.03a48.527 48.527 0 0 1-1.087-.128C2.905 16.58 1.5 14.833 1.5 12.862V6.638c0-1.97 1.405-3.718 3.413-3.979Z"}),S.createElement("path",{d:"M15.75 7.5c-1.376 0-2.739.057-4.086.169C10.124 7.797 9 9.103 9 10.609v4.285c0 1.507 1.128 2.814 2.67 2.94 1.243.102 2.5.157 3.768.165l2.782 2.781a.75.75 0 0 0 1.28-.53v-2.39l.33-.026c1.542-.125 2.67-1.433 2.67-2.94v-4.286c0-1.505-1.125-2.811-2.664-2.94A49.392 49.392 0 0 0 15.75 7.5Z"}))}const ob=S.forwardRef(QE);function JE({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{fillRule:"evenodd",d:"M12.53 16.28a.75.75 0 0 1-1.06 0l-7.5-7.5a.75.75 0 0 1 1.06-1.06L12 14.69l6.97-6.97a.75.75 0 1 1 1.06 1.06l-7.5 7.5Z",clipRule:"evenodd"}))}const WE=S.forwardRef(JE);function eC({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{fillRule:"evenodd",d:"M7.72 12.53a.75.75 0 0 1 0-1.06l7.5-7.5a.75.75 0 1 1 1.06 1.06L9.31 12l6.97 6.97a.75.75 0 1 1-1.06 1.06l-7.5-7.5Z",clipRule:"evenodd"}))}const tC=S.forwardRef(eC);function iC({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{fillRule:"evenodd",d:"M16.28 11.47a.75.75 0 0 1 0 1.06l-7.5 7.5a.75.75 0 0 1-1.06-1.06L14.69 12 7.72 5.03a.75.75 0 0 1 1.06-1.06l7.5 7.5Z",clipRule:"evenodd"}))}const Qp=S.forwardRef(iC);function nC({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{fillRule:"evenodd",d:"M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25ZM12.75 6a.75.75 0 0 0-1.5 0v6c0 .414.336.75.75.75h4.5a.75.75 0 0 0 0-1.5h-3.75V6Z",clipRule:"evenodd"}))}const Tr=S.forwardRef(nC);function aC({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{d:"M4.5 3.75a3 3 0 0 0-3 3v.75h21v-.75a3 3 0 0 0-3-3h-15Z"}),S.createElement("path",{fillRule:"evenodd",d:"M22.5 9.75h-21v7.5a3 3 0 0 0 3 3h15a3 3 0 0 0 3-3v-7.5Zm-18 3.75a.75.75 0 0 1 .75-.75h6a.75.75 0 0 1 0 1.5h-6a.75.75 0 0 1-.75-.75Zm.75 2.25a.75.75 0 0 0 0 1.5h3a.75.75 0 0 0 0-1.5h-3Z",clipRule:"evenodd"}))}const Df=S.forwardRef(aC);function rC({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{fillRule:"evenodd",d:"M12.963 2.286a.75.75 0 0 0-1.071-.136 9.742 9.742 0 0 0-3.539 6.176 7.547 7.547 0 0 1-1.705-1.715.75.75 0 0 0-1.152-.082A9 9 0 1 0 15.68 4.534a7.46 7.46 0 0 1-2.717-2.248ZM15.75 14.25a3.75 3.75 0 1 1-7.313-1.172c.628.465 1.35.81 2.133 1a5.99 5.99 0 0 1 1.925-3.546 3.75 3.75 0 0 1 3.255 3.718Z",clipRule:"evenodd"}))}const hs=S.forwardRef(rC);function oC({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{d:"m11.645 20.91-.007-.003-.022-.012a15.247 15.247 0 0 1-.383-.218 25.18 25.18 0 0 1-4.244-3.17C4.688 15.36 2.25 12.174 2.25 8.25 2.25 5.322 4.714 3 7.688 3A5.5 5.5 0 0 1 12 5.052 5.5 5.5 0 0 1 16.313 3c2.973 0 5.437 2.322 5.437 5.25 0 3.925-2.438 7.111-4.739 9.256a25.175 25.175 0 0 1-4.244 3.17 15.247 15.247 0 0 1-.383.219l-.022.012-.007.004-.003.001a.752.752 0 0 1-.704 0l-.003-.001Z"}))}const Jp=S.forwardRef(oC);function sC({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{fillRule:"evenodd",d:"m11.54 22.351.07.04.028.016a.76.76 0 0 0 .723 0l.028-.015.071-.041a16.975 16.975 0 0 0 1.144-.742 19.58 19.58 0 0 0 2.683-2.282c1.944-1.99 3.963-4.98 3.963-8.827a8.25 8.25 0 0 0-16.5 0c0 3.846 2.02 6.837 3.963 8.827a19.58 19.58 0 0 0 2.682 2.282 16.975 16.975 0 0 0 1.145.742ZM12 13.5a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z",clipRule:"evenodd"}))}const S2=S.forwardRef(sC);function lC({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{fillRule:"evenodd",d:"M4.25 12a.75.75 0 0 1 .75-.75h14a.75.75 0 0 1 0 1.5H5a.75.75 0 0 1-.75-.75Z",clipRule:"evenodd"}))}const cC=S.forwardRef(lC);function uC({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{fillRule:"evenodd",d:"M1.5 4.5a3 3 0 0 1 3-3h1.372c.86 0 1.61.586 1.819 1.42l1.105 4.423a1.875 1.875 0 0 1-.694 1.955l-1.293.97c-.135.101-.164.249-.126.352a11.285 11.285 0 0 0 6.697 6.697c.103.038.25.009.352-.126l.97-1.293a1.875 1.875 0 0 1 1.955-.694l4.423 1.105c.834.209 1.42.959 1.42 1.82V19.5a3 3 0 0 1-3 3h-2.25C8.552 22.5 1.5 15.448 1.5 6.75V4.5Z",clipRule:"evenodd"}))}const Wi=S.forwardRef(uC);function dC({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{fillRule:"evenodd",d:"M12 3.75a.75.75 0 0 1 .75.75v6.75h6.75a.75.75 0 0 1 0 1.5h-6.75v6.75a.75.75 0 0 1-1.5 0v-6.75H4.5a.75.75 0 0 1 0-1.5h6.75V4.5a.75.75 0 0 1 .75-.75Z",clipRule:"evenodd"}))}const fC=S.forwardRef(dC);function hC({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{fillRule:"evenodd",d:"M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12Zm11.378-3.917c-.89-.777-2.366-.777-3.255 0a.75.75 0 0 1-.988-1.129c1.454-1.272 3.776-1.272 5.23 0 1.513 1.324 1.513 3.518 0 4.842a3.75 3.75 0 0 1-.837.552c-.676.328-1.028.774-1.028 1.152v.75a.75.75 0 0 1-1.5 0v-.75c0-1.279 1.06-2.107 1.875-2.502.182-.088.351-.199.503-.331.83-.727.83-1.857 0-2.584ZM12 18a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5Z",clipRule:"evenodd"}))}const qo=S.forwardRef(hC);function pC({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{fillRule:"evenodd",d:"M12.516 2.17a.75.75 0 0 0-1.032 0 11.209 11.209 0 0 1-7.877 3.08.75.75 0 0 0-.722.515A12.74 12.74 0 0 0 2.25 9.75c0 5.942 4.064 10.933 9.563 12.348a.749.749 0 0 0 .374 0c5.499-1.415 9.563-6.406 9.563-12.348 0-1.39-.223-2.73-.635-3.985a.75.75 0 0 0-.722-.516l-.143.001c-2.996 0-5.717-1.17-7.734-3.08Zm3.094 8.016a.75.75 0 1 0-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 0 0-1.06 1.06l2.25 2.25a.75.75 0 0 0 1.14-.094l3.75-5.25Z",clipRule:"evenodd"}))}const mC=S.forwardRef(pC);function gC({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{fillRule:"evenodd",d:"M7.5 6v.75H5.513c-.96 0-1.764.724-1.865 1.679l-1.263 12A1.875 1.875 0 0 0 4.25 22.5h15.5a1.875 1.875 0 0 0 1.865-2.071l-1.263-12a1.875 1.875 0 0 0-1.865-1.679H16.5V6a4.5 4.5 0 1 0-9 0ZM12 3a3 3 0 0 0-3 3v.75h6V6a3 3 0 0 0-3-3Zm-3 8.25a3 3 0 1 0 6 0v-.75a.75.75 0 0 1 1.5 0v.75a4.5 4.5 0 1 1-9 0v-.75a.75.75 0 0 1 1.5 0v.75Z",clipRule:"evenodd"}))}const yC=S.forwardRef(gC);function xC({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{fillRule:"evenodd",d:"M9 4.5a.75.75 0 0 1 .721.544l.813 2.846a3.75 3.75 0 0 0 2.576 2.576l2.846.813a.75.75 0 0 1 0 1.442l-2.846.813a3.75 3.75 0 0 0-2.576 2.576l-.813 2.846a.75.75 0 0 1-1.442 0l-.813-2.846a3.75 3.75 0 0 0-2.576-2.576l-2.846-.813a.75.75 0 0 1 0-1.442l2.846-.813A3.75 3.75 0 0 0 7.466 7.89l.813-2.846A.75.75 0 0 1 9 4.5ZM18 1.5a.75.75 0 0 1 .728.568l.258 1.036c.236.94.97 1.674 1.91 1.91l1.036.258a.75.75 0 0 1 0 1.456l-1.036.258c-.94.236-1.674.97-1.91 1.91l-.258 1.036a.75.75 0 0 1-1.456 0l-.258-1.036a2.625 2.625 0 0 0-1.91-1.91l-1.036-.258a.75.75 0 0 1 0-1.456l1.036-.258a2.625 2.625 0 0 0 1.91-1.91l.258-1.036A.75.75 0 0 1 18 1.5ZM16.5 15a.75.75 0 0 1 .712.513l.394 1.183c.15.447.5.799.948.948l1.183.395a.75.75 0 0 1 0 1.422l-1.183.395c-.447.15-.799.5-.948.948l-.395 1.183a.75.75 0 0 1-1.422 0l-.395-1.183a1.5 1.5 0 0 0-.948-.948l-1.183-.395a.75.75 0 0 1 0-1.422l1.183-.395c.447-.15.799-.5.948-.948l.395-1.183A.75.75 0 0 1 16.5 15Z",clipRule:"evenodd"}))}const Uc=S.forwardRef(xC);function bC({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{fillRule:"evenodd",d:"M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.006 5.404.434c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.434 2.082-5.005Z",clipRule:"evenodd"}))}const ps=S.forwardRef(bC);function vC({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{fillRule:"evenodd",d:"M8.25 6.75a3.75 3.75 0 1 1 7.5 0 3.75 3.75 0 0 1-7.5 0ZM15.75 9.75a3 3 0 1 1 6 0 3 3 0 0 1-6 0ZM2.25 9.75a3 3 0 1 1 6 0 3 3 0 0 1-6 0ZM6.31 15.117A6.745 6.745 0 0 1 12 12a6.745 6.745 0 0 1 6.709 7.498.75.75 0 0 1-.372.568A12.696 12.696 0 0 1 12 21.75c-2.305 0-4.47-.612-6.337-1.684a.75.75 0 0 1-.372-.568 6.787 6.787 0 0 1 1.019-4.38Z",clipRule:"evenodd"}),S.createElement("path",{d:"M5.082 14.254a8.287 8.287 0 0 0-1.308 5.135 9.687 9.687 0 0 1-1.764-.44l-.115-.04a.563.563 0 0 1-.373-.487l-.01-.121a3.75 3.75 0 0 1 3.57-4.047ZM20.226 19.389a8.287 8.287 0 0 0-1.308-5.135 3.75 3.75 0 0 1 3.57 4.047l-.01.121a.563.563 0 0 1-.373.486l-.115.04c-.567.2-1.156.349-1.764.441Z"}))}const es=S.forwardRef(vC),wC="/assets/logo-footer-CQc8sCzi.png",SC=w.footer`
  position: relative;
  background: linear-gradient(135deg, #90B3A7 0%, #A8C5B8 100%);
  padding: 3rem 2rem 0;
  color: white;
  z-index: 1;
  overflow: hidden;
  margin: -5px 0 0 0;
  min-height: auto;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.45);
    z-index: -1;
  }
  
  &::after {
    content: '';
    position: absolute;
    bottom: -10px;
    left: 0;
    width: 100%;
    height: 10px;
    background: linear-gradient(135deg, #90B3A7 0%, #A8C5B8 100%);
    z-index: 1;
  }
  
  @media (max-width: 768px) {
    padding: 2.5rem 1rem 0;
  }
`,TC=w.div`
  position: relative;
  z-index: 10;
  max-width: 1400px;
  margin: 0 auto;
  padding: 2rem 1.5rem 0;
  
  @media (min-width: 1024px) {
    padding: 3rem 2rem 0;
  }
`,jC=w.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 2rem;
  margin-bottom: 2rem;
  
  @media (min-width: 768px) {
    grid-template-columns: repeat(2, 1fr);
    gap: 3rem;
  }
  
  @media (min-width: 1024px) {
    grid-template-columns: 1.8fr 1fr 1fr 1.2fr;
    gap: 2.5rem;
  }
`,AC=w(O.div)`
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  
  @media (max-width: 1023px) {
    text-align: center;
    align-items: center;
    grid-column: 1 / -1;
    margin-bottom: 0.5rem;
  }
`,EC=w(O.img)`
  height: auto;
  width: 360px;
  object-fit: contain;
  margin-bottom: 1.5rem;
  filter: brightness(1.2) contrast(1.1);
  display: block;
  
  /* Десктопная версия и iPad Pro с отрицательным отступом */
  @media (min-width: 1024px) {
    margin-left: -3.5rem;
    align-self: flex-start;
  }
  
  /* Специальные стили для iPad Pro (1024px и выше по ширине) */
  @media (min-width: 1024px) and (max-width: 1366px) and (orientation: portrait) {
    margin-left: -3.2rem;
    width: 320px;
  }
  
  /* Стили для iPad Air и маленьких планшетов (820-900px) */
  @media (min-width: 820px) and (max-width: 900px) {
    margin: 0 auto 1.5rem;
    width: 300px;
    align-self: center;
  }
  
  /* Стили для средних планшетов */
  @media (min-width: 901px) and (max-width: 1023px) {
    margin-left: 0;
    width: 300px;
    align-self: flex-start;
  }
  
  /* Мобильная версия с центрированием */
  @media (max-width: 768px) {
    margin: 0 auto 1.5rem;
    width: 320px;
    align-self: center;
  }
`;w.p`
  font-family: ${({theme:e})=>{var i;return((i=e==null?void 0:e.fonts)==null?void 0:i.primary)||"Inter, sans-serif"}};
  font-size: 0.875rem;
  color: rgba(255, 255, 255, 0.8);
  text-transform: uppercase;
  letter-spacing: 0.15em;
  margin-bottom: 1.5rem;
`;const CC=w.p`
  font-family: ${({theme:e})=>{var i;return((i=e==null?void 0:e.fonts)==null?void 0:i.primary)||"Inter, sans-serif"}};
  font-size: 1.125rem;
  line-height: 1.6;
  margin-bottom: 1.5rem;
  color: rgba(255, 255, 255, 0.9);
  max-width: 400px;
  
  @media (max-width: 1023px) {
    max-width: 480px;
    text-align: center;
    margin-left: auto;
    margin-right: auto;
    font-size: 1.05rem;
  }
`,OC=w.div`
  display: flex;
  gap: 1rem;
  
  @media (max-width: 1023px) {
    justify-content: center;
  }
`,Mf=w(O.a)`
  width: 2.5rem;
  height: 2.5rem;
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: rgba(255, 255, 255, 0.8);
  text-decoration: none;
  transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  backdrop-filter: blur(10px);
  
  &:hover {
    background: ${({theme:e})=>{var i,a;return((a=(i=e==null?void 0:e.colors)==null?void 0:i.gradients)==null?void 0:a.logo)||"linear-gradient(135deg, rgba(255, 99, 71, 0.07) 0%, rgba(255, 99, 71, 0.10) 5%, rgba(206, 128, 114, 0.12) 12%, rgba(157, 157, 157, 0.15) 20%, rgba(108, 186, 200, 0.18) 28%, rgba(0, 180, 216, 0.20) 36%, rgba(71, 168, 203, 0.18) 44%, rgba(142, 157, 188, 0.15) 52%, rgba(214, 145, 173, 0.12) 60%, rgba(255, 105, 180, 0.10) 68%, rgba(219, 140, 149, 0.12) 76%, rgba(183, 175, 118, 0.15) 84%, rgba(147, 210, 95, 0.10) 92%, rgba(92, 184, 72, 0.07) 100%)"}};
    border-color: rgba(255, 255, 255, 0.4);
    color: white;
    transform: translateY(-3px) scale(1.05);
    box-shadow: 0 10px 25px rgba(144, 179, 167, 0.3);
  }
  
  svg {
    width: 1rem;
    height: 1rem;
  }
`,Bf=w(O.div)`
  text-align: center;
  
  @media (min-width: 1024px) {
    text-align: left;
  }
`,zf=w.h3`
  font-family: ${({theme:e})=>{var i;return((i=e==null?void 0:e.fonts)==null?void 0:i.heading)||'"Playfair Display", serif'}};
  font-size: 1.5rem;
  font-weight: 500;
  margin-bottom: 1.25rem;
  color: white;
  position: relative;
  
  &::after {
    content: '';
    position: absolute;
    left: 0;
    bottom: -0.5rem;
    width: 40px;
    height: 2px;
    background: linear-gradient(135deg, 
      ${({theme:e})=>{var i;return((i=e==null?void 0:e.colors)==null?void 0:i.primary)||"#90B3A7"}} 0%, 
      ${({theme:e})=>{var i;return((i=e==null?void 0:e.colors)==null?void 0:i.secondary)||"#D4A574"}} 100%
    );
  }
  
  @media (max-width: 1023px) {
    text-align: center;
    font-size: 1.3rem;
    
    &::after {
      left: 50%;
      transform: translateX(-50%);
    }
  }
`,sb=w(hi)`
  display: block;
  font-family: ${({theme:e})=>{var i;return((i=e==null?void 0:e.fonts)==null?void 0:i.primary)||"Inter, sans-serif"}};
  font-size: 1.05rem;
  color: rgba(255, 255, 255, 0.8);
  text-decoration: none;
  padding: 0.4rem 0;
  transition: all 0.3s ease;
  
  &:hover {
    color: white;
    transform: translateX(4px);
  }
`,$f=w(O.div)`
  display: flex;
  align-items: flex-start;
  gap: 0.75rem;
  margin-bottom: 1.25rem;
  
  @media (max-width: 1023px) {
    justify-content: center;
    text-align: left;
  }
  
  svg {
    width: 1.1rem;
    height: 1.1rem;
    color: rgba(144, 179, 167, 0.8);
    margin-top: 0.125rem;
    flex-shrink: 0;
  }
`,Nf=w.div`
  font-family: ${({theme:e})=>{var i;return((i=e==null?void 0:e.fonts)==null?void 0:i.primary)||"Inter, sans-serif"}};
  font-size: 1.05rem;
  color: rgba(255, 255, 255, 0.8);
  line-height: 1.5;
`,RC=w.a`
  color: rgba(255, 255, 255, 0.8);
  text-decoration: none;
  transition: color 0.3s ease;
  
  &:hover {
    color: white;
  }
`,kC=w.div`
  padding: 1.5rem 0 1rem 0;
  display: flex;
  flex-direction: column;
  gap: 1rem;
  align-items: center;
  text-align: center;
  
  @media (min-width: 768px) {
    flex-direction: row;
    justify-content: space-between;
    text-align: left;
  }
`,DC=w.p`
  font-family: ${({theme:e})=>{var i;return((i=e==null?void 0:e.fonts)==null?void 0:i.primary)||"Inter, sans-serif"}};
  font-size: 1rem;
  color: rgba(255, 255, 255, 0.6);
  margin: 0;
  
  .highlight {
    color: rgba(144, 179, 167, 0.8);
    font-weight: 500;
  }
`,MC=w.div`
  display: flex;
  gap: 2rem;
  
  a {
    font-family: ${({theme:e})=>{var i;return((i=e==null?void 0:e.fonts)==null?void 0:i.primary)||"Inter, sans-serif"}};
    font-size: 1rem;
    color: rgba(255, 255, 255, 0.6);
    text-decoration: none;
    transition: color 0.3s ease;
    
    &:hover {
      color: rgba(255, 255, 255, 0.8);
    }
  }
`,Lf=w(O.div)`
  position: absolute;
  width: 150px;
  height: 150px;
  border-radius: 50%;
  background: ${({$variant:e})=>{switch(e){case"secondary":return"linear-gradient(135deg, rgba(212, 165, 116, 0.08) 0%, rgba(184, 196, 168, 0.06) 100%)";case"tertiary":return"linear-gradient(135deg, rgba(184, 196, 168, 0.08) 0%, rgba(144, 179, 167, 0.06) 100%)";default:return"linear-gradient(135deg, rgba(144, 179, 167, 0.08) 0%, rgba(212, 165, 116, 0.06) 100%)"}}};
  filter: blur(60px);
  z-index: 2;
  pointer-events: none;
  
  &.deco-1 {
    top: -50px;
    left: 10%;
  }
  
  &.deco-2 {
    top: 30%;
    right: 5%;
  }
  
  &.deco-3 {
    bottom: -50px;
    left: 50%;
    transform: translateX(-50%);
  }
`,BC=()=>{const{t:e}=De(),i={hidden:{opacity:0},visible:{opacity:1,transition:{duration:.8,staggerChildren:.2}}},a={hidden:{opacity:0,y:30},visible:{opacity:1,y:0,transition:{duration:.6,ease:[.25,.46,.45,.94]}}},r={animate:{y:[0,-15,0],transition:{duration:12,repeat:1/0,ease:"easeInOut",repeatType:"mirror"}}},s=new Date().getFullYear(),c=[{path:"/",label:e("navigation.home"),id:"home"},{path:"/restaurant",label:e("navigation.restaurant"),id:"restaurant"},{path:"/spa",label:e("navigation.spa"),id:"spa"},{path:"/sports",label:e("navigation.sports"),id:"sports-main"},{path:"/contacts",label:e("navigation.contacts"),id:"contacts"}],u=[{path:"/spa",label:"Сауна и хаммам",id:"spa-sauna"},{path:"/restaurant",label:"Ресторан",id:"restaurant"},{path:"/sports",label:"Фитнес-центр",id:"sports-fitness"},{path:"/banya",label:"Русская баня",id:"banya"},{path:"/sports",label:"Бойцовский клуб",id:"sports-club"}];return h.jsxs(SC,{children:[h.jsx(Lf,{className:"deco-1",$variant:"primary",variants:r,animate:"animate"}),h.jsx(Lf,{className:"deco-2",$variant:"secondary",variants:r,animate:"animate",style:{animationDelay:"-4s"}}),h.jsx(Lf,{className:"deco-3",$variant:"tertiary",variants:r,animate:"animate",style:{animationDelay:"-8s"}}),h.jsx(TC,{children:h.jsxs(O.div,{variants:i,initial:"hidden",whileInView:"visible",viewport:{once:!0,amount:.3},children:[h.jsxs(jC,{children:[h.jsxs(AC,{variants:a,children:[h.jsx(EC,{src:wC,alt:"KAIF",whileHover:{scale:1.05,transition:{duration:.3,ease:"easeOut"}}}),h.jsx(CC,{children:"Премиальный оздоровительный комплекс на Пхукете. Мы создаем уникальный опыт wellness для восстановления гармонии тела и души."}),h.jsxs(OC,{children:[h.jsx(Mf,{href:"https://facebook.com",target:"_blank",rel:"noopener noreferrer",whileHover:{scale:1.1,transition:{duration:.3,ease:"easeOut"}},whileTap:{scale:.95},children:h.jsx("svg",{fill:"currentColor",viewBox:"0 0 24 24",children:h.jsx("path",{d:"M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"})})}),h.jsx(Mf,{href:"https://instagram.com",target:"_blank",rel:"noopener noreferrer",whileHover:{scale:1.1,transition:{duration:.3,ease:"easeOut"}},whileTap:{scale:.95},children:h.jsx("svg",{fill:"currentColor",viewBox:"0 0 24 24",children:h.jsx("path",{d:"M12.017 0C5.396 0 .029 5.367.029 11.987c0 6.62 5.367 11.987 11.988 11.987 6.62 0 11.987-5.367 11.987-11.987C24.014 5.367 18.637.001 12.017.001zM8.449 16.988c-2.717 0-4.915-2.198-4.915-4.915S5.732 7.158 8.449 7.158s4.915 2.198 4.915 4.915-2.198 4.915-4.915 4.915zm7.44-9.622a1.158 1.158 0 11-2.316 0 1.158 1.158 0 012.316 0z"})})}),h.jsx(Mf,{href:`tel:${e("common.phone_number")}`,whileHover:{scale:1.1,transition:{duration:.3,ease:"easeOut"}},whileTap:{scale:.95},children:h.jsx(Wi,{})})]})]}),h.jsxs(Bf,{variants:a,children:[h.jsx(zf,{children:"Навигация"}),c.map(f=>h.jsx(sb,{to:f.path,children:f.label},f.id))]}),h.jsxs(Bf,{variants:a,children:[h.jsx(zf,{children:"Услуги"}),u.map(f=>h.jsx(sb,{to:f.path,children:f.label},f.id))]}),h.jsxs(Bf,{variants:a,children:[h.jsx(zf,{children:"Контакты"}),h.jsxs($f,{children:[h.jsx(S2,{}),h.jsx(Nf,{children:e("common.address")})]}),h.jsxs($f,{children:[h.jsx(Wi,{}),h.jsx(Nf,{children:h.jsx(RC,{href:`tel:${e("common.phone_number")}`,children:e("common.phone_number")})})]}),h.jsxs($f,{children:[h.jsx(Tr,{}),h.jsxs(Nf,{children:["Ежедневно",h.jsx("br",{}),"7:00 - 22:00"]})]})]})]}),h.jsxs(kC,{children:[h.jsxs(DC,{children:["© ",s," ",h.jsx("span",{className:"highlight",children:"KAIF"}),". Все права защищены."]}),h.jsxs(MC,{children:[h.jsx("a",{href:"/privacy",children:"Политика конфиденциальности"}),h.jsx("a",{href:"/terms",children:"Условия использования"})]})]})]})})]})};var _f={exports:{}},Hf,lb;function zC(){if(lb)return Hf;lb=1;var e="SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";return Hf=e,Hf}var Vf,cb;function $C(){if(cb)return Vf;cb=1;var e=zC();function i(){}function a(){}return a.resetWarningCache=i,Vf=function(){function r(u,f,p,m,y,x){if(x!==e){var b=new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");throw b.name="Invariant Violation",b}}r.isRequired=r;function s(){return r}var c={array:r,bigint:r,bool:r,func:r,number:r,object:r,string:r,symbol:r,any:r,arrayOf:s,element:r,elementType:r,instanceOf:s,node:r,objectOf:s,oneOf:s,oneOfType:s,shape:s,exact:s,checkPropTypes:a,resetWarningCache:i};return c.PropTypes=c,c},Vf}var ub;function NC(){return ub||(ub=1,_f.exports=$C()()),_f.exports}var LC=NC();const Fe=jr(LC);var Pf,db;function _C(){if(db)return Pf;db=1;function e(f){return f&&typeof f=="object"&&"default"in f?f.default:f}var i=Rc(),a=e(i);function r(f,p,m){return p in f?Object.defineProperty(f,p,{value:m,enumerable:!0,configurable:!0,writable:!0}):f[p]=m,f}function s(f,p){f.prototype=Object.create(p.prototype),f.prototype.constructor=f,f.__proto__=p}var c=!!(typeof window<"u"&&window.document&&window.document.createElement);function u(f,p,m){if(typeof f!="function")throw new Error("Expected reducePropsToState to be a function.");if(typeof p!="function")throw new Error("Expected handleStateChangeOnClient to be a function.");if(typeof m<"u"&&typeof m!="function")throw new Error("Expected mapStateOnServer to either be undefined or a function.");function y(x){return x.displayName||x.name||"Component"}return function(b){if(typeof b!="function")throw new Error("Expected WrappedComponent to be a React component.");var T=[],A;function C(){A=f(T.map(function(E){return E.props})),B.canUseDOM?p(A):m&&(A=m(A))}var B=function(E){s(k,E);function k(){return E.apply(this,arguments)||this}k.peek=function(){return A},k.rewind=function(){if(k.canUseDOM)throw new Error("You may only call rewind() on the server. Call peek() to read the current state.");var D=A;return A=void 0,T=[],D};var M=k.prototype;return M.UNSAFE_componentWillMount=function(){T.push(this),C()},M.componentDidUpdate=function(){C()},M.componentWillUnmount=function(){var D=T.indexOf(this);T.splice(D,1),C()},M.render=function(){return a.createElement(b,this.props)},k}(i.PureComponent);return r(B,"displayName","SideEffect("+y(b)+")"),r(B,"canUseDOM",c),B}}return Pf=u,Pf}var HC=_C();const VC=jr(HC);var Ff,fb;function PC(){if(fb)return Ff;fb=1;var e=typeof Element<"u",i=typeof Map=="function",a=typeof Set=="function",r=typeof ArrayBuffer=="function"&&!!ArrayBuffer.isView;function s(c,u){if(c===u)return!0;if(c&&u&&typeof c=="object"&&typeof u=="object"){if(c.constructor!==u.constructor)return!1;var f,p,m;if(Array.isArray(c)){if(f=c.length,f!=u.length)return!1;for(p=f;p--!==0;)if(!s(c[p],u[p]))return!1;return!0}var y;if(i&&c instanceof Map&&u instanceof Map){if(c.size!==u.size)return!1;for(y=c.entries();!(p=y.next()).done;)if(!u.has(p.value[0]))return!1;for(y=c.entries();!(p=y.next()).done;)if(!s(p.value[1],u.get(p.value[0])))return!1;return!0}if(a&&c instanceof Set&&u instanceof Set){if(c.size!==u.size)return!1;for(y=c.entries();!(p=y.next()).done;)if(!u.has(p.value[0]))return!1;return!0}if(r&&ArrayBuffer.isView(c)&&ArrayBuffer.isView(u)){if(f=c.length,f!=u.length)return!1;for(p=f;p--!==0;)if(c[p]!==u[p])return!1;return!0}if(c.constructor===RegExp)return c.source===u.source&&c.flags===u.flags;if(c.valueOf!==Object.prototype.valueOf&&typeof c.valueOf=="function"&&typeof u.valueOf=="function")return c.valueOf()===u.valueOf();if(c.toString!==Object.prototype.toString&&typeof c.toString=="function"&&typeof u.toString=="function")return c.toString()===u.toString();if(m=Object.keys(c),f=m.length,f!==Object.keys(u).length)return!1;for(p=f;p--!==0;)if(!Object.prototype.hasOwnProperty.call(u,m[p]))return!1;if(e&&c instanceof Element)return!1;for(p=f;p--!==0;)if(!((m[p]==="_owner"||m[p]==="__v"||m[p]==="__o")&&c.$$typeof)&&!s(c[m[p]],u[m[p]]))return!1;return!0}return c!==c&&u!==u}return Ff=function(u,f){try{return s(u,f)}catch(p){if((p.message||"").match(/stack|recursion/i))return console.warn("react-fast-compare cannot handle circular refs"),!1;throw p}},Ff}var FC=PC();const UC=jr(FC);/*
object-assign
(c) Sindre Sorhus
@license MIT
*/var Uf,hb;function qC(){if(hb)return Uf;hb=1;var e=Object.getOwnPropertySymbols,i=Object.prototype.hasOwnProperty,a=Object.prototype.propertyIsEnumerable;function r(c){if(c==null)throw new TypeError("Object.assign cannot be called with null or undefined");return Object(c)}function s(){try{if(!Object.assign)return!1;var c=new String("abc");if(c[5]="de",Object.getOwnPropertyNames(c)[0]==="5")return!1;for(var u={},f=0;f<10;f++)u["_"+String.fromCharCode(f)]=f;var p=Object.getOwnPropertyNames(u).map(function(y){return u[y]});if(p.join("")!=="0123456789")return!1;var m={};return"abcdefghijklmnopqrst".split("").forEach(function(y){m[y]=y}),Object.keys(Object.assign({},m)).join("")==="abcdefghijklmnopqrst"}catch{return!1}}return Uf=s()?Object.assign:function(c,u){for(var f,p=r(c),m,y=1;y<arguments.length;y++){f=Object(arguments[y]);for(var x in f)i.call(f,x)&&(p[x]=f[x]);if(e){m=e(f);for(var b=0;b<m.length;b++)a.call(f,m[b])&&(p[m[b]]=f[m[b]])}}return p},Uf}var IC=qC();const YC=jr(IC);var sa={BODY:"bodyAttributes",HTML:"htmlAttributes",TITLE:"titleAttributes"},pe={BASE:"base",BODY:"body",HEAD:"head",HTML:"html",LINK:"link",META:"meta",NOSCRIPT:"noscript",SCRIPT:"script",STYLE:"style",TITLE:"title"};Object.keys(pe).map(function(e){return pe[e]});var Ue={CHARSET:"charset",CSS_TEXT:"cssText",HREF:"href",HTTPEQUIV:"http-equiv",INNER_HTML:"innerHTML",ITEM_PROP:"itemprop",NAME:"name",PROPERTY:"property",REL:"rel",SRC:"src",TARGET:"target"},jc={accesskey:"accessKey",charset:"charSet",class:"className",contenteditable:"contentEditable",contextmenu:"contextMenu","http-equiv":"httpEquiv",itemprop:"itemProp",tabindex:"tabIndex"},ms={DEFAULT_TITLE:"defaultTitle",DEFER:"defer",ENCODE_SPECIAL_CHARACTERS:"encodeSpecialCharacters",ON_CHANGE_CLIENT_STATE:"onChangeClientState",TITLE_TEMPLATE:"titleTemplate"},GC=Object.keys(jc).reduce(function(e,i){return e[jc[i]]=i,e},{}),KC=[pe.NOSCRIPT,pe.SCRIPT,pe.STYLE],li="data-react-helmet",XC=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(e){return typeof e}:function(e){return e&&typeof Symbol=="function"&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},ZC=function(e,i){if(!(e instanceof i))throw new TypeError("Cannot call a class as a function")},QC=function(){function e(i,a){for(var r=0;r<a.length;r++){var s=a[r];s.enumerable=s.enumerable||!1,s.configurable=!0,"value"in s&&(s.writable=!0),Object.defineProperty(i,s.key,s)}}return function(i,a,r){return a&&e(i.prototype,a),r&&e(i,r),i}}(),kt=Object.assign||function(e){for(var i=1;i<arguments.length;i++){var a=arguments[i];for(var r in a)Object.prototype.hasOwnProperty.call(a,r)&&(e[r]=a[r])}return e},JC=function(e,i){if(typeof i!="function"&&i!==null)throw new TypeError("Super expression must either be null or a function, not "+typeof i);e.prototype=Object.create(i&&i.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),i&&(Object.setPrototypeOf?Object.setPrototypeOf(e,i):e.__proto__=i)},pb=function(e,i){var a={};for(var r in e)i.indexOf(r)>=0||Object.prototype.hasOwnProperty.call(e,r)&&(a[r]=e[r]);return a},WC=function(e,i){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return i&&(typeof i=="object"||typeof i=="function")?i:e},Xh=function(i){var a=arguments.length>1&&arguments[1]!==void 0?arguments[1]:!0;return a===!1?String(i):String(i).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#x27;")},eO=function(i){var a=pr(i,pe.TITLE),r=pr(i,ms.TITLE_TEMPLATE);if(r&&a)return r.replace(/%s/g,function(){return Array.isArray(a)?a.join(""):a});var s=pr(i,ms.DEFAULT_TITLE);return a||s||void 0},tO=function(i){return pr(i,ms.ON_CHANGE_CLIENT_STATE)||function(){}},qf=function(i,a){return a.filter(function(r){return typeof r[i]<"u"}).map(function(r){return r[i]}).reduce(function(r,s){return kt({},r,s)},{})},iO=function(i,a){return a.filter(function(r){return typeof r[pe.BASE]<"u"}).map(function(r){return r[pe.BASE]}).reverse().reduce(function(r,s){if(!r.length)for(var c=Object.keys(s),u=0;u<c.length;u++){var f=c[u],p=f.toLowerCase();if(i.indexOf(p)!==-1&&s[p])return r.concat(s)}return r},[])},Vo=function(i,a,r){var s={};return r.filter(function(c){return Array.isArray(c[i])?!0:(typeof c[i]<"u"&&oO("Helmet: "+i+' should be of type "Array". Instead found type "'+XC(c[i])+'"'),!1)}).map(function(c){return c[i]}).reverse().reduce(function(c,u){var f={};u.filter(function(b){for(var T=void 0,A=Object.keys(b),C=0;C<A.length;C++){var B=A[C],E=B.toLowerCase();a.indexOf(E)!==-1&&!(T===Ue.REL&&b[T].toLowerCase()==="canonical")&&!(E===Ue.REL&&b[E].toLowerCase()==="stylesheet")&&(T=E),a.indexOf(B)!==-1&&(B===Ue.INNER_HTML||B===Ue.CSS_TEXT||B===Ue.ITEM_PROP)&&(T=B)}if(!T||!b[T])return!1;var k=b[T].toLowerCase();return s[T]||(s[T]={}),f[T]||(f[T]={}),s[T][k]?!1:(f[T][k]=!0,!0)}).reverse().forEach(function(b){return c.push(b)});for(var p=Object.keys(f),m=0;m<p.length;m++){var y=p[m],x=YC({},s[y],f[y]);s[y]=x}return c},[]).reverse()},pr=function(i,a){for(var r=i.length-1;r>=0;r--){var s=i[r];if(s.hasOwnProperty(a))return s[a]}return null},nO=function(i){return{baseTag:iO([Ue.HREF,Ue.TARGET],i),bodyAttributes:qf(sa.BODY,i),defer:pr(i,ms.DEFER),encode:pr(i,ms.ENCODE_SPECIAL_CHARACTERS),htmlAttributes:qf(sa.HTML,i),linkTags:Vo(pe.LINK,[Ue.REL,Ue.HREF],i),metaTags:Vo(pe.META,[Ue.NAME,Ue.CHARSET,Ue.HTTPEQUIV,Ue.PROPERTY,Ue.ITEM_PROP],i),noscriptTags:Vo(pe.NOSCRIPT,[Ue.INNER_HTML],i),onChangeClientState:tO(i),scriptTags:Vo(pe.SCRIPT,[Ue.SRC,Ue.INNER_HTML],i),styleTags:Vo(pe.STYLE,[Ue.CSS_TEXT],i),title:eO(i),titleAttributes:qf(sa.TITLE,i)}},Zh=function(){var e=Date.now();return function(i){var a=Date.now();a-e>16?(e=a,i(a)):setTimeout(function(){Zh(i)},0)}}(),mb=function(i){return clearTimeout(i)},aO=typeof window<"u"?window.requestAnimationFrame&&window.requestAnimationFrame.bind(window)||window.webkitRequestAnimationFrame||window.mozRequestAnimationFrame||Zh:global.requestAnimationFrame||Zh,rO=typeof window<"u"?window.cancelAnimationFrame||window.webkitCancelAnimationFrame||window.mozCancelAnimationFrame||mb:global.cancelAnimationFrame||mb,oO=function(i){return console&&typeof console.warn=="function"&&console.warn(i)},Po=null,sO=function(i){Po&&rO(Po),i.defer?Po=aO(function(){gb(i,function(){Po=null})}):(gb(i),Po=null)},gb=function(i,a){var r=i.baseTag,s=i.bodyAttributes,c=i.htmlAttributes,u=i.linkTags,f=i.metaTags,p=i.noscriptTags,m=i.onChangeClientState,y=i.scriptTags,x=i.styleTags,b=i.title,T=i.titleAttributes;Qh(pe.BODY,s),Qh(pe.HTML,c),lO(b,T);var A={baseTag:tr(pe.BASE,r),linkTags:tr(pe.LINK,u),metaTags:tr(pe.META,f),noscriptTags:tr(pe.NOSCRIPT,p),scriptTags:tr(pe.SCRIPT,y),styleTags:tr(pe.STYLE,x)},C={},B={};Object.keys(A).forEach(function(E){var k=A[E],M=k.newTags,F=k.oldTags;M.length&&(C[E]=M),F.length&&(B[E]=A[E].oldTags)}),a&&a(),m(i,C,B)},T2=function(i){return Array.isArray(i)?i.join(""):i},lO=function(i,a){typeof i<"u"&&document.title!==i&&(document.title=T2(i)),Qh(pe.TITLE,a)},Qh=function(i,a){var r=document.getElementsByTagName(i)[0];if(r){for(var s=r.getAttribute(li),c=s?s.split(","):[],u=[].concat(c),f=Object.keys(a),p=0;p<f.length;p++){var m=f[p],y=a[m]||"";r.getAttribute(m)!==y&&r.setAttribute(m,y),c.indexOf(m)===-1&&c.push(m);var x=u.indexOf(m);x!==-1&&u.splice(x,1)}for(var b=u.length-1;b>=0;b--)r.removeAttribute(u[b]);c.length===u.length?r.removeAttribute(li):r.getAttribute(li)!==f.join(",")&&r.setAttribute(li,f.join(","))}},tr=function(i,a){var r=document.head||document.querySelector(pe.HEAD),s=r.querySelectorAll(i+"["+li+"]"),c=Array.prototype.slice.call(s),u=[],f=void 0;return a&&a.length&&a.forEach(function(p){var m=document.createElement(i);for(var y in p)if(p.hasOwnProperty(y))if(y===Ue.INNER_HTML)m.innerHTML=p.innerHTML;else if(y===Ue.CSS_TEXT)m.styleSheet?m.styleSheet.cssText=p.cssText:m.appendChild(document.createTextNode(p.cssText));else{var x=typeof p[y]>"u"?"":p[y];m.setAttribute(y,x)}m.setAttribute(li,"true"),c.some(function(b,T){return f=T,m.isEqualNode(b)})?c.splice(f,1):u.push(m)}),c.forEach(function(p){return p.parentNode.removeChild(p)}),u.forEach(function(p){return r.appendChild(p)}),{oldTags:c,newTags:u}},j2=function(i){return Object.keys(i).reduce(function(a,r){var s=typeof i[r]<"u"?r+'="'+i[r]+'"':""+r;return a?a+" "+s:s},"")},cO=function(i,a,r,s){var c=j2(r),u=T2(a);return c?"<"+i+" "+li+'="true" '+c+">"+Xh(u,s)+"</"+i+">":"<"+i+" "+li+'="true">'+Xh(u,s)+"</"+i+">"},uO=function(i,a,r){return a.reduce(function(s,c){var u=Object.keys(c).filter(function(m){return!(m===Ue.INNER_HTML||m===Ue.CSS_TEXT)}).reduce(function(m,y){var x=typeof c[y]>"u"?y:y+'="'+Xh(c[y],r)+'"';return m?m+" "+x:x},""),f=c.innerHTML||c.cssText||"",p=KC.indexOf(i)===-1;return s+"<"+i+" "+li+'="true" '+u+(p?"/>":">"+f+"</"+i+">")},"")},A2=function(i){var a=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{};return Object.keys(i).reduce(function(r,s){return r[jc[s]||s]=i[s],r},a)},dO=function(i){var a=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{};return Object.keys(i).reduce(function(r,s){return r[GC[s]||s]=i[s],r},a)},fO=function(i,a,r){var s,c=(s={key:a},s[li]=!0,s),u=A2(r,c);return[Ce.createElement(pe.TITLE,u,a)]},hO=function(i,a){return a.map(function(r,s){var c,u=(c={key:s},c[li]=!0,c);return Object.keys(r).forEach(function(f){var p=jc[f]||f;if(p===Ue.INNER_HTML||p===Ue.CSS_TEXT){var m=r.innerHTML||r.cssText;u.dangerouslySetInnerHTML={__html:m}}else u[p]=r[f]}),Ce.createElement(i,u)})},Ii=function(i,a,r){switch(i){case pe.TITLE:return{toComponent:function(){return fO(i,a.title,a.titleAttributes)},toString:function(){return cO(i,a.title,a.titleAttributes,r)}};case sa.BODY:case sa.HTML:return{toComponent:function(){return A2(a)},toString:function(){return j2(a)}};default:return{toComponent:function(){return hO(i,a)},toString:function(){return uO(i,a,r)}}}},E2=function(i){var a=i.baseTag,r=i.bodyAttributes,s=i.encode,c=i.htmlAttributes,u=i.linkTags,f=i.metaTags,p=i.noscriptTags,m=i.scriptTags,y=i.styleTags,x=i.title,b=x===void 0?"":x,T=i.titleAttributes;return{base:Ii(pe.BASE,a,s),bodyAttributes:Ii(sa.BODY,r,s),htmlAttributes:Ii(sa.HTML,c,s),link:Ii(pe.LINK,u,s),meta:Ii(pe.META,f,s),noscript:Ii(pe.NOSCRIPT,p,s),script:Ii(pe.SCRIPT,m,s),style:Ii(pe.STYLE,y,s),title:Ii(pe.TITLE,{title:b,titleAttributes:T},s)}},pO=function(i){var a,r;return r=a=function(s){JC(c,s);function c(){return ZC(this,c),WC(this,s.apply(this,arguments))}return c.prototype.shouldComponentUpdate=function(f){return!UC(this.props,f)},c.prototype.mapNestedChildrenToProps=function(f,p){if(!p)return null;switch(f.type){case pe.SCRIPT:case pe.NOSCRIPT:return{innerHTML:p};case pe.STYLE:return{cssText:p}}throw new Error("<"+f.type+" /> elements are self-closing and can not contain children. Refer to our API for more information.")},c.prototype.flattenArrayTypeChildren=function(f){var p,m=f.child,y=f.arrayTypeChildren,x=f.newChildProps,b=f.nestedChildren;return kt({},y,(p={},p[m.type]=[].concat(y[m.type]||[],[kt({},x,this.mapNestedChildrenToProps(m,b))]),p))},c.prototype.mapObjectTypeChildren=function(f){var p,m,y=f.child,x=f.newProps,b=f.newChildProps,T=f.nestedChildren;switch(y.type){case pe.TITLE:return kt({},x,(p={},p[y.type]=T,p.titleAttributes=kt({},b),p));case pe.BODY:return kt({},x,{bodyAttributes:kt({},b)});case pe.HTML:return kt({},x,{htmlAttributes:kt({},b)})}return kt({},x,(m={},m[y.type]=kt({},b),m))},c.prototype.mapArrayTypeChildrenToProps=function(f,p){var m=kt({},p);return Object.keys(f).forEach(function(y){var x;m=kt({},m,(x={},x[y]=f[y],x))}),m},c.prototype.warnOnInvalidChildren=function(f,p){return!0},c.prototype.mapChildrenToProps=function(f,p){var m=this,y={};return Ce.Children.forEach(f,function(x){if(!(!x||!x.props)){var b=x.props,T=b.children,A=pb(b,["children"]),C=dO(A);switch(m.warnOnInvalidChildren(x,T),x.type){case pe.LINK:case pe.META:case pe.NOSCRIPT:case pe.SCRIPT:case pe.STYLE:y=m.flattenArrayTypeChildren({child:x,arrayTypeChildren:y,newChildProps:C,nestedChildren:T});break;default:p=m.mapObjectTypeChildren({child:x,newProps:p,newChildProps:C,nestedChildren:T});break}}}),p=this.mapArrayTypeChildrenToProps(y,p),p},c.prototype.render=function(){var f=this.props,p=f.children,m=pb(f,["children"]),y=kt({},m);return p&&(y=this.mapChildrenToProps(p,y)),Ce.createElement(i,y)},QC(c,null,[{key:"canUseDOM",set:function(f){i.canUseDOM=f}}]),c}(Ce.Component),a.propTypes={base:Fe.object,bodyAttributes:Fe.object,children:Fe.oneOfType([Fe.arrayOf(Fe.node),Fe.node]),defaultTitle:Fe.string,defer:Fe.bool,encodeSpecialCharacters:Fe.bool,htmlAttributes:Fe.object,link:Fe.arrayOf(Fe.object),meta:Fe.arrayOf(Fe.object),noscript:Fe.arrayOf(Fe.object),onChangeClientState:Fe.func,script:Fe.arrayOf(Fe.object),style:Fe.arrayOf(Fe.object),title:Fe.string,titleAttributes:Fe.object,titleTemplate:Fe.string},a.defaultProps={defer:!0,encodeSpecialCharacters:!0},a.peek=i.peek,a.rewind=function(){var s=i.rewind();return s||(s=E2({baseTag:[],bodyAttributes:{},htmlAttributes:{},linkTags:[],metaTags:[],noscriptTags:[],scriptTags:[],styleTags:[],title:"",titleAttributes:{}})),s},r},mO=function(){return null},gO=VC(nO,sO,E2)(mO),Jh=pO(gO);Jh.renderStatic=Jh.rewind;const yO=({title:e="KAIF | Премиальный велнес-центр в Пхукете"})=>h.jsxs(Jh,{children:[h.jsx("title",{children:e}),h.jsx("link",{rel:"shortcut icon",type:"image/png",href:"/favicon.png"}),h.jsx("link",{rel:"icon",type:"image/png",href:"/favicon.png"}),h.jsx("meta",{name:"theme-color",content:"#2C614F"})]}),xO=w.div`
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  height: 100%;
  background: transparent;
  margin: 0;
  padding: 0;
  flex: 1;
`,bO=w.main`
  flex: 1;
  padding-top: 4rem;
  display: flex;
  flex-direction: column;
  width: 100%;
  will-change: opacity, transform;
  background: transparent;
  margin: 0;
  padding-bottom: 0;
  
  @media (min-width: 768px) {
    padding-top: 4.5rem;
  }
  
  @media (min-width: 1024px) {
    padding-top: 5rem;
  }
`,vO=({children:e})=>{const i=fi();return S.useEffect(()=>{window.scrollTo(0,0)},[i.pathname]),h.jsxs(xO,{children:[h.jsx(yO,{}),h.jsx(GE,{}),h.jsx(bO,{children:e}),h.jsx(BC,{})]})},wO="/assets/hero-spa-DTdp7JL8.jpg",SO="/assets/hero-pool-D1w69rNO.jpg",TO="/assets/hero-restaurant-B-WOCk0r.jpg",jO="/assets/hero-fitness-C8kFY2Cm.jpg",AO="/assets/hero-luxury-CYZ2FLIl.png",EO="/assets/logo-homepage-Yn4-hFZp.png",yb=[wO,SO,TO,jO],CO=w.section`
  position: relative;
  width: 100%;
  height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  color: white;
  overflow: hidden;
  background: #000;
`,OO=w.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 1;
`,RO=w.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  opacity: ${e=>e.$active?1:0};
  transition: opacity 2s ease-in-out;
  
  &::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(
      135deg,
      rgba(0,0,0,0.65) 0%,
      rgba(0,0,0,0.45) 50%,
      rgba(0,0,0,0.55) 100%
    );
    z-index: 2;
  }
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center;
    filter: brightness(0.8) contrast(1.1) saturate(0.9);
  }
`,kO=w.div`
  position: relative;
  z-index: 10;
  text-align: center;
  padding: 3rem 2rem;
  max-width: 800px;
  margin: 0 auto;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  width: 100%;
  
  @media (max-width: 768px) {
    padding: 2rem 1.5rem;
    max-width: 90%;
  }
  
  @media (max-width: 480px) {
    padding: 1.5rem 1rem;
    max-width: 95%;
  }
`,DO=w(O.img)`
  max-width: 480px;
  height: auto;
  margin: 0 auto 3rem;
  display: block;
  filter: 
    drop-shadow(0 25px 80px rgba(0, 0, 0, 0.9))
    drop-shadow(0 10px 30px rgba(0, 0, 0, 0.7));
  
  @media (max-width: 768px) {
    max-width: 380px;
    margin: 0 auto 2.5rem;
  }
  
  @media (max-width: 480px) {
    max-width: 340px;
    margin: 0 auto 2rem;
  }
`,MO=w(O.h1)`
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  font-size: clamp(1.3rem, 3.5vw, 1.9rem);
  font-weight: 300;
  color: rgba(255, 255, 255, 0.95);
  margin: 0 0 4rem;
  text-shadow: 
    0 6px 25px rgba(0, 0, 0, 0.9),
    0 2px 8px rgba(0, 0, 0, 0.8);
  letter-spacing: 0.05em;
  line-height: 1.4;
  max-width: 600px;
  
  @media (max-width: 768px) {
    margin: 0 0 3.5rem;
    font-size: clamp(1.2rem, 4vw, 1.6rem);
  }
  
  @media (max-width: 480px) {
    margin: 0 0 3rem;
    letter-spacing: 0.03em;
  }
`,BO=w(O(hi))`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 1.2rem 3rem;
  font-size: 0.9rem;
  font-weight: 500;
  letter-spacing: 0.1em;
  text-decoration: none;
  text-transform: uppercase;
  color: #000;
  background: rgba(255, 255, 255, 0.95);
  border: none;
  border-radius: 12px;
  backdrop-filter: blur(10px);
  transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  position: relative;
  overflow: hidden;
  min-width: 220px;
  box-shadow: 
    0 8px 25px rgba(0, 0, 0, 0.3),
    0 15px 50px rgba(0, 0, 0, 0.2);
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(
      90deg, 
      transparent, 
      rgba(0, 0, 0, 0.05), 
      transparent
    );
    transition: left 0.6s ease;
  }
  
  &:hover {
    background: rgba(255, 255, 255, 1);
    transform: translateY(-2px);
    box-shadow: 
      0 12px 35px rgba(0, 0, 0, 0.4),
      0 20px 60px rgba(0, 0, 0, 0.25);
    color: #000;
    text-decoration: none;
    
    &::before {
      left: 100%;
    }
  }
  
  &:active {
    transform: translateY(-1px);
  }
  
  @media (max-width: 768px) {
    padding: 1.1rem 2.5rem;
    font-size: 0.85rem;
    min-width: 200px;
  }
  
  @media (max-width: 480px) {
    padding: 1rem 2rem;
    font-size: 0.8rem;
    min-width: 180px;
    width: 100%;
    max-width: 300px;
  }
`,zO=w(O(hi))`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 1.2rem 3rem;
  font-size: 0.9rem;
  font-weight: 300;
  letter-spacing: 0.1em;
  text-decoration: none;
  text-transform: uppercase;
  color: rgba(255, 255, 255, 0.8);
  background: transparent;
  border: 1px solid rgba(255, 255, 255, 0.25);
  border-radius: 12px;
  transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  position: relative;
  min-width: 220px;
  margin-top: 1.2rem;
  
  &:hover {
    color: rgba(255, 255, 255, 1);
    border-color: rgba(255, 255, 255, 0.6);
    background: rgba(255, 255, 255, 0.08);
    transform: translateY(-1px);
    box-shadow: 0 8px 25px rgba(255, 255, 255, 0.1);
    text-decoration: none;
  }
  
  &:active {
    transform: translateY(0);
  }
  
  @media (max-width: 768px) {
    padding: 1.1rem 2.5rem;
    font-size: 0.85rem;
    min-width: 200px;
  }
  
  @media (max-width: 480px) {
    padding: 1rem 2rem;
    font-size: 0.8rem;
    min-width: 180px;
    width: 100%;
    max-width: 300px;
    margin-top: 1rem;
  }
`,$O=w.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0;
  
  @media (max-width: 480px) {
    width: 100%;
    max-width: 320px;
  }
`,ir={logo:{initial:{scale:.85,opacity:0,y:30},animate:{scale:1,opacity:1,y:0,transition:{duration:1.4,ease:[.25,.46,.45,.94],delay:.6}}},title:{initial:{opacity:0,y:25},animate:{opacity:1,y:0,transition:{duration:1.1,ease:[.25,.46,.45,.94],delay:1.3}}},buttons:{initial:{opacity:0,y:25},animate:{opacity:1,y:0,transition:{duration:.9,ease:[.25,.46,.45,.94],delay:1.9}}}},NO=()=>{const{t:e}=De(),[i,a]=S.useState(0);return S.useEffect(()=>{const r=setInterval(()=>{a(s=>(s+1)%yb.length)},8e3);return()=>clearInterval(r)},[]),h.jsxs(CO,{children:[h.jsx(OO,{children:yb.map((r,s)=>h.jsx(RO,{$active:s===i,children:h.jsx("img",{src:r,alt:`KAIF - Слайд ${s+1}`,loading:"lazy",onError:c=>{const u=["https://images.unsplash.com/photo-1544161515-4ab6ce6db874?ixlib=rb-4.0.3&auto=format&fit=crop&w=1400&q=85","https://images.unsplash.com/photo-1600334129128-685c5582fd35?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80","https://images.unsplash.com/photo-1519823551278-64ac92734fb1?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80","https://images.unsplash.com/photo-1515377905703-c4788e51af15?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"];c.target.src=u[s%u.length]}})},`slide-${s}`))}),h.jsxs(kO,{children:[h.jsx(DO,{src:EO,alt:"KAIF",initial:ir.logo.initial,animate:ir.logo.animate,whileHover:{scale:1.03,transition:{duration:.3,ease:[.25,.46,.45,.94]}}}),h.jsx(MO,{as:O.h1,initial:ir.title.initial,animate:ir.title.animate,children:"Премиальный комплекс на Пхукете"}),h.jsxs($O,{as:O.div,initial:ir.buttons.initial,animate:ir.buttons.animate,children:[h.jsx(BO,{to:"/contacts",whileHover:{scale:1.03,transition:{duration:.2,ease:[.25,.46,.45,.94]}},whileTap:{scale:.97},children:"Записаться"}),h.jsx(zO,{to:"/sports",whileHover:{scale:1.02,transition:{duration:.2,ease:[.25,.46,.45,.94]}},whileTap:{scale:.98},children:"Узнать больше"})]})]})]})};function LO({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:1.5,stroke:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M17.25 8.25 21 12m0 0-3.75 3.75M21 12H3"}))}const C2=S.forwardRef(LO);function _O({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:1.5,stroke:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3"}))}const HO=S.forwardRef(_O);function VO({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:1.5,stroke:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M13.5 6H5.25A2.25 2.25 0 0 0 3 8.25v10.5A2.25 2.25 0 0 0 5.25 21h10.5A2.25 2.25 0 0 0 18 18.75V10.5m-10.5 6L21 3m0 0h-5.25M21 3v5.25"}))}const If=S.forwardRef(VO);function PO({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:1.5,stroke:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"m3.75 13.5 10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75Z"}))}const xb=S.forwardRef(PO);function FO({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:1.5,stroke:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 0 1 2.25-2.25h13.5A2.25 2.25 0 0 1 21 7.5v11.25m-18 0A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75m-18 0v-7.5A2.25 2.25 0 0 1 5.25 9h13.5A2.25 2.25 0 0 1 21 11.25v7.5"}))}const Il=S.forwardRef(FO);function UO({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:1.5,stroke:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M15.75 19.5 8.25 12l7.5-7.5"}))}const bb=S.forwardRef(UO);function qO({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:1.5,stroke:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"m8.25 4.5 7.5 7.5-7.5 7.5"}))}const Wh=S.forwardRef(qO);function IO({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:1.5,stroke:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M12 6v6h4.5m4.5 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"}))}const sc=S.forwardRef(IO);function YO({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:1.5,stroke:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M21.75 6.75v10.5a2.25 2.25 0 0 1-2.25 2.25h-15a2.25 2.25 0 0 1-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0 0 19.5 4.5h-15a2.25 2.25 0 0 0-2.25 2.25m19.5 0v.243a2.25 2.25 0 0 1-1.07 1.916l-7.5 4.615a2.25 2.25 0 0 1-2.36 0L3.32 8.91a2.25 2.25 0 0 1-1.07-1.916V6.75"}))}const GO=S.forwardRef(YO);function KO({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:1.5,stroke:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M12 21a9.004 9.004 0 0 0 8.716-6.747M12 21a9.004 9.004 0 0 1-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 0 1 7.843 4.582M12 3a8.997 8.997 0 0 0-7.843 4.582m15.686 0A11.953 11.953 0 0 1 12 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0 1 21 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0 1 12 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 0 1 3 12c0-1.605.42-3.113 1.157-4.418"}))}const XO=S.forwardRef(KO);function ZO({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:1.5,stroke:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12Z"}))}const QO=S.forwardRef(ZO);function JO({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:1.5,stroke:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M15 10.5a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"}),S.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1 1 15 0Z"}))}const WO=S.forwardRef(JO);function eR({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:1.5,stroke:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 0 0 2.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 0 1-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 0 0-1.091-.852H4.5A2.25 2.25 0 0 0 2.25 4.5v2.25Z"}))}const tR=S.forwardRef(eR);function iR({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:1.5,stroke:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M9.813 15.904 9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 0 0-3.09 3.09ZM18.259 8.715 18 9.75l-.259-1.035a3.375 3.375 0 0 0-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 0 0 2.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 0 0 2.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 0 0-2.456 2.456ZM16.894 20.567 16.5 21.75l-.394-1.183a2.25 2.25 0 0 0-1.423-1.423L13.5 18.75l1.183-.394a2.25 2.25 0 0 0 1.423-1.423l.394-1.183.394 1.183a2.25 2.25 0 0 0 1.423 1.423l1.183.394-1.183.394a2.25 2.25 0 0 0-1.423 1.423Z"}))}const Ut=S.forwardRef(iR);function nR({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:1.5,stroke:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M11.48 3.499a.562.562 0 0 1 1.04 0l2.125 5.111a.563.563 0 0 0 .475.345l5.518.442c.499.04.701.663.321.988l-4.204 3.602a.563.563 0 0 0-.182.557l1.285 5.385a.562.562 0 0 1-.84.61l-4.725-2.885a.562.562 0 0 0-.586 0L6.982 20.54a.562.562 0 0 1-.84-.61l1.285-5.386a.562.562 0 0 0-.182-.557l-4.204-3.602a.562.562 0 0 1 .321-.988l5.518-.442a.563.563 0 0 0 .475-.345L11.48 3.5Z"}))}const aR=S.forwardRef(nR);function rR({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:1.5,stroke:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M18 18.72a9.094 9.094 0 0 0 3.741-.479 3 3 0 0 0-4.682-2.72m.94 3.198.001.031c0 .225-.012.447-.037.666A11.944 11.944 0 0 1 12 21c-2.17 0-4.207-.576-5.963-1.584A6.062 6.062 0 0 1 6 18.719m12 0a5.971 5.971 0 0 0-.941-3.197m0 0A5.995 5.995 0 0 0 12 12.75a5.995 5.995 0 0 0-5.058 2.772m0 0a3 3 0 0 0-4.681 2.72 8.986 8.986 0 0 0 3.74.477m.94-3.197a5.971 5.971 0 0 0-.94 3.197M15 6.75a3 3 0 1 1-6 0 3 3 0 0 1 6 0Zm6 3a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0Zm-13.5 0a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0Z"}))}const lc=S.forwardRef(rR);function oR({title:e,titleId:i,...a},r){return S.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:1.5,stroke:"currentColor","aria-hidden":"true","data-slot":"icon",ref:r,"aria-labelledby":i},a),e?S.createElement("title",{id:i},e):null,S.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M6 18 18 6M6 6l12 12"}))}const sR=S.forwardRef(oR),lR=w.section`
  position: relative;
  padding: 6rem 0;
  background-color: #ffffff;
  overflow: hidden;
  
  @media (min-width: 768px) {
    padding: 8rem 0;
  }
`,cR=w.div`
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 2rem;
  
  @media (max-width: 768px) {
    padding: 0 1.5rem;
  }
`,uR=w.div`
  margin-bottom: 3rem;
`,dR=w(O.div)`
  font-family: ${({theme:e})=>{var i;return(i=e==null?void 0:e.fonts)==null?void 0:i.primary}};
  font-size: 0.9rem;
  font-weight: 400;
  letter-spacing: 3px;
  text-transform: uppercase;
  color: #FF6347;
  margin-bottom: 1.5rem;
  display: flex;
  align-items: center;
  
  &::before {
    content: '';
    display: inline-block;
    width: 30px;
    height: 2px;
    background: ${({theme:e})=>{var i,a;return((a=(i=e==null?void 0:e.colors)==null?void 0:i.gradients)==null?void 0:a.logo)||"linear-gradient(135deg, #FF6347 0%, #00B4D8 33%, #FF69B4 66%, #5CB848 100%)"}};
    margin-right: 1rem;
  }
`,fR=w(O.h2)`
  font-family: ${({theme:e})=>{var i;return((i=e==null?void 0:e.fonts)==null?void 0:i.elegant)||'"Playfair Display", serif'}};
  font-size: clamp(2.5rem, 5vw, 3.5rem);
  font-weight: 300;
  line-height: 1.2;
  color: ${({theme:e})=>{var i,a;return((a=(i=e==null?void 0:e.colors)==null?void 0:i.text)==null?void 0:a.primary)||"#2C3E2D"}};
  margin: 0;
`,hR=w.div`
  margin-top: 2rem;
`,vb=w.div`
  display: flex;
  align-items: center;
  margin-bottom: 2.5rem;
  position: relative;
  
  &::after {
    content: '';
    flex-grow: 1;
    height: 1px;
    background-color: rgba(44, 62, 45, 0.1);
    margin-left: 2rem;
  }
`,wb=w.h3`
  font-family: ${({theme:e})=>{var i;return((i=e==null?void 0:e.fonts)==null?void 0:i.elegant)||'"Playfair Display", serif'}};
  font-size: clamp(1.5rem, 3vw, 2.2rem);
  font-weight: 300;
  margin: 0;
  color: ${({theme:e})=>{var i,a;return((a=(i=e==null?void 0:e.colors)==null?void 0:i.text)==null?void 0:a.primary)||"#2C3E2D"}};
  position: relative;
  display: flex;
  align-items: center;
  
  svg {
    width: 24px;
    height: 24px;
    margin-right: 1rem;
    color: #5CB848;
  }
`,Sb=w.div`
  display: grid;
  grid-template-columns: repeat(1, 1fr);
  gap: 1.5rem;
  margin-bottom: 5rem;
  
  @media (min-width: 768px) {
    grid-template-columns: repeat(2, 1fr);
    gap: 2rem;
  }
  
  @media (min-width: 1024px) {
    grid-template-columns: repeat(3, 1fr);
    gap: 2.5rem;
  }
  
  @media (max-width: 767px) {
    margin-bottom: 4rem;
  }
`,Mr=w(O.div)`
  position: relative;
  height: 280px;
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  transition: all 0.5s cubic-bezier(0.19, 1, 0.22, 1);
  cursor: pointer;
  
  @media (min-width: 480px) {
    height: 320px;
    border-radius: 20px;
    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.12);
  }
  
  @media (min-width: 768px) {
    height: 360px;
    border-radius: 24px;
  }
  
  @media (min-width: 1024px) {
    height: 380px;
  }
  
  &:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 25px 50px rgba(0, 0, 0, 0.15);
  }
  
  @media (max-width: 480px) {
    &:hover {
      transform: translateY(-8px) scale(1.01);
      box-shadow: 0 20px 45px rgba(0, 0, 0, 0.18);
    }
  }
  
  &::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(
      to bottom,
      rgba(0, 0, 0, 0.1) 0%,
      rgba(0, 0, 0, 0.8) 100%
    );
    z-index: 1;
    transition: all 0.5s ease;
  }
  
  &:hover::after {
    background: linear-gradient(
      to bottom,
      rgba(0, 0, 0, 0.05) 0%,
      rgba(0, 0, 0, 0.7) 100%
    );
  }
  
  @media (max-width: 480px) {
    &::after {
      background: linear-gradient(
        to bottom,
        rgba(0, 0, 0, 0.15) 0%,
        rgba(0, 0, 0, 0.8) 100%
      );
    }
    
    &:hover::after {
      background: linear-gradient(
        to bottom,
        rgba(0, 0, 0, 0.1) 0%,
        rgba(0, 0, 0, 0.7) 100%
      );
    }
  }
`,pR=w.img`
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: center;
  transition: transform 0.6s cubic-bezier(0.23, 1, 0.32, 1);
  
  ${Mr}:hover & {
    transform: scale(1.1);
  }
`,mR=w.div`
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  padding: 2rem;
  z-index: 2;
  color: #fff;
  transform: translateY(0);
  transition: transform 0.4s ease;
  
  ${Mr}:hover & {
    transform: translateY(-5px);
  }
`,gR=w.h3`
  font-family: 'Montserrat', sans-serif;
  font-size: 1.75rem;
  font-weight: 600;
  margin: 0 0 0.5rem;
  letter-spacing: 0.5px;
  color: #fff;
  text-shadow: 0px 2px 8px rgba(0, 0, 0, 0.8);
  transition: all 0.3s ease;
  
  ${Mr}:hover & {
    transform: translateY(-2px);
    text-shadow: 0px 4px 12px rgba(0, 0, 0, 0.9);
  }
`,yR=w.p`
  font-family: 'Inter', sans-serif;
  font-size: 1.1rem;
  line-height: 1.5;
  margin: 0 0 1.5rem;
  opacity: 0.95;
  color: #fff;
  font-weight: 500;
  letter-spacing: 0.2px;
  transition: all 0.3s ease;
  text-shadow: 0px 2px 6px rgba(0, 0, 0, 0.8);
  
  ${Mr}:hover & {
    opacity: 1;
    transform: translateY(-2px);
    text-shadow: 0px 3px 8px rgba(0, 0, 0, 0.9);
  }
`,xR=w(hi)`
  display: inline-flex;
  align-items: center;
  font-family: 'Montserrat', sans-serif;
  font-size: 0.85rem;
  font-weight: 600;
  letter-spacing: 0.8px;
  color: #fff !important;
  text-decoration: none !important;
  padding: 0.8rem 1.5rem;
  background: rgba(255, 255, 255, 0.15);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 50px;
  transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  position: relative;
  overflow: hidden;
  transform: translateY(10px);
  opacity: 0.8;
  
  svg {
    width: 18px;
    height: 18px;
    margin-left: 0.5rem;
    transition: transform 0.3s ease;
    color: #fff !important;
  }
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.15), transparent);
    transition: left 0.6s ease;
  }
  
  ${Mr}:hover & {
    transform: translateY(0);
    opacity: 1;
    background: rgba(255, 255, 255, 0.25);
    border-color: rgba(255, 255, 255, 0.3);
    color: #fff !important;
    
    svg {
      transform: translateX(4px);
      color: #fff !important;
    }
  }
  
  &:hover {
    background: rgba(255, 255, 255, 0.3) !important;
    transform: translateY(-2px) !important;
    color: #fff !important;
    text-decoration: none !important;
    
    svg {
      color: #fff !important;
    }
  }
  
  &:hover::before {
    left: 100%;
  }
  
  &:visited,
  &:link,
  &:active {
    color: #fff !important;
    text-decoration: none !important;
  }
`,bR=[{id:"fitness",name:"Тренажерный зал",description:"Современное пространство с премиальным оборудованием",image:"/images/zones/fitness.jpg",path:"/fitness"},{id:"combat",name:"Боевые искусства",description:"MMA, бокс и муай-тай с профессиональными тренерами",image:"/images/zones/combat.jpg",path:"/combat"},{id:"pool",name:"Бассейн олимпийский",description:"Плавание в 25-метровом бассейне",image:"/images/zones/pool.jpg",path:"/pool"}],vR=[{id:"spa",name:"СПА-комплекс",description:"Расслабляющие процедуры и премиальные массажи",image:"/images/zones/spa.jpg",path:"/spa"},{id:"banya",name:"Русская баня",description:"Традиционные банные процедуры и оздоровление",image:AO,path:"/banya"},{id:"restaurant",name:"Ресторан",description:"Изысканная кухня и авторское меню",image:"/images/zones/restaurant.jpg",path:"/restaurant"}],wR=w.div`
  display: flex;
  justify-content: center;
  margin-bottom: 3rem;
  position: relative;
  
  @media (max-width: 768px) {
    flex-direction: column;
    align-items: center;
    gap: 1rem;
  }
`,Yf=w.button`
  background: ${e=>e.$active?"linear-gradient(135deg, #90B3A7 0%, #A8C5B8 100%)":"rgba(255, 255, 255, 0.1)"};
  color: ${e=>e.$active?"white":"#2C3E2D"};
  border: 2px solid ${e=>e.$active?"transparent":"rgba(144, 179, 167, 0.3)"};
  border-radius: 50px;
  padding: 1rem 2.5rem;
  font-family: ${({theme:e})=>{var i;return(i=e==null?void 0:e.fonts)==null?void 0:i.primary}};
  font-size: 0.95rem;
  font-weight: 600;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  cursor: pointer;
  margin: 0 0.8rem;
  display: flex;
  align-items: center;
  position: relative;
  overflow: hidden;
  box-shadow: ${e=>e.$active?"0 8px 25px rgba(144, 179, 167, 0.4)":"0 4px 15px rgba(0, 0, 0, 0.1)"};
  backdrop-filter: blur(10px);
  min-width: 180px;
  justify-content: center;
  
  svg {
    width: 18px;
    height: 18px;
    margin-right: 0.6rem;
    transition: all 0.3s ease;
    color: ${e=>e.$active?"white":"#90B3A7"};
  }
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.15), transparent);
    transition: left 0.6s ease;
  }
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: ${e=>e.$active?"0 12px 35px rgba(144, 179, 167, 0.6)":"0 8px 25px rgba(144, 179, 167, 0.3)"};
    background: ${e=>e.$active?"linear-gradient(135deg, #A8C5B8 0%, #B8CFC2 100%)":"rgba(144, 179, 167, 0.1)"};
    border-color: ${e=>e.$active?"transparent":"rgba(144, 179, 167, 0.5)"};
    color: ${e=>e.$active?"white":"#90B3A7"};
    
    svg {
      transform: scale(1.1);
      color: ${e=>e.$active?"white":"#90B3A7"};
    }
  }
  
  &:hover::before {
    left: 100%;
  }
  
  &:focus {
    outline: none;
    box-shadow: 0 0 0 3px rgba(144, 179, 167, 0.3);
  }
  
  &:active {
    transform: translateY(-1px);
  }
  
  @media (max-width: 768px) {
    width: 80%;
    justify-content: center;
    margin: 0 0 1rem 0;
    min-width: unset;
    padding: 0.9rem 2rem;
  }
`,SR=()=>{const{t:e}=De(),[i,a]=S.useState("all"),r=c=>c.map((u,f)=>h.jsxs(Mr,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.1},transition:{duration:.8,delay:f*.1},children:[h.jsx(pR,{src:u.image,alt:u.name}),h.jsxs(mR,{children:[h.jsx(gR,{children:u.name}),h.jsx(yR,{children:u.description}),h.jsxs(xR,{to:u.path,children:[e("common.exploreMore","Подробнее"),h.jsx(C2,{})]})]})]},u.id)),s=c=>{a(c)};return h.jsx(lR,{id:"exclusive-zones",children:h.jsxs(cR,{children:[h.jsxs(uR,{children:[h.jsx(dR,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.2},transition:{duration:.8},children:e("zones.overline","Пространства KAIF")}),h.jsx(fR,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.2},transition:{duration:.8,delay:.2},children:e("zones.title","Всё необходимое для активного отдыха и релаксации")})]}),h.jsxs(wR,{as:O.div,initial:{opacity:0,y:10},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.8},transition:{duration:.5},children:[h.jsx(Yf,{$active:i==="all",onClick:()=>s("all"),children:e("zones.all","Все зоны")}),h.jsxs(Yf,{$active:i==="activity",onClick:()=>s("activity"),children:[h.jsx(xb,{}),e("zones.activity","Активити")]}),h.jsxs(Yf,{$active:i==="relax",onClick:()=>s("relax"),children:[h.jsx(Ut,{}),e("zones.relax","Релакс")]})]}),h.jsxs(hR,{as:O.div,initial:{opacity:0},animate:{opacity:1},transition:{duration:.5},children:[(i==="all"||i==="activity")&&h.jsxs(O.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.6},children:[h.jsx(vb,{as:O.div,initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.2},transition:{duration:.8},children:h.jsxs(wb,{children:[h.jsx(xb,{}),e("zones.activity","Активити")]})}),h.jsx(Sb,{children:r(bR)})]}),(i==="all"||i==="relax")&&h.jsxs(O.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.6,delay:i==="all"?.3:0},children:[h.jsx(vb,{as:O.div,initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.2},transition:{duration:.8},children:h.jsxs(wb,{children:[h.jsx(Ut,{}),e("zones.relax","Релакс")]})}),h.jsx(Sb,{children:r(vR)})]})]},i)]})})},TR=w.section`
  position: relative;
  padding: 8rem 0;
  background: linear-gradient(135deg, #fafafa 0%, #ffffff 100%);
  overflow: hidden;
`,Tb=w(O.div)`
  position: absolute;
  border-radius: 50%;
  background: linear-gradient(135deg, rgba(144, 179, 167, 0.08) 0%, rgba(168, 197, 184, 0.04) 100%);
  filter: blur(60px);
  z-index: 0;
  pointer-events: none;
`,jR=w.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 2rem;
  position: relative;
  z-index: 1;
  
  @media (max-width: 768px) {
    padding: 0 1.5rem;
  }
`,AR=w.div`
  text-align: center;
  margin-bottom: 5rem;
`,ER=w(O.div)`
  font-family: 'Inter', sans-serif;
  font-size: 0.875rem;
  font-weight: 600;
  letter-spacing: 3px;
  text-transform: uppercase;
  color: #90B3A7;
  margin-bottom: 1.5rem;
  position: relative;
  
  &::before,
  &::after {
    content: '';
    position: absolute;
    top: 50%;
    width: 40px;
    height: 1px;
    background: #90B3A7;
  }
  
  &::before {
    left: -60px;
  }
  
  &::after {
    right: -60px;
  }
`,CR=w(O.h2)`
  font-family: 'Playfair Display', serif;
  font-size: clamp(2.5rem, 5vw, 3.8rem);
  font-weight: 400;
  line-height: 1.2;
  color: #2C3E2D;
  margin: 0 0 2rem;
  letter-spacing: -0.02em;
`,OR=w(O.p)`
  font-family: 'Inter', sans-serif;
  font-size: 1.125rem;
  line-height: 1.7;
  color: #5A6B5D;
  max-width: 700px;
  margin: 0 auto;
  font-weight: 400;
`,RR=w.div`
  display: grid;
  grid-template-columns: repeat(1, 1fr);
  gap: 2rem;
  margin-top: 4rem;
  
  @media (min-width: 640px) {
    grid-template-columns: repeat(2, 1fr);
    gap: 2.5rem;
  }
  
  @media (min-width: 1024px) {
    grid-template-columns: repeat(4, 1fr);
    gap: 2rem;
  }
`,O2=w(O.div)`
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(20px);
  border-radius: 20px;
  padding: 3rem 2rem 2.5rem;
  text-align: center;
  border: 1px solid ${e=>e.$borderColor};
  transition: all 0.5s cubic-bezier(0.25, 0.1, 0.25, 1);
  position: relative;
  overflow: hidden;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 4px;
    background: ${e=>e.$accent};
    transform: scaleX(0);
    transform-origin: left;
    transition: transform 0.5s ease;
  }
  
  &::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: ${e=>e.$accent};
    opacity: 0;
    transition: opacity 0.5s ease;
  }
  
  &:hover {
    transform: translateY(-12px);
    box-shadow: 0 30px 60px rgba(144, 179, 167, 0.15);
    border-color: ${e=>e.$accent};
    
    &::before {
      transform: scaleX(1);
    }
    
    &::after {
      opacity: 0.02;
    }
  }
`,kR=w.div`
  font-size: 3rem;
  margin-bottom: 2rem;
  position: relative;
  z-index: 2;
  transition: transform 0.3s ease;
  
  ${O2}:hover & {
    transform: scale(1.1);
  }
`,DR=w.div`
  margin-bottom: 2rem;
  position: relative;
  z-index: 2;
`,MR=w(O.span)`
  font-family: 'Playfair Display', serif;
  font-size: 3rem;
  font-weight: 400;
  color: ${e=>e.$color};
  letter-spacing: -0.02em;
  display: block;
  line-height: 1;
`,BR=w.span`
  font-family: 'Inter', sans-serif;
  font-size: 1rem;
  font-weight: 600;
  color: ${e=>e.$color};
  opacity: 0.8;
  margin-left: 0.25rem;
`,zR=w.h3`
  font-family: 'Playfair Display', serif;
  font-size: 1.5rem;
  font-weight: 500;
  color: #2C3E2D;
  margin: 1.5rem 0 1rem;
  letter-spacing: -0.01em;
  position: relative;
  z-index: 2;
`,$R=w.p`
  font-family: 'Inter', sans-serif;
  font-size: 0.95rem;
  line-height: 1.6;
  color: #5A6B5D;
  margin: 0;
  font-weight: 400;
  position: relative;
  z-index: 2;
`,NR=[{id:"gym",emoji:"💪",number:"70",unit:"+",name:"Тренажеров",description:"Современное оборудование для эффективных тренировок",accent:"linear-gradient(135deg, #E8734A 0%, #F28A5F 100%)",color:"#E8734A",borderColor:"rgba(232, 115, 74, 0.15)"},{id:"banya",emoji:"🔥",number:"150",unit:"m2",name:"Русская баня",description:"Самая большая панорамная русская парная на Пхукете",accent:"linear-gradient(135deg, #8B4513 0%, #CD853F 100%)",color:"#8B4513",borderColor:"rgba(139, 69, 19, 0.15)"},{id:"restaurant",emoji:"🍽️",number:"200",unit:"",name:"Мест в ресторане",description:"Ресторан на открытом воздухе",accent:"linear-gradient(135deg, #D4A574 0%, #E6B885 100%)",color:"#D4A574",borderColor:"rgba(212, 165, 116, 0.15)"},{id:"pool",emoji:"🏊‍♂️",number:"25",unit:"м",name:"Бассейн",description:"Бассейн 25 метров",accent:"linear-gradient(135deg, #90B3A7 0%, #A8C5B8 100%)",color:"#90B3A7",borderColor:"rgba(144, 179, 167, 0.15)"}],LR=({value:e,delay:i=0})=>{const a=S.useRef(null),r=rA(a,{once:!0,amount:.3}),[s,c]=Ce.useState("0");return Ce.useEffect(()=>{if(r){const u=setTimeout(()=>{const f=parseInt(e.replace(/\D/g,""))||0;if(f===0){c(e);return}const p=2e3,m=60,y=f/m;let x=0;const b=setInterval(()=>{if(x++,x>=m)c(e),clearInterval(b);else{const T=Math.floor(y*x);c(e.replace(/\d+/,T.toString()))}},p/m);return()=>clearInterval(b)},i);return()=>clearTimeout(u)}},[r,e,i]),h.jsx("span",{ref:a,children:s})},_R=()=>{const{t:e}=De(),i={hidden:{opacity:0,y:40},visible:{opacity:1,y:0,transition:{duration:.8,ease:[.25,.1,.25,1]}}},a={hidden:{opacity:0},visible:{opacity:1,transition:{staggerChildren:.2}}};return h.jsxs(TR,{id:"facilities",children:[h.jsx(Tb,{style:{width:"400px",height:"400px",top:"5%",right:"0%"},animate:{scale:[1,1.1,1],opacity:[.3,.6,.3]},transition:{duration:12,repeat:1/0,repeatType:"reverse"}}),h.jsx(Tb,{style:{width:"300px",height:"300px",bottom:"5%",left:"0%"},animate:{scale:[1,1.2,1],opacity:[.2,.5,.2]},transition:{duration:15,repeat:1/0,repeatType:"reverse",delay:4}}),h.jsxs(jR,{children:[h.jsxs(AR,{children:[h.jsx(ER,{initial:"hidden",whileInView:"visible",viewport:{once:!0,amount:.3},variants:i,children:e("facilities.overline","НАШИ ФАЦИЛИТИ")}),h.jsx(CR,{initial:"hidden",whileInView:"visible",viewport:{once:!0,amount:.3},variants:i,transition:{delay:.2},children:e("facilities.title","Пространство для гармонии и саморазвития")}),h.jsx(OR,{initial:"hidden",whileInView:"visible",viewport:{once:!0,amount:.3},variants:i,transition:{delay:.3},children:e("facilities.subtitle","Мы создаем пространство, где жизнь становится ярче. Наша миссия — сделать отдых и заботу о себе не обязанностью, а удовольствием")})]}),h.jsx(O.div,{initial:"hidden",whileInView:"visible",viewport:{once:!0,amount:.2},variants:a,children:h.jsx(RR,{children:NR.map((r,s)=>h.jsxs(O2,{variants:i,$accent:r.accent,$borderColor:r.borderColor,whileHover:{scale:1.02,transition:{duration:.3}},children:[h.jsx(kR,{children:r.emoji}),h.jsx(DR,{children:h.jsxs(MR,{$color:r.color,children:[h.jsx(LR,{value:r.number,delay:s*300}),r.unit&&h.jsx(BR,{$color:r.color,children:r.unit})]})}),h.jsx(zR,{children:r.name}),h.jsx($R,{children:r.description})]},r.id))})})]})]})},HR=(e={})=>{const[i,a]=S.useState(null),[r,s]=S.useState(!1),[c,u]=S.useState(!1);return S.useEffect(()=>{if(!i)return;const f=new IntersectionObserver(([p])=>{s(p.isIntersecting),p.isIntersecting&&!c&&u(!0)},{threshold:.1,rootMargin:"20px",...e});return f.observe(i),()=>{i&&f.unobserve(i)}},[i,c,e]),[a,r,c]},VR=()=>{const[e,i]=S.useState(!1),[a,r]=S.useState(!1);S.useEffect(()=>{const c=window.matchMedia("(prefers-reduced-motion: reduce)");i(c.matches);const u=f=>i(f.matches);return c.addEventListener("change",u),"hardwareConcurrency"in navigator&&r(navigator.hardwareConcurrency<=2),()=>c.removeEventListener("change",u)},[]);const s=S.useCallback(c=>e?{duration:0}:a?{...c,duration:(c.duration||.5)*.7}:c,[e,a]);return{isReducedMotion:e,isSlowDevice:a,getOptimizedAnimation:s}},jb=(e,i)=>{const[a,r]=S.useState(null),[s,c]=S.useState(null),u=50,f=S.useCallback(y=>{c(null),r(y.targetTouches[0].clientX)},[]),p=S.useCallback(y=>{c(y.targetTouches[0].clientX)},[]),m=S.useCallback(()=>{if(!a||!s)return;const y=a-s,x=y>u,b=y<-50;x&&e&&e(),b&&i&&i()},[a,s,e,i]);return{onTouchStart:f,onTouchMove:p,onTouchEnd:m}},PR=()=>{const[e,i]=S.useState(!1),[a,r]=S.useState(null),s=S.useCallback(u=>{r(u),i(!0),document.body.style.overflow="hidden"},[]),c=S.useCallback(()=>{i(!1),r(null),document.body.style.overflow="auto"},[]);return S.useEffect(()=>{if(!e)return;const u=f=>{f.key==="Escape"&&c()};return document.addEventListener("keydown",u),()=>document.removeEventListener("keydown",u)},[e,c]),{isOpen:e,content:a,open:s,close:c}},FR=(e,i)=>{const[a,r]=S.useState(()=>{try{const u=window.localStorage.getItem(e);return u?JSON.parse(u):i}catch(u){return console.error(`Error reading localStorage key "${e}":`,u),i}}),s=S.useCallback(u=>{try{const f=u instanceof Function?u(a):u;r(f),window.localStorage.setItem(e,JSON.stringify(f))}catch(f){console.error(`Error setting localStorage key "${e}":`,f)}},[e,a]),c=S.useCallback(()=>{try{window.localStorage.removeItem(e),r(i)}catch(u){console.error(`Error removing localStorage key "${e}":`,u)}},[e,i]);return[a,s,c]},UR=w(O.section)`
  position: relative;
  padding: 6rem 0;
  background: linear-gradient(135deg, #fafafa 0%, #ffffff 50%, #f8fffe 100%);
  overflow: hidden;
  min-height: 100vh;
  
  @media (max-width: 1024px) {
    padding: 4rem 0;
  }
  
  @media (max-width: 768px) {
    padding: 3rem 0;
  }
  
  @media (max-width: 480px) {
    padding: 2rem 0;
    min-height: auto;
  }

  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: 
      radial-gradient(circle at 20% 80%, rgba(144, 179, 167, 0.08) 0%, transparent 50%),
      radial-gradient(circle at 80% 20%, rgba(212, 165, 116, 0.06) 0%, transparent 50%),
      radial-gradient(circle at 50% 50%, rgba(232, 115, 74, 0.03) 0%, transparent 60%);
    pointer-events: none;
  }
`,qR=w(O.div)`
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 2rem;
  position: relative;
  z-index: 1;
  
  @media (max-width: 768px) {
    padding: 0 1.5rem;
  }
  
  @media (max-width: 480px) {
    padding: 0 1rem;
  }
`,IR=w(O.div)`
  text-align: center;
  margin-bottom: 4rem;
  
  @media (max-width: 768px) {
    margin-bottom: 3rem;
  }
  
  @media (max-width: 480px) {
    margin-bottom: 2rem;
  }
`,YR=w(O.p)`
  font-family: 'Inter', sans-serif;
  font-size: 0.875rem;
  font-weight: 600;
  letter-spacing: 3px;
  text-transform: uppercase;
  color: #90B3A7;
  margin-bottom: 1rem;
  opacity: 0.9;
  
  @media (max-width: 480px) {
    font-size: 0.8rem;
    letter-spacing: 2px;
  }
`,GR=w(O.h2)`
  font-family: 'Playfair Display', serif;
  font-size: 3.5rem;
  font-weight: 600;
  color: #2C3E2D;
  margin-bottom: 1.5rem;
  line-height: 1.2;
  
  @media (max-width: 1024px) {
    font-size: 3rem;
  }
  
  @media (max-width: 768px) {
    font-size: 2.5rem;
    margin-bottom: 1rem;
  }
  
  @media (max-width: 480px) {
    font-size: 2rem;
    line-height: 1.3;
  }
`,KR=w(O.p)`
  font-family: 'Inter', sans-serif;
  font-size: 1.25rem;
  color: #5A6B5D;
  max-width: 800px;
  margin: 0 auto 2.5rem;
  line-height: 1.8;
  font-weight: 400;
  opacity: 0.9;
  
  @media (max-width: 768px) {
    font-size: 1.125rem;
    margin-bottom: 2rem;
  }
  
  @media (max-width: 480px) {
    font-size: 1rem;
    margin-bottom: 1.5rem;
    line-height: 1.6;
  }
`,XR=w(O.div)`
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 1rem;
  margin-bottom: 3rem;
  
  @media (max-width: 768px) {
    gap: 0.75rem;
    margin-bottom: 2rem;
  }
  
  @media (max-width: 480px) {
    gap: 0.5rem;
    margin-bottom: 1.5rem;
  }
`,ZR=w(O.button)`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 1rem 2.5rem;
  font-size: 0.875rem;
  font-weight: 600;
  letter-spacing: 1.5px;
  text-transform: uppercase;
  border: none;
  border-radius: 50px;
  cursor: pointer;
  transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  position: relative;
  overflow: hidden;
  font-family: 'Inter', sans-serif;
  text-decoration: none;
  min-width: 140px;
  text-align: center;
  
  background: ${({active:e})=>e?"linear-gradient(135deg, #90B3A7 0%, #A8C5B8 100%)":"rgba(255, 255, 255, 0.1)"};
  color: ${({active:e})=>e?"white":"#2C3E2D"};
  box-shadow: ${({active:e})=>e?"0 8px 32px rgba(144, 179, 167, 0.35), inset 0 1px 0 rgba(255, 255, 255, 0.2)":"0 4px 20px rgba(0, 0, 0, 0.08), inset 0 1px 0 rgba(255, 255, 255, 0.25)"};
  backdrop-filter: blur(25px);
  border: 1px solid ${({active:e})=>e?"rgba(255, 255, 255, 0.3)":"rgba(255, 255, 255, 0.15)"};
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
    transition: left 0.8s ease;
  }
  
  &::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, #90B3A7 0%, #A8C5B8 100%);
    opacity: 0;
    transition: all 0.4s ease;
    border-radius: 50px;
    z-index: -1;
  }
  
  &:hover {
    transform: translateY(-4px) scale(1.03);
    color: ${({active:e})=>"white"};
    background: ${({active:e})=>"linear-gradient(135deg, #90B3A7 0%, #A8C5B8 100%)"};
    box-shadow: ${({active:e})=>e?"0 12px 45px rgba(144, 179, 167, 0.5), inset 0 1px 0 rgba(255, 255, 255, 0.4)":"0 8px 35px rgba(144, 179, 167, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.5)"};
    border-color: rgba(255, 255, 255, 0.4);
    
    &::before {
      left: 100%;
    }
    
    &::after {
      opacity: 0;
    }
  }
  
  &:active {
    transform: translateY(-2px) scale(0.98);
  }
  
  @media (max-width: 768px) {
    padding: 0.875rem 2rem;
    font-size: 0.8rem;
    min-width: 120px;
    letter-spacing: 1.2px;
  }
  
  @media (max-width: 480px) {
    padding: 0.75rem 1.75rem;
    font-size: 0.75rem;
    min-width: 100px;
    letter-spacing: 1px;
  }
`,QR=w(O.div)`
  position: relative;
  width: 100%;
  max-width: 1200px;
  margin: 3rem auto;
  overflow: hidden;
  border-radius: 20px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
  background: transparent;
  
  @media (max-width: 768px) {
    margin: 2rem auto;
    border-radius: 16px;
  }
  
  @media (max-width: 480px) {
    margin: 1.5rem auto;
    border-radius: 12px;
  }
`,JR=w(O.div)`
  display: flex;
  width: 100%;
  height: 100%;
  will-change: transform;
  background: transparent;
  margin: 0;
  padding: 0;
`,WR=w(O.div)`
  flex-shrink: 0;
  width: 100%;
  height: 650px;
  position: relative;
  background: transparent;
  overflow: hidden;
  margin: 0;
  padding: 0;
  border: none;
  
  @media (max-width: 768px) {
    height: 500px;
  }
  
  @media (max-width: 480px) {
    height: 400px;
  }
`,ek=w(O.img)`
  width: 100%;
  height: 100%;
  object-fit: cover;
  cursor: pointer;
  will-change: transform;
  backface-visibility: hidden;
  transform: translateZ(0);
  display: block;
  margin: 0;
  padding: 0;
  border: none;
  outline: none;
  vertical-align: top;
  object-position: ${e=>e.$customPosition||"center"};
  
  &:hover {
    transform: scale(1.02) translateZ(0);
    transition: transform 0.4s cubic-bezier(0.25, 0.1, 0.25, 1);
  }
`,tk=w(O.div)`
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  padding: 2.5rem 3rem;
  background: transparent;
  color: white;
  pointer-events: none;
  
  @media (max-width: 768px) {
    padding: 2rem 2.5rem;
  }
  
  @media (max-width: 480px) {
    padding: 1.5rem 2rem;
  }
`,ik=w(O.h3)`
  font-family: 'Playfair Display', serif;
  font-size: 1.875rem;
  font-weight: 500;
  margin: 0;
  color: white;
  text-shadow: 
    0 0 20px rgba(0, 0, 0, 0.9),
    0 2px 8px rgba(0, 0, 0, 0.8),
    0 4px 16px rgba(0, 0, 0, 0.7),
    0 8px 32px rgba(0, 0, 0, 0.5);
  pointer-events: auto;
  line-height: 1.2;
  
  @media (max-width: 768px) {
    font-size: 1.5rem;
  }
  
  @media (max-width: 480px) {
    font-size: 1.25rem;
  }
`;w(O.p)`
  font-family: 'Inter', sans-serif;
  font-size: 1.125rem;
  color: white;
  opacity: 0.95;
  line-height: 1.7;
  max-width: 600px;
  text-shadow: 
    0 0 16px rgba(0, 0, 0, 0.9),
    0 2px 6px rgba(0, 0, 0, 0.8),
    0 4px 12px rgba(0, 0, 0, 0.5);
  pointer-events: auto;
  
  @media (max-width: 768px) {
    font-size: 1rem;
  }
  
  @media (max-width: 480px) {
    font-size: 0.95rem;
  }
`;const Ab=w(O.button)`
  position: absolute !important;
  top: 50% !important;
  transform: translateY(-50%) !important;
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  color: #2C3E2D;
  border: none;
  border-radius: 50%;
  width: 2.5rem;
  height: 2.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.3s ease;
  z-index: 10;
  opacity: 0.8;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  
  &:hover {
    opacity: 1;
    background: rgba(255, 255, 255, 1);
    transform: translateY(-50%) scale(1.05) !important;
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
  }
  
  &:active {
    transform: translateY(-50%) scale(0.95) !important;
  }
  
  &:disabled {
    opacity: 0.4;
    cursor: not-allowed;
    
    &:hover {
      transform: translateY(-50%) !important;
      background: rgba(255, 255, 255, 0.9);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }
  }
  
  &.prev {
    left: 1rem;
  }
  
  &.next {
    right: 1rem;
  }
  
  svg {
    width: 1rem;
    height: 1rem;
    opacity: 0.8;
  }
  
  @media (max-width: 768px) {
    width: 2.25rem;
    height: 2.25rem;
    
    &.prev {
      left: 0.75rem;
    }
    
    &.next {
      right: 0.75rem;
    }
    
    svg {
      width: 0.875rem;
      height: 0.875rem;
    }
  }
  
  @media (max-width: 480px) {
    width: 2rem;
    height: 2rem;
    
    &.prev {
      left: 0.5rem;
    }
    
    &.next {
      right: 0.5rem;
    }
    
    svg {
      width: 0.75rem;
      height: 0.75rem;
    }
  }
`,nk=w(O.div)`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.95);
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 2rem;
  
  @media (max-width: 480px) {
    padding: 1rem;
  }
`,ak=w(O.div)`
  position: relative;
  max-width: 90vw;
  max-height: 90vh;
  background: white;
  border-radius: 20px;
  overflow: hidden;
  box-shadow: 0 25px 50px rgba(0, 0, 0, 0.3);
  
  @media (max-width: 768px) {
    max-width: 95vw;
    max-height: 95vh;
    border-radius: 16px;
  }
  
  @media (max-width: 480px) {
    max-width: 100vw;
    max-height: 100vh;
    border-radius: 0;
  }
`,rk=w(O.img)`
  width: 100%;
  max-height: 70vh;
  object-fit: contain;
  display: block;
  
  @media (max-width: 480px) {
    max-height: 60vh;
  }
`,ok=w(O.div)`
  padding: 2rem;
  
  h3 {
    font-family: 'Playfair Display', serif;
    font-size: 1.75rem;
    font-weight: 600;
    color: #2C3E2D;
    margin-bottom: 0.75rem;
    
    @media (max-width: 480px) {
      font-size: 1.5rem;
      margin-bottom: 0.5rem;
    }
  }
  
  p {
    font-family: 'Inter', sans-serif;
    font-size: 1rem;
    color: #5A6B5D;
    line-height: 1.6;
    margin-bottom: 1.5rem;
    
    @media (max-width: 480px) {
      font-size: 0.9rem;
      margin-bottom: 1rem;
    }
  }
  
  @media (max-width: 480px) {
    padding: 1.5rem;
  }
`,sk=w(O.div)`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 1rem;
`,Eb=w(O.button)`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.75rem 1.5rem;
  background: linear-gradient(135deg, #90B3A7 0%, #A8C5B8 100%);
  color: white;
  border: none;
  border-radius: 50px;
  font-family: 'Inter', sans-serif;
  font-size: 0.875rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  opacity: ${({disabled:e})=>e?.5:1};
  pointer-events: ${({disabled:e})=>e?"none":"auto"};
  
  &:hover:not(:disabled) {
    background: linear-gradient(135deg, #7DA096 0%, #90B3A7 100%);
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(144, 179, 167, 0.3);
  }
  
  svg {
    width: 16px;
    height: 16px;
  }
  
  @media (max-width: 480px) {
    padding: 0.6rem 1.2rem;
    font-size: 0.8rem;
  }
`,lk=w(O.button)`
  position: absolute;
  top: 1rem;
  right: 1rem;
  width: 44px;
  height: 44px;
  border-radius: 50%;
  background: rgba(0, 0, 0, 0.5);
  backdrop-filter: blur(10px);
  border: none;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  cursor: pointer;
  z-index: 10;
  transition: all 0.3s ease;
  
  &:hover {
    background: rgba(0, 0, 0, 0.7);
    transform: scale(1.1);
  }
  
  svg {
    width: 24px;
    height: 24px;
  }
  
  @media (max-width: 480px) {
    top: 0.75rem;
    right: 0.75rem;
    width: 40px;
    height: 40px;
    
    svg {
      width: 20px;
      height: 20px;
    }
  }
`,ck=()=>{const[e,i]=S.useState("all"),[a,r]=S.useState(0),[s,c]=S.useState(0),{isOpen:u,content:f,open:p,close:m}=PR(),[y,x]=FR("gallery-liked-images",[]),{getOptimizedAnimation:b,isReducedMotion:T}=VR(),[A,C]=HR({threshold:.1}),B=S.useMemo(()=>[{id:1,image:"/src/assets/images/spa/services/thai-massage-new.jpg",title:"Тайский массаж",category:"spa",description:"Традиционный тайский массаж в исполнении опытных мастеров. Восстановление энергии и гармонии тела."},{id:2,image:"/src/assets/images/spa/services/aromatherapy-new.jpg",title:"Ароматерапия",category:"spa",description:"Расслабляющие процедуры с натуральными эфирными маслами премиум-качества."},{id:3,image:"/src/assets/images/spa/services/banya-new.jpg",title:"Баня",category:"spa",description:"Традиционная русская баня с березовыми вениками и парильщиком."},{id:4,image:"/src/assets/images/sports/gym/gym-1.JPG",title:"Тренажерный зал",category:"fitness",description:"Более 70 современных тренажеров премиум-класса. Профессиональное оборудование для всех видов тренировок."},{id:5,image:"/src/assets/images/sports/fight-club/fight-1.jpg",title:"Файт-клуб",category:"fitness",description:"Профессиональный ринг для занятий боксом и единоборствами с опытными тренерами."},{id:9,image:"/src/assets/images/beauty/services/facial-new.jpg",title:"Косметология",category:"relax",description:"Профессиональные процедуры для лица с использованием премиум косметики."},{id:10,image:"/src/assets/images/beauty/services/manicure-new.jpg",title:"Маникюр и педикюр",category:"relax",description:"Профессиональный уход за руками и ногами в комфортной обстановке."}],[]),E=S.useMemo(()=>[{id:"all",label:"ВСЕ"},{id:"spa",label:"СПА"},{id:"fitness",label:"ФИТНЕС"},{id:"relax",label:"РЕЛАКСАЦИЯ"}],[]),k=S.useMemo(()=>e==="all"?B:B.filter(ne=>ne.category===e),[e,B]);S.useEffect(()=>{c(0)},[e]);const M=S.useCallback(ne=>{i(ne)},[]),F=S.useCallback(()=>{c(ne=>(ne+1)%k.length)},[k.length]),D=S.useCallback(()=>{c(ne=>(ne-1+k.length)%k.length)},[k.length]),[U,G]=S.useState(!0);S.useEffect(()=>{if(k.length<=1||!U)return;const ne=setInterval(()=>{c(we=>(we+1)%k.length)},4e3);return()=>clearInterval(ne)},[k.length,U]);const Z=S.useCallback(()=>{G(!1)},[]),J=S.useCallback(()=>{G(!0)},[]),ie=jb(F,D);S.useCallback(ne=>{x(we=>{const P=[...we],X=P.indexOf(ne);return X>-1?P.splice(X,1):P.push(ne),P})},[x]);const oe=S.useCallback((ne,we)=>{r(we),p(ne)},[p]),xe=S.useCallback(ne=>{const we=ne==="next"?(a+1)%k.length:(a-1+k.length)%k.length;r(we),p(k[we])},[a,k,p]),Le=jb(()=>xe("next"),()=>xe("prev"));return S.useEffect(()=>{if(!u)return;const ne=we=>{switch(we.key){case"Escape":m();break;case"ArrowLeft":xe("prev");break;case"ArrowRight":xe("next");break}};return document.addEventListener("keydown",ne),()=>document.removeEventListener("keydown",ne)},[u,m,xe]),h.jsxs(UR,{id:"gallery",ref:A,children:[h.jsxs(qR,{children:[h.jsxs(IR,{children:[h.jsx(YR,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},transition:b({duration:.8,ease:"easeOut"}),viewport:{once:!0},children:"ГАЛЕРЕЯ"}),h.jsx(GR,{initial:{opacity:0,y:40},whileInView:{opacity:1,y:0},transition:b({duration:.8,delay:.2,ease:"easeOut"}),viewport:{once:!0},children:"Впечатления KAIF"}),h.jsx(KR,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},transition:b({duration:.8,delay:.4,ease:"easeOut"}),viewport:{once:!0},children:"Погрузитесь в атмосферу KAIF через нашу галерею фотографий. Познакомьтесь с нашими услугами и возможностями комплекса."})]}),h.jsx(XR,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},transition:b({duration:.8,delay:.6,ease:"easeOut"}),viewport:{once:!0},children:E.map((ne,we)=>h.jsx(ZR,{active:e===ne.id,onClick:()=>M(ne.id),initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},transition:b({duration:.5,delay:.7+we*.1}),viewport:{once:!0},whileHover:T?{}:{scale:1.05},whileTap:T?{}:{scale:.95},children:ne.label},ne.id))}),C&&k.length>0&&h.jsx(ua,{mode:"wait",children:h.jsxs(QR,{initial:{opacity:0,scale:.95},animate:{opacity:1,scale:1},exit:{opacity:0,scale:.95},transition:b({duration:.4,ease:"easeInOut"}),onMouseEnter:Z,onMouseLeave:J,...ie,children:[h.jsx(JR,{animate:{x:`-${s*100}%`},transition:{type:"tween",ease:[.25,.1,.25,1],duration:.6},children:k.map((ne,we)=>h.jsxs(WR,{children:[h.jsx(ek,{src:ne.image,alt:ne.title,onClick:()=>oe(ne,we),loading:"lazy",$customPosition:ne.title==="Тайский массаж"?"center bottom":"center"}),h.jsx(tk,{children:h.jsx(ik,{children:ne.title})})]},`${e}-${ne.id}`))}),k.length>1&&h.jsxs(h.Fragment,{children:[h.jsx(Ab,{className:"prev",onClick:D,whileHover:{scale:1.05},whileTap:{scale:.95},disabled:k.length<=1,children:h.jsx(bb,{})}),h.jsx(Ab,{className:"next",onClick:F,whileHover:{scale:1.05},whileTap:{scale:.95},disabled:k.length<=1,children:h.jsx(Wh,{})})]})]},e)})]}),h.jsx(ua,{children:u&&f&&h.jsx(nk,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},transition:b({duration:.3}),onClick:m,...Le,children:h.jsxs(ak,{onClick:ne=>ne.stopPropagation(),initial:{scale:.8,opacity:0,y:50},animate:{scale:1,opacity:1,y:0},exit:{scale:.8,opacity:0,y:30},transition:b({duration:.4,ease:[.25,.1,.25,1]}),children:[h.jsx(rk,{src:f.image,alt:f.title,initial:{opacity:0},animate:{opacity:1},transition:b({duration:.5,delay:.2})}),h.jsxs(ok,{children:[h.jsx(O.h3,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:b({duration:.5,delay:.3}),children:f.title}),h.jsx(O.p,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:b({duration:.5,delay:.4}),children:f.description}),h.jsxs(sk,{children:[h.jsxs(Eb,{onClick:()=>xe("prev"),disabled:a===0,whileHover:T?{}:{scale:1.05},whileTap:T?{}:{scale:.95},children:[h.jsx(bb,{}),"Предыдущее"]}),h.jsxs("span",{style:{color:"#5A6B5D",fontSize:"0.875rem",fontWeight:"500"},children:[a+1," из ",k.length]}),h.jsxs(Eb,{onClick:()=>xe("next"),disabled:a===k.length-1,whileHover:T?{}:{scale:1.05},whileTap:T?{}:{scale:.95},children:["Следующее",h.jsx(Wh,{})]})]})]}),h.jsx(lk,{onClick:m,whileHover:T?{}:{scale:1.1,rotate:90},whileTap:T?{}:{scale:.9},children:h.jsx(sR,{})})]})})})]})},uk=w.section`
  position: relative;
  padding: 3rem 0;
  background: linear-gradient(135deg, rgba(144, 179, 167, 0.05) 0%, rgba(168, 197, 184, 0.03) 100%); /* Легкий градиент в зеленых тонах */
  overflow: hidden;
  
  @media (max-width: 768px) {
    padding: 1.5rem 0;
  }
  
  @media (max-width: 480px) {
    padding: 1rem 0;
  }
`,dk=w.div`
  position: relative;
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 1.5rem;
  
  @media (min-width: 1024px) {
    padding: 0 2rem;
  }
`,fk=w(O.div)`
  text-align: center;
  margin-bottom: 2rem;
  
  @media (max-width: 768px) {
    margin-bottom: 1.5rem;
  }
  
  @media (max-width: 480px) {
    margin-bottom: 1rem;
  }
`,hk=w(O.div)`
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem 1rem;
  background: rgba(144, 179, 167, 0.08); /* Зеленый цвет KAIF с прозрачностью */
  border: 1px solid rgba(144, 179, 167, 0.15); /* Зеленый бордер */
  border-radius: 24px;
  font-family: ${({theme:e})=>{var i;return((i=e==null?void 0:e.fonts)==null?void 0:i.primary)||"Inter, sans-serif"}};
  font-size: 0.875rem;
  font-weight: 500;
  color: #90B3A7; /* Зеленый цвет KAIF */
  margin-bottom: 2rem;
  
  svg {
    width: 1rem;
    height: 1rem;
    color: #90B3A7; /* Зеленый цвет KAIF */
  }
`,pk=w(O.h2)`
  font-family: ${({theme:e})=>{var i;return((i=e==null?void 0:e.fonts)==null?void 0:i.heading)||'"Poppins", sans-serif'}};
  font-size: clamp(2.5rem, 5vw, 4rem);
  font-weight: 700;
  line-height: 1.1;
  margin-bottom: 1.5rem;
  color: #0f172a;
  letter-spacing: -0.025em;
`,mk=w(O.p)`
  font-family: ${({theme:e})=>{var i;return((i=e==null?void 0:e.fonts)==null?void 0:i.primary)||"Inter, sans-serif"}};
  font-size: 1.125rem;
  line-height: 1.6;
  color: #64748b;
  max-width: 600px;
  margin: 0 auto;
`,gk=w.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 3rem;
  
  @media (min-width: 1024px) {
    grid-template-columns: 1fr 1fr;
    gap: 4rem;
  }
`,yk=w(O.div)`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`,R2=w(O.div)`
  background: white;
  border: 1px solid ${({$isOpen:e})=>e?"#e2e8f0":"#f1f5f9"};
  border-radius: 16px;
  overflow: hidden;
  transition: all 0.3s ease;
  
  ${({$isOpen:e})=>e&&`
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
    transform: translateY(-1px);
  `}
  
  &:hover {
    border-color: #e2e8f0;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  }
`,xk=w.button`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1.5rem 2rem;
  background: none;
  border: none;
  cursor: pointer;
  text-align: left;
  transition: all 0.3s ease;
  
  &:hover {
    background: #f8fafc;
  }
`,bk=w.div`
  display: flex;
  align-items: center;
  gap: 1rem;
  flex: 1;
`,vk=w.div`
  width: 2.5rem;
  height: 2.5rem;
  background: rgba(144, 179, 167, 0.08); /* Зеленый цвет KAIF с прозрачностью */
  border: 1px solid rgba(144, 179, 167, 0.15); /* Зеленый бордер */
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #90B3A7; /* Зеленый цвет KAIF */
  transition: all 0.3s ease;
  flex-shrink: 0;
  
  svg {
    width: 1rem;
    height: 1rem;
  }
  
  ${R2}:hover & {
    background: linear-gradient(135deg, #90B3A7 0%, #A8C5B8 100%); /* Градиент зеленого цвета */
    color: white;
    border-color: transparent;
  }
`,wk=w.h3`
  font-family: ${({theme:e})=>{var i;return((i=e==null?void 0:e.fonts)==null?void 0:i.heading)||'"Poppins", sans-serif'}};
  font-size: 1.125rem;
  font-weight: 600;
  color: #0f172a;
  margin: 0;
  line-height: 1.4;
`,Sk=w(O.div)`
  width: 2rem;
  height: 2rem;
  background: ${({$isOpen:e})=>e?"linear-gradient(135deg, #90B3A7 0%, #A8C5B8 100%)":"rgba(144, 179, 167, 0.08)"};
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: ${({$isOpen:e})=>e?"white":"#5CB848"};
  transition: all 0.3s ease;
  flex-shrink: 0;
  box-shadow: ${({$isOpen:e})=>e?"0 4px 8px rgba(0, 0, 0, 0.1)":"none"};
  
  svg {
    width: 1rem;
    height: 1rem;
  }
`,Tk=w(O.div)`
  overflow: hidden;
`,jk=w.div`
  padding: 0 2rem 2rem 5.5rem;
  
  @media (max-width: 768px) {
    padding: 0 1.5rem 2rem 1.5rem;
  }
`,Ak=w.p`
  font-family: ${({theme:e})=>{var i;return((i=e==null?void 0:e.fonts)==null?void 0:i.primary)||"Inter, sans-serif"}};
  font-size: 1rem;
  line-height: 1.7;
  color: #64748b;
  margin: 0;
`,Ek=w(O.div)`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`,cc=w(O.div)`
  background: white;
  border: 1px solid rgba(144, 179, 167, 0.1); /* Зеленый цвет KAIF */
  border-radius: 16px;
  padding: 2rem 1.5rem;
  text-align: center;
  transition: all 0.4s ease;
  position: relative;
  overflow: hidden;
  
  &::before {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 3px;
    background: linear-gradient(135deg, #90B3A7 0%, #A8C5B8 100%);
    transform: scaleX(0);
    transform-origin: right;
    transition: transform 0.6s ease;
  }
  
  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 30px rgba(144, 179, 167, 0.15); /* Тень с зеленым цветом KAIF */
    border-color: rgba(144, 179, 167, 0.2); /* Зеленый цвет KAIF */
    
    &::before {
      transform: scaleX(1);
      transform-origin: left;
    }
  }
`,Gf=w.div`
  width: 3rem;
  height: 3rem;
  margin: 0 auto 1.5rem;
  background: rgba(144, 179, 167, 0.08); /* Зеленый цвет KAIF с прозрачностью */
  border: 1px solid rgba(144, 179, 167, 0.15); /* Зеленый бордер */
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #90B3A7; /* Зеленый цвет KAIF */
  transition: all 0.4s ease;
  position: relative;
  overflow: hidden;
  
  svg {
    width: 1.25rem;
    height: 1.25rem;
    transition: transform 0.4s ease;
  }
  
  ${cc}:hover & {
    background: linear-gradient(135deg, #90B3A7 0%, #A8C5B8 100%); /* Градиент зеленого цвета */
    color: white;
    border-color: transparent;
    transform: scale(1.1);
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.15);
    
    svg {
      transform: scale(1.1);
    }
  }
`,Kf=w.h3`
  font-family: ${({theme:e})=>{var i;return((i=e==null?void 0:e.fonts)==null?void 0:i.heading)||'"Poppins", sans-serif'}};
  font-size: 1.25rem;
  font-weight: 600;
  color: #0f172a;
  margin-bottom: 1rem;
  line-height: 1.3;
`,Xf=w.p`
  font-family: ${({theme:e})=>{var i;return((i=e==null?void 0:e.fonts)==null?void 0:i.primary)||"Inter, sans-serif"}};
  font-size: 0.9rem;
  color: #64748b;
  line-height: 1.6;
  margin-bottom: 1.5rem;
`,Zf=w.div`
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
`,nr=w.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.75rem;
  font-family: ${({theme:e})=>{var i;return((i=e==null?void 0:e.fonts)==null?void 0:i.primary)||"Inter, sans-serif"}};
  font-size: 0.875rem;
  color: #64748b;
  font-weight: 500;
  
  svg {
    width: 1rem;
    height: 1rem;
    color: #94a3b8;
    flex-shrink: 0;
  }
`,Ck=()=>{const{t:e}=De(),[i,a]=S.useState(null),r=p=>{a(i===p?null:p)},s={hidden:{opacity:.5,y:10},visible:{opacity:1,y:0,transition:{duration:.4,ease:"easeOut"}}},c={hidden:{opacity:.4,y:15},visible:{opacity:1,y:0,transition:{duration:.3,ease:"easeOut"}}},u={hidden:{height:0,opacity:0,transition:{height:{duration:.3},opacity:{duration:.2}}},visible:{height:"auto",opacity:1,transition:{height:{duration:.4,ease:[.25,.46,.45,.94]},opacity:{duration:.3,delay:.1}}}},f=[{category:"general",icon:h.jsx(qo,{}),question:"Что включает в себя комплекс KAIF?",answer:"KAIF — уникальный комплекс на Пхукете, где можно сочетать активность, отдых и уход за собой в одном месте. На территории находятся: современный спортзал, олимпийский бассейн с зонами для релакса, студия танцев и функциональных тренировок, зал боевых искусств, бьюти-студия, СПА в качестве русской сауны, тайского хаммама и массажных услуг, ресторан с восточной кухней, русской классикой и блюдами на мангале."},{category:"general",icon:h.jsx(Tr,{}),question:"Режим работы комплекса?",answer:"Мы работаем ежедневно с 6:00 до 23:00. Некоторые зоны (СПА, ресторан) могут иметь отдельный график. Рекомендуем уточнять время работы конкретных услуг при бронировании."},{category:"booking",icon:h.jsx(es,{}),question:"Как забронировать услуги?",answer:"Бронирование доступно через наш сайт, мобильное приложение, по телефону +66 76 123 456 или WhatsApp. Рекомендуем бронировать заранее, особенно СПА-процедуры и столики в ресторане."},{category:"booking",icon:h.jsx(Df,{}),question:"Можно ли приобрести абонементы?",answer:"Да! У нас есть различные абонементы: дневные, недельные, месячные и годовые. Также доступны комбинированные пакеты, включающие несколько услуг со скидкой до 30%."},{category:"services",icon:h.jsx(es,{}),question:"Нужен ли опыт для занятий?",answer:'Нет! У нас есть программы для всех уровней подготовки. Новичкам предоставляем вводный инструктаж, персональные консультации и программы "первые шаги" для безопасного начала тренировок.'},{category:"payment",icon:h.jsx(Df,{}),question:"Какие способы оплаты принимаются?",answer:"Принимаем наличные (THB, USD, EUR), банковские карты всех систем, мобильные платежи, криптовалюты и банковские переводы. Доступна рассрочка для крупных пакетов услуг."},{category:"payment",icon:h.jsx(qo,{}),question:"Есть ли программа лояльности?",answer:"Да! Программа KAIF Rewards дает накопительные скидки, бонусы за приведение друзей, эксклюзивные мероприятия и приоритетное бронирование. Накопленные баллы можно тратить на любые услуги."}];return h.jsx(uk,{children:h.jsx(dk,{children:h.jsxs("div",{children:[h.jsxs(fk,{children:[h.jsxs(hk,{children:[h.jsx(ob,{}),"Ответы на вопросы"]}),h.jsx(pk,{children:"Часто задаваемые вопросы"}),h.jsx(mk,{children:"Всё, что нужно знать о нашем многофункциональном комплексе"})]}),h.jsxs(gk,{children:[h.jsx(yk,{children:f.map((p,m)=>h.jsx(O.div,{variants:c,custom:m,whileInView:"visible",viewport:{once:!0,amount:.1},children:h.jsxs(R2,{$isOpen:i===m,children:[h.jsxs(xk,{onClick:()=>r(m),children:[h.jsxs(bk,{children:[h.jsx(vk,{children:p.icon}),h.jsx(wk,{children:p.question})]}),h.jsx(Sk,{$isOpen:i===m,animate:{rotate:i===m?180:0},transition:{duration:.3,ease:"easeInOut"},children:i===m?h.jsx(cC,{}):h.jsx(fC,{})})]}),h.jsx(ua,{children:i===m&&h.jsx(Tk,{variants:u,initial:"hidden",animate:"visible",exit:"hidden",children:h.jsx(jk,{children:h.jsx(Ak,{children:p.answer})})})})]})},m))}),h.jsxs(Ek,{children:[h.jsx(O.div,{variants:s,children:h.jsxs(cc,{whileHover:{scale:1.02,transition:{duration:.2}},children:[h.jsx(Gf,{children:h.jsx(Wi,{})}),h.jsx(Kf,{children:"Служба поддержки"}),h.jsx(Xf,{children:"Наша команда готова помочь вам 24/7. Свяжитесь с нами любым удобным способом."}),h.jsxs(Zf,{children:[h.jsxs(nr,{children:[h.jsx(S2,{}),"Пхукет, Таиланд"]}),h.jsxs(nr,{children:[h.jsx(Tr,{}),"24/7 поддержка"]})]})]})}),h.jsx(O.div,{variants:s,children:h.jsxs(cc,{whileHover:{scale:1.02,transition:{duration:.2}},children:[h.jsx(Gf,{children:h.jsx(ob,{})}),h.jsx(Kf,{children:"WhatsApp чат"}),h.jsx(Xf,{children:"Быстрые ответы в мессенджере. Бронирование, вопросы, поддержка - всё в одном чате."}),h.jsxs(Zf,{children:[h.jsxs(nr,{children:[h.jsx(es,{}),"Мгновенные ответы"]}),h.jsxs(nr,{children:[h.jsx(Wi,{}),"Персональный менеджер"]})]})]})}),h.jsx(O.div,{variants:s,children:h.jsxs(cc,{whileHover:{scale:1.02,transition:{duration:.2}},children:[h.jsx(Gf,{children:h.jsx(qo,{})}),h.jsx(Kf,{children:"Персональные консультации"}),h.jsx(Xf,{children:"Индивидуальный подход к каждому гостю. Поможем составить программу под ваши цели."}),h.jsxs(Zf,{children:[h.jsxs(nr,{children:[h.jsx(qo,{}),"Бесплатная консультация"]}),h.jsxs(nr,{children:[h.jsx(Df,{}),"Гибкая оплата"]})]})]})})]})]})]})})})},Ok=w(O.div)`
  display: flex;
  justify-content: center;
  padding: 30px 20px;
  background: linear-gradient(135deg, rgba(144, 179, 167, 0.05) 0%, rgba(168, 197, 184, 0.03) 100%);
  
  @media (max-width: 768px) {
    padding: 20px 20px;
  }
  
  @media (max-width: 480px) {
    padding: 15px 20px;
  }
`,Rk=w(O(hi))`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  padding: 0.9rem 2.2rem;
  font-size: 0.85rem;
  font-weight: 600;
  letter-spacing: 1px;
  text-transform: uppercase;
  text-decoration: none;
  border-radius: 50px;
  transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  position: relative;
  overflow: hidden;
  min-width: 220px;
  text-align: center;
  background: linear-gradient(135deg, #90B3A7 0%, #A8C5B8 100%);
  color: white !important;
  border: 2px solid transparent;
  box-shadow: 0 6px 20px rgba(144, 179, 167, 0.3);
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.15), transparent);
    transition: left 0.6s ease;
  }
  
  &:hover::before {
    left: 100%;
  }
  
  &:hover {
    transform: translateY(-2px) !important;
    box-shadow: 0 8px 25px rgba(144, 179, 167, 0.5) !important;
    background: linear-gradient(135deg, #A8C5B8 0%, #B8CFC2 100%) !important;
    color: white !important;
    text-decoration: none !important;
  }
  
  &:active {
    transform: translateY(-1px) !important;
  }
  
  &:focus {
    outline: none !important;
    box-shadow: 0 0 0 3px rgba(144, 179, 167, 0.3) !important;
  }
  
  svg {
    width: 16px;
    height: 16px;
    transition: transform 0.3s ease;
  }
  
  &:hover svg {
    transform: translateX(3px);
  }
  
  @media (max-width: 768px) {
    width: 100%;
    max-width: 320px;
    padding: 1rem 2rem;
    font-size: 0.8rem;
    min-width: unset;
    border-radius: 14px;
    box-shadow: 0 8px 25px rgba(144, 179, 167, 0.4);
    
    &:hover {
      transform: translateY(-3px) scale(1.01) !important;
      box-shadow: 0 12px 35px rgba(144, 179, 167, 0.6) !important;
    }
  }
  
  @media (max-width: 480px) {
    padding: 0.9rem 1.8rem;
    font-size: 0.75rem;
    border-radius: 12px;
    box-shadow: 0 10px 30px rgba(144, 179, 167, 0.5);
    
    svg {
      width: 14px;
      height: 14px;
    }
    
    &:hover {
      transform: translateY(-4px) scale(1.02) !important;
      box-shadow: 0 15px 40px rgba(144, 179, 167, 0.7) !important;
    }
  }
`,kk=()=>{const{showLoading:e}=Hv(),i=S.useRef(!1);S.useEffect(()=>{i.current||(i.current=!0,e(1100))},[]);const a={hidden:{scale:.9,opacity:0},visible:{scale:1,opacity:1,transition:{duration:.6,type:"spring",stiffness:120,damping:15}},hover:{scale:1.02,transition:{duration:.3,ease:"easeOut"}},tap:{scale:.98}};return h.jsxs(O.main,{initial:{opacity:0},animate:{opacity:1},transition:{duration:.6,ease:[.22,1,.36,1]},children:[h.jsx(NO,{}),h.jsx(SR,{}),h.jsx(_R,{}),h.jsx(ck,{}),h.jsx(Ck,{}),h.jsx(Ok,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{duration:.8,ease:[.25,.46,.45,.94]},children:h.jsxs(Rk,{to:"/contacts",variants:a,initial:"hidden",whileInView:"visible",viewport:{once:!0},whileHover:"hover",whileTap:"tap",children:["Связаться с нами",h.jsxs("svg",{xmlns:"http://www.w3.org/2000/svg",width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[h.jsx("path",{d:"M5 12h14"}),h.jsx("path",{d:"M12 5l7 7-7 7"})]})]})})]})},Dk=e=>{const i=[{id:1,name:'Завтрак "KAIF"',description:"Фирменный завтрак нашего ресторана",price:"320 THB",image:"https://images.unsplash.com/photo-1533089860892-a7c6f0a88666?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["breakfast","popular"],popular:!0,category:"breakfast"},{id:2,name:"Шакшука со шпинатом и лососем",description:"Яичное блюдо с добавлением шпината и нежного лосося",price:"330 THB",image:"https://images.unsplash.com/photo-1590412200988-a436970781fa?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["breakfast","seafood"],popular:!1,category:"breakfast"},{id:3,name:"Шакшука с томатами и фетой",description:"Традиционная шакшука с сочными томатами и сыром фета",price:"300 THB",image:"https://images.unsplash.com/photo-1520218576172-c1a2df3fa5fc?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["breakfast","vegetarian"],popular:!1,category:"breakfast"},{id:4,name:"Сырники со сметаной и соусом из маракуйи",description:"Нежные домашние сырники с оригинальным соусом из маракуйи",price:"250 THB",image:"https://images.unsplash.com/photo-1505253716362-afaea1d3d1af?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["breakfast","sweet"],popular:!0,category:"breakfast"},{id:5,name:"Тост со сливочным сыром и ветчиной",description:"Хрустящий тост с нежным сливочным сыром и качественной ветчиной",price:"250 THB",image:"https://images.unsplash.com/photo-1528207776546-365bb710ee93?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["breakfast","meat"],popular:!1,category:"breakfast"},{id:6,name:"Тост с соленым лососем и авокадо",description:"Изысканное сочетание хрустящего тоста, нежного лосося и спелого авокадо",price:"330 THB",image:"https://images.unsplash.com/photo-1603532648955-039310d9ed75?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["breakfast","seafood"],popular:!0,category:"breakfast"},{id:7,name:"Тост с авокадо и томатами",description:"Легкий и полезный завтрак из хрустящего тоста с авокадо и сочными томатами",price:"270 THB",image:"https://images.unsplash.com/photo-1588137378633-dea1336ce1e2?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["breakfast","vegetarian","healthy"],popular:!1,category:"breakfast"},{id:8,name:"Мацони с абрикосовым вареньем",description:"Традиционный кавказский йогурт с натуральным абрикосовым вареньем",price:"120 THB",image:"https://images.unsplash.com/photo-1488477181946-6428a0291777?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["breakfast","vegetarian"],popular:!1,category:"breakfast"},{id:9,name:"Гречневая каша с цыпленком, грибами и соусом Пармезан",description:"Питательная гречневая каша с нежным цыпленком, ароматными грибами и сливочным соусом",price:"250 THB",image:"https://images.unsplash.com/photo-1555813456-77dd136e1407?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["breakfast","healthy"],popular:!1,category:"breakfast"},{id:10,name:"Окрошка на айране",description:"Освежающий холодный суп на кисломолочной основе с овощами и зеленью",price:"270 THB",image:"https://images.unsplash.com/photo-1547592166-23ac45744acd?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["soup","cold"],popular:!0,category:"soup"},{id:11,name:"Окрошка на квасе",description:"Классическая окрошка на квасе с отборными овощами, яйцом и свежей зеленью",price:"270 THB",image:"https://images.unsplash.com/photo-1629634355805-0e1e89cf9010?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["soup","cold"],popular:!1,category:"soup"},{id:12,name:"Чихиртма с кукурузой",description:"Традиционный грузинский суп с насыщенным вкусом, дополненный сладкой кукурузой",price:"190 THB",image:"https://images.unsplash.com/photo-1613844237802-4beb8b23cf7d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["soup","hot"],popular:!1,category:"soup"},{id:13,name:"Борщ классический",description:"Традиционный славянский суп насыщенного рубинового цвета с говядиной и овощами",price:"270 THB",image:"https://images.unsplash.com/photo-1550138616-c4d696fc4864?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["soup","hot"],popular:!0,category:"soup"},{id:14,name:"Листья салата с молодым картофелем и соленым лососем",description:"Свежий микс салатов с молодым картофелем и нежным соленым лососем",price:"360 THB",image:"https://images.unsplash.com/photo-1546069901-ba9599a7e63c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["salad","seafood"],popular:!0,category:"salad"},{id:15,name:"Салат из свежих овощей с брынзой",description:"Традиционный салат из свежих овощей с добавлением нежной брынзы",price:"320 THB",image:"https://images.unsplash.com/photo-1512621776951-a57141f2eefd?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["salad","vegetarian"],popular:!1,category:"salad"},{id:16,name:"Помидоры, огурцы, зелень",description:"Свежие сочные помидоры и хрустящие огурцы с ароматной зеленью, заправленные по выбору сметаной или оливковым маслом",price:"190 THB",image:"https://images.unsplash.com/photo-1529059997568-3d847b1154f0?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["salad","vegetarian","healthy"],popular:!1,category:"salad"},{id:17,name:"Хумус с печеным нутом",description:"Нежный хумус с дополнительным печеным нутом для текстуры",price:"170 THB",image:"https://images.unsplash.com/photo-1640719502926-b205fcbe99be?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["appetizer","vegetarian"],popular:!1,category:"appetizer"},{id:18,name:"Хумус с авокадо и томатами",description:"Оригинальный хумус с добавлением спелого авокадо и свежих томатов",price:"250 THB",image:"https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["appetizer","vegetarian","healthy"],popular:!0,category:"appetizer"},{id:19,name:"Хумус с креветками гриль",description:"Классический хумус, дополненный сочными креветками с гриля",price:"390 THB",image:"https://images.unsplash.com/photo-1559304822-9eb2813c9a84?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["appetizer","seafood"],popular:!0,category:"appetizer"},{id:20,name:"Хумус с куриным кебабом",description:"Хумус, поданный с ароматными кусочками куриного кебаба",price:"250 THB",image:"https://images.unsplash.com/photo-1625938145744-e380515399b7?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["appetizer","meat"],popular:!1,category:"appetizer"},{id:21,name:"Дзадзыки с оливками и маринованным перцем",description:"Освежающий йогуртовый соус с огурцами, чесноком и зеленью, дополненный оливками и маринованным перцем",price:"220 THB",image:"https://images.unsplash.com/photo-1609771600140-a398eb699e87?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["appetizer","vegetarian"],popular:!1,category:"appetizer"},{id:22,name:"Кебаб из курицы (в йогурте)",description:"Сочный кебаб из куриного филе, маринованного в йогурте с восточными специями",price:"250 THB",image:"https://images.unsplash.com/photo-1544025162-d76694265947?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["grill","meat"],popular:!0,category:"grill"},{id:23,name:"Кебаб из говядины",description:"Сочный кебаб из отборной говядины, приготовленный на открытом огне",price:"490 THB",image:"https://images.unsplash.com/photo-1529694157872-4e0c0f3b238b?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["grill","meat"],popular:!0,category:"grill"},{id:24,name:"Кебаб из свиной шеи",description:"Кебаб из маринованной свиной шеи с ароматными специями",price:"290 THB",image:"https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["grill","meat"],popular:!1,category:"grill"},{id:25,name:"Цыпленок в аджике с картофелем",description:"Сочный цыпленок, маринованный в пикантном соусе аджика, с гарниром из молодого картофеля",price:"330 THB",image:"https://images.unsplash.com/photo-1598103442080-4e95925f39f3?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["grill","meat"],popular:!1,category:"grill"},{id:26,name:"Люля-кебаб (курица)",description:"Рубленый кебаб из куриного филе с добавлением ароматных специй",price:"250 THB",image:"https://images.unsplash.com/photo-1599161146648-0fe1bc2bf160?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["grill","meat"],popular:!1,category:"grill"},{id:27,name:"Люля-кебаб (баранина)",description:"Традиционный люля-кебаб из рубленой баранины с восточными специями",price:"390 THB",image:"https://images.unsplash.com/photo-1603360946369-dc9bb6258143?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["grill","meat"],popular:!0,category:"grill"},{id:28,name:"Люля-кебаб (говядина и свинина)",description:"Сочный люля-кебаб из смеси рубленой говядины и свинины",price:"370 THB",image:"https://images.unsplash.com/photo-1565299543923-37dd37887442?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["grill","meat"],popular:!1,category:"grill"},{id:29,name:"Лосось на мангале",description:"Нежное филе лосося, приготовленное на открытом огне",price:"420 THB",image:"https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["grill","seafood"],popular:!0,category:"grill"},{id:30,name:"Филе белого окуня",description:"Нежное филе белого окуня, приготовленное на мангале",price:"390 THB",image:"https://images.unsplash.com/photo-1619894991209-32b8fb2a8f1c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["grill","seafood"],popular:!1,category:"grill"},{id:31,name:"Креветки на мангале",description:"Сочные тигровые креветки, приготовленные на мангале с добавлением трав и чесночного масла",price:"490 THB",image:"https://images.unsplash.com/photo-1559737558-2f5a35f4523b?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["grill","seafood"],popular:!0,category:"grill"},{id:32,name:"Картофель фри",description:"Хрустящий картофель фри, приготовленный в растительном масле",price:"170 THB",image:"https://images.unsplash.com/photo-1541592106381-b31e9677c0e5?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["side","vegetarian"],popular:!0,category:"side"},{id:33,name:"Картофельное пюре",description:"Нежное картофельное пюре с маслом и сливками",price:"150 THB",image:"https://images.unsplash.com/photo-1600175074395-5d7d3c511dd9?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["side","vegetarian"],popular:!1,category:"side"},{id:34,name:"Овощи гриль",description:"Ассорти из сезонных овощей, приготовленных на гриле",price:"250 THB",image:"https://images.unsplash.com/photo-1607352294091-3c7cec864da9?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["side","vegetarian","healthy"],popular:!0,category:"side"},{id:35,name:"Рис с шафраном",description:"Ароматный рис длиннозерный с добавлением шафрана",price:"150 THB",image:"https://images.unsplash.com/photo-1624314138470-5a2f24623f10?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["side","vegetarian"],popular:!1,category:"side"},{id:36,name:"Зеленый салат с заправкой",description:"Свежий микс зелени с легкой заправкой на основе оливкового масла",price:"120 THB",image:"https://images.unsplash.com/photo-1588710277537-126980e8d44e?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["side","vegetarian","healthy"],popular:!1,category:"side"},{id:37,name:"Томатный соус",description:"Классический томатный соус с добавлением трав и специй",price:"70 THB",image:"https://images.unsplash.com/photo-1472476443507-c7a5948772fc?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["sauce","vegetarian"],popular:!1,category:"sauce"},{id:38,name:"Соус Тар-тар",description:"Сливочный соус с добавлением корнишонов и зелени",price:"90 THB",image:"https://images.unsplash.com/photo-1582871095047-a5b2c208e622?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["sauce","vegetarian"],popular:!1,category:"sauce"},{id:39,name:"Соус Чимичурри",description:"Традиционный аргентинский соус из зелени, чеснока и оливкового масла",price:"90 THB",image:"https://images.unsplash.com/photo-1631890004583-aca432c827e8?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["sauce","vegetarian"],popular:!0,category:"sauce"},{id:40,name:"Соус Сацебели",description:"Острый грузинский соус из томатов, чеснока, перца и зелени",price:"90 THB",image:"https://images.unsplash.com/photo-1580999196779-ca0ae386ec64?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["sauce","vegetarian","spicy"],popular:!1,category:"sauce"},{id:41,name:"Фокачча с розмарином",description:"Традиционный итальянский хлеб с розмарином и морской солью",price:"120 THB",image:"https://images.unsplash.com/photo-1587137223122-9a1770e51d67?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["bread","vegetarian"],popular:!0,category:"bread"},{id:42,name:"Лепешка заатар",description:"Тонкая лепешка с добавлением смеси восточных специй заатар",price:"90 THB",image:"https://images.unsplash.com/photo-1619535860434-806c372572ba?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["bread","vegetarian"],popular:!1,category:"bread"},{id:43,name:"Бургер классический",description:"Сочная говяжья котлета, салат, помидор, маринованные огурцы, сыр и специальный соус",price:"350 THB",image:"https://images.unsplash.com/photo-1568901346375-23c9450c58cd?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["burger","meat"],popular:!0,category:"burger"},{id:44,name:"Бургер с беконом и яйцом",description:"Бургер с говяжьей котлетой, хрустящим беконом и жареным яйцом",price:"390 THB",image:"https://images.unsplash.com/photo-1553979459-d2229ba7433b?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["burger","meat"],popular:!0,category:"burger"},{id:45,name:"Бургер с курицей и сыром",description:"Нежная куриная котлета с плавленым сыром, салатом и специальным соусом",price:"320 THB",image:"https://images.unsplash.com/photo-1594212699903-ec8a3eca50f5?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["burger","meat"],popular:!1,category:"burger"},{id:46,name:"Бургер с рыбой",description:"Котлета из филе окуня в хрустящей панировке с соусом тар-тар",price:"350 THB",image:"https://images.unsplash.com/photo-1584947897558-e5bc29242a71?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["burger","seafood"],popular:!1,category:"burger"},{id:47,name:"Бургер вегетарианский",description:"Котлета из нута, чечевицы и овощей с свежими овощами и специальным соусом",price:"290 THB",image:"https://images.unsplash.com/photo-1585238341710-4d3ff484184d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["burger","vegetarian","healthy"],popular:!1,category:"burger"},{id:48,name:"Шаурма с курицей",description:"Традиционная шаурма с курицей, овощами и соусом",price:"250 THB",image:"https://images.unsplash.com/photo-1542574271-7f3b92e6c821?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["shawarma","meat"],popular:!0,category:"shawarma"},{id:49,name:"Шаурма с говядиной",description:"Шаурма с сочной говядиной, свежими овощами и фирменным соусом",price:"290 THB",image:"https://images.unsplash.com/photo-1530469912745-a215c6b256ea?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["shawarma","meat"],popular:!1,category:"shawarma"},{id:50,name:"Шаурма вегетарианская",description:"Вегетарианская шаурма с фалафелем, хумусом и свежими овощами",price:"220 THB",image:"https://images.unsplash.com/photo-1630445396366-8dea03c85ead?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["shawarma","vegetarian","healthy"],popular:!1,category:"shawarma"},{id:51,name:"Чизкейк Нью-Йорк",description:"Классический американский чизкейк с нежной кремовой текстурой и тонким слоем сливочного крема",price:"270 THB",image:"https://images.unsplash.com/photo-1567171466-2c6f942c8cfb?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["dessert","sweet"],popular:!0,category:"dessert"},{id:52,name:"Тирамису",description:"Традиционный итальянский десерт с маскарпоне, пропитанный кофе и ликером",price:"250 THB",image:"https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["dessert","sweet"],popular:!0,category:"dessert"},{id:53,name:"Яблочный штрудель",description:"Теплый яблочный штрудель с корицей и ванильным мороженым",price:"220 THB",image:"https://images.unsplash.com/photo-1606313564200-e75d8e223e04?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["dessert","sweet"],popular:!1,category:"dessert"},{id:54,name:"Шоколадный фондан",description:"Теплый шоколадный кекс с жидкой шоколадной начинкой и шариком ванильного мороженого",price:"290 THB",image:"https://images.unsplash.com/photo-1541783245831-57d6f0d6f9a4?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["dessert","sweet"],popular:!0,category:"dessert"},{id:55,name:"Панна-котта с ягодным соусом",description:"Нежный сливочный десерт с ванилью и свежим ягодным соусом",price:"190 THB",image:"https://images.unsplash.com/photo-1488477181946-6428a0291777?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["dessert","sweet"],popular:!1,category:"dessert"},{id:56,name:"Фруктовый салат",description:"Ассорти из свежих сезонных фруктов с медом и мятой",price:"190 THB",image:"https://images.unsplash.com/photo-1493807742375-fbc46d996e8f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["dessert","sweet","healthy"],popular:!1,category:"dessert"},{id:57,name:"Мороженое ассорти (3 шарика)",description:"Три шарика мороженого на выбор: ванильное, шоколадное, клубничное, фисташковое или манговое",price:"170 THB",image:"https://images.unsplash.com/photo-1497034825429-c343d7c6a68f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["dessert","sweet"],popular:!0,category:"dessert"},{id:58,name:"Чай зеленый",description:"Классический китайский зеленый чай",price:"120 THB",image:"https://images.unsplash.com/photo-1627435601361-ec25f5b1d0e5?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["tea","hot"],popular:!1,category:"tea"},{id:59,name:"Чай черный",description:"Крепкий черный чай",price:"120 THB",image:"https://images.unsplash.com/photo-1576092768241-dec231879fc3?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["tea","hot"],popular:!1,category:"tea"},{id:60,name:"Чай с имбирем и медом",description:"Согревающий чай со свежим имбирем, лимоном и медом",price:"150 THB",image:"https://images.unsplash.com/photo-1576092768241-dec231879fc3?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["tea","hot"],popular:!0,category:"tea"},{id:61,name:"Чай с мятой",description:"Освежающий чай со свежей мятой",price:"150 THB",image:"https://images.unsplash.com/photo-1597481499750-3e6b92e73b5b?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["tea","hot"],popular:!1,category:"tea"},{id:62,name:"Чай ясминовый",description:"Деликатный зеленый чай с ясмином",price:"120 THB",image:"https://images.unsplash.com/photo-1546648898-b1a3dd82cf32?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["tea","hot"],popular:!1,category:"tea"},{id:63,name:"Чай фруктовый",description:"Чай с ассорти из сушеных фруктов и ягод",price:"150 THB",image:"https://images.unsplash.com/photo-1571934811356-5cc061b6821f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["tea","hot"],popular:!1,category:"tea"},{id:64,name:"Тайский чай со льдом и молоком",description:"Традиционный тайский чай со сгущенным молоком и льдом",price:"150 THB",image:"https://images.unsplash.com/photo-1563503136947-cc262d2b48ac?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["tea","cold"],popular:!0,category:"tea"},{id:65,name:"Эспрессо",description:"Классический эспрессо из зерен арабики",price:"120 THB",image:"https://images.unsplash.com/photo-1596952953998-ac5212a0c6c4?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["coffee","hot"],popular:!1,category:"coffee"},{id:66,name:"Американо",description:"Эспрессо с добавлением горячей воды",price:"140 THB",image:"https://images.unsplash.com/photo-1551030173-122aabc4489c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["coffee","hot"],popular:!1,category:"coffee"},{id:67,name:"Капучино",description:"Эспрессо с добавлением взбитого молока",price:"150 THB",image:"https://images.unsplash.com/photo-1534778101976-62847782c213?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["coffee","hot"],popular:!0,category:"coffee"},{id:68,name:"Латте",description:"Эспрессо с добавлением стеамед молока",price:"160 THB",image:"https://images.unsplash.com/photo-1592318730259-6c7c6178e6c4?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["coffee","hot"],popular:!0,category:"coffee"},{id:69,name:"Мокко",description:"Эспрессо с добавлением горячего шоколада и взбитого молока",price:"180 THB",image:"https://images.unsplash.com/photo-1587080413959-06b859fb107d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["coffee","hot"],popular:!1,category:"coffee"},{id:70,name:"Айс латте",description:"Охлажденный кофе с молоком и льдом",price:"170 THB",image:"https://images.unsplash.com/photo-1517701604599-bb29b565090c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["coffee","cold"],popular:!0,category:"coffee"},{id:71,name:"Фраппе",description:"Холодный кофейный напиток с молочной пенкой",price:"170 THB",image:"https://images.unsplash.com/photo-1553909489-cd47e0907980?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["coffee","cold"],popular:!1,category:"coffee"},{id:72,name:"Смузи манго и маракуйя",description:"Свежий смузи из спелого манго и маракуйи",price:"190 THB",image:"https://images.unsplash.com/photo-1623065422902-30a2d299bbe4?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["smoothie","cold","healthy"],popular:!0,category:"smoothie"},{id:73,name:"Смузи клубника и банан",description:"Нежный смузи из свежей клубники и спелых бананов",price:"180 THB",image:"https://images.unsplash.com/photo-1638176067000-3e3935a51cc6?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["smoothie","cold","healthy"],popular:!0,category:"smoothie"},{id:74,name:"Смузи авокадо и шпинат",description:"Полезный смузи из спелого авокадо, шпината и зеленого яблока",price:"200 THB",image:"https://images.unsplash.com/photo-1638439430466-b9f5b7a267e4?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["smoothie","cold","healthy"],popular:!1,category:"smoothie"},{id:75,name:"Смузи черника и ацаи",description:"Смузи с насыщенным вкусом черники и ягод ацаи",price:"220 THB",image:"https://images.unsplash.com/photo-1589733955941-5eeaf752f6dd?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["smoothie","cold","healthy"],popular:!1,category:"smoothie"},{id:76,name:"Лимонад классический",description:"Освежающий напиток из свежих лимонов, мяты и тростникового сахара",price:"150 THB",image:"https://images.unsplash.com/photo-1523677011781-c91d1bbe2f9e?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["lemonade","cold"],popular:!0,category:"lemonade"},{id:77,name:"Лимонад малиновый",description:"Лимонад с добавлением свежей малины и мяты",price:"160 THB",image:"https://images.unsplash.com/photo-1560526860-1f0e56046c85?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["lemonade","cold"],popular:!1,category:"lemonade"},{id:78,name:"Лимонад имбирный",description:"Острый имбирный лимонад со свежим имбирем и медом",price:"160 THB",image:"https://images.unsplash.com/photo-1556679343-c1ffd81309ee?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["lemonade","cold"],popular:!1,category:"lemonade"},{id:79,name:"Лимонад из маракуйи",description:"Экзотический лимонад из свежей маракуйи",price:"170 THB",image:"https://images.unsplash.com/photo-1587888637140-849b25d80ef9?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["lemonade","cold"],popular:!0,category:"lemonade"},{id:80,name:"Сок апельсиновый",description:"Свежевыжатый апельсиновый сок",price:"180 THB",image:"https://images.unsplash.com/photo-1600271886742-f049cd451bba?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["juice","cold","healthy"],popular:!0,category:"juice"},{id:81,name:"Сок яблочный",description:"Свежевыжатый яблочный сок",price:"170 THB",image:"https://images.unsplash.com/photo-1576673442511-7e39b6545c87?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["juice","cold","healthy"],popular:!1,category:"juice"},{id:82,name:"Сок грейпфрутовый",description:"Свежевыжатый грейпфрутовый сок",price:"180 THB",image:"https://images.unsplash.com/photo-1621506289937-a8e4df240d0b?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["juice","cold","healthy"],popular:!1,category:"juice"},{id:83,name:"Сок ананасовый",description:"Свежевыжатый сок из спелого ананаса",price:"190 THB",image:"https://images.unsplash.com/photo-1587157708858-de748580439e?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["juice","cold","healthy"],popular:!0,category:"juice"},{id:84,name:"Сок морковный",description:"Свежевыжатый морковный сок",price:"160 THB",image:"https://images.unsplash.com/photo-1622597468620-656aa1327fcf?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["juice","cold","healthy"],popular:!1,category:"juice"},{id:85,name:'Фреш "Детокс"',description:"Смесь свежевыжатых соков из яблока, сельдерея, шпината и огурца",price:"220 THB",image:"https://images.unsplash.com/photo-1622597448366-b8e756fa58cc?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["juice","cold","healthy"],popular:!0,category:"juice"},{id:86,name:"Мохито",description:"Классический кубинский коктейль с белым ромом, лаймом, мятой и тростниковым сахаром",price:"290 THB",image:"https://images.unsplash.com/photo-1551024709-8f23befc6f87?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["cocktail","alcohol"],popular:!0,category:"cocktail"},{id:87,name:"Пина Колада",description:"Экзотический коктейль с белым ромом, кокосовым молоком и ананасовым соком",price:"320 THB",image:"https://images.unsplash.com/photo-1582400910504-897603b7be77?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["cocktail","alcohol"],popular:!0,category:"cocktail"},{id:88,name:"Маргарита",description:"Мексиканский коктейль с текилой, апельсиновым ликером и соком лайма",price:"290 THB",image:"https://images.unsplash.com/photo-1601887389937-0b02c26b602c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["cocktail","alcohol"],popular:!1,category:"cocktail"},{id:89,name:"Май Тай",description:"Тропический коктейль на основе рома с фруктовыми соками",price:"280 THB",image:"https://images.unsplash.com/photo-1563223771-5fe4038fbfc9?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["cocktail","alcohol"],popular:!1,category:"cocktail"},{id:90,name:"Блу Хавай",description:"Яркий голубой коктейль с текилой, голубым ликером и ананасовым соком",price:"320 THB",image:"https://images.unsplash.com/photo-1558927339-be1a5249a865?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["cocktail","alcohol"],popular:!0,category:"cocktail"},{id:91,name:"Огуречный спритц",description:"Освежающий коктейль из джина, свежего огурца и тоника",price:"290 THB",image:"https://images.unsplash.com/photo-1591952986314-aa4747f0daf6?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["cocktail","alcohol"],popular:!1,category:"cocktail"},{id:92,name:"Красное сухое вино Cabernet Sauvignon",description:"Итальянское красное сухое вино",price:"350 THB / 1750 THB",image:"https://images.unsplash.com/photo-1553361371-9fe24f4c1a04?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["wine","alcohol"],popular:!0,category:"wine"},{id:93,name:"Белое сухое вино Chardonnay",description:"Французское белое сухое вино",price:"350 THB / 1750 THB",image:"https://images.unsplash.com/photo-1582031726307-827be0ef729e?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["wine","alcohol"],popular:!0,category:"wine"},{id:94,name:"Розовое вино Pinot Noir",description:"Легкое французское розовое вино",price:"350 THB / 1750 THB",image:"https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["wine","alcohol"],popular:!1,category:"wine"},{id:95,name:"Игристое вино Prosecco",description:"Итальянское игристое вино",price:"2500 THB",image:"https://images.unsplash.com/photo-1576676754872-52bee930c919?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["wine","alcohol"],popular:!0,category:"wine"},{id:96,name:"Singha",description:"Тайское светлое пиво",price:"150 THB",image:"https://images.unsplash.com/photo-1600213903598-25be92abde40?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["beer","alcohol"],popular:!0,category:"beer"},{id:97,name:"Chang",description:"Тайское светлое пиво",price:"140 THB",image:"https://images.unsplash.com/photo-1600213903598-25be92abde40?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["beer","alcohol"],popular:!1,category:"beer"},{id:98,name:"Leo",description:"Тайское светлое пиво",price:"140 THB",image:"https://images.unsplash.com/photo-1600213903598-25be92abde40?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["beer","alcohol"],popular:!1,category:"beer"},{id:99,name:"Heineken",description:"Импортное светлое пиво",price:"180 THB",image:"https://images.unsplash.com/photo-1618885472179-5e474019f2a9?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["beer","alcohol"],popular:!0,category:"beer"},{id:100,name:"Водка Absolut",description:"Шведская водка (50 мл)",price:"240 THB",image:"https://images.unsplash.com/photo-1627736822334-544a9bff34d5?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["strong","alcohol"],popular:!1,category:"strong"},{id:101,name:"Виски Jack Daniel's",description:"Теннессийский виски (50 мл)",price:"290 THB",image:"https://images.unsplash.com/photo-1608293953848-715f452a57ba?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["strong","alcohol"],popular:!0,category:"strong"},{id:102,name:"Ром Bacardi",description:"Белый ром (50 мл)",price:"260 THB",image:"https://images.unsplash.com/photo-1514218853559-cf44500f7e83?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["strong","alcohol"],popular:!1,category:"strong"},{id:103,name:"Текила Jose Cuervo",description:"Мексиканская текила (50 мл)",price:"270 THB",image:"https://images.unsplash.com/photo-1522128418537-a497c66414d0?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",tags:["strong","alcohol"],popular:!0,category:"strong"}],a=[{id:1,image:"https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1740&q=80",title:e("restaurant.slider.slide1.title","Изысканная кухня"),description:e("restaurant.slider.slide1.description","Откройте для себя уникальные вкусы пяти разных кухонь мира в нашем ресторане")},{id:2,image:"https://images.unsplash.com/photo-1414235077428-338989a2e8c0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1740&q=80",title:e("restaurant.slider.slide2.title","Атмосфера комфорта"),description:e("restaurant.slider.slide2.description","Наслаждайтесь едой в уютной атмосфере с видом на тропический сад")},{id:3,image:"https://images.unsplash.com/photo-1424847651672-bf20a4b0982b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1740&q=80",title:e("restaurant.slider.slide3.title","Свежие ингредиенты"),description:e("restaurant.slider.slide3.description","Мы используем только свежие и качественные ингредиенты для приготовления наших блюд")}];return{menuItems:i,slides:a,tagStyles:{vegetarian:"bg-green-50 text-green-600",healthy:"bg-primary bg-opacity-10 text-primary",seafood:"bg-blue-50 text-blue-600",meat:"bg-red-50 text-red-600",grill:"bg-orange-50 text-orange-600",sweet:"bg-pink-50 text-pink-600",breakfast:"bg-indigo-50 text-indigo-600",dessert:"bg-purple-50 text-purple-600",drink:"bg-cyan-50 text-cyan-600",fruit:"bg-lime-50 text-lime-600",soup:"bg-amber-50 text-amber-600",cold:"bg-sky-50 text-sky-600",hot:"bg-orange-50 text-orange-600",salad:"bg-emerald-50 text-emerald-600",appetizer:"bg-violet-50 text-violet-600",grill:"bg-orange-50 text-orange-600",bbq:"bg-rose-50 text-rose-600",side:"bg-gray-50 text-gray-600",sauce:"bg-yellow-50 text-yellow-600",burger:"bg-red-50 text-red-600",shawarma:"bg-amber-50 text-amber-600",tea:"bg-green-50 text-green-600",coffee:"bg-brown-50 text-amber-800",cocktail:"bg-purple-50 text-purple-600",alcohol:"bg-rose-50 text-rose-600",wine:"bg-purple-50 text-purple-600",beer:"bg-yellow-50 text-yellow-600",popular:"bg-primary text-white"}}},Mk=w(O.div)`
  background-color: ${e=>e.theme.colors.background};
  color: ${e=>e.theme.colors.text.primary};
  min-height: 100vh;
  font-family: ${e=>e.theme.fonts.primary};
  overflow-x: hidden;
`;w.div`
  display: flex;
  justify-content: center;
  margin-bottom: 2rem;
  flex-wrap: wrap;
  gap: 0.5rem;
`;w(O.button)`
  padding: 0.75rem 1.5rem;
  border: none;
  background: ${e=>{var i,a,r;return e.active?((r=(a=(i=e.theme)==null?void 0:i.colors)==null?void 0:a.gradients)==null?void 0:r.logo)||"linear-gradient(135deg, rgba(255, 99, 71, 0.07) 0%, rgba(255, 99, 71, 0.10) 5%, rgba(206, 128, 114, 0.12) 12%, rgba(157, 157, 157, 0.15) 20%, rgba(108, 186, 200, 0.18) 28%, rgba(0, 180, 216, 0.20) 36%, rgba(71, 168, 203, 0.18) 44%, rgba(142, 157, 188, 0.15) 52%, rgba(214, 145, 173, 0.12) 60%, rgba(255, 105, 180, 0.10) 68%, rgba(219, 140, 149, 0.12) 76%, rgba(183, 175, 118, 0.15) 84%, rgba(147, 210, 95, 0.10) 92%, rgba(92, 184, 72, 0.07) 100%)":"#E0E8E1"}};
  color: ${e=>e.active?"white":"#333333"};
  font-weight: ${e=>e.active?"600":"500"};
  border-radius: 30px;
  cursor: pointer;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  transition: all 0.3s ease;
  font-family: 'Inter', sans-serif;
  
  &:hover {
    background-color: ${e=>e.active?"#D29B84":"#d0d8d1"};
    transform: translateY(-2px);
  }
  
  &:focus {
    outline: none;
  }
`;w(O.div)`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 2rem;
  margin-top: 2rem;
`;const Bk=w(O.div)`
  background-color: white;
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.05);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  cursor: pointer;
  
  &:hover {
    transform: translateY(-10px);
    box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
  }
`;w.div`
  height: 200px;
  background-color: #f0f0f0;
  background-size: cover;
  background-position: center;
  position: relative;
  
  &::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 50%;
    background: linear-gradient(to top, rgba(0, 0, 0, 0.5), transparent);
    opacity: 0;
    transition: opacity 0.3s ease;
  }
  
  ${Bk}:hover &::after {
    opacity: 1;
  }
`;w.div`
  padding: 1.5rem;
`;w.h3`
  font-size: 1.25rem;
  font-weight: 600;
  margin-bottom: 0.5rem;
  font-family: 'Playfair Display', serif;
  color: #333333;
`;w.p`
  font-size: 0.9rem;
  color: #666666;
  margin-bottom: 1rem;
  line-height: 1.5;
`;w.div`
  font-weight: 600;
  color: #D29B84;
  font-size: 1.1rem;
`;w.div`
  display: flex;
  gap: 0.5rem;
  margin-top: 1rem;
  flex-wrap: wrap;
`;w.span`
  font-size: 0.7rem;
  padding: 0.25rem 0.5rem;
  background-color: #f0f0f0;
  border-radius: 20px;
  color: #666666;
`;w(O.div)`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.7);
  z-index: 100;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 1rem;
  overflow-y: auto;
`;w(O.div)`
  background-color: white;
  border-radius: 16px;
  width: 100%;
  max-width: 900px;
  max-height: 90vh;
  overflow-y: auto;
  display: grid;
  grid-template-columns: 1fr;
  position: relative;
  
  @media (min-width: 768px) {
    grid-template-columns: 1fr 1fr;
  }
`;w.div`
  height: 300px;
  background-size: cover;
  background-position: center;
  
  @media (min-width: 768px) {
    height: 100%;
  }
`;w.div`
  padding: 2rem;
  display: flex;
  flex-direction: column;
`;w(O.p)`
  font-size: clamp(1rem, 2vw, 1.2rem);
  line-height: 1.8;
  color: ${e=>e.theme.colors.text.secondary};
  margin-bottom: 2.5rem;
  max-width: 530px;
  font-weight: 300;
`;w.h2`
  font-size: 1.75rem;
  font-weight: 700;
  margin-bottom: 1rem;
  font-family: 'Playfair Display', serif;
  color: #333333;
`;w.p`
  font-size: 1rem;
  color: #666666;
  margin-bottom: 1.5rem;
  line-height: 1.6;
`;w.div`
  font-weight: 600;
  color: #D29B84;
  font-size: 1.25rem;
  margin-bottom: 1.5rem;
`;w.div`
  margin-bottom: 1.5rem;
  
  h3 {
    font-size: 1.1rem;
    font-weight: 600;
    margin-bottom: 0.5rem;
    color: #333333;
  }
  
  ul {
    list-style-type: none;
    padding-left: 0;
  }
  
  li {
    padding: 0.25rem 0;
    font-size: 0.9rem;
    color: #666666;
    display: flex;
    align-items: center;
    
    &:before {
      content: '•';
      color: #D29B84;
      font-weight: bold;
      margin-right: 0.5rem;
    }
  }
`;w(O.button)`
  position: absolute;
  top: 1rem;
  right: 1rem;
  background-color: rgba(255, 255, 255, 0.8);
  border: none;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  z-index: 10;
  
  &:focus {
    outline: none;
  }
`;w.section`
  height: 100vh;
  min-height: 700px;
  position: relative;
  overflow: hidden;
  display: flex;
  align-items: center;
  background-color: ${e=>e.theme.colors.background};
  padding: 0;
  margin: 0;
`;w.div`
  width: 100%;
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 2rem;
  display: grid;
  grid-template-columns: 1fr;
  gap: 4rem;
  position: relative;
  z-index: 5;
  
  @media (min-width: 1024px) {
    grid-template-columns: 1fr 1fr;
    gap: 2rem;
  }
`;w(O.div)`
  width: 100%;
  height: 100%;
  background-size: cover;
  background-position: center;
  position: absolute;
  top: 0;
  left: 0;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
`;w(O.div)`
  position: relative;
  z-index: 10;
  height: 100%;
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
  padding: 0 20px;
  color: white;
`;w(O.button)`
  display: inline-flex;
  align-items: center;
  gap: 0.75rem;
  background-color: ${e=>e.theme.colors.primary};
  color: white;
  font-weight: 600;
  padding: 1rem 2rem;
  border-radius: 50px;
  border: none;
  cursor: pointer;
  font-size: 1.1rem;
  box-shadow: 0 10px 25px rgba(210, 155, 132, 0.3);
  transition: all 0.3s ease;
  
  &:hover {
    background-color: ${e=>e.theme.colors.accent||"#B08D57"};
    transform: translateY(-3px);
  }
  
  svg {
    width: 20px;
    height: 20px;
    transition: transform 0.3s ease;
  }
  
  &:hover svg {
    transform: translateX(5px);
  }
`;const zk=({activeCategory:e,setActiveCategory:i})=>{const{t:a}=De(),r=S.useRef(null),s=[{id:"all",name:a("restaurant.menu.categories.all","Все блюда")},{id:"breakfast",name:a("restaurant.menu.categories.breakfast","Breakfast")},{id:"lunch",name:a("restaurant.menu.categories.lunch","Обеды")},{id:"dinner",name:a("restaurant.menu.categories.dinner","Ужины")},{id:"soups",name:a("restaurant.menu.categories.soups","Супы")},{id:"salads",name:a("restaurant.menu.categories.salads","Салаты")},{id:"grill",name:a("restaurant.menu.categories.grill","Гриль")},{id:"garnish",name:a("restaurant.menu.categories.garnish","Гарниры")},{id:"sauces",name:a("restaurant.menu.categories.sauces","Соусы")},{id:"bread",name:a("restaurant.menu.categories.bread","Хлеб")},{id:"burgers",name:a("restaurant.menu.categories.burgers","Бургеры")},{id:"shawarma",name:a("restaurant.menu.categories.shawarma","Шаурма")},{id:"desserts",name:a("restaurant.menu.categories.desserts","Десерты")},{id:"tea",name:a("restaurant.menu.categories.tea","Чай")},{id:"coffee",name:a("restaurant.menu.categories.coffee","Кофе")},{id:"smoothies",name:a("restaurant.menu.categories.smoothies","Смузи")},{id:"lemonades",name:a("restaurant.menu.categories.lemonades","Лимонады")},{id:"juices",name:a("restaurant.menu.categories.juices","Соки")},{id:"cocktails",name:a("restaurant.menu.categories.cocktails","Коктейли")},{id:"wine",name:a("restaurant.menu.categories.wine","Вино")},{id:"beer",name:a("restaurant.menu.categories.beer","Пиво")},{id:"strong_alcohol",name:a("restaurant.menu.categories.strong_alcohol","Крепкий алкоголь")}];return S.useEffect(()=>{if(r.current){const c=r.current.querySelector(`[data-category="${e}"]`);if(c){const u=r.current,f=c.offsetLeft-u.clientWidth/2+c.clientWidth/2;u.scrollTo({left:f,behavior:"smooth"})}}},[e]),h.jsxs("div",{className:"relative mb-8",children:[h.jsx("div",{className:"absolute left-0 top-0 bottom-0 w-12 bg-gradient-to-r from-white to-transparent z-10 pointer-events-none"}),h.jsx(O.div,{ref:r,className:"flex overflow-x-auto pb-4 hide-scrollbar",initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{duration:.5},style:{scrollbarWidth:"none",msOverflowStyle:"none"},children:h.jsx("div",{className:"flex space-x-3 px-2",children:s.map(c=>h.jsx(O.button,{"data-category":c.id,className:`px-5 py-2.5 rounded-full text-sm whitespace-nowrap transition-all duration-300 ${e===c.id?"bg-primary text-white font-medium shadow-md":"bg-gray-50 text-gray-600 border border-gray-100 hover:bg-gray-100"}`,whileHover:{y:-2,scale:1.05},whileTap:{y:0,scale:.95},onClick:()=>i(c.id),children:c.name},c.id))})}),h.jsx("div",{className:"absolute right-0 top-0 bottom-0 w-12 bg-gradient-to-l from-white to-transparent z-10 pointer-events-none"})]})},$k=()=>{const{t:e}=De(),[i,a]=S.useState(0),[r,s]=S.useState("all"),[c,u]=S.useState(6),[f,p]=S.useState("default"),m=S.useRef(null),y=S.useRef(null),{menuItems:x,tagStyles:b}=Dk(e);S.useEffect(()=>{u(6)},[r]);const T=C=>{switch(f){case"popular":return[...C].sort((B,E)=>E.popular-B.popular);case"price_low":return[...C].sort((B,E)=>parseFloat(B.price.replace(/[^\d.]/g,""))-parseFloat(E.price.replace(/[^\d.]/g,"")));case"price_high":return[...C].sort((B,E)=>parseFloat(E.price.replace(/[^\d.]/g,""))-parseFloat(B.price.replace(/[^\d.]/g,"")));case"name":return[...C].sort((B,E)=>B.name.localeCompare(E.name));default:return C}},A=[{id:1,image:"https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1740&q=80",title:e("restaurant.slider.slide1.title","Изысканная кухня"),description:e("restaurant.slider.slide1.description","Откройте для себя уникальные вкусы пяти разных кухонь мира в нашем ресторане")},{id:2,image:"https://images.unsplash.com/photo-1414235077428-338989a2e8c0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1740&q=80",title:e("restaurant.slider.slide2.title","Атмосфера комфорта"),description:e("restaurant.slider.slide2.description","Наслаждайтесь едой в уютной атмосфере с видом на тропический сад")},{id:3,image:"https://images.unsplash.com/photo-1424847651672-bf20a4b0982b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1740&q=80",title:e("restaurant.slider.slide3.title","Свежие ингредиенты"),description:e("restaurant.slider.slide3.description","Мы используем только свежие и качественные ингредиенты для приготовления наших блюд")}];return S.useEffect(()=>(m.current=setInterval(()=>{a(C=>(C+1)%A.length)},5e3),()=>{m.current&&clearInterval(m.current)}),[A.length]),h.jsxs(Mk,{initial:{opacity:0},animate:{opacity:1},transition:{duration:.5},children:[h.jsxs("section",{className:"py-24 px-4 md:px-8 relative overflow-hidden",style:{position:"relative"},children:[h.jsx("div",{className:"absolute inset-0 z-0",style:{backgroundImage:"url('https://images.unsplash.com/photo-1552566626-52f8b828add9?ixlib=rb-1.2.1&auto=format&fit=crop&w=2070&q=80')",backgroundSize:"cover",backgroundPosition:"center",filter:"blur(8px) brightness(0.7)",transform:"scale(1.1)"}}),h.jsx("div",{className:"absolute inset-0 bg-gradient-to-r from-black/70 to-black/50"}),h.jsx(O.div,{className:"absolute top-20 right-20 w-64 h-64 rounded-full bg-primary opacity-5",animate:{scale:[1,1.2,1],rotate:[0,90,0]},transition:{duration:20,repeat:1/0,ease:"easeInOut"}}),h.jsx(O.div,{className:"absolute -bottom-20 -left-20 w-96 h-96 rounded-full bg-primary opacity-5",animate:{scale:[1,1.3,1],rotate:[0,-90,0]},transition:{duration:15,repeat:1/0,ease:"easeInOut",delay:2}}),h.jsxs("div",{className:"max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center min-h-[70vh] relative z-10",children:[h.jsxs(O.div,{initial:{opacity:0,x:-30},animate:{opacity:1,x:0},transition:{duration:.7},className:"bg-black bg-opacity-40 p-8 rounded-xl backdrop-blur-sm",children:[h.jsx("span",{className:"inline-block py-1 px-3 rounded-full bg-white bg-opacity-20 text-white text-sm font-medium mb-4 backdrop-blur-sm",children:e("restaurant.hero.label","Our Restaurant")}),h.jsxs("h1",{className:"text-4xl md:text-5xl font-bold font-playfair mb-6 leading-tight relative text-white",children:[e("restaurant.hero.title","Exquisite Cuisine")," ",h.jsx("span",{className:"text-primary",children:e("restaurant.hero.highlight","with a Modern Twist")}),h.jsx("div",{className:"w-24 h-1.5 bg-primary mt-6 rounded-full"})]}),h.jsx("p",{className:"text-lg text-white mb-8 max-w-lg",children:e("restaurant.hero.subtitle","Our chefs create unique dishes by combining traditional recipes with new culinary techniques.")}),h.jsxs(O.button,{whileHover:{scale:1.05},whileTap:{scale:.95},className:"inline-flex items-center gap-3 px-8 py-4 bg-primary text-white font-bold rounded-full shadow-lg hover:bg-opacity-90 transition-all duration-300 text-lg border-2 border-white",onClick:()=>{var C;(C=y.current)==null||C.scrollIntoView({behavior:"smooth"})},children:[h.jsx("span",{className:"text-xl",children:e("restaurant.hero.button","Наше меню")}),h.jsx(Sr,{className:"w-6 h-6"})]})]}),h.jsx(O.div,{initial:{opacity:0,x:30},animate:{opacity:1,x:0},transition:{duration:.7},className:"relative",children:h.jsxs("div",{className:"relative",children:[h.jsx("div",{className:"w-[400px] h-[400px] mx-auto rounded-full overflow-hidden border-8 border-white shadow-2xl",children:h.jsx("img",{src:"https://images.unsplash.com/photo-1546069901-ba9599a7e63c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",alt:"Elegant dish",className:"w-full h-full object-cover"})}),h.jsxs(O.div,{className:"absolute -bottom-6 -left-6 bg-white rounded-xl p-4 shadow-lg",initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.5,delay:.4},children:[h.jsxs("div",{className:"flex items-center gap-2",children:[h.jsx(ps,{className:"w-5 h-5 text-primary"}),h.jsx("p",{className:"font-medium",children:"4.9 (1.2k+)"})]}),h.jsx("p",{className:"text-sm text-gray-500",children:e("restaurant.hero.reviews","Excellent Reviews")})]}),h.jsxs(O.div,{className:"absolute -top-6 -right-6 bg-white rounded-xl p-4 shadow-lg",initial:{opacity:0,y:-20},animate:{opacity:1,y:0},transition:{duration:.5,delay:.6},children:[h.jsxs("div",{className:"flex items-center gap-2",children:[h.jsx(Tr,{className:"w-5 h-5 text-primary"}),h.jsxs("p",{className:"font-medium",children:["30-45 ",e("restaurant.hero.min","min")]})]}),h.jsx("p",{className:"text-sm text-gray-500",children:e("restaurant.hero.delivery","Delivery Time")})]}),h.jsx(O.div,{className:"absolute bottom-10 right-10 bg-primary text-white py-1.5 px-4 rounded-full text-sm font-medium shadow-lg",initial:{opacity:0,scale:.8},animate:{opacity:1,scale:1},transition:{duration:.5,delay:.7},children:e("restaurant.hero.featured","Featured")})]})})]})]}),h.jsxs("section",{ref:y,className:"py-20 px-4 md:px-8 max-w-7xl mx-auto",id:"menu-section",children:[h.jsxs(O.div,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.3},transition:{duration:.7},className:"text-center mb-12",children:[h.jsx("span",{className:"inline-block py-1 px-3 rounded-full bg-opacity-10 bg-primary text-primary text-sm font-medium mb-4",children:e("restaurant.menu.tag","Изысканные блюда")}),h.jsx("h2",{className:"text-3xl md:text-4xl font-bold font-playfair mb-6",children:e("restaurant.menu.title","Наше меню")}),h.jsx("p",{className:"text-lg text-gray-600 max-w-2xl mx-auto",children:e("restaurant.menu.description","Откройте для себя разнообразие вкусов в нашем меню, созданном талантливыми шеф-поварами")})]}),h.jsxs("div",{className:"mb-16",children:[h.jsx(zk,{activeCategory:r,setActiveCategory:s}),h.jsxs("div",{className:"flex flex-col md:flex-row justify-between items-center mt-8 mb-6",children:[h.jsxs("div",{className:"flex items-center gap-2 mb-4 md:mb-0",children:[h.jsx("span",{className:"inline-flex items-center justify-center w-8 h-8 bg-primary bg-opacity-10 rounded-full text-primary font-semibold text-sm",children:x.filter(C=>r==="all"||C.category===r).length}),h.jsx("p",{className:"text-gray-600 font-medium",children:e("restaurant.menu.items_available","доступных позиций")})]}),h.jsxs("div",{className:"flex items-center gap-4",children:[h.jsx("span",{className:"text-gray-600 font-medium text-sm md:text-base",children:e("restaurant.menu.sort_by","Сортировать:")}),h.jsxs("div",{className:"relative inline-block",children:[h.jsxs("select",{className:"appearance-none bg-transparent border-b border-gray-300 py-1 pl-1 pr-8 text-sm md:text-base focus:outline-none focus:border-primary transition-all duration-300",value:f,onChange:C=>p(C.target.value),children:[h.jsx("option",{value:"default",children:e("restaurant.menu.sort.default","По умолчанию")}),h.jsx("option",{value:"popular",children:e("restaurant.menu.sort.popular","Популярные")}),h.jsx("option",{value:"price_low",children:e("restaurant.menu.sort.price_low","Сначала дешёвые")}),h.jsx("option",{value:"price_high",children:e("restaurant.menu.sort.price_high","Сначала дорогие")}),h.jsx("option",{value:"name",children:e("restaurant.menu.sort.name","По алфавиту")})]}),h.jsx("div",{className:"pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-600",children:h.jsx("svg",{className:"w-4 h-4 fill-current",xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 20 20",children:h.jsx("path",{d:"M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"})})})]})]})]}),h.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-8",children:T(x.filter(C=>r==="all"||C.category===r)).slice(0,c).map((C,B)=>h.jsxs(O.div,{className:"bg-white rounded-2xl overflow-hidden shadow-lg",initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{duration:.5,delay:.1*(B%6)},whileHover:{y:-10},children:[h.jsxs("div",{className:"h-64 overflow-hidden relative",children:[h.jsx("img",{src:C.image,alt:C.name,className:"w-full h-full object-cover transition-transform duration-500 hover:scale-105"}),C.popular&&h.jsx("div",{className:"absolute top-4 left-4 bg-primary text-white text-xs font-bold px-2 py-1 rounded-full",children:e("restaurant.menu.popular","Popular")})]}),h.jsxs("div",{className:"p-6",children:[h.jsx("div",{className:"flex flex-wrap gap-2 mb-3",children:C.tags.map(E=>h.jsx("span",{className:`inline-block px-2 py-1 text-xs font-medium rounded-full ${b[E]||"bg-gray-50 text-gray-600"}`,children:e(`restaurant.menu.tags.${E}`,E.charAt(0).toUpperCase()+E.slice(1))},E))}),h.jsx("h3",{className:"text-xl font-bold mb-2 font-playfair",children:C.name}),h.jsx("p",{className:"text-gray-600 mb-4",children:C.description}),h.jsxs("div",{className:"flex justify-between items-center",children:[h.jsx("span",{className:"text-primary text-xl font-bold",children:C.price}),h.jsxs(O.button,{className:"flex items-center justify-center gap-2 px-3 py-2 bg-primary rounded-full text-white transition-all duration-300",whileHover:{scale:1.1},whileTap:{scale:.9},title:e("restaurant.menu.add_to_order","Добавить в заказ"),children:[h.jsx(yC,{className:"w-4 h-4"}),h.jsx("span",{className:"text-sm font-medium",children:e("restaurant.menu.add","Добавить")})]})]})]})]},C.id))}),x.filter(C=>r==="all"||C.category===r).length>c&&h.jsxs("div",{className:"text-center mt-8",children:[h.jsxs(O.button,{className:"inline-flex items-center gap-2 px-6 py-3 bg-primary text-white font-semibold rounded-full shadow-md hover:bg-opacity-90 transition-all duration-300",whileHover:{scale:1.05},whileTap:{scale:.95},onClick:()=>u(C=>C+6),children:[h.jsx("span",{className:"text-base font-medium",children:e("restaurant.menu.show_more","Показать еще")}),h.jsx(Qp,{className:"w-5 h-5"})]}),h.jsx("p",{className:"mt-2 text-gray-500 text-sm",children:e("restaurant.menu.showing_count","Показано {{visible}} из {{total}}",{visible:Math.min(c,x.filter(C=>r==="all"||C.category===r).length),total:x.filter(C=>r==="all"||C.category===r).length})})]}),h.jsxs("div",{className:"text-center mt-12",children:[h.jsxs(O.button,{className:"inline-flex items-center gap-2 px-8 py-4 bg-primary text-white font-semibold rounded-full shadow-lg border-2 border-white hover:bg-opacity-90 transition-all duration-300 relative z-10",whileHover:{scale:1.05},whileTap:{scale:.95},onClick:()=>{var C;(C=y.current)==null||C.scrollIntoView({behavior:"smooth"})},children:[h.jsx("span",{className:"text-base font-bold",children:e("restaurant.menu.view_all","Открыть полное меню")}),h.jsx(Sr,{className:"w-5 h-5"})]}),h.jsx("p",{className:"mt-2 text-gray-600 font-medium",children:e("restaurant.menu.navigation_hint","Нажмите, чтобы перейти к полному меню ресторана")})]})]})]}),h.jsxs("section",{className:"py-24 bg-gray-50 relative overflow-hidden",children:[h.jsx(O.div,{className:"absolute top-20 right-20 w-64 h-64 rounded-full bg-primary opacity-5",animate:{scale:[1,1.2,1],rotate:[0,90,0]},transition:{duration:20,repeat:1/0,ease:"easeInOut"}}),h.jsx(O.div,{className:"absolute bottom-20 left-20 w-40 h-40 rounded-full bg-primary opacity-5",animate:{scale:[1,1.3,1],rotate:[0,-90,0]},transition:{duration:15,repeat:1/0,ease:"easeInOut",delay:2}}),h.jsx("div",{className:"max-w-7xl mx-auto px-4 md:px-8 relative z-10",children:h.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-2 gap-12 items-center",children:[h.jsxs(O.div,{initial:{opacity:0,x:-30},whileInView:{opacity:1,x:0},viewport:{once:!0},transition:{duration:.7},children:[h.jsx("span",{className:"inline-block py-1 px-3 rounded-full bg-opacity-10 bg-primary text-primary text-sm font-medium mb-4",children:e("restaurant.booking.label","Бронирование")}),h.jsx("h2",{className:"text-3xl md:text-4xl font-bold font-playfair mb-6",children:e("restaurant.booking.title","Забронируйте стол в нашем ресторане")}),h.jsx("p",{className:"text-lg text-gray-600 mb-8",children:e("restaurant.booking.description","Заранее зарезервируйте столик для особого события или просто для гарантированного места в нашем ресторане.")}),h.jsxs("div",{className:"flex flex-col md:flex-row gap-6 mb-8",children:[h.jsxs("div",{className:"flex items-center gap-3",children:[h.jsx("div",{className:"w-10 h-10 rounded-full bg-primary bg-opacity-10 flex items-center justify-center",children:h.jsx(Tr,{className:"w-5 h-5 text-primary"})}),h.jsxs("div",{children:[h.jsx("p",{className:"font-medium",children:e("restaurant.booking.open_hours","Часы работы")}),h.jsx("p",{className:"text-gray-500 text-sm",children:"10:00 - 22:00"})]})]}),h.jsxs("div",{className:"flex items-center gap-3",children:[h.jsx("div",{className:"w-10 h-10 rounded-full bg-primary bg-opacity-10 flex items-center justify-center",children:h.jsx(Wi,{className:"w-5 h-5 text-primary"})}),h.jsxs("div",{children:[h.jsx("p",{className:"font-medium",children:e("restaurant.booking.reservation","Резервация")}),h.jsx("p",{className:"text-gray-500 text-sm",children:e("common.phone_number")})]})]})]}),h.jsxs("a",{href:"tel:+66624805877",className:"inline-flex items-center gap-2 px-8 py-3.5 bg-primary text-white font-semibold rounded-full shadow-md hover:bg-opacity-90 transition-all duration-300 text-lg",children:[e("restaurant.booking.call_now","Позвонить сейчас"),h.jsx(Wi,{className:"w-5 h-5"})]})]}),h.jsxs(O.div,{initial:{opacity:0,x:30},whileInView:{opacity:1,x:0},viewport:{once:!0},transition:{duration:.7},className:"relative",children:[h.jsxs("div",{className:"relative rounded-3xl overflow-hidden aspect-[4/3] shadow-xl",children:[h.jsx("img",{src:"https://images.unsplash.com/photo-1559329007-40df8a9345d8?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",alt:"Restaurant interior",className:"w-full h-full object-cover"}),h.jsx("div",{className:"absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"})]}),h.jsx(O.div,{className:"absolute -bottom-6 -left-6 bg-white rounded-2xl p-4 shadow-lg",initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{duration:.5,delay:.4},children:h.jsxs("div",{className:"flex items-center gap-4",children:[h.jsx("div",{className:"flex",children:[1,2,3,4,5].map(C=>h.jsx(ps,{className:"w-5 h-5 text-yellow-400"},C))}),h.jsx("div",{className:"h-6 w-px bg-gray-300"}),h.jsx("p",{className:"font-medium",children:"4.9 (2.5k+)"})]})})]})]})})]})]})},Nk=w.section`
  position: relative;
  min-height: 100vh;
  background: linear-gradient(135deg, 
    #fcfaf8 0%,
    #f7f4f0 60%,
    #f4f0eb 100%
  );
  overflow: hidden;
  display: flex;
  align-items: center;
  padding: 6rem 0;
`,Lk=w.div`
  position: relative;
  z-index: 10;
  width: 100%;
  max-width: 1500px;
  margin: 0 auto;
  padding: 0 1.5rem;
  
  @media (min-width: 768px) {
    padding: 0 2rem;
  }
  
  @media (min-width: 1280px) {
    padding: 0 3rem;
  }
`,_k=w.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 4rem;
  align-items: center;
  position: relative;
  z-index: 2;
  
  @media (min-width: 1024px) {
    grid-template-columns: 1fr 1fr;
    gap: 2rem;
  }
`,Hk=w(O.div)`
  position: relative;
  text-align: left;
  max-width: 600px;
  z-index: 10;
  
  @media (max-width: 1023px) {
    text-align: center;
    margin: 0 auto;
  }
`,Vk=w(O.div)`
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.75rem 1.5rem;
  background: rgba(212, 165, 116, 0.1);
  border: 1px solid rgba(212, 165, 116, 0.2);
  border-radius: 30px;
  font-size: 0.875rem;
  font-weight: 500;
  color: #8A6C55;
  margin-bottom: 2rem;
  
  svg {
    width: 1rem;
    height: 1rem;
    color: #D4A574;
  }
`,Pk=w(O.h1)`
  font-size: clamp(2.75rem, 7vw, 4.5rem);
  font-weight: 600;
  line-height: 1.1;
  margin-bottom: 1.5rem;
  color: #5A6B5D;
`,Fk=w(O.h2)`
  font-size: clamp(1.125rem, 2.5vw, 1.5rem);
  font-weight: 400;
  line-height: 1.4;
  margin-bottom: 2rem;
  color: #7A8A7D;
`,Uk=w(O.p)`
  font-size: 1.125rem;
  line-height: 1.7;
  color: #6B7B6E;
  margin-bottom: 3rem;
  max-width: 480px;
`,qk=w(O.div)`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  
  @media (min-width: 640px) {
    flex-direction: row;
    gap: 1.5rem;
  }
`,Ik=w(O.button)`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  padding: 1rem 2rem;
  background: linear-gradient(135deg, #90B3A7 0%, #7A8A7D 100%);
  color: white;
  border: none;
  border-radius: 50px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  
  svg {
    width: 1.25rem;
    height: 1.25rem;
  }
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(144, 179, 167, 0.3);
  }
`,Yk=w(O.button)`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  padding: 1rem 2rem;
  background: transparent;
  color: #5A6B5D;
  border: 2px solid #90B3A7;
  border-radius: 50px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  
  svg {
    width: 1.25rem;
    height: 1.25rem;
  }
  
  &:hover {
    background: #90B3A7;
    color: white;
  }
`,Gk=w(O.div)`
  position: relative;
  min-height: 400px;
  background: linear-gradient(135deg, 
    rgba(144, 179, 167, 0.1) 0%, 
    rgba(212, 165, 116, 0.1) 100%
  );
  border-radius: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  padding: 3rem 2rem;
  
  @media (max-width: 1023px) {
    min-height: 300px;
    padding: 2rem 1rem;
  }
`,Kk=w(O.div)`
  width: 6rem;
  height: 6rem;
  background: linear-gradient(135deg, #90B3A7 0%, #D4A574 100%);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 1.5rem;
  
  svg {
    width: 3rem;
    height: 3rem;
    color: white;
  }
`,Xk=w.h3`
  font-size: 1.5rem;
  font-weight: 600;
  color: #5A6B5D;
  margin-bottom: 1rem;
`,Zk=w.p`
  font-size: 1rem;
  color: #7A8A7D;
  max-width: 300px;
`,k2=S.memo(()=>{const{t:e}=De();return h.jsx(Nk,{children:h.jsx(Lk,{children:h.jsxs(_k,{children:[h.jsxs(Hk,{initial:{opacity:0,y:30},animate:{opacity:1,y:0},transition:{duration:.6,delay:.2},children:[h.jsxs(Vk,{initial:{opacity:0,scale:.9},animate:{opacity:1,scale:1},transition:{duration:.5,delay:.3},children:[h.jsx(Uc,{}),e("spa.hero.badge","Премиум СПА")]}),h.jsx(Pk,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.6,delay:.4},children:e("spa.hero.title","Погрузитесь в мир релаксации и красоты")}),h.jsx(Fk,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.6,delay:.5},children:e("spa.hero.subtitle","Профессиональные СПА процедуры в роскошной атмосфере KAIF")}),h.jsx(Uk,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.6,delay:.6},children:e("spa.hero.description","Откройте для себя широкий спектр релаксирующих процедур, массажей и beauty-услуг, созданных для вашего полного комфорта и восстановления.")}),h.jsxs(qk,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.6,delay:.7},children:[h.jsxs(Ik,{whileHover:{scale:1.02},whileTap:{scale:.98},children:[e("spa.hero.book_now","Записаться на процедуру"),h.jsx(Sr,{})]}),h.jsx(Yk,{whileHover:{scale:1.02},whileTap:{scale:.98},children:e("spa.hero.learn_more","Узнать больше")})]})]}),h.jsxs(Gk,{initial:{opacity:0,x:30},animate:{opacity:1,x:0},transition:{duration:.6,delay:.4},children:[h.jsx(Kk,{initial:{scale:0},animate:{scale:1},transition:{duration:.5,delay:.8},children:h.jsx(Jp,{})}),h.jsx(Xk,{children:e("spa.hero.experience_title","Уникальный опыт")}),h.jsx(Zk,{children:e("spa.hero.experience_text","Профессиональные мастера, премиальная косметика и индивидуальный подход к каждому гостю")})]})]})})})});k2.displayName="SpaHeroSection";const Qk=w.section`
  padding: 8rem 2rem;
  background: linear-gradient(135deg, 
    #fdfcfb 0%,
    #f5f3f0 50%,
    #ede9e4 100%
  );
  position: relative;
`,Jk=w.div`
  max-width: 1400px;
  margin: 0 auto;
  position: relative;
`,Wk=w(O.h2)`
  font-size: clamp(2.2rem, 4vw, 3.2rem);
  color: #5A6B5D;
  text-align: center;
  margin-bottom: 1.5rem;
  font-weight: 600;
`,eD=w(O.p)`
  font-size: clamp(1.05rem, 2vw, 1.25rem);
  color: #7A8A7D;
  text-align: center;
  max-width: 700px;
  margin: 2.5rem auto 4.5rem auto;
  line-height: 1.8;
  font-weight: 400;
`,tD=w.div`
  display: flex;
  justify-content: center;
  margin-bottom: 5rem;
  flex-wrap: wrap;
  gap: 1rem;
  max-width: 800px;
  margin-left: auto;
  margin-right: auto;
`,Cb=w(O.button)`
  padding: 1rem 2.5rem;
  border: none;
  background-color: ${e=>e.active?"#90B3A7":"rgba(255, 255, 255, 0.7)"};
  color: ${e=>e.active?"white":"#5A6B5D"};
  border: 1px solid ${e=>e.active?"transparent":"rgba(144, 179, 167, 0.2)"};
  border-radius: 50px;
  font-weight: ${e=>e.active?"600":"500"};
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 1rem;
  
  &:hover {
    background-color: #90B3A7;
    color: white;
    transform: translateY(-1px);
  }
`,iD=w(O.div)`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
  gap: 2.5rem;
  max-width: 1400px;
  margin: 0 auto;
  
  @media (min-width: 1280px) {
    grid-template-columns: repeat(3, 1fr);
  }
`,nD=w(O.div)`
  background: rgba(255, 255, 255, 0.9);
  border-radius: 25px;
  overflow: hidden;
  box-shadow: 0 10px 30px rgba(144, 179, 167, 0.08);
  transition: all 0.3s ease;
  height: 100%;
  display: flex;
  flex-direction: column;
  border: 1px solid rgba(144, 179, 167, 0.1);
  
  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 20px 40px rgba(144, 179, 167, 0.15);
  }
`,aD=w.div`
  height: 200px;
  background: ${e=>e.bgColor||"linear-gradient(135deg, #90B3A7 0%, #B8C4A8 100%)"};
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 4rem;
  color: white;
  
  @media (max-width: 768px) {
    height: 150px;
    font-size: 3rem;
  }
`,rD=w.div`
  padding: 2rem;
  flex: 1;
  display: flex;
  flex-direction: column;
`,oD=w.h3`
  font-size: 1.5rem;
  font-weight: 600;
  color: #5A6B5D;
  margin-bottom: 1rem;
`,sD=w.p`
  color: #7A8A7D;
  line-height: 1.6;
  margin-bottom: 1.5rem;
  flex: 1;
`,lD=w.div`
  font-size: 1.25rem;
  font-weight: 600;
  color: #90B3A7;
  margin-bottom: 1rem;
`,cD=w(O.button)`
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.75rem 1.5rem;
  background: transparent;
  color: #90B3A7;
  border: 2px solid #90B3A7;
  border-radius: 25px;
  cursor: pointer;
  font-weight: 500;
  transition: all 0.3s ease;
  align-self: flex-start;
  
  svg {
    width: 1rem;
    height: 1rem;
  }
  
  &:hover {
    background: #90B3A7;
    color: white;
  }
`,uD=()=>{const{t:e}=De(),[i,a]=S.useState("spa"),c=i==="spa"?[{icon:"🌿",title:"Тайский массаж",description:"Традиционный тайский массаж для полного расслабления и восстановления энергии",price:"от 3,500 ฿",bgColor:"linear-gradient(135deg, #90B3A7 0%, #B8C4A8 100%)"},{icon:"🧘‍♀️",title:"Ароматерапия",description:"Расслабляющий массаж с использованием натуральных эфирных масел",price:"от 4,000 ฿",bgColor:"linear-gradient(135deg, #D4A574 0%, #E6B885 100%)"},{icon:"♨️",title:"Финская сауна",description:"Традиционная сухая сауна для детоксикации и укрепления иммунитета",price:"от 2,000 ฿",bgColor:"linear-gradient(135deg, #A8B8A8 0%, #C0D0C0 100%)"},{icon:"🛁",title:"Турецкий хаммам",description:"Паровая баня с пилингом и расслабляющими процедурами",price:"от 2,500 ฿",bgColor:"linear-gradient(135deg, #90B3A7 0%, #A0C3B7 100%)"},{icon:"🏊‍♀️",title:"Бассейн",description:"Просторный бассейн с подогревом для плавания и водных процедур",price:"от 1,500 ฿",bgColor:"linear-gradient(135deg, #7A9FAF 0%, #8AAFBF 100%)"},{icon:"🛀",title:"Джакузи",description:"Гидромассажная ванна с пузырьками для максимального расслабления",price:"от 2,200 ฿",bgColor:"linear-gradient(135deg, #B8A8C8 0%, #C8B8D8 100%)"}]:[{icon:"✂️",title:"Стрижки и укладки",description:"Профессиональные стрижки и стайлинг от опытных мастеров",price:"от 2,500 ฿",bgColor:"linear-gradient(135deg, #E8A87C 0%, #F8B88C 100%)"},{icon:"🎨",title:"Окрашивание волос",description:"Современные техники окрашивания премиальными красителями",price:"от 4,500 ฿",bgColor:"linear-gradient(135deg, #D4A574 0%, #E4B584 100%)"},{icon:"💅",title:"Маникюр",description:"Классический и аппаратный маникюр с покрытием гель-лак",price:"от 1,800 ฿",bgColor:"linear-gradient(135deg, #F0A0B0 0%, #FFB0C0 100%)"},{icon:"🦶",title:"Педикюр",description:"Профессиональный педикюр с уходовыми процедурами",price:"от 2,200 ฿",bgColor:"linear-gradient(135deg, #A0C8F0 0%, #B0D8FF 100%)"},{icon:"✨",title:"Уход за лицом",description:"Комплексные процедуры для сияния и молодости кожи",price:"от 3,500 ฿",bgColor:"linear-gradient(135deg, #C8D8A8 0%, #D8E8B8 100%)"}];return h.jsx(Qk,{children:h.jsxs(Jk,{children:[h.jsx(Wk,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},transition:{duration:.6},viewport:{once:!0},children:e("spa.services.title","Наши услуги")}),h.jsx(eD,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},transition:{duration:.6,delay:.2},viewport:{once:!0},children:e("spa.services.subtitle","Широкий спектр SPA процедур и beauty услуг для вашего комфорта и красоты")}),h.jsxs(tD,{children:[h.jsx(Cb,{active:i==="spa",onClick:()=>a("spa"),whileHover:{scale:1.02},whileTap:{scale:.98},children:"SPA процедуры"}),h.jsx(Cb,{active:i==="beauty",onClick:()=>a("beauty"),whileHover:{scale:1.02},whileTap:{scale:.98},children:"Beauty услуги"})]}),h.jsx(iD,{initial:{opacity:0},whileInView:{opacity:1},transition:{duration:.6},viewport:{once:!0},children:c.map((u,f)=>h.jsxs(nD,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},transition:{duration:.5,delay:f*.1},viewport:{once:!0},whileHover:{scale:1.02},children:[h.jsx(aD,{bgColor:u.bgColor,children:u.icon}),h.jsxs(rD,{children:[h.jsx(oD,{children:u.title}),h.jsx(sD,{children:u.description}),h.jsx(lD,{children:u.price}),h.jsxs(cD,{whileHover:{scale:1.05},whileTap:{scale:.95},children:["Записаться",h.jsx(C2,{})]})]})]},`${i}-${f}`))})]})})},dD=w.section`
  padding: 8rem 2rem;
  background: linear-gradient(135deg, 
    #f5f3f0 0%,
    #ede9e4 50%,
    #e6e2dc 100%
  );
  position: relative;
`,fD=w.div`
  max-width: 1400px;
  margin: 0 auto;
  position: relative;
`,hD=w(O.h2)`
  font-size: clamp(2.2rem, 4vw, 3.2rem);
  color: #5A6B5D;
  text-align: center;
  margin-bottom: 1.5rem;
  font-weight: 600;
`,pD=w(O.p)`
  font-size: clamp(1.05rem, 2vw, 1.25rem);
  color: #7A8A7D;
  text-align: center;
  max-width: 700px;
  margin: 2.5rem auto 4.5rem auto;
  line-height: 1.8;
  font-weight: 400;
`,mD=w.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 2.5rem;
  max-width: 1200px;
  margin: 4rem auto 0;
  
  @media (min-width: 992px) {
    grid-template-columns: repeat(4, 1fr);
  }
`,D2=w(O.div)`
  background: rgba(255, 255, 255, 0.8);
  padding: 2.5rem 2rem;
  border-radius: 25px;
  box-shadow: 0 10px 30px rgba(144, 179, 167, 0.08);
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  transition: all 0.3s ease;
  border: 1px solid rgba(144, 179, 167, 0.1);
  
  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 20px 40px rgba(144, 179, 167, 0.15);
  }
`,gD=w.div`
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background: linear-gradient(135deg, rgba(144, 179, 167, 0.15) 0%, rgba(184, 196, 168, 0.15) 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 1.5rem;
  color: #90B3A7;
  transition: all 0.3s ease;
  
  &:hover {
    background: linear-gradient(135deg, rgba(144, 179, 167, 0.25) 0%, rgba(184, 196, 168, 0.25) 100%);
    transform: scale(1.05);
  }
  
  svg {
    width: 36px;
    height: 36px;
  }
`,yD=w.h3`
  font-size: 1.4rem;
  font-weight: 600;
  margin-bottom: 1rem;
  color: #5A6B5D;
  transition: color 0.3s ease;
  
  ${D2}:hover & {
    color: #90B3A7;
  }
`,xD=w.p`
  font-size: 1rem;
  line-height: 1.6;
  color: #7A8A7D;
  margin-bottom: 0;
  font-weight: 400;
`,bD=()=>{const{t:e}=De(),i=[{id:1,icon:h.jsx(Ut,{}),title:"Премиум качество",description:"Используем только лучшие продукты и оборудование для всех процедур"},{id:2,icon:h.jsx(QO,{}),title:"Полное расслабление",description:"Создаем атмосферу комфорта для вашего расслабления и отдыха"},{id:3,icon:h.jsx(lc,{}),title:"Опытные мастера",description:"Специалисты с многолетним опытом и постоянным развитием навыков"},{id:4,icon:h.jsx(aR,{}),title:"Индивидуальный подход",description:"Учитываем ваши пожелания и особенности для максимального результата"}];return h.jsx(dD,{children:h.jsxs(fD,{children:[h.jsx(hD,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},transition:{duration:.6},viewport:{once:!0},children:e("spa.features.title","Почему выбирают нас")}),h.jsx(pD,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},transition:{duration:.6,delay:.2},viewport:{once:!0},children:e("spa.features.subtitle","Мы стремимся предоставить вам исключительный опыт релаксации и ухода")}),h.jsx(mD,{children:i.map((a,r)=>h.jsxs(D2,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},transition:{duration:.5,delay:r*.1},viewport:{once:!0},whileHover:{scale:1.02},children:[h.jsx(gD,{children:a.icon}),h.jsx(yD,{children:a.title}),h.jsx(xD,{children:a.description})]},a.id))})]})})},vD=w.section`
  padding: 8rem 2rem;
  background: linear-gradient(135deg, 
    #fdfcfb 0%,
    #f8f6f3 100%
  );
  position: relative;
`,wD=w.div`
  max-width: 1200px;
  margin: 0 auto;
  position: relative;
`,SD=w(O.h2)`
  font-size: clamp(2.2rem, 4vw, 3.2rem);
  color: #5A6B5D;
  text-align: center;
  margin-bottom: 1.5rem;
  font-weight: 600;
`,TD=w(O.p)`
  font-size: clamp(1.05rem, 2vw, 1.25rem);
  color: #7A8A7D;
  text-align: center;
  max-width: 700px;
  margin: 2.5rem auto 4.5rem auto;
  line-height: 1.8;
  font-weight: 400;
`,jD=w.div`
  position: relative;
  max-width: 800px;
  margin: 0 auto;
`,AD=w(O.div)`
  background: rgba(255, 255, 255, 0.9);
  padding: 3rem 2.5rem;
  border-radius: 25px;
  box-shadow: 0 15px 40px rgba(144, 179, 167, 0.1);
  text-align: center;
  margin: 0 1rem;
  border: 1px solid rgba(144, 179, 167, 0.05);
`,ED=w.div`
  display: flex;
  justify-content: center;
  gap: 0.5rem;
  margin-bottom: 2rem;
`,CD=w(ps)`
  width: 24px;
  height: 24px;
  color: #D4A574;
`,OD=w.p`
  font-size: 1.25rem;
  line-height: 1.7;
  color: #5A6B5D;
  margin-bottom: 2rem;
  font-style: italic;
`,RD=w.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
`,kD=w.h4`
  font-size: 1.1rem;
  font-weight: 600;
  color: #5A6B5D;
  margin: 0;
`,DD=w.p`
  font-size: 0.95rem;
  color: #7A8A7D;
  margin: 0;
`,MD=w.div`
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 2rem;
  margin-top: 3rem;
`,Ob=w(O.button)`
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background: rgba(144, 179, 167, 0.1);
  border: 2px solid rgba(144, 179, 167, 0.2);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.3s ease;
  
  svg {
    width: 20px;
    height: 20px;
    color: #90B3A7;
  }
  
  &:hover {
    background: #90B3A7;
    border-color: #90B3A7;
    
    svg {
      color: white;
    }
  }
  
  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`,BD=w.div`
  display: flex;
  gap: 0.75rem;
`,zD=w(O.button)`
  width: 12px;
  height: 12px;
  border-radius: 50%;
  border: none;
  background: ${e=>e.active?"#90B3A7":"rgba(144, 179, 167, 0.3)"};
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    background: #90B3A7;
  }
`,$D=()=>{const{t:e}=De(),[i,a]=S.useState(0),r=[{id:1,text:"Потрясающий опыт! Тайский массаж был невероятно расслабляющим, а атмосфера просто волшебная. Обязательно вернусь снова.",author:"Анна Петрова",title:"Постоянный клиент",rating:5},{id:2,text:"Профессиональные мастера, качественные процедуры и внимание к деталям. Это лучший СПА центр, который я посещала в Пхукете.",author:"Екатерина Сидорова",title:"Гость из Москвы",rating:5},{id:3,text:"Прекрасное место для отдыха и восстановления. Особенно понравилась финская сауна и джакузи. Рекомендую всем!",author:"Михаил Волков",title:"Резидент KAIF",rating:5}],s=()=>{a(u=>(u+1)%r.length)},c=()=>{a(u=>(u-1+r.length)%r.length)};return h.jsx(vD,{children:h.jsxs(wD,{children:[h.jsx(SD,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},transition:{duration:.6},viewport:{once:!0},children:e("spa.testimonials.title","Отзывы наших гостей")}),h.jsx(TD,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},transition:{duration:.6,delay:.2},viewport:{once:!0},children:e("spa.testimonials.subtitle","Узнайте, что говорят о нас наши довольные клиенты")}),h.jsxs(jD,{children:[h.jsxs(AD,{initial:{opacity:0,x:50},animate:{opacity:1,x:0},exit:{opacity:0,x:-50},transition:{duration:.5},children:[h.jsx(ED,{children:[...Array(r[i].rating)].map((u,f)=>h.jsx(CD,{},f))}),h.jsxs(OD,{children:['"',r[i].text,'"']}),h.jsxs(RD,{children:[h.jsx(kD,{children:r[i].author}),h.jsx(DD,{children:r[i].title})]})]},i),h.jsxs(MD,{children:[h.jsx(Ob,{onClick:c,whileHover:{scale:1.05},whileTap:{scale:.95},children:h.jsx(tC,{})}),h.jsx(BD,{children:r.map((u,f)=>h.jsx(zD,{active:i===f,onClick:()=>a(f),whileHover:{scale:1.2},whileTap:{scale:.9}},f))}),h.jsx(Ob,{onClick:s,whileHover:{scale:1.05},whileTap:{scale:.95},children:h.jsx(Qp,{})})]})]})]})})},ND=w.section`
  padding: 8rem 2rem;
  background: linear-gradient(135deg, 
    #ede9e4 0%,
    #e6e2dc 50%,
    #ddd8d0 100%
  );
  position: relative;
  overflow: hidden;
`,LD=w.div`
  position: absolute;
  width: 100%;
  height: 100%;
  overflow: hidden;
  z-index: 1;
`,Rb=w(O.div)`
  position: absolute;
  border-radius: 50%;
  background: ${e=>e.$color};
  filter: blur(40px);
  opacity: 0.5;
`,_D=w.div`
  max-width: 1400px;
  margin: 0 auto;
  position: relative;
  z-index: 10;
`,HD=w(O.h2)`
  font-family: ${e=>{var i,a;return((a=(i=e.theme)==null?void 0:i.fonts)==null?void 0:a.elegant)||'"Playfair Display", serif'}};
  font-size: clamp(2.2rem, 4vw, 3.2rem);
  background: linear-gradient(135deg, #5A6B5D 0%, #7A8A7D 50%, #90B3A7 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  text-align: center;
  margin-bottom: 1.5rem;
  font-weight: 600;
  position: relative;
  display: inline-block;
  width: 100%;
`,VD=w(O.p)`
  font-size: clamp(1.05rem, 2vw, 1.25rem);
  color: #7A8A7D;
  text-align: center;
  max-width: 700px;
  margin: 2.5rem auto 4.5rem auto;
  line-height: 1.8;
  font-weight: 400;
`,PD=w(O.div)`
  background: rgba(255, 255, 255, 0.8);
  border-radius: 30px;
  padding: 3.5rem;
  max-width: 800px;
  margin: 0 auto;
  box-shadow: 0 20px 60px rgba(144, 179, 167, 0.12);
  position: relative;
  overflow: hidden;
  backdrop-filter: blur(20px);
  border: 1px solid rgba(144, 179, 167, 0.1);
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 4px;
    background: linear-gradient(90deg, #90B3A7, #B8C4A8);
  }
  
  @media (max-width: 768px) {
    padding: 2.5rem 1.5rem;
  }
`,FD=w.p`
  text-align: center;
  color: #6B7B6E;
  margin-bottom: 2.5rem;
  font-size: 1.1rem;
  line-height: 1.8;
  font-weight: 400;
`,UD=w.div`
  display: flex;
  justify-content: center;
  gap: 1.5rem;
  flex-wrap: wrap;
`,qD=w(O.a)`
  display: inline-flex;
  align-items: center;
  gap: 0.75rem;
  background: linear-gradient(135deg, #90B3A7 0%, #B8C4A8 100%);
  color: white;
  font-weight: 600;
  padding: 1.2rem 2.5rem;
  border-radius: 50px;
  border: none;
  cursor: pointer;
  font-size: 1.1rem;
  box-shadow: 0 10px 25px rgba(144, 179, 167, 0.3);
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
  z-index: 1;
  text-decoration: none;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 0%;
    height: 100%;
    background: linear-gradient(135deg, #7A8A7D 0%, #90B3A7 100%);
    transition: width 0.4s ease;
    z-index: -1;
  }
  
  &:hover {
    box-shadow: 0 15px 35px rgba(144, 179, 167, 0.4);
    transform: translateY(-2px);
    color: white;
  }
  
  &:hover::before {
    width: 100%;
  }
  
  svg {
    width: 20px;
    height: 20px;
    transition: transform 0.3s ease;
  }
  
  &:hover svg {
    transform: translateX(3px);
  }
`,ID=w(O.a)`
  display: inline-flex;
  align-items: center;
  gap: 0.75rem;
  background: rgba(255, 255, 255, 0.8);
  color: #5A6B5D;
  font-weight: 600;
  padding: 1.2rem 2.5rem;
  border-radius: 50px;
  border: 2px solid rgba(144, 179, 167, 0.3);
  cursor: pointer;
  font-size: 1.1rem;
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
  z-index: 1;
  text-decoration: none;
  backdrop-filter: blur(10px);
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 0%;
    height: 100%;
    background: linear-gradient(135deg, #90B3A7 0%, #B8C4A8 100%);
    transition: width 0.4s ease;
    z-index: -1;
  }
  
  &:hover {
    color: white;
    transform: translateY(-2px);
    border-color: rgba(144, 179, 167, 0.5);
    box-shadow: 0 10px 25px rgba(144, 179, 167, 0.2);
  }
  
  &:hover::before {
    width: 100%;
  }
  
  svg {
    width: 20px;
    height: 20px;
    transition: transform 0.3s ease;
  }
  
  &:hover svg {
    transform: translateX(3px);
  }
`,YD=()=>{const{t:e}=De(),i={initial:{y:0},animate:{y:[-8,8,-8],transition:{duration:6,repeat:1/0,ease:"easeInOut"}}};return h.jsxs(ND,{children:[h.jsxs(LD,{children:[h.jsx(Rb,{$color:"linear-gradient(135deg, rgba(144, 179, 167, 0.08) 0%, rgba(184, 196, 168, 0.08) 100%)",style:{width:"200px",height:"200px",top:"20%",left:"15%"},variants:i,initial:"initial",animate:"animate"}),h.jsx(Rb,{$color:"linear-gradient(135deg, rgba(184, 196, 168, 0.06) 0%, rgba(144, 179, 167, 0.06) 100%)",style:{width:"150px",height:"150px",bottom:"25%",right:"20%"},variants:i,initial:"initial",animate:"animate",transition:{delay:3}})]}),h.jsxs(_D,{children:[h.jsx(HD,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.3},transition:{duration:.7},children:"Записаться на процедуру"}),h.jsx(VD,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.3},transition:{duration:.7,delay:.2},children:"Забронируйте SPA-процедуру или услугу салона красоты для полного расслабления"}),h.jsxs(PD,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{duration:.7},children:[h.jsx(FD,{children:"Онлайн-бронирование скоро будет доступно. Пока что, пожалуйста, позвоните нам для записи или отправьте сообщение в WhatsApp."}),h.jsxs(UD,{children:[h.jsxs(qD,{href:"tel:+66624805877",whileHover:{scale:1.03},whileTap:{scale:.97},children:[h.jsx(Wi,{}),"+66 62 480 5877"]}),h.jsxs(ID,{href:"https://wa.me/66624805877",target:"_blank",rel:"noopener noreferrer",whileHover:{scale:1.03},whileTap:{scale:.97},children:["WhatsApp",h.jsx(Qp,{})]})]})]})]})]})};var M2={color:void 0,size:void 0,className:void 0,style:void 0,attr:void 0},kb=Ce.createContext&&Ce.createContext(M2),GD=["attr","size","title"];function KD(e,i){if(e==null)return{};var a=XD(e,i),r,s;if(Object.getOwnPropertySymbols){var c=Object.getOwnPropertySymbols(e);for(s=0;s<c.length;s++)r=c[s],!(i.indexOf(r)>=0)&&Object.prototype.propertyIsEnumerable.call(e,r)&&(a[r]=e[r])}return a}function XD(e,i){if(e==null)return{};var a={};for(var r in e)if(Object.prototype.hasOwnProperty.call(e,r)){if(i.indexOf(r)>=0)continue;a[r]=e[r]}return a}function Ac(){return Ac=Object.assign?Object.assign.bind():function(e){for(var i=1;i<arguments.length;i++){var a=arguments[i];for(var r in a)Object.prototype.hasOwnProperty.call(a,r)&&(e[r]=a[r])}return e},Ac.apply(this,arguments)}function Db(e,i){var a=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);i&&(r=r.filter(function(s){return Object.getOwnPropertyDescriptor(e,s).enumerable})),a.push.apply(a,r)}return a}function Ec(e){for(var i=1;i<arguments.length;i++){var a=arguments[i]!=null?arguments[i]:{};i%2?Db(Object(a),!0).forEach(function(r){ZD(e,r,a[r])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(a)):Db(Object(a)).forEach(function(r){Object.defineProperty(e,r,Object.getOwnPropertyDescriptor(a,r))})}return e}function ZD(e,i,a){return i=QD(i),i in e?Object.defineProperty(e,i,{value:a,enumerable:!0,configurable:!0,writable:!0}):e[i]=a,e}function QD(e){var i=JD(e,"string");return typeof i=="symbol"?i:i+""}function JD(e,i){if(typeof e!="object"||!e)return e;var a=e[Symbol.toPrimitive];if(a!==void 0){var r=a.call(e,i);if(typeof r!="object")return r;throw new TypeError("@@toPrimitive must return a primitive value.")}return(i==="string"?String:Number)(e)}function B2(e){return e&&e.map((i,a)=>Ce.createElement(i.tag,Ec({key:a},i.attr),B2(i.child)))}function z2(e){return i=>Ce.createElement(WD,Ac({attr:Ec({},e.attr)},i),B2(e.child))}function WD(e){var i=a=>{var{attr:r,size:s,title:c}=e,u=KD(e,GD),f=s||a.size||"1em",p;return a.className&&(p=a.className),e.className&&(p=(p?p+" ":"")+e.className),Ce.createElement("svg",Ac({stroke:"currentColor",fill:"currentColor",strokeWidth:"0"},a.attr,r,u,{className:p,style:Ec(Ec({color:e.color||a.color},a.style),e.style),height:f,width:f,xmlns:"http://www.w3.org/2000/svg"}),c&&Ce.createElement("title",null,c),e.children)};return kb!==void 0?Ce.createElement(kb.Consumer,null,a=>i(a)):i(M2)}function eM(e){return z2({attr:{viewBox:"0 0 448 512"},child:[{tag:"path",attr:{d:"M416 208H32c-17.67 0-32 14.33-32 32v32c0 17.67 14.33 32 32 32h384c17.67 0 32-14.33 32-32v-32c0-17.67-14.33-32-32-32z"},child:[]}]})(e)}function tM(e){return z2({attr:{viewBox:"0 0 448 512"},child:[{tag:"path",attr:{d:"M416 208H272V64c0-17.67-14.33-32-32-32h-32c-17.67 0-32 14.33-32 32v144H32c-17.67 0-32 14.33-32 32v32c0 17.67 14.33 32 32 32h144v144c0 17.67 14.33 32 32 32h32c17.67 0 32-14.33 32-32V304h144c17.67 0 32-14.33 32-32v-32c0-17.67-14.33-32-32-32z"},child:[]}]})(e)}const iM=w.section`
  padding: 8rem 2rem;
  background: linear-gradient(135deg, 
    #ede9e4 0%,
    #e6e2dc 50%,
    #ddd8d0 100%
  );
  position: relative;
  overflow: hidden;
`,nM=w.div`
  position: absolute;
  width: 100%;
  height: 100%;
  overflow: hidden;
  z-index: 1;
`,Mb=w(O.div)`
  position: absolute;
  border-radius: 50%;
  background: ${e=>e.$color};
  filter: blur(50px);
  opacity: 0.3;
`,aM=w.div`
  max-width: 1000px;
  margin: 0 auto;
  position: relative;
  z-index: 10;
`,rM=w(O.h2)`
  font-family: ${e=>{var i,a;return((a=(i=e.theme)==null?void 0:i.fonts)==null?void 0:a.elegant)||'"Playfair Display", serif'}};
  font-size: clamp(2.2rem, 4vw, 3.2rem);
  background: linear-gradient(135deg, #5A6B5D 0%, #7A8A7D 50%, #90B3A7 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  text-align: center;
  margin-bottom: 3rem;
  font-weight: 600;
`,oM=w.div`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`,sM=w(O.div)`
  background: rgba(255, 255, 255, 0.8);
  border-radius: 20px;
  box-shadow: 0 10px 30px rgba(144, 179, 167, 0.08);
  overflow: hidden;
  border: 1px solid rgba(144, 179, 167, 0.1);
  backdrop-filter: blur(20px);
  transition: all 0.3s ease;
  
  &:hover {
    box-shadow: 0 15px 40px rgba(144, 179, 167, 0.12);
    background: rgba(255, 255, 255, 0.9);
  }
`,lM=w(O.div)`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.5rem 2rem;
  cursor: pointer;
  font-size: 1.1rem;
  font-weight: 600;
  color: ${e=>e.$isOpen?"white":"#5A6B5D"};
  background: ${e=>e.$isOpen?"linear-gradient(135deg, #90B3A7 0%, #B8C4A8 100%)":"transparent"};
  transition: all 0.3s ease;
  font-family: ${e=>{var i,a;return((a=(i=e.theme)==null?void 0:i.fonts)==null?void 0:a.heading)||'"Poppins", sans-serif'}};

  &:hover {
    background: ${e=>e.$isOpen?"linear-gradient(135deg, #90B3A7 0%, #B8C4A8 100%)":"rgba(144, 179, 167, 0.1)"};
    color: ${e=>e.$isOpen?"white":"#90B3A7"};
  }
`,cM=w(O.div)`
  padding: 0 2rem 1.5rem 2rem;
  font-size: 1rem;
  color: #6B7B6E;
  line-height: 1.7;
  overflow: hidden;
  font-weight: 400;
  font-family: ${e=>{var i,a;return((a=(i=e.theme)==null?void 0:i.fonts)==null?void 0:a.primary)||"Inter, sans-serif"}};
`,uM=w.span`
  font-size: 1rem;
  color: ${e=>e.$isOpen?"white":"#90B3A7"};
  transition: all 0.3s ease;
  transform: ${e=>e.$isOpen?"rotate(180deg)":"rotate(0deg)"};
`,dM=()=>{const{t:e}=De(),[i,a]=S.useState(null),r=f=>{a(i===f?null:f)},s={hidden:{opacity:0,height:0,y:-10},visible:{opacity:1,height:"auto",y:0,transition:{duration:.4,ease:"easeInOut"}},exit:{opacity:0,height:0,y:-10,transition:{duration:.3,ease:"easeInOut"}}},c={initial:{y:0},animate:{y:[-5,5,-5],transition:{duration:8,repeat:1/0,ease:"easeInOut"}}},u=[{key:"faq1",question:"Какие услуги предлагает SPA-центр?",answer:"Мы предлагаем широкий спектр услуг: тайский массаж, ароматерапия, сауну, хаммам, косметологические процедуры и услуги салона красоты."},{key:"faq2",question:"Как записаться на процедуру?",answer:"Вы можете записаться по телефону +66 62 480 5877, через WhatsApp или лично посетив наш центр. Онлайн-бронирование скоро будет доступно."},{key:"faq3",question:"Каковы правила отмены записи?",answer:"Мы просим уведомлять об отмене не менее чем за 24 часа. При отмене менее чем за 24 часа может взиматься плата за отмену."},{key:"faq4",question:"Есть ли подарочные сертификаты?",answer:"Да, мы предлагаем подарочные сертификаты различного номинала. Их можно приобрести у нас в центре или забронировать по телефону."},{key:"faq5",question:"Нужно ли что-то приносить с собой?",answer:"Мы предоставляем все необходимое: полотенца, халаты, тапочки. Вам нужно только прийти и расслабиться."}];return h.jsxs(iM,{children:[h.jsxs(nM,{children:[h.jsx(Mb,{$color:"linear-gradient(135deg, rgba(144, 179, 167, 0.04) 0%, rgba(184, 196, 168, 0.04) 100%)",style:{width:"200px",height:"200px",top:"20%",left:"20%"},variants:c,initial:"initial",animate:"animate"}),h.jsx(Mb,{$color:"linear-gradient(135deg, rgba(184, 196, 168, 0.03) 0%, rgba(144, 179, 167, 0.03) 100%)",style:{width:"150px",height:"150px",bottom:"30%",right:"25%"},variants:c,initial:"initial",animate:"animate",transition:{delay:4}})]}),h.jsxs(aM,{children:[h.jsx(rM,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{duration:.7},children:"Часто задаваемые вопросы"}),h.jsx(oM,{children:u.map((f,p)=>h.jsxs(sM,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{duration:.6,delay:p*.1},whileHover:{scale:1.01},children:[h.jsxs(lM,{onClick:()=>r(p),$isOpen:i===p,children:[f.question,h.jsx(uM,{$isOpen:i===p,children:i===p?h.jsx(eM,{}):h.jsx(tM,{})})]}),h.jsx(ua,{children:i===p&&h.jsx(cM,{variants:s,initial:"hidden",animate:"visible",exit:"exit",children:f.answer})})]},f.key))})]})]})},fM=w(O.div)`
  background-color: ${e=>e.theme.colors.background};
  color: ${e=>e.theme.colors.text.primary};
  min-height: 100vh;
  font-family: ${e=>e.theme.fonts.primary};
  overflow-x: hidden;
`,hM=()=>{const{t:e}=De();Ce.useEffect(()=>(console.log("SpaPage загружается..."),document.body.classList.add("spa-page"),window.scrollTo(0,0),()=>{console.log("SpaPage выгружается..."),document.body.classList.remove("spa-page")}),[]);const i={initial:{opacity:0},animate:{opacity:1},exit:{opacity:0}};return h.jsxs(fM,{initial:"initial",animate:"animate",exit:"exit",variants:i,transition:{duration:.2},children:[h.jsx(k2,{}),h.jsx(uD,{}),h.jsx(bD,{}),h.jsx($D,{}),h.jsx(dM,{}),h.jsx(YD,{})]})},pM=w.section`
  min-height: 90vh;
  position: relative;
  display: flex;
  align-items: center;
  background-color: #111;
  overflow: hidden;
`,mM=w.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 1;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, 
      #1a1a1a 0%, 
      #2d2d2d 50%, 
      #1a1a1a 100%
    );
  }
  
  &::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0.3) 100%);
  }
`,gM=w.div`
  width: 100%;
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 2rem;
  display: grid;
  grid-template-columns: 1fr;
  gap: 4rem;
  position: relative;
  z-index: 2;
  
  @media (min-width: 1024px) {
    grid-template-columns: 7fr 5fr;
    gap: 5rem;
  }
`,yM=w(O.div)`
  display: flex;
  flex-direction: column;
  justify-content: center;
  color: #FFFFFF;
  text-align: left;
`;w(O.span)`
  display: inline-block;
  background-color: rgba(210, 155, 132, 0.2);
  color: ${e=>e.theme.colors.primary};
  padding: 0.6rem 1.2rem;
  border-radius: 50px;
  font-size: 0.9rem;
  font-weight: 600;
  margin-bottom: 1.5rem;
  backdrop-filter: blur(5px);
  border: 1px solid rgba(210, 155, 132, 0.3);
`;const xM=w(O.h1)`
  font-family: ${e=>e.theme.fonts.heading};
  font-size: clamp(3rem, 5vw, 5rem);
  font-weight: 700;
  line-height: 1.1;
  margin-bottom: 1.5rem;
  color: #FFFFFF;
  position: relative;
  
  span {
    color: ${e=>e.theme.colors.primary};
    position: relative;
    display: inline-block;
    
    &::after {
      content: '';
      position: absolute;
      left: 0;
      bottom: 0;
      width: 100%;
      height: 0.2em;
      background-color: ${e=>e.theme.colors.primary};
      opacity: 0.3;
      border-radius: 2px;
    }
  }
`,bM=w(O.p)`
  font-size: clamp(1.1rem, 2vw, 1.3rem);
  line-height: 1.8;
  color: rgba(255, 255, 255, 0.8);
  margin-bottom: 2.5rem;
  max-width: 580px;
  font-weight: 300;
`,vM=w(O.div)`
  display: flex;
  gap: 1.5rem;
  flex-wrap: wrap;
  margin-bottom: 2rem;
`,wM=w(O.button)`
  display: inline-flex;
  align-items: center;
  gap: 0.75rem;
  background-color: ${e=>e.theme.colors.primary};
  color: white;
  font-weight: 600;
  padding: 1.2rem 2.5rem;
  border-radius: 50px;
  cursor: pointer;
  border: none;
  box-shadow: 0 5px 15px rgba(210, 155, 132, 0.3);
  position: relative;
  overflow: hidden;
  transition: all 0.3s ease;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 0;
    height: 100%;
    background-color: rgba(255, 255, 255, 0.1);
    transition: width 0.3s ease;
  }
  
  &:hover {
    box-shadow: 0 8px 25px rgba(210, 155, 132, 0.4);
    transform: translateY(-3px);
  }
  
  &:hover::before {
    width: 100%;
  }
  
  svg {
    width: 20px;
    height: 20px;
    transition: transform 0.3s ease;
  }
  
  &:hover svg {
    transform: translateX(5px);
  }
`,SM=w(O.button)`
  display: inline-flex;
  align-items: center;
  gap: 0.75rem;
  background-color: transparent;
  color: white;
  font-weight: 600;
  padding: 1.15rem 2.45rem;
  border-radius: 50px;
  cursor: pointer;
  border: 1.5px solid rgba(255, 255, 255, 0.5);
  backdrop-filter: blur(10px);
  position: relative;
  overflow: hidden;
  transition: all 0.3s ease;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 0;
    height: 100%;
    background-color: rgba(255, 255, 255, 0.05);
    transition: width 0.3s ease;
  }
  
  &:hover {
    border-color: rgba(255, 255, 255, 0.8);
    transform: translateY(-3px);
  }
  
  &:hover::before {
    width: 100%;
  }
  
  svg {
    width: 20px;
    height: 20px;
    transition: transform 0.3s ease;
  }
  
  &:hover svg {
    transform: translateX(5px);
  }
`,TM=w(O.div)`
  display: flex;
  gap: 2rem;
  flex-wrap: wrap;
  
  @media (max-width: 768px) {
    gap: 1.5rem;
  }
`,Qf=w(O.div)`
  display: flex;
  flex-direction: column;
  
  &::before {
    content: '';
    display: block;
    width: 40px;
    height: 3px;
    background-color: ${e=>e.theme.colors.primary};
    margin-bottom: 1rem;
    border-radius: 3px;
    opacity: 0.7;
  }
`,Jf=w.span`
  font-size: 2.8rem;
  font-weight: 700;
  font-family: ${e=>e.theme.fonts.heading};
  color: white;
  margin-bottom: 0.5rem;
  line-height: 1;
`,Wf=w.span`
  font-size: 1rem;
  color: rgba(255, 255, 255, 0.7);
  font-weight: 400;
  text-transform: uppercase;
  letter-spacing: 1px;
`,jM=w(O.div)`
  display: flex;
  align-items: center;
  justify-content: flex-end;
  height: 100%;
  
  @media (max-width: 1023px) {
    justify-content: center;
  }
`;w(O.img)`
  max-width: 100%;
  height: auto;
  border-radius: 30px;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
  
  @media (max-width: 768px) {
    max-width: 90%;
  }
`;const AM=()=>{const{t:e}=De();return h.jsxs(pM,{children:[h.jsx(mM,{}),h.jsxs(gM,{children:[h.jsxs(yM,{initial:{opacity:0,y:30},animate:{opacity:1,y:0},transition:{duration:.6,delay:.2},style:{paddingTop:"2rem"},children:[h.jsx(xM,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.5,delay:.4},children:e("sports.hero.title","Достигайте новых <span>спортивных высот</span> с KAIF")}),h.jsx(bM,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.5,delay:.5},children:e("sports.hero.subtitle","В KAIF Jungle Club & SPA вы найдете все необходимое для активного образа жизни, тренировок и спортивного развлечения в атмосфере роскоши и комфорта.")}),h.jsxs(vM,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.5,delay:.6},children:[h.jsxs(wM,{whileHover:{scale:1.03},whileTap:{scale:.97},children:[e("sports.hero.primary_cta","Записаться на тренировку"),h.jsx(HO,{})]}),h.jsxs(SM,{whileHover:{scale:1.03},whileTap:{scale:.97},children:[e("sports.hero.secondary_cta","Узнать подробнее"),h.jsx(Wh,{})]})]}),h.jsxs(TM,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.5,delay:.7},children:[h.jsxs(Qf,{initial:{opacity:0,scale:.9},animate:{opacity:1,scale:1},transition:{duration:.4,delay:.8},children:[h.jsx(Jf,{children:"5+"}),h.jsx(Wf,{children:e("sports.hero.stats.facilities","Спортивных объектов")})]}),h.jsxs(Qf,{initial:{opacity:0,scale:.9},animate:{opacity:1,scale:1},transition:{duration:.4,delay:.9},children:[h.jsx(Jf,{children:"10+"}),h.jsx(Wf,{children:e("sports.hero.stats.trainers","Профессиональных тренеров")})]}),h.jsxs(Qf,{initial:{opacity:0,scale:.9},animate:{opacity:1,scale:1},transition:{duration:.4,delay:1},children:[h.jsx(Jf,{children:"24/7"}),h.jsx(Wf,{children:e("sports.hero.stats.access","Доступ для резидентов")})]})]})]}),h.jsx(jM,{initial:{opacity:0,x:30},animate:{opacity:1,x:0},transition:{duration:.6,delay:.4},style:{marginTop:"2rem"},children:h.jsx("div",{style:{width:"100%",maxWidth:"500px",height:"400px",background:"linear-gradient(135deg, rgba(210, 155, 132, 0.1) 0%, rgba(139, 69, 19, 0.15) 50%, rgba(210, 155, 132, 0.08) 100%)",borderRadius:"30px",display:"flex",alignItems:"center",justifyContent:"center",boxShadow:"0 20px 40px rgba(210, 155, 132, 0.15)",border:"1px solid rgba(210, 155, 132, 0.2)",fontSize:"4rem",color:"rgba(210, 155, 132, 0.8)",fontWeight:"bold"},children:"🏋️‍♂️"})})]})]})},eh=w(O.div)`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 4rem;
  margin: 6rem 0;
  align-items: center;
  
  @media (max-width: 992px) {
    grid-template-columns: 1fr;
    gap: 3rem;
  }
  
  &:nth-child(even) {
    grid-template-columns: 1fr 1fr;
    
    @media (max-width: 992px) {
      grid-template-columns: 1fr;
    }
    
    .facility-content {
      order: 2;
      
      @media (max-width: 992px) {
        order: 1;
      }
    }
    
    .facility-gallery {
      order: 1;
      
      @media (max-width: 992px) {
        order: 2;
      }
    }
  }
  
  &:first-child {
    margin-top: 0;
  }
`,th=w.h3`
  font-family: ${e=>e.theme.fonts.heading};
  font-size: clamp(1.8rem, 3vw, 2.5rem);
  color: ${e=>e.theme.colors.text.primary};
  margin-bottom: 1.5rem;
  font-weight: 700;
  position: relative;
  display: inline-block;
  padding-bottom: 0.8rem;
  
  &::after {
    content: '';
    position: absolute;
    left: 0;
    bottom: 0;
    width: 60px;
    height: 3px;
    background-color: ${e=>e.theme.colors.primary};
    border-radius: 2px;
  }
`,ih=w.div`
  font-size: 1.05rem;
  line-height: 1.8;
  color: ${e=>e.theme.colors.text.secondary};
  margin-bottom: 2rem;
  
  p {
    margin-bottom: 1rem;
  }
  
  ul {
    margin: 1rem 0;
    padding-left: 1.5rem;
  }
  
  li {
    margin-bottom: 0.5rem;
  }
`,nh=w.div`
  position: relative;
  direction: ltr;
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  grid-template-rows: repeat(2, 230px);
  gap: 1.5rem;
  
  @media (max-width: 768px) {
    grid-template-rows: repeat(2, 180px);
  }
`,ar=w(O.div)`
  height: 100%;
  background-color: ${e=>e.theme.colors.secondary};
  background-image: url(${e=>e.src});
  background-size: cover;
  background-position: center;
  border-radius: 20px;
  overflow: hidden;
  transition: all 0.4s ease;
  box-shadow: ${e=>e.theme.shadows.md};
  position: relative;
  
  &::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(to top, rgba(0,0,0,0.5) 0%, rgba(0,0,0,0) 60%);
    opacity: 0.7;
    transition: opacity 0.4s ease;
  }
  
  &:hover {
    transform: scale(1.03);
    box-shadow: ${e=>e.theme.shadows.xl};
    
    &::after {
      opacity: 1;
    }
  }
  
  &:first-child {
    grid-column: 1 / 3;
    grid-row: 1 / 2;
  }
`,vi=w(O.div)`
  display: flex;
  align-items: center;
  margin-bottom: 1.2rem;
  
  svg {
    width: 20px;
    height: 20px;
    color: ${e=>e.theme.colors.primary};
    margin-right: 0.75rem;
    flex-shrink: 0;
  }
  
  span {
    font-size: 1rem;
    color: ${e=>e.theme.colors.text.secondary};
  }
`,ah=w.div`
  display: flex;
  flex-wrap: wrap;
  gap: 1.5rem;
  margin-bottom: 2rem;
`,rr=w.div`
  display: flex;
  align-items: center;
  
  svg {
    width: 20px;
    height: 20px;
    color: ${e=>e.theme.colors.primary};
    margin-right: 0.75rem;
  }
  
  span {
    font-size: 0.95rem;
    color: ${e=>e.theme.colors.text.secondary};
  }
`;w(O.div)`
  width: 100%;
  margin: 2rem 0 3rem;
  overflow: visible;
  background-color: transparent;
  position: relative;
`;w.div`
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  margin-bottom: 2rem;
  position: relative;
  padding-bottom: 1rem;
  
  &::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 80px;
    height: 2px;
    background: linear-gradient(to right, #6366f1, transparent);
  }
  
  .title-wrapper {
    h3 {
      font-family: ${e=>e.theme.fonts.heading};
      font-size: 1.5rem;
      font-weight: 600;
      color: #222;
      margin: 0 0 0.5rem 0;
      letter-spacing: 0.5px;
      position: relative;
    }
    
    p {
      color: #666;
      font-size: 0.85rem;
      margin: 0;
      line-height: 1.5;
      max-width: 500px;
    }
  }
`;w.div`
  font-size: 0.85rem;
  color: #4b5563;
  font-weight: 600;
  margin-right: 0.75rem;
  letter-spacing: 0.5px;
  display: flex;
  align-items: center;
`;w.div`
  display: flex;
  align-items: center;
  margin-bottom: 2rem;
  flex-wrap: wrap;
  gap: 0.75rem;
  position: relative;
  padding: 1rem 1.25rem;
  background: rgba(249, 250, 251, 0.7);
  border-radius: 16px;
  backdrop-filter: blur(10px);
  box-shadow: 0 2px 10px rgba(0,0,0,0.03);
  border: 1px solid rgba(255,255,255,0.7);
`;w.button`
  background: ${e=>e.active?"linear-gradient(135deg, #6366f1, #8b5cf6)":"transparent"};
  color: ${e=>e.active?"#fff":"#888"};
  border: ${e=>e.active?"none":"1px solid #e5e7eb"};
  padding: ${e=>e.active?"6px 14px":"5px 12px"};
  font-size: 0.75rem;
  font-weight: 600;
  cursor: pointer;
  border-radius: 50px;
  transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
  text-transform: uppercase;
  letter-spacing: 0.6px;
  box-shadow: ${e=>e.active?"0 4px 10px rgba(99, 102, 241, 0.25)":"none"};
  transform-origin: center;
  position: relative;
  overflow: hidden;
  
  &:hover {
    transform: translateY(-1px);
    border-color: ${e=>e.active?"none":"#cbd5e1"};
    color: ${e=>e.active?"#fff":"#333"};
    box-shadow: ${e=>e.active?"0 6px 15px rgba(99, 102, 241, 0.3)":"0 2px 6px rgba(0,0,0,0.04)"};    
  }
  
  &:active {
    transform: translateY(1px);
    box-shadow: ${e=>e.active?"0 2px 5px rgba(99, 102, 241, 0.2)":"none"};
  }
  
  &:focus {
    outline: none;
  }
`;w.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 24px;
  width: 100%;
  perspective: 1000px;
  
  @media (max-width: 768px) {
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 16px;
  }
`;const Br=w(O.div)`
  background-color: white;
  background-image: ${e=>e.isPrimary?"linear-gradient(135deg, rgba(249, 250, 251, 0.9), rgba(243, 244, 246, 0.4))":"none"};
  border-radius: 16px;
  padding: 24px;
  position: relative;
  cursor: pointer;
  border: 1px solid rgba(229, 231, 235, 0.7);
  transition: all 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.01), 0 1px 3px rgba(0, 0, 0, 0.02);
  overflow: hidden;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  backdrop-filter: blur(5px);
  transform-style: preserve-3d;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 5px;
    height: 0;
    background: linear-gradient(to bottom, #6366f1, #8b5cf6);
    transition: height 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
    opacity: 0.85;
    border-top-left-radius: 16px;
    border-bottom-left-radius: 16px;
  }
  
  &::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(to bottom right, rgba(99, 102, 241, 0.05), rgba(139, 92, 246, 0.05));
    opacity: 0;
    transition: opacity 0.4s ease;
    pointer-events: none;
  }
  
  &:hover {
    transform: translateY(-8px) rotateX(2deg);
    box-shadow: 0 20px 25px rgba(0, 0, 0, 0.07), 0 10px 10px rgba(0, 0, 0, 0.04);
    border-color: rgba(203, 213, 225, 0.6);
    
    &::before {
      height: 100%;
    }
    
    &::after {
      opacity: 1;
    }
  }
  
  &:active {
    transform: translateY(-2px);
    transition: all 0.1s;
  }
`;w.div`
  display: flex;
  align-items: center;
  margin-bottom: 6px;
  
  svg {
    width: 14px;
    height: 14px;
    margin-right: 5px;
    color: #999;
  }
  
  span {
    font-size: 0.8rem;
    color: #666;
    font-weight: 500;
  }
`;w.h4`
  font-size: 1.05rem;
  font-weight: 700;
  margin: 0 0 8px 0;
  color: #111827;
  position: relative;
  display: inline-block;
  
  &::after {
    content: '';
    position: absolute;
    bottom: -4px;
    left: 0;
    width: 0;
    height: 2px;
    background: linear-gradient(to right, #6366f1, transparent);
    transition: width 0.3s ease;
  }
  
  ${Br}:hover & {
    &::after {
      width: 100%;
    }
  }
`;w.div`
  display: flex;
  align-items: center;
  margin-bottom: 6px;
  
  svg {
    width: 14px;
    height: 14px;
    margin-right: 5px;
    color: #999;
  }
  
  span {
    font-size: 0.75rem;
    color: #777;
  }
`;w.span`
  display: inline-block;
  font-size: 0.65rem;
  text-transform: uppercase;
  letter-spacing: 0.6px;
  padding: 4px 10px;
  border-radius: 20px;
  background-color: ${e=>e.type==="personal"?"rgba(37, 99, 235, 0.1)":e.type==="event"?"rgba(219, 39, 119, 0.1)":e.type==="group"?"rgba(75, 85, 99, 0.1)":e.color==="green"?"rgba(22, 163, 74, 0.1)":e.color==="yellow"?"rgba(245, 158, 11, 0.1)":e.color==="red"?"rgba(220, 38, 38, 0.1)":"rgba(75, 85, 99, 0.1)"};
  color: ${e=>e.type==="personal"?"#2563eb":e.type==="event"?"#db2777":e.color==="green"?"#16a34a":e.color==="yellow"?"#f59e0b":e.color==="red"?"#dc2626":"#4b5563"};
  font-weight: 600;
  transition: all 0.3s ease;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.02);
  transform: translateY(0);
  
  ${Br}:hover & {
    transform: translateY(-1px);
    box-shadow: 0 2px 5px ${e=>e.type==="personal"?"rgba(37, 99, 235, 0.15)":e.type==="event"?"rgba(219, 39, 119, 0.15)":e.color==="green"?"rgba(22, 163, 74, 0.15)":e.color==="yellow"?"rgba(245, 158, 11, 0.15)":e.color==="red"?"rgba(220, 38, 38, 0.15)":"rgba(75, 85, 99, 0.15)"};
  }
`;w.div`
  display: flex;
  flex-wrap: wrap;
  margin-top: 16px;
  gap: 6px;
  transition: all 0.3s ease;
`;w.div`
  display: flex;
  justify-content: flex-end;
  margin-top: 1.5rem;
`;w(O.button)`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  background-color: #000;
  color: white;
  border: none;
  border-radius: 3px;
  padding: 0.55rem 1.2rem;
  font-family: ${e=>e.theme.fonts.body};
  font-weight: 500;
  font-size: 0.75rem;
  cursor: pointer;
  transition: all 0.2s ease;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  
  &:hover {
    opacity: 0.9;
    transform: translateY(-1px);
  }
  
  &:focus {
    outline: none;
  }
`;w.div`
  text-align: center;
  padding: 1rem 0;
  font-style: italic;
  color: #6b7280;
  font-size: 0.8rem;
  margin-top: 1.5rem;
  background: rgba(249, 250, 251, 0.7);
  border-radius: 8px;
  border: 1px dashed #e5e7eb;
  position: relative;
  overflow: hidden;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 2px;
    background: linear-gradient(to right, transparent, rgba(99, 102, 241, 0.3), transparent);
  }
`;w.div`
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 16px;
  position: relative;
  z-index: 1;
  
  &::before {
    content: '';
    position: absolute;
    top: -10px;
    right: -10px;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: linear-gradient(135deg, rgba(99, 102, 241, 0.1), rgba(139, 92, 246, 0.1));
    opacity: 0;
    transform: scale(0.5);
    transition: all 0.4s ease;
    z-index: -1;
  }
  
  ${Br}:hover & {
    &::before {
      opacity: 1;
      transform: scale(1);
    }
  }
`;w.div`
  font-size: 0.8rem;
  color: #6366f1;
  font-weight: 600;
  background: rgba(99, 102, 241, 0.1);
  padding: 3px 8px;
  border-radius: 20px;
  letter-spacing: 0.5px;
  transition: all 0.3s ease;
  
  ${Br}:hover & {
    background: rgba(99, 102, 241, 0.15);
    box-shadow: 0 2px 5px rgba(99, 102, 241, 0.1);
  }
`;w.div`
  display: flex;
  align-items: center;
  margin-bottom: 10px;
  transition: all 0.3s ease;
  transform: translateX(0);
  
  svg {
    width: 15px;
    height: 15px;
    margin-right: 6px;
    color: #6b7280;
    transition: all 0.3s ease;
  }
  
  span {
    font-size: 0.8rem;
    color: #4b5563;
    font-weight: 500;
    transition: all 0.3s ease;
  }
  
  ${Br}:hover & {
    transform: translateX(3px);
    
    svg {
      color: #6366f1;
      transform: scale(1.1);
    }
    
    span {
      color: #374151;
    }
  }
`;w.div`
  display: flex;
  align-items: center;
  margin-bottom: 12px;
  transition: all 0.3s ease;
  transform: translateX(0);
  
  svg {
    width: 15px;
    height: 15px;
    margin-right: 6px;
    color: #6b7280;
    transition: all 0.3s ease;
  }
  
  span {
    font-size: 0.8rem;
    color: #4b5563;
    font-weight: 500;
    transition: all 0.3s ease;
  }
  
  ${Br}:hover & {
    transform: translateX(3px);
    transition-delay: 0.05s;
    
    svg {
      color: #6366f1;
      transform: scale(1.1);
    }
    
    span {
      color: #374151;
    }
  }
`;w.div`
  display: ${e=>e.active?"block":"none"};
  animation: ${e=>e.active?"fadeIn 0.5s ease":"none"};
  
  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
`;w.div`
  padding: 3rem 2rem;
  text-align: center;
  color: #6b7280;
  font-size: 0.95rem;
  background: linear-gradient(135deg, #f9fafb, #f3f4f6);
  border-radius: 16px;
  width: 100%;
  grid-column: 1 / -1;
  border: 1px dashed #e5e7eb;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.02);
  position: relative;
  overflow: hidden;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: linear-gradient(to right, #6366f1, #8b5cf6);
    opacity: 0.3;
  }
`;const EM=w(O.div)`
  background-color: ${e=>e.theme.colors.background};
  color: ${e=>e.theme.colors.text.primary};
  min-height: 100vh;
  font-family: ${e=>e.theme.fonts.primary};
  overflow-x: hidden;
`,Wp=w.section`
  padding: 9rem 2rem;
  background-color: ${e=>e.bgColor||e.theme.colors.background};
  position: relative;
  overflow: hidden;
  
  &:nth-child(even) {
    background-color: ${e=>e.bgColor||e.theme.colors.surface};
  }
`,e0=w(O.span)`
  display: inline-block;
  background-color: rgba(210, 155, 132, 0.1);
  color: ${e=>e.theme.colors.primary};
  padding: 0.6rem 1.2rem;
  border-radius: 50px;
  font-size: 0.9rem;
  font-weight: 600;
  margin-bottom: 1rem;
  letter-spacing: 1px;
  text-transform: uppercase;
`,$2=w(O.h2)`
  font-family: ${e=>e.theme.fonts.heading};
  font-size: clamp(2.2rem, 4vw, 3.2rem);
  color: ${e=>e.theme.colors.text.primary};
  text-align: center;
  margin-bottom: 1.5rem;
  font-weight: 700;
  
  span {
    color: ${e=>e.theme.colors.primary};
    position: relative;
    
    &::after {
      content: '';
      position: absolute;
      left: 0;
      bottom: 0;
      width: 100%;
      height: 0.15em;
      background-color: ${e=>e.theme.colors.primary};
      opacity: 0.3;
      border-radius: 2px;
    }
  }
`,N2=w(O.p)`
  font-size: clamp(1rem, 2vw, 1.1rem);
  color: ${e=>e.theme.colors.text.secondary};
  text-align: center;
  max-width: 800px;
  margin: 2.5rem auto 4.5rem auto;
  line-height: 1.8;
  font-weight: 300;
`,t0=w.div`
  max-width: 1400px;
  margin: 0 auto;
  position: relative;
  z-index: 2;
`,i0=w(O.div)`
  position: absolute;
  border-radius: 50%;
  background: linear-gradient(135deg, ${e=>e.theme.colors.primary}10, ${e=>e.theme.colors.primary}30);
  filter: blur(60px);
  z-index: 1;
`,CM=w(i0)`
  width: 500px;
  height: 500px;
  top: -100px;
  right: -100px;
`,OM=w(i0)`
  width: 600px;
  height: 600px;
  bottom: -200px;
  left: -200px;
`;w(i0)`
  width: 500px;
  height: 500px;
  bottom: -150px;
  right: -150px;
`;const Yl=w(O.button)`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.75rem;
  background-color: ${e=>e.theme.colors.primary};
  color: white;
  border: none;
  padding: 1rem 2rem;
  border-radius: 50px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
  box-shadow: 0 4px 15px rgba(210, 155, 132, 0.25);
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 0;
    height: 100%;
    background-color: rgba(255, 255, 255, 0.1);
    transition: width 0.3s ease;
  }
  
  &:hover {
    box-shadow: 0 6px 20px rgba(210, 155, 132, 0.35);
  }
  
  &:hover::before {
    width: 100%;
  }
  
  svg {
    width: 20px;
    height: 20px;
    transition: transform 0.3s ease;
  }
  
  &:hover svg {
    transform: translateX(5px);
  }
`,RM="/assets/gym-1-CnkDcUEU.JPG",kM="/assets/gym-2-DzuyA8fG.JPG",DM="/assets/gym-3-Jg52iATt.JPG",MM="/assets/fight-1-YGz9VxJh.jpg",BM="/assets/fight-2-CCvRgy_G.jpg",zM="/assets/fight-3-D1BQSPAQ.jpg",$M=()=>{const{t:e}=De(),[i,a]=S.useState("all"),r={hidden:{opacity:0},visible:{opacity:1,transition:{staggerChildren:.2}}},s={hidden:{opacity:0,y:20},visible:{opacity:1,y:0,transition:{duration:.6}}};return h.jsxs(Wp,{children:[h.jsx(CM,{animate:{scale:[1,1.1,1],opacity:[.7,.9,.7]},transition:{duration:8,repeat:1/0,repeatType:"reverse"}}),h.jsxs(t0,{children:[h.jsxs("div",{style:{textAlign:"center"},children:[h.jsx(e0,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.3},transition:{duration:.5},children:e("sports.facilities.tag","Наши объекты")}),h.jsx($2,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.3},transition:{duration:.7},children:e("sports.facilities.title","Современные <span>спортивные</span> пространства")}),h.jsx(N2,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.3},transition:{duration:.7,delay:.2},children:e("sports.facilities.subtitle","KAIF предлагает широкий выбор премиальных спортивных пространств с передовым оборудованием и профессиональными тренерами, которые помогут вам достичь ваших фитнес-целей.")})]}),h.jsxs(eh,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.3},transition:{duration:.7},children:[h.jsxs("div",{className:"facility-content",children:[h.jsx(th,{children:e("sports.facilities.gym.title","Тренажерный зал")}),h.jsxs(ah,{children:[h.jsxs(rr,{children:[h.jsx(sc,{}),h.jsx("span",{children:e("sports.facilities.gym.hours","06:00 - 23:00")})]}),h.jsxs(rr,{children:[h.jsx(lc,{}),h.jsx("span",{children:e("sports.facilities.gym.capacity","До 40 человек")})]})]}),h.jsxs(ih,{children:[h.jsx("p",{children:e("sports.facilities.gym.description1","Наш тренажерный зал оснащен современным оборудованием премиум-класса от ведущих производителей. Здесь вы найдете все необходимое для эффективных тренировок - от свободных весов до кардиотренажеров последнего поколения.")}),h.jsx("p",{children:e("sports.facilities.gym.description2","Просторное помещение с панорамными окнами создает идеальную атмосферу для тренировок, а профессиональные тренеры всегда готовы помочь составить индивидуальную программу.")})]}),h.jsxs(O.div,{variants:r,initial:"hidden",whileInView:"visible",viewport:{once:!0,amount:.3},children:[h.jsxs(vi,{variants:s,children:[h.jsx(Ut,{}),h.jsx("span",{children:e("sports.facilities.gym.feature1","Премиальное оборудование Technogym и Life Fitness")})]}),h.jsxs(vi,{variants:s,children:[h.jsx(Ut,{}),h.jsx("span",{children:e("sports.facilities.gym.feature2","Зона функционального тренинга")})]}),h.jsxs(vi,{variants:s,children:[h.jsx(Ut,{}),h.jsx("span",{children:e("sports.facilities.gym.feature3","Индивидуальные тренировки с сертифицированными тренерами")})]})]}),h.jsx(O.div,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{duration:.6,delay:.4},style:{marginTop:"2rem"},children:h.jsxs(Yl,{whileHover:{scale:1.05},whileTap:{scale:.95},children:[e("sports.facilities.book_button","Забронировать тренировку"),h.jsx(Il,{style:{width:"18px",height:"18px"}})]})})]}),h.jsx("div",{className:"facility-gallery",children:h.jsxs(nh,{children:[h.jsx(ar,{src:RM,whileHover:{scale:1.03},transition:{duration:.4}}),h.jsx(ar,{src:kM,whileHover:{scale:1.03},transition:{duration:.4}}),h.jsx(ar,{src:DM,whileHover:{scale:1.03},transition:{duration:.4}})]})})]}),h.jsxs(eh,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.3},transition:{duration:.7},children:[h.jsxs("div",{className:"facility-content",children:[h.jsx(th,{children:e("sports.facilities.fight.title","Бойцовский клуб")}),h.jsxs(ah,{children:[h.jsxs(rr,{children:[h.jsx(sc,{}),h.jsx("span",{children:e("sports.facilities.fight.hours","07:00 - 22:00")})]}),h.jsxs(rr,{children:[h.jsx(lc,{}),h.jsx("span",{children:e("sports.facilities.fight.capacity","До 25 человек")})]})]}),h.jsxs(ih,{children:[h.jsx("p",{children:e("sports.facilities.fight.description1","Бойцовский клуб KAIF — это современное пространство для тренировок по различным видам единоборств. Профессиональный ринг, груши, мешки, и специальное покрытие создают идеальные условия как для новичков, так и для опытных бойцов.")}),h.jsx("p",{children:e("sports.facilities.fight.description2","Наши тренеры — опытные бойцы и чемпионы, которые помогут освоить технику и достичь высоких результатов в выбранном боевом искусстве.")})]}),h.jsxs(O.div,{variants:r,initial:"hidden",whileInView:"visible",viewport:{once:!0,amount:.3},children:[h.jsxs(vi,{variants:s,children:[h.jsx(Ut,{}),h.jsx("span",{children:e("sports.facilities.fight.feature1","Профессиональный боксерский ринг")})]}),h.jsxs(vi,{variants:s,children:[h.jsx(Ut,{}),h.jsx("span",{children:e("sports.facilities.fight.feature2","Тренировки по боксу, тайскому боксу, ММА")})]}),h.jsxs(vi,{variants:s,children:[h.jsx(Ut,{}),h.jsx("span",{children:e("sports.facilities.fight.feature3","Тренеры с международными сертификатами")})]})]}),h.jsx(O.div,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{duration:.6,delay:.4},style:{marginTop:"2rem"},children:h.jsxs(Yl,{whileHover:{scale:1.05},whileTap:{scale:.95},children:[e("sports.facilities.book_button","Забронировать тренировку"),h.jsx(Il,{style:{width:"18px",height:"18px"}})]})})]}),h.jsx("div",{className:"facility-gallery",children:h.jsxs(nh,{children:[h.jsx(ar,{src:MM,whileHover:{scale:1.03},transition:{duration:.4}}),h.jsx(ar,{src:BM,whileHover:{scale:1.03},transition:{duration:.4}}),h.jsx(ar,{src:zM,whileHover:{scale:1.03},transition:{duration:.4}})]})})]}),h.jsxs(eh,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.3},transition:{duration:.7},children:[h.jsxs("div",{className:"facility-content",children:[h.jsx(th,{children:e("sports.facilities.dance.title","Танцевальная студия")}),h.jsxs(ah,{children:[h.jsxs(rr,{children:[h.jsx(sc,{}),h.jsx("span",{children:e("sports.facilities.dance.hours","09:00 - 21:00")})]}),h.jsxs(rr,{children:[h.jsx(lc,{}),h.jsx("span",{children:e("sports.facilities.dance.capacity","До 30 человек")})]})]}),h.jsxs(ih,{children:[h.jsx("p",{children:e("sports.facilities.dance.description1","Просторная танцевальная студия с профессиональным покрытием, зеркальными стенами и передовой аудиосистемой создает идеальные условия для различных танцевальных направлений и групповых занятий.")}),h.jsx("p",{children:e("sports.facilities.dance.description2","Здесь проходят занятия по современным и классическим танцевальным направлениям, а также групповые фитнес-тренировки под руководством опытных инструкторов.")})]}),h.jsx(O.div,{variants:r,initial:"hidden",whileInView:"visible",viewport:{once:!0,amount:.3},children:h.jsxs(vi,{variants:s,children:[h.jsx(Ut,{}),h.jsx("span",{children:e("sports.facilities.dance.feature4","Гибкое расписание групповых и индивидуальных занятий")})]})}),h.jsx(O.div,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{duration:.5,delay:.4},style:{margin:"2rem 0"},children:h.jsxs(Yl,{whileHover:{scale:1.05,boxShadow:"0 15px 30px rgba(0, 0, 0, 0.1)"},whileTap:{scale:.95},style:{display:"flex",margin:"0 auto"},onClick:()=>window.location.href="#schedule",children:[e("sports.facilities.dance.view_schedule","Посмотреть расписание"),h.jsx(Il,{style:{width:"18px",height:"18px",marginLeft:"8px"}})]})}),h.jsxs(O.div,{variants:r,initial:"hidden",whileInView:"visible",viewport:{once:!0,amount:.3},children:[h.jsxs(vi,{variants:s,children:[h.jsx(Ut,{}),h.jsx("span",{children:e("sports.facilities.dance.feature1","Профессиональное танцевальное покрытие")})]}),h.jsxs(vi,{variants:s,children:[h.jsx(Ut,{}),h.jsx("span",{children:e("sports.facilities.dance.feature2","Широкий выбор танцевальных направлений")})]}),h.jsxs(vi,{variants:s,children:[h.jsx(Ut,{}),h.jsx("span",{children:e("sports.facilities.dance.feature3","Групповые и индивидуальные занятия")})]})]}),h.jsx(O.div,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{duration:.6,delay:.4},style:{marginTop:"2rem"},children:h.jsxs(Yl,{whileHover:{scale:1.05},whileTap:{scale:.95},children:[e("sports.facilities.book_button","Забронировать занятие"),h.jsx(Il,{style:{width:"18px",height:"18px"}})]})})]}),h.jsx("div",{className:"facility-gallery",children:h.jsx(nh,{children:h.jsx("div",{style:{background:"linear-gradient(135deg, rgba(139, 69, 19, 0.1) 0%, rgba(210, 155, 132, 0.15) 100%)",borderRadius:"20px",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"3rem",gridColumn:"1 / -1",gridRow:"1 / -1"},children:"💃🕺"})})})]})]})]})},NM=w.div`
  position: relative;
  width: 100%;
  max-width: 1200px;
  margin: 3rem auto 0;
  overflow: hidden;
  border-radius: 20px;
  box-shadow: var(--shadow-wellness-lg);
  
  @media (max-width: 768px) {
    margin: 2rem auto 0;
    border-radius: 16px;
  }
  
  @media (max-width: 480px) {
    margin: 1.5rem auto 0;
    border-radius: 12px;
  }
`,LM=w(O.div)`
  display: flex;
  width: 100%;
  height: 100%;
`,_M=w(O.div)`
  flex-shrink: 0;
  width: 100%;
  height: 500px;
  position: relative;
  
  @media (max-width: 768px) {
    height: 400px;
  }
  
  @media (max-width: 480px) {
    height: 300px;
  }
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  
  .slide-overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    padding: 2rem;
    background: linear-gradient(to top, rgba(0,0,0,0.8) 0%, rgba(0,0,0,0) 100%);
    color: white;
    transition: all 0.3s ease;
    
    @media (max-width: 480px) {
      padding: 1.5rem;
    }
  }
  
  .slide-title {
    font-weight: 700;
    font-size: 1.5rem;
    margin-bottom: 0.5rem;
    
    @media (max-width: 480px) {
      font-size: 1.2rem;
    }
  }
  
  .slide-subtitle {
    font-size: 1rem;
    opacity: 0.9;
    
    @media (max-width: 480px) {
      font-size: 0.9rem;
    }
  }
`,Bb=w.button`
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  background: rgba(255, 255, 255, 0.8);
  color: var(--color-text-primary);
  border: none;
  width: 50px;
  height: 50px;
  border-radius: 50%;
  font-size: 1.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  z-index: 10;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;
  
  &:hover {
    background: white;
    box-shadow: 0 6px 15px rgba(0, 0, 0, 0.15);
  }
  
  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
  
  &.prev {
    left: 20px;
  }
  
  &.next {
    right: 20px;
  }
  
  @media (max-width: 768px) {
    width: 40px;
    height: 40px;
    font-size: 1.2rem;
  }
  
  @media (max-width: 480px) {
    width: 35px;
    height: 35px;
    font-size: 1rem;
    
    &.prev {
      left: 10px;
    }
    
    &.next {
      right: 10px;
    }
  }
`,HM=w.div`
  display: flex;
  justify-content: center;
  gap: 10px;
  margin-top: 20px;
  
  @media (max-width: 480px) {
    gap: 8px;
    margin-top: 15px;
  }
`,VM=w.button`
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: ${e=>e.active?"var(--color-primary)":"rgba(144, 179, 167, 0.3)"};
  border: none;
  padding: 0;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    background: ${e=>e.active?"var(--color-primary)":"rgba(144, 179, 167, 0.5)"};
  }
  
  @media (max-width: 480px) {
    width: 10px;
    height: 10px;
  }
`;w.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 1.5rem;
  margin-top: 3rem;
`;w(O.div)`
  height: 280px;
  background-color: var(--color-surface);
  border-radius: 20px;
  overflow: hidden;
  position: relative;
  box-shadow: var(--shadow-wellness);
  transition: all 0.3s ease;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: all 0.5s ease;
  }
  
  .photo-overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    padding: 1.5rem;
    background: linear-gradient(to top, rgba(0,0,0,0.8) 0%, rgba(0,0,0,0) 100%);
    color: white;
    transition: all 0.3s ease;
  }
  
  &:hover {
    transform: translateY(-5px);
    box-shadow: var(--shadow-wellness-lg);
    
    img {
      transform: scale(1.05);
    }
    
    .photo-overlay {
      padding-bottom: 2rem;
    }
  }
  
  .photo-title {
    font-weight: 600;
    font-size: 1.1rem;
    margin-bottom: 0.25rem;
  }
  
  .photo-subtitle {
    font-size: 0.85rem;
    opacity: 0.8;
  }
`;w(O.div)`
  height: 280px;
  background-color: var(--color-secondary);
  background-opacity: 0.1;
  border-radius: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--color-text-secondary);
  font-size: 0.95rem;
  box-shadow: inset 0 0 0 1px rgba(0, 0, 0, 0.05);
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-5px);
    box-shadow: inset 0 0 0 1px rgba(0, 0, 0, 0.1), 0 10px 20px rgba(0, 0, 0, 0.05);
  }
`;const wi=[{id:1,emoji:"🏋️‍♂️",title:"Тренажерный зал",subtitle:"Современное оборудование",gradient:"linear-gradient(135deg, rgba(210, 155, 132, 0.15) 0%, rgba(139, 69, 19, 0.1) 100%)"},{id:2,emoji:"🥊",title:"Бойцовский клуб",subtitle:"Профессиональный ринг",gradient:"linear-gradient(135deg, rgba(220, 38, 127, 0.15) 0%, rgba(139, 69, 19, 0.1) 100%)"},{id:3,emoji:"👨‍🏫",title:"Персональный тренинг",subtitle:"Индивидуальный подход",gradient:"linear-gradient(135deg, rgba(59, 130, 246, 0.15) 0%, rgba(139, 69, 19, 0.1) 100%)"},{id:4,emoji:"🏊‍♂️",title:"Бассейн",subtitle:"Релаксация и восстановление",gradient:"linear-gradient(135deg, rgba(14, 165, 233, 0.15) 0%, rgba(139, 69, 19, 0.1) 100%)"}],PM=()=>{const{t:e}=De(),[i,a]=S.useState(0),[r,s]=S.useState(0),[c,u]=S.useState(!0);S.useEffect(()=>{if(!c)return;const k=setInterval(()=>{f()},4e3);return()=>clearInterval(k)},[i,c]);const f=()=>{s(1),a(k=>(k+1)%wi.length)},p=()=>{s(-1),a(k=>(k-1+wi.length)%wi.length)},m=k=>{s(k>i?1:-1),a(k)},[y,x]=S.useState(null),[b,T]=S.useState(null),A=k=>{x(k.targetTouches[0].clientX)},C=k=>{T(k.targetTouches[0].clientX)},B=()=>{if(!y||!b)return;const k=y-b,M=k>50,F=k<-50;M&&f(),F&&p()},E={enter:k=>({x:k>0?1e3:-1e3,opacity:0}),center:{zIndex:1,x:0,opacity:1},exit:k=>({zIndex:0,x:k<0?1e3:-1e3,opacity:0})};return h.jsxs(Wp,{id:"gallery",children:[h.jsx(OM,{animate:{scale:[1,1.15,1],opacity:[.6,.8,.6]},transition:{duration:10,repeat:1/0,repeatType:"reverse",delay:1}}),h.jsxs(t0,{children:[h.jsxs("div",{style:{textAlign:"center"},children:[h.jsx(e0,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.3},transition:{duration:.5},children:e("sports.gallery.tag","Фото")}),h.jsx($2,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.3},transition:{duration:.7},children:e("sports.gallery.title","Gallery")}),h.jsx(N2,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.3},transition:{duration:.7,delay:.2},children:e("sports.gallery.subtitle","Captured moments of sports life at KAIF Jungle Club & SPA. Join our community and share your own achievements")})]}),h.jsxs(NM,{onTouchStart:A,onTouchMove:C,onTouchEnd:B,tabIndex:"0",onMouseEnter:()=>u(!1),onMouseLeave:()=>u(!0),children:[h.jsx(ua,{initial:!1,custom:r,children:h.jsx(LM,{children:h.jsxs(_M,{custom:r,variants:E,initial:"enter",animate:"center",exit:"exit",transition:{x:{type:"spring",stiffness:300,damping:30},opacity:{duration:.2}},children:[h.jsx("div",{style:{width:"100%",height:"400px",background:wi[i].gradient,borderRadius:"20px",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",fontSize:"5rem",marginBottom:"2rem"},children:wi[i].emoji}),h.jsxs("div",{className:"slide-overlay",children:[h.jsx("div",{className:"slide-title",children:e(`sports.gallery.${wi[i].title.toLowerCase().replace(/\s+/g,"_")}`,wi[i].title)}),h.jsx("div",{className:"slide-subtitle",children:e(`sports.gallery.subtitle_${wi[i].title.toLowerCase().replace(/\s+/g,"_")}`,wi[i].subtitle)})]})]},i)})}),h.jsx(Bb,{className:"prev",onClick:p,"aria-label":"Предыдущий слайд",children:"‹"}),h.jsx(Bb,{className:"next",onClick:f,"aria-label":"Следующий слайд",children:"›"}),h.jsx(HM,{children:wi.map((k,M)=>h.jsx(VM,{active:M===i,onClick:()=>m(M),"aria-label":`Перейти к слайду ${M+1}`},M))})]})]})]})},FM=w.div`
  width: 100%;
  margin: 2rem 0;
  padding: 1.5rem;
  background: var(--color-surface);
  border-radius: 16px;
  box-shadow: var(--shadow-wellness-lg);
  
  @media (max-width: 768px) {
    padding: 1rem;
    margin: 1rem 0;
  }
  
  @media (max-width: 480px) {
    padding: 0.7rem;
    margin: 0.7rem 0;
    border-radius: 12px;
  }
`,UM=w.h2`
  font-family: var(--font-heading);
  font-size: 2.5rem;
  font-weight: 800;
  text-align: center;
  margin-bottom: 1rem;
  color: var(--color-text-primary);
  
  @media (max-width: 480px) {
    font-size: 2rem;
    margin-bottom: 0.5rem;
  }
`,qM=w.h3`
  font-family: var(--font-primary);
  font-size: 1.2rem;
  font-weight: 600;
  text-align: center;
  color: var(--color-text-secondary);
  margin-bottom: 2rem;
  
  @media (max-width: 480px) {
    font-size: 1rem;
    margin-bottom: 1rem;
  }
`,IM=w.div`
  display: flex;
  justify-content: center;
  gap: 0.5rem;
  margin-bottom: 2rem;
  overflow-x: auto;
  padding: 0.5rem;
  background: var(--color-surface-secondary);
  border-radius: 16px;
  box-shadow: var(--shadow-wellness);
  
  @media (max-width: 768px) {
    gap: 0.25rem;
    padding: 0.5rem 0.25rem;
    margin-bottom: 1.5rem;
    justify-content: flex-start;
    -webkit-overflow-scrolling: touch;
    scrollbar-width: none;
    -ms-overflow-style: none;
    
    &::-webkit-scrollbar {
      display: none;
    }
  }
  
  @media (max-width: 480px) {
    gap: 0.2rem;
    padding: 0.4rem 0.2rem;
    margin-bottom: 1rem;
    border-radius: 10px;
    position: sticky;
    top: 0;
    z-index: 10;
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(5px);
  }
`,YM=w.button`
  padding: 0.75rem 1rem;
  border-radius: 12px;
  border: none;
  background: ${e=>e.isSelected?"var(--color-primary)":"var(--color-surface)"};
  color: ${e=>e.isSelected?"var(--color-text-white)":"var(--color-text-primary)"};
  font-weight: 600;
  cursor: pointer;
  box-shadow: ${e=>e.isSelected?"var(--shadow-glow)":"var(--shadow-wellness)"};
  min-width: 80px;
  transition: var(--transition-natural);
  transform: ${e=>e.isSelected?"translateY(-3px) scale(1.05)":"none"};
  position: relative;
  overflow: hidden;
  z-index: ${e=>e.isSelected?"2":"1"};
  
  &::before {
    content: '';
    position: absolute;
    top: ${e=>e.isSelected?"-10%":"100%"};
    left: 0;
    width: 100%;
    height: 4px;
    background: var(--color-tertiary);
    transition: var(--transition-natural);
    opacity: ${e=>e.isSelected?"1":"0"};
  }
  
  &:hover {
    transform: ${e=>e.isSelected?"translateY(-3px) scale(1.05)":"translateY(-2px)"};
    box-shadow: var(--shadow-wellness-lg);
    background: ${e=>e.isSelected?"var(--color-primary)":"var(--color-secondary)"};
    color: var(--color-text-white);
    
    &::before {
      top: ${e=>e.isSelected?"-10%":"0"};
      opacity: 1;
    }
  }
  
  @media (max-width: 768px) {
    min-width: 70px;
    padding: 0.6rem 0.8rem;
    font-size: 0.9rem;
  }
  
  @media (max-width: 480px) {
    min-width: 55px;
    flex: 1;
    padding: 0.4rem 0.3rem;
    font-size: 0.8rem;
    border-radius: 8px;
    transform: ${e=>e.isSelected?"translateY(-2px) scale(1.02)":"none"};
    display: flex;
    flex-direction: column;
    align-items: center;
    
    span {
      display: block;
      line-height: 1.2;
    }
  }
`,GM=w.table`
  width: 100%;
  border-collapse: separate;
  border-spacing: 4px;
  
  @media (max-width: 768px) {
    border-spacing: 2px;
  }
  
  @media (max-width: 480px) {
    border-spacing: 3px 4px;
    margin-top: 0.5rem;
  }
`,KM=w.th`
  padding: 1rem 0.5rem;
  text-align: center;
  font-weight: 700;
  color: ${e=>e.isSelected?"var(--color-primary)":"var(--color-text-primary)"};
  background: ${e=>e.isSelected?"rgba(144, 179, 167, 0.15)":"transparent"};
  border-radius: 12px 12px 0 0;
  transition: var(--transition-natural);
  position: relative;
  border-bottom: ${e=>e.isSelected?"3px solid var(--color-primary)":"none"};
  transform: ${e=>e.isSelected?"translateY(-4px)":"none"};
  box-shadow: ${e=>e.isSelected?"var(--shadow-wellness)":"none"};
  
  .day-name {
    display: block;
    font-size: ${e=>e.isSelected?"1.1rem":"1rem"};
    margin-bottom: 0.25rem;
    font-family: var(--font-primary);
    font-weight: ${e=>e.isSelected?"800":"700"};
    letter-spacing: ${e=>e.isSelected?"0.5px":"normal"};
  }
  
  .day-number {
    display: block;
    font-size: 0.9rem;
    opacity: ${e=>e.isSelected?"1":"0.7"};
    font-family: var(--font-primary);
  }
  
  &::after {
    content: ${e=>e.isSelected?'"▾"':'""'};
    position: absolute;
    bottom: -10px;
    left: 50%;
    transform: translateX(-50%);
    font-size: 16px;
    color: var(--color-primary);
    opacity: ${e=>e.isSelected?"1":"0"};
    transition: var(--transition-natural);
  }
  
  @media (max-width: 480px) {
    padding: 0.7rem 0.3rem;
    border-radius: 8px 8px 0 0;
    display: ${e=>e.hiddenOnMobile?"none":"table-cell"};
    width: ${e=>e.isSelected?"100%":"0"};
    
    .day-name {
      font-size: ${e=>e.isSelected?"0.95rem":"0.85rem"};
      margin-bottom: 0.1rem;
    }
    
    .day-number {
      font-size: 0.75rem;
    }
    
    &::after {
      bottom: -8px;
      font-size: 12px;
    }
  }
`,zb=w.td`
  padding: 0.5rem;
  text-align: right;
  font-weight: 600;
  font-family: var(--font-primary);
  color: var(--color-text-secondary);
  width: 80px;
  
  @media (max-width: 768px) {
    width: 60px;
    padding: 0.4rem;
    font-size: 0.9rem;
  }
  
  @media (max-width: 480px) {
    width: 40px;
    padding: 0.3rem 0.1rem 0.3rem 0;
    font-size: 0.75rem;
    position: sticky;
    left: 0;
    background: var(--color-surface);
    z-index: 2;
  }
`,$b=w.td`
  padding: 0.75rem 0.5rem;
  background-color: ${e=>e.bgColor||"transparent"};
  text-align: center;
  border-radius: 12px;
  box-shadow: ${e=>e.bgColor?"var(--shadow-wellness)":"none"};
  transition: var(--transition-natural);
  position: relative;
  height: 80px;
  width: ${e=>e.isCurrentDay?"14%":"13%"};
  overflow: hidden;
  cursor: ${e=>e.hasClass?"pointer":"default"};
  border: ${e=>e.hasClass&&e.isCurrentDay?"2px solid var(--color-primary)":"none"};
  transform: ${e=>e.hasClass&&e.isCurrentDay?"scale(1.02)":"none"};
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(135deg, rgba(144, 179, 167, 0.3), rgba(144, 179, 167, 0.1));
    opacity: 0;
    transition: var(--transition-natural);
    border-radius: 12px;
    z-index: 1;
  }
  
  &:hover {
    transform: ${e=>e.hasClass?"translateY(-3px) scale(1.03)":"none"};
    box-shadow: ${e=>e.hasClass?"0 5px 15px rgba(144, 179, 167, 0.4)":"none"};
    z-index: 2;
    border: ${e=>e.hasClass?"2px solid var(--color-primary)":"none"};
    
    &::before {
      opacity: ${e=>e.hasClass?"1":"0"};
    }
  }
  
  @media (max-width: 768px) {
    height: 70px;
    padding: 0.5rem 0.3rem;
    border-radius: 8px;
  }
  
  @media (max-width: 480px) {
    height: auto;
    min-height: 60px;
    padding: 0.3rem 0.2rem;
    width: auto;
    display: ${e=>e.hiddenOnMobile?"none":"table-cell"};
    border-radius: 8px;
  }
`,XM=w.div`
  font-weight: 700;
  text-transform: uppercase;
  font-size: 0.9rem;
  font-family: var(--font-primary);
  color: var(--color-text-primary);
  position: relative;
  z-index: 2;
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
`,ZM=w.div`
  font-weight: 800;
  text-transform: uppercase;
  font-size: 0.9rem;
  font-family: var(--font-primary);
  color: var(--color-text-primary);
  
  @media (max-width: 768px) {
    font-size: 0.8rem;
  }
  
  @media (max-width: 480px) {
    font-size: 0.75rem;
  }
`,QM=w.div`
  font-size: 0.75rem;
  font-weight: 500;
  color: var(--color-text-secondary);
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 4px;
  
  @media (max-width: 768px) {
    font-size: 0.7rem;
  }
  
  @media (max-width: 480px) {
    font-size: 0.65rem;
  }
`,JM=w.div`
  font-size: 0.75rem;
  font-weight: 500;
  font-style: italic;
  color: var(--color-text-secondary);
  
  @media (max-width: 768px) {
    font-size: 0.7rem;
  }
  
  @media (max-width: 480px) {
    font-size: 0.65rem;
  }
`,Io=[{name:"MON",number:"1",fullName:"Понедельник"},{name:"TUE",number:"2",fullName:"Вторник"},{name:"WED",number:"3",fullName:"Среда"},{name:"THU",number:"4",fullName:"Четверг"},{name:"FRI",number:"5",fullName:"Пятница"},{name:"SAT",number:"6",fullName:"Суббота"},{name:"SUN",number:"7",fullName:"Воскресенье"}],Nb=["9:00","10:00","11:00","12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00"],Lb=["YOGA","STRETCHING","MOBILITY","ZUMBA","BARRE","HIGH HEELS","TABATA","FITNESS","STRONG NATION","CIRCL MOBILITY"],_b=["Anna K.","Michael S.","Elena G.","Sergei T.","Maria V.","Alexey D.","Viktoria Z.","Dmitry L.","Natalia M.","Ivan P."],WM=()=>{const e=[];return Io.forEach((i,a)=>{const r=3+Math.floor(Math.random()*3);for(let s=0;s<r;s++){const c=9+Math.floor(Math.random()*9),u=45+Math.floor(Math.random()*4)*15,f=Lb[Math.floor(Math.random()*Lb.length)],p=_b[Math.floor(Math.random()*_b.length)],m=10+Math.floor(Math.random()*11),y=Math.floor(Math.random()*(m+1));e.push({id:`class-${a}-${s}`,day:a,startTime:`${c}:00`,classType:f,trainer:p,duration:u,maxParticipants:m,currentParticipants:y})}}),e},eB=e=>({YOGA:"rgba(144, 179, 167, 0.2)",STRETCHING:"rgba(200, 168, 233, 0.2)",MOBILITY:"rgba(144, 179, 167, 0.15)",ZUMBA:"rgba(212, 165, 116, 0.2)",BARRE:"rgba(212, 165, 116, 0.15)","HIGH HEELS":"rgba(200, 168, 233, 0.15)",TABATA:"rgba(212, 165, 116, 0.25)",FITNESS:"rgba(144, 179, 167, 0.25)","STRONG NATION":"rgba(200, 168, 233, 0.25)","CIRCL MOBILITY":"rgba(144, 179, 167, 0.18)"})[e]||"rgba(144, 179, 167, 0.1)",tB=()=>{const{t:e}=De(),[i,a]=S.useState([]),[r,s]=S.useState(!0),[c,u]=S.useState(new Date().getDay()===0?6:new Date().getDay()-1),[f,p]=S.useState(window.innerWidth<=480);return S.useEffect(()=>{(async()=>{s(!0),await new Promise(x=>setTimeout(x,500));const y=WM();a(y),s(!1)})()},[]),S.useEffect(()=>{const m=()=>{p(window.innerWidth<=480)};return m(),window.addEventListener("resize",m),()=>window.removeEventListener("resize",m)},[]),h.jsx(Wp,{id:"schedule",children:h.jsxs(t0,{children:[h.jsxs("div",{style:{textAlign:"center"},children:[h.jsx(e0,{children:e("sports.schedule.tag","Расписание")}),h.jsx(UM,{children:"SCHEDULE"}),h.jsx(qM,{children:"ВЫБЕРИТЕ ДЕНЬ НЕДЕЛИ"})]}),h.jsxs(FM,{children:[h.jsx(IM,{children:Io.map((m,y)=>h.jsxs(YM,{isSelected:y===c,onClick:()=>u(y),children:[h.jsx("span",{children:m.name}),h.jsx("span",{style:{fontSize:"0.8rem",opacity:.8},children:m.number})]},m.name))}),h.jsxs(GM,{children:[h.jsx("thead",{children:h.jsxs("tr",{children:[h.jsx("th",{style:{width:f?"40px":"80px"}}),Io.map((m,y)=>h.jsxs(KM,{isSelected:y===c,hiddenOnMobile:f&&y!==c,children:[h.jsx("span",{className:"day-name",children:m.name}),h.jsx("span",{className:"day-number",children:m.number})]},m.name))]})}),h.jsx("tbody",{children:r?Nb.map((m,y)=>h.jsxs("tr",{children:[h.jsx(zb,{children:m}),Io.map((x,b)=>h.jsx($b,{children:Math.random()>.7&&h.jsx("div",{style:{height:"100%",background:"#f3f4f6",borderRadius:"4px",animation:"pulse 1.5s infinite"}})},`loading-cell-${b}-${y}`))]},`loading-row-${y}`)):Nb.map((m,y)=>h.jsxs("tr",{children:[h.jsx(zb,{children:m}),Io.map((x,b)=>{const T=i.find(A=>A.day===b&&A.startTime===m);return h.jsx($b,{bgColor:T?eB(T.classType):"transparent",hasClass:!!T,isCurrentDay:b===c,hiddenOnMobile:f&&b!==c,children:T&&h.jsxs(XM,{children:[h.jsx(ZM,{children:T.classType}),h.jsxs(QM,{children:[T.duration," мин"]}),h.jsx(JM,{children:T.trainer})]})},`cell-${b}-${y}`)})]},`time-row-${y}`))})]})]})]})})},iB=()=>(S.useEffect(()=>(console.log("SportsPage загружается..."),document.body.classList.add("sports-page"),window.scrollTo(0,0),()=>{console.log("SportsPage выгружается..."),document.body.classList.remove("sports-page")}),[]),h.jsxs(EM,{initial:{opacity:0},animate:{opacity:1},transition:{duration:.2},children:[h.jsx(AM,{}),h.jsx($M,{}),h.jsx(PM,{}),h.jsx(tB,{})]})),nB=w.section`
  position: relative;
  min-height: 100vh;
  background: linear-gradient(135deg, 
    #fef7f0 0%,
    #f7e8d8 60%,
    #f2dcc4 100%
  );
  overflow: hidden;
  display: flex;
  align-items: center;
  padding: 6rem 0;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: 
      radial-gradient(circle at 20% 20%, rgba(180, 142, 98, 0.08) 0%, transparent 50%),
      radial-gradient(circle at 80% 80%, rgba(205, 133, 63, 0.08) 0%, transparent 50%);
    z-index: 1;
    pointer-events: none;
  }
`,aB=w.div`
  position: absolute;
  width: 100%;
  height: 100%;
  overflow: hidden;
  z-index: 2;
  pointer-events: none;
`,Hb=w(O.div)`
  position: absolute;
  border-radius: 50%;
  background: ${e=>e.$color};
  opacity: ${e=>e.$opacity||.15};
`,rB=w(O.div)`
  position: absolute;
  background: ${e=>e.$gradient||"linear-gradient(135deg, rgba(180, 142, 98, 0.1) 0%, rgba(180, 142, 98, 0.01) 100%)"};
  border-radius: ${e=>e.$borderRadius||"30% 70% 70% 30% / 30% 30% 70% 70%"};
  opacity: ${e=>e.$opacity||.08};
  z-index: ${e=>e.$zIndex||1};
`,oB=w.div`
  position: relative;
  z-index: 10;
  width: 100%;
  max-width: 1500px;
  margin: 0 auto;
  padding: 0 1.5rem;
  
  @media (min-width: 768px) {
    padding: 0 2rem;
  }
  
  @media (min-width: 1280px) {
    padding: 0 3rem;
  }
`,sB=w.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 4rem;
  align-items: center;
  position: relative;
  z-index: 2;
  
  @media (min-width: 1024px) {
    grid-template-columns: 0.9fr 1.1fr;
    gap: 2rem;
  }
  
  @media (min-width: 1280px) {
    grid-template-columns: 0.85fr 1.15fr;
    gap: 4rem;
  }
`,lB=w(O.div)`
  position: relative;
  text-align: left;
  max-width: 600px;
  z-index: 10;
  
  @media (max-width: 1023px) {
    text-align: center;
    margin: 0 auto;
    padding-top: 2rem;
  }
`,cB=w(O.div)`
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.75rem 1.5rem;
  background: linear-gradient(135deg, rgba(205, 133, 63, 0.15) 0%, rgba(180, 142, 98, 0.18) 100%);
  border: 1px solid rgba(205, 133, 63, 0.25);
  border-radius: 30px;
  font-family: ${({theme:e})=>{var i;return((i=e==null?void 0:e.fonts)==null?void 0:i.primary)||"Inter, sans-serif"}};
  font-size: 0.875rem;
  font-weight: 500;
  color: #B8804A;
  margin-bottom: 2rem;
  box-shadow: 0 4px 15px rgba(205, 133, 63, 0.12);
  letter-spacing: 0.03em;
  
  svg {
    width: 1rem;
    height: 1rem;
    color: #CD853F;
  }
`,uB=w(O.h1)`
  font-family: ${({theme:e})=>{var i;return((i=e==null?void 0:e.fonts)==null?void 0:i.elegant)||'"Playfair Display", serif'}};
  font-size: clamp(2.75rem, 7vw, 4.5rem);
  font-weight: 600;
  line-height: 1.1;
  margin-bottom: 1.5rem;
  background: linear-gradient(135deg, 
    #8B4513 0%, 
    #A0522D 40%, 
    #CD853F 70%, 
    #DEB887 100%
  );
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  letter-spacing: -0.03em;
`,dB=w(O.h2)`
  font-family: ${({theme:e})=>{var i;return((i=e==null?void 0:e.fonts)==null?void 0:i.heading)||'"Poppins", sans-serif'}};
  font-size: clamp(1.125rem, 2.5vw, 1.5rem);
  font-weight: 400;
  line-height: 1.4;
  margin-bottom: 2rem;
  color: #A0522D;
  letter-spacing: 0.02em;
`,fB=w(O.p)`
  font-family: ${({theme:e})=>{var i;return((i=e==null?void 0:e.fonts)==null?void 0:i.primary)||"Inter, sans-serif"}};
  font-size: 1.125rem;
  line-height: 1.7;
  color: #8B6F4A;
  margin-bottom: 3rem;
  font-weight: 400;
  letter-spacing: 0.01em;
`,hB=w(O.div)`
  display: flex;
  flex-wrap: wrap;
  gap: 1rem;
  margin-bottom: 3rem;
  
  @media (max-width: 640px) {
    justify-content: center;
  }
`,pB=w(O.button)`
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 1rem 2rem;
  background: linear-gradient(135deg, #CD853F 0%, #DEB887 100%);
  color: white;
  border: none;
  border-radius: 50px;
  font-family: ${({theme:e})=>{var i;return((i=e==null?void 0:e.fonts)==null?void 0:i.primary)||"Inter, sans-serif"}};
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 4px 15px rgba(205, 133, 63, 0.3);
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(205, 133, 63, 0.4);
  }
  
  svg {
    width: 1.25rem;
    height: 1.25rem;
    transition: transform 0.3s ease;
  }
  
  &:hover svg {
    transform: translateX(3px);
  }
`,mB=w(O.button)`
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 1rem 2rem;
  background: transparent;
  color: #CD853F;
  border: 2px solid #CD853F;
  border-radius: 50px;
  font-family: ${({theme:e})=>{var i;return((i=e==null?void 0:e.fonts)==null?void 0:i.primary)||"Inter, sans-serif"}};
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    background: #CD853F;
    color: white;
    transform: translateY(-2px);
  }
  
  svg {
    width: 1.25rem;
    height: 1.25rem;
  }
`,gB=w(O.div)`
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 400px;
  
  @media (max-width: 1023px) {
    margin-top: 2rem;
  }
`,yB=w.div`
  position: relative;
  width: 100%;
  max-width: 500px;
  height: 400px;
  background: linear-gradient(135deg, 
    rgba(205, 133, 63, 0.1) 0%, 
    rgba(222, 184, 135, 0.15) 50%,
    rgba(180, 142, 98, 0.1) 100%
  );
  border-radius: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 20px 40px rgba(205, 133, 63, 0.15);
  border: 1px solid rgba(205, 133, 63, 0.2);
`,xB=w.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 2rem;
  align-items: center;
  justify-items: center;
`,Gl=w(O.div)`
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  gap: 0.5rem;
  
  svg {
    width: 3rem;
    height: 3rem;
    color: #CD853F;
    margin-bottom: 0.5rem;
  }
  
  span {
    font-size: 0.875rem;
    color: #8B6F4A;
    font-weight: 500;
    text-align: center;
  }
`,bB=w(O.div)`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 2rem;
  margin-top: 2rem;
  
  @media (max-width: 640px) {
    grid-template-columns: 1fr;
    gap: 1rem;
  }
`,rh=w.div`
  text-align: center;
  
  .stat-number {
    font-family: ${({theme:e})=>{var i;return((i=e==null?void 0:e.fonts)==null?void 0:i.elegant)||'"Playfair Display", serif'}};
    font-size: 2.5rem;
    font-weight: 700;
    color: #CD853F;
    margin-bottom: 0.5rem;
    display: block;
  }
  
  .stat-label {
    font-size: 0.875rem;
    color: #8B6F4A;
    font-weight: 500;
  }
`,vB=()=>{const{t:e}=De(),i={hidden:{opacity:0},visible:{opacity:1,transition:{duration:.6,staggerChildren:.1}}},a={hidden:{opacity:0,y:20},visible:{opacity:1,y:0,transition:{duration:.5}}};return h.jsxs(nB,{children:[h.jsxs(aB,{children:[h.jsx(Hb,{style:{top:"10%",left:"5%",width:"100px",height:"100px"},$color:"linear-gradient(135deg, rgba(205, 133, 63, 0.1), rgba(222, 184, 135, 0.05))",animate:{scale:[1,1.2,1],opacity:[.1,.2,.1]},transition:{duration:8,repeat:1/0}}),h.jsx(Hb,{style:{top:"60%",right:"10%",width:"150px",height:"150px"},$color:"linear-gradient(135deg, rgba(180, 142, 98, 0.08), rgba(205, 133, 63, 0.03))",animate:{scale:[1,1.1,1],opacity:[.08,.15,.08]},transition:{duration:10,repeat:1/0,delay:2}}),h.jsx(rB,{style:{top:"20%",right:"20%",width:"80px",height:"80px"},animate:{rotate:[0,180,360]},transition:{duration:20,repeat:1/0,ease:"linear"}})]}),h.jsx(oB,{children:h.jsxs(sB,{children:[h.jsxs(lB,{variants:i,initial:"hidden",animate:"visible",children:[h.jsxs(cB,{variants:a,children:[h.jsx(hs,{}),e("banya.hero.badge","Традиционная русская баня")]}),h.jsx(uB,{variants:a,children:e("banya.hero.title","Погрузитесь в мир русской бани")}),h.jsx(dB,{variants:a,children:e("banya.hero.subtitle","Истинное наслаждение и оздоровление")}),h.jsx(fB,{variants:a,children:e("banya.hero.description","Откройте для себя традиции русской бани в современном исполнении. Парение на березовых вениках, ароматные травы и профессиональный уход для полного расслабления и оздоровления.")}),h.jsxs(hB,{variants:a,children:[h.jsxs(pB,{whileHover:{scale:1.05},whileTap:{scale:.95},children:[e("banya.hero.book_now","Забронировать сеанс"),h.jsx(Sr,{})]}),h.jsxs(mB,{whileHover:{scale:1.05},whileTap:{scale:.95},children:[e("banya.hero.learn_more","Узнать больше"),h.jsx(ab,{})]})]}),h.jsxs(bB,{variants:a,children:[h.jsxs(rh,{children:[h.jsx("span",{className:"stat-number",children:"85°C"}),h.jsx("span",{className:"stat-label",children:e("banya.hero.temp","Оптимальная температура")})]}),h.jsxs(rh,{children:[h.jsx("span",{className:"stat-number",children:"3"}),h.jsx("span",{className:"stat-label",children:e("banya.hero.rooms","Парных помещения")})]}),h.jsxs(rh,{children:[h.jsx("span",{className:"stat-number",children:"24/7"}),h.jsx("span",{className:"stat-label",children:e("banya.hero.access","Доступ для гостей")})]})]})]}),h.jsx(gB,{initial:{opacity:0,x:30},animate:{opacity:1,x:0},transition:{duration:.8,delay:.3},children:h.jsx(yB,{children:h.jsxs(xB,{children:[h.jsxs(Gl,{whileHover:{scale:1.1},transition:{duration:.3},children:[h.jsx(hs,{}),h.jsx("span",{children:e("banya.hero.steam","Пар")})]}),h.jsxs(Gl,{whileHover:{scale:1.1},transition:{duration:.3},children:[h.jsx(ab,{}),h.jsx("span",{children:e("banya.hero.herbs","Травы")})]}),h.jsxs(Gl,{whileHover:{scale:1.1},transition:{duration:.3},children:[h.jsx(es,{}),h.jsx("span",{children:e("banya.hero.company","Компания")})]}),h.jsxs(Gl,{whileHover:{scale:1.1},transition:{duration:.3},children:[h.jsx(Tr,{}),h.jsx("span",{children:e("banya.hero.relax","Релакс")})]})]})})})]})})]})},wB=S.memo(vB),SB=w.section`
  position: relative;
  padding: 8rem 0;
  background: linear-gradient(135deg, 
    #fefcfa 0%, 
    #f9f5f1 50%, 
    #f5f0eb 100%
  );
  overflow: hidden;
`,TB=w.div`
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 1.5rem;
  
  @media (min-width: 768px) {
    padding: 0 2rem;
  }
`,jB=w.div`
  text-align: center;
  margin-bottom: 6rem;
`,AB=w(O.div)`
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.75rem 1.5rem;
  background: linear-gradient(135deg, rgba(205, 133, 63, 0.12) 0%, rgba(180, 142, 98, 0.15) 100%);
  border: 1px solid rgba(205, 133, 63, 0.2);
  border-radius: 30px;
  font-size: 0.875rem;
  font-weight: 500;
  color: #B8804A;
  margin-bottom: 1.5rem;
  
  svg {
    width: 1rem;
    height: 1rem;
    color: #CD853F;
  }
`,EB=w(O.h2)`
  font-family: "Playfair Display", serif;
  font-size: clamp(2.5rem, 5vw, 3.5rem);
  font-weight: 600;
  line-height: 1.2;
  margin-bottom: 1.5rem;
  background: linear-gradient(135deg, #8B4513 0%, #CD853F 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
`,CB=w(O.p)`
  font-size: 1.25rem;
  line-height: 1.6;
  color: #8B6F4A;
  max-width: 600px;
  margin: 0 auto;
`,OB=w.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 2rem;
  
  @media (min-width: 768px) {
    grid-template-columns: repeat(2, 1fr);
    gap: 2.5rem;
  }
  
  @media (min-width: 1024px) {
    grid-template-columns: repeat(3, 1fr);
    gap: 3rem;
  }
`,RB=w(O.div)`
  background: rgba(255, 252, 250, 0.8);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(205, 133, 63, 0.15);
  border-radius: 25px;
  padding: 2.5rem 2rem;
  text-align: center;
  position: relative;
  overflow: hidden;
  transition: all 0.4s ease;
  
  &:hover {
    transform: translateY(-8px);
    box-shadow: 0 20px 40px rgba(205, 133, 63, 0.15);
    border-color: rgba(205, 133, 63, 0.3);
  }
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(135deg, rgba(205, 133, 63, 0.02) 0%, rgba(180, 142, 98, 0.03) 100%);
    opacity: 0;
    transition: opacity 0.3s ease;
  }
  
  &:hover::before {
    opacity: 1;
  }
`,kB=w.div`
  width: 80px;
  height: 80px;
  background: linear-gradient(135deg, rgba(205, 133, 63, 0.15) 0%, rgba(180, 142, 98, 0.2) 100%);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 1.5rem;
  position: relative;
  z-index: 2;
  
  svg {
    width: 40px;
    height: 40px;
    color: #CD853F;
  }
`,DB=w.h3`
  font-family: "Poppins", sans-serif;
  font-size: 1.5rem;
  font-weight: 600;
  color: #8B4513;
  margin-bottom: 1rem;
  position: relative;
  z-index: 2;
`,MB=w.p`
  font-size: 1rem;
  line-height: 1.6;
  color: #8B6F4A;
  margin-bottom: 1.5rem;
  position: relative;
  z-index: 2;
`,BB=w.ul`
  list-style: none;
  padding: 0;
  margin: 0 0 2rem 0;
  position: relative;
  z-index: 2;
`,zB=w.li`
  font-size: 0.875rem;
  color: #A0522D;
  margin-bottom: 0.5rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  
  &::before {
    content: '✓';
    color: #CD853F;
    font-weight: bold;
  }
`,$B=w.div`
  font-size: 1.25rem;
  font-weight: 700;
  color: #8B4513;
  margin-bottom: 1.5rem;
  position: relative;
  z-index: 2;
`,NB=w(O.button)`
  background: linear-gradient(135deg, #CD853F 0%, #DEB887 100%);
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 25px;
  font-weight: 600;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin: 0 auto;
  transition: all 0.3s ease;
  position: relative;
  z-index: 2;
  
  &:hover {
    transform: scale(1.05);
    box-shadow: 0 8px 20px rgba(205, 133, 63, 0.3);
  }
  
  svg {
    width: 16px;
    height: 16px;
    transition: transform 0.3s ease;
  }
  
  &:hover svg {
    transform: translateX(3px);
  }
`,LB=[{icon:hs,title:"Классическая Баня",description:"Традиционная русская баня с березовыми вениками и ароматными травами",features:["Березовые веники","Травяные настои","Контрастные процедуры","Чаепитие"],price:"2500 ₽",duration:"2 часа"},{icon:Uc,title:"VIP Баня",description:"Премиальный банный комплекс с дополнительными услугами и персональным обслуживанием",features:["Персональный банщик","Элитные веники","Медовые обертывания","Массаж"],price:"5000 ₽",duration:"3 часа"},{icon:Jp,title:"Парная для двоих",description:"Романтическая банная церемония для пар с особой атмосферой",features:["Приватная парная","Ароматерапия","Шампанское","Фрукты"],price:"4000 ₽",duration:"2.5 часа"},{icon:es,title:"Корпоративная Баня",description:"Банные программы для компаний и больших групп до 8 человек",features:["Групповые процедуры","Банкетный зал","Развлечения","Кейтеринг"],price:"8000 ₽",duration:"4 часа"}],_B=()=>{const{t:e}=De(),i={hidden:{},visible:{transition:{staggerChildren:.2}}},a={hidden:{opacity:0,y:30},visible:{opacity:1,y:0,transition:{duration:.6,ease:[.25,.46,.45,.94]}}};return h.jsx(SB,{children:h.jsxs(TB,{children:[h.jsxs(jB,{children:[h.jsxs(AB,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{duration:.6},children:[h.jsx(hs,{}),"Наши Услуги"]}),h.jsx(EB,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{delay:.2,duration:.8},children:"Банные Программы"}),h.jsx(CB,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{delay:.4,duration:.8},children:"Выберите подходящую программу для полного расслабления и оздоровления"})]}),h.jsx(O.div,{variants:i,initial:"hidden",whileInView:"visible",viewport:{once:!0},children:h.jsx(OB,{children:LB.map((r,s)=>h.jsxs(RB,{variants:a,whileHover:{scale:1.02},children:[h.jsx(kB,{children:h.jsx(r.icon,{})}),h.jsx(DB,{children:r.title}),h.jsx(MB,{children:r.description}),h.jsx(BB,{children:r.features.map((c,u)=>h.jsx(zB,{children:c},u))}),h.jsxs($B,{children:[r.price," ",h.jsxs("span",{style:{fontSize:"0.875rem",fontWeight:400},children:["/ ",r.duration]})]}),h.jsxs(NB,{whileHover:{scale:1.05},whileTap:{scale:.95},children:["Забронировать",h.jsx(Sr,{})]})]},s))})})]})})},HB=w.section`
  position: relative;
  padding: 8rem 0;
  background: linear-gradient(135deg, #f7f3ef 0%, #f2e8d8 100%);
  overflow: hidden;
`,VB=w.div`
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 1.5rem;
  
  @media (min-width: 768px) {
    padding: 0 2rem;
  }
`,PB=w.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 4rem;
  align-items: center;
  
  @media (min-width: 1024px) {
    grid-template-columns: 1fr 1fr;
    gap: 6rem;
  }
`,FB=w.div`
  text-align: left;
  
  @media (max-width: 1023px) {
    text-align: center;
  }
`,UB=w(O.div)`
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.75rem 1.5rem;
  background: linear-gradient(135deg, rgba(205, 133, 63, 0.12) 0%, rgba(180, 142, 98, 0.15) 100%);
  border: 1px solid rgba(205, 133, 63, 0.2);
  border-radius: 30px;
  font-size: 0.875rem;
  font-weight: 500;
  color: #B8804A;
  margin-bottom: 2rem;
  
  svg {
    width: 1rem;
    height: 1rem;
    color: #CD853F;
  }
`,qB=w(O.h2)`
  font-family: "Playfair Display", serif;
  font-size: clamp(2.5rem, 5vw, 3.5rem);
  font-weight: 600;
  line-height: 1.2;
  margin-bottom: 1.5rem;
  background: linear-gradient(135deg, #8B4513 0%, #CD853F 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
`,IB=w(O.p)`
  font-size: 1.25rem;
  line-height: 1.6;
  color: #8B6F4A;
  margin-bottom: 3rem;
`,YB=w.div`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`,GB=w(O.div)`
  display: flex;
  align-items: flex-start;
  gap: 1rem;
  padding: 1.5rem;
  background: rgba(255, 252, 250, 0.8);
  border: 1px solid rgba(205, 133, 63, 0.15);
  border-radius: 20px;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateX(10px);
    box-shadow: 0 10px 30px rgba(205, 133, 63, 0.1);
    border-color: rgba(205, 133, 63, 0.25);
  }
`,KB=w.div`
  width: 60px;
  height: 60px;
  background: linear-gradient(135deg, rgba(205, 133, 63, 0.15) 0%, rgba(180, 142, 98, 0.2) 100%);
  border-radius: 15px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  
  svg {
    width: 30px;
    height: 30px;
    color: #CD853F;
  }
`,XB=w.div`
  flex: 1;
`,ZB=w.h3`
  font-family: "Poppins", sans-serif;
  font-size: 1.25rem;
  font-weight: 600;
  color: #8B4513;
  margin-bottom: 0.5rem;
`,QB=w.p`
  font-size: 1rem;
  line-height: 1.5;
  color: #8B6F4A;
`,JB=w(O.div)`
  position: relative;
  
  @media (max-width: 1023px) {
    order: -1;
  }
`,WB=w.div`
  position: relative;
  border-radius: 30px;
  overflow: hidden;
  box-shadow: 0 25px 60px rgba(139, 69, 19, 0.15);
`,ez=w.img`
  width: 100%;
  height: 500px;
  object-fit: cover;
  
  @media (max-width: 768px) {
    height: 400px;
  }
`,tz=w(O.div)`
  position: absolute;
  bottom: 2rem;
  left: 2rem;
  right: 2rem;
  background: rgba(255, 252, 250, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 20px;
  padding: 1.5rem;
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1rem;
  
  @media (max-width: 640px) {
    grid-template-columns: 1fr;
    gap: 0.5rem;
  }
`,oh=w.div`
  text-align: center;
`,sh=w.div`
  font-size: 1.5rem;
  font-weight: 700;
  color: #8B4513;
  margin-bottom: 0.25rem;
`,lh=w.div`
  font-size: 0.875rem;
  color: #A0522D;
  font-weight: 500;
`,iz=[{icon:Jp,title:"Здоровье и оздоровление",description:"Улучшает кровообращение, выводит токсины, укрепляет иммунитет и снимает стресс"},{icon:mC,title:"Безопасность и комфорт",description:"Соблюдение всех санитарных норм, современное оборудование, комфортная температура"},{icon:Uc,title:"Эксклюзивные процедуры",description:"Авторские банные ритуалы, редкие виды веников, уникальные ароматические композиции"},{icon:hs,title:"Аутентичная атмосфера",description:"Традиционная русская баня с соблюдением всех классических канонов и обрядов"}],nz=()=>{const{t:e}=De(),i={hidden:{},visible:{transition:{staggerChildren:.2}}},a={hidden:{opacity:0,x:-30},visible:{opacity:1,x:0,transition:{duration:.6,ease:[.25,.46,.45,.94]}}};return h.jsx(HB,{children:h.jsx(VB,{children:h.jsxs(PB,{children:[h.jsxs(FB,{children:[h.jsxs(UB,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{duration:.6},children:[h.jsx(Uc,{}),"Преимущества"]}),h.jsx(qB,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{delay:.2,duration:.8},children:"Почему выбирают нашу баню"}),h.jsx(IB,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{delay:.4,duration:.8},children:"Мы создали уникальное пространство, где традиции русской бани сочетаются с современным комфортом и высоким качеством обслуживания"}),h.jsx(O.div,{variants:i,initial:"hidden",whileInView:"visible",viewport:{once:!0},children:h.jsx(YB,{children:iz.map((r,s)=>h.jsxs(GB,{variants:a,whileHover:{scale:1.02},children:[h.jsx(KB,{children:h.jsx(r.icon,{})}),h.jsxs(XB,{children:[h.jsx(ZB,{children:r.title}),h.jsx(QB,{children:r.description})]})]},s))})})]}),h.jsx(JB,{initial:{opacity:0,scale:.95},whileInView:{opacity:1,scale:1},viewport:{once:!0},transition:{duration:1,ease:[.25,.46,.45,.94]},children:h.jsxs(WB,{children:[h.jsx(ez,{src:"https://images.unsplash.com/photo-1594736797933-d0401ba2fe65?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=85",alt:"Банные процедуры"}),h.jsxs(tz,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{delay:.6,duration:.8},children:[h.jsxs(oh,{children:[h.jsx(sh,{children:"15+"}),h.jsx(lh,{children:"Лет опыта"})]}),h.jsxs(oh,{children:[h.jsx(sh,{children:"5000+"}),h.jsx(lh,{children:"Довольных гостей"})]}),h.jsxs(oh,{children:[h.jsx(sh,{children:"100°C"}),h.jsx(lh,{children:"Идеальный пар"})]})]})]})})]})})})},az=w.section`
  padding: 8rem 0;
  background: linear-gradient(135deg, #fefcfa 0%, #f9f5f1 100%);
`,rz=w.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 1.5rem;
`,oz=w.div`
  text-align: center;
  margin-bottom: 4rem;
`,sz=w(O.h2)`
  font-family: "Playfair Display", serif;
  font-size: clamp(2.5rem, 5vw, 3.5rem);
  font-weight: 600;
  color: #8B4513;
  margin-bottom: 1rem;
`,lz=w(O.div)`
  background: rgba(255, 252, 250, 0.9);
  border: 1px solid rgba(205, 133, 63, 0.15);
  border-radius: 25px;
  padding: 2.5rem;
  text-align: center;
  position: relative;
  box-shadow: 0 10px 30px rgba(205, 133, 63, 0.1);
`,cz=w.div`
  width: 60px;
  height: 60px;
  background: linear-gradient(135deg, #CD853F 0%, #DEB887 100%);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 1.5rem;
  
  svg {
    width: 30px;
    height: 30px;
    color: white;
  }
`,uz=w.p`
  font-size: 1.125rem;
  line-height: 1.6;
  color: #8B6F4A;
  margin-bottom: 2rem;
  font-style: italic;
`,dz=w.h4`
  font-weight: 600;
  color: #8B4513;
  margin-bottom: 0.5rem;
`,fz=w.p`
  color: #A0522D;
  font-size: 0.875rem;
`,hz=w.div`
  display: flex;
  justify-content: center;
  gap: 0.25rem;
  margin-bottom: 1rem;
  
  svg {
    width: 20px;
    height: 20px;
    color: #CD853F;
  }
`,pz=()=>h.jsx(az,{children:h.jsxs(rz,{children:[h.jsx(oz,{children:h.jsx(sz,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{duration:.8},children:"Отзывы наших гостей"})}),h.jsxs(lz,{initial:{opacity:0,y:40},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{duration:.8,delay:.2},children:[h.jsx(cz,{children:h.jsx(ps,{})}),h.jsx(hz,{children:[...Array(5)].map((e,i)=>h.jsx(ps,{},i))}),h.jsx(uz,{children:'"Невероятный опыт! Настоящая русская баня с аутентичной атмосферой. Березовые веники, ароматный пар, профессиональный банщик - все на высшем уровне. Чувствую себя полностью обновленным после каждого посещения."'}),h.jsx(dz,{children:"Александр Петров"}),h.jsx(fz,{children:"Постоянный гость"})]})]})}),mz=w.section`
  padding: 8rem 0;
  background: linear-gradient(135deg, #f2dcc4 0%, #e8c5a0 100%);
  position: relative;
  overflow: hidden;
`,gz=w.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 1.5rem;
  text-align: center;
`,yz=w(O.h2)`
  font-family: "Playfair Display", serif;
  font-size: clamp(2.5rem, 5vw, 3.5rem);
  font-weight: 600;
  color: #8B4513;
  margin-bottom: 1.5rem;
`,xz=w(O.p)`
  font-size: 1.25rem;
  line-height: 1.6;
  color: #8B6F4A;
  margin-bottom: 3rem;
  max-width: 600px;
  margin-left: auto;
  margin-right: auto;
`,bz=w(O.div)`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  align-items: center;
  
  @media (min-width: 640px) {
    flex-direction: row;
    justify-content: center;
    gap: 2rem;
  }
`,vz=w(O(hi))`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.75rem;
  padding: 1.25rem 3rem;
  font-size: 1.125rem;
  font-weight: 600;
  text-decoration: none;
  border-radius: 50px;
  background: linear-gradient(135deg, #8B4513 0%, #A0522D 100%);
  color: white !important;
  box-shadow: 0 10px 30px rgba(139, 69, 19, 0.3);
  transition: all 0.4s ease;
  
  &:hover {
    transform: translateY(-3px);
    box-shadow: 0 15px 40px rgba(139, 69, 19, 0.4);
  }
  
  svg {
    width: 20px;
    height: 20px;
  }
`,wz=w(O.button)`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.75rem;
  padding: 1.25rem 3rem;
  font-size: 1.125rem;
  font-weight: 500;
  border: 2px solid rgba(139, 69, 19, 0.3);
  background: rgba(255, 252, 250, 0.9);
  color: #8B4513;
  border-radius: 50px;
  cursor: pointer;
  transition: all 0.4s ease;
  
  &:hover {
    transform: translateY(-2px);
    background: rgba(139, 69, 19, 0.1);
    border-color: rgba(139, 69, 19, 0.5);
  }
  
  svg {
    width: 20px;
    height: 20px;
  }
`,Sz=w(O.div)`
  margin-top: 4rem;
  padding: 2rem;
  background: rgba(255, 252, 250, 0.8);
  border: 1px solid rgba(205, 133, 63, 0.2);
  border-radius: 25px;
  backdrop-filter: blur(10px);
`,Tz=w.h3`
  font-family: "Poppins", sans-serif;
  font-size: 1.5rem;
  font-weight: 600;
  color: #8B4513;
  margin-bottom: 1rem;
`,jz=w.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  
  @media (min-width: 768px) {
    flex-direction: row;
    justify-content: center;
    gap: 3rem;
  }
`,Vb=w.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.75rem;
  font-size: 1.125rem;
  color: #8B6F4A;
  
  svg {
    width: 24px;
    height: 24px;
    color: #CD853F;
  }
`,Az=()=>{const{t:e}=De();return h.jsx(mz,{children:h.jsxs(gz,{children:[h.jsx(yz,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{duration:.8},children:"Забронируйте сеанс"}),h.jsx(xz,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{delay:.2,duration:.8},children:"Окунитесь в мир традиционной русской бани. Забронируйте свой сеанс прямо сейчас и получите незабываемый опыт оздоровления и релаксации."}),h.jsxs(bz,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{delay:.4,duration:.8},children:[h.jsxs(vz,{to:"/contacts",whileHover:{scale:1.02},whileTap:{scale:.98},children:[h.jsx(rb,{}),"Забронировать онлайн",h.jsx(Sr,{})]}),h.jsxs(wz,{whileHover:{scale:1.02},whileTap:{scale:.98},children:[h.jsx(Wi,{}),"Позвонить сейчас"]})]}),h.jsxs(Sz,{initial:{opacity:0,y:40},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{delay:.6,duration:.8},children:[h.jsx(Tz,{children:"Контакты для бронирования"}),h.jsxs(jz,{children:[h.jsxs(Vb,{children:[h.jsx(Wi,{}),"+7 (495) 123-45-67"]}),h.jsxs(Vb,{children:[h.jsx(rb,{}),"Работаем ежедневно 10:00 - 22:00"]})]})]})]})})},Ez=w.section`
  padding: 8rem 0;
  background: linear-gradient(135deg, #f7f3ef 0%, #f2e8d8 100%);
`,Cz=w.div`
  max-width: 800px;
  margin: 0 auto;
  padding: 0 1.5rem;
`,Oz=w.div`
  text-align: center;
  margin-bottom: 4rem;
`,Rz=w(O.div)`
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.75rem 1.5rem;
  background: linear-gradient(135deg, rgba(205, 133, 63, 0.12) 0%, rgba(180, 142, 98, 0.15) 100%);
  border: 1px solid rgba(205, 133, 63, 0.2);
  border-radius: 30px;
  font-size: 0.875rem;
  font-weight: 500;
  color: #B8804A;
  margin-bottom: 2rem;
  
  svg {
    width: 1rem;
    height: 1rem;
    color: #CD853F;
  }
`,kz=w(O.h2)`
  font-family: "Playfair Display", serif;
  font-size: clamp(2.5rem, 5vw, 3.5rem);
  font-weight: 600;
  color: #8B4513;
  margin-bottom: 1rem;
`,Dz=w.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`,Mz=w(O.div)`
  background: rgba(255, 252, 250, 0.9);
  border: 1px solid rgba(205, 133, 63, 0.15);
  border-radius: 20px;
  overflow: hidden;
`,Bz=w.button`
  width: 100%;
  padding: 1.5rem 2rem;
  background: none;
  border: none;
  text-align: left;
  font-size: 1.125rem;
  font-weight: 600;
  color: #8B4513;
  cursor: pointer;
  display: flex;
  justify-content: space-between;
  align-items: center;
  transition: all 0.3s ease;
  
  &:hover {
    background: rgba(205, 133, 63, 0.05);
  }
`,zz=w(O.div)`
  svg {
    width: 24px;
    height: 24px;
    color: #CD853F;
  }
`,$z=w(O.div)`
  padding: 0 2rem 1.5rem;
  font-size: 1rem;
  line-height: 1.6;
  color: #8B6F4A;
`,Nz=[{question:"Что входит в стоимость банного сеанса?",answer:"В стоимость входит: посещение парной, березовые веники, травяные настои, полотенца, простыни, тапочки, чай с медом и традиционными русскими сладостями."},{question:"Нужно ли бронировать заранее?",answer:"Да, рекомендуем бронировать за 1-2 дня, особенно на выходные. Это гарантирует наличие свободного времени и позволяет нам подготовить все необходимое для вашего визита."},{question:"Есть ли ограничения по возрасту или здоровью?",answer:"Посещение бани не рекомендуется детям до 12 лет, беременным женщинам, людям с сердечно-сосудистыми заболеваниями без консультации врача. При наличии хронических заболеваний обязательна консультация специалиста."},{question:"Что взять с собой?",answer:"Все необходимое мы предоставляем: полотенца, простыни, тапочки, шапочки для бани. Вы можете принести только личные вещи и купальник/плавки."},{question:"Можно ли отменить или перенести бронирование?",answer:"Да, вы можете отменить или перенести бронирование не позднее чем за 24 часа до сеанса без штрафных санкций. При отмене менее чем за 24 часа взимается 50% от стоимости."}],Lz=()=>{const{t:e}=De(),[i,a]=S.useState(null),r=s=>{a(i===s?null:s)};return h.jsx(Ez,{children:h.jsxs(Cz,{children:[h.jsxs(Oz,{children:[h.jsxs(Rz,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{duration:.6},children:[h.jsx(qo,{}),"FAQ"]}),h.jsx(kz,{initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{delay:.2,duration:.8},children:"Часто задаваемые вопросы"})]}),h.jsx(Dz,{children:Nz.map((s,c)=>h.jsxs(Mz,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{delay:c*.1,duration:.6},children:[h.jsxs(Bz,{onClick:()=>r(c),children:[s.question,h.jsx(zz,{animate:{rotate:i===c?180:0},transition:{duration:.3},children:h.jsx(WE,{})})]}),h.jsx(ua,{children:i===c&&h.jsx($z,{initial:{height:0,opacity:0},animate:{height:"auto",opacity:1},exit:{height:0,opacity:0},transition:{duration:.3,ease:[.25,.46,.45,.94]},children:s.answer})})]},c))})]})})},_z=w(O.div)`
  background-color: ${e=>e.theme.colors.background};
  color: ${e=>e.theme.colors.text.primary};
  min-height: 100vh;
  font-family: ${e=>e.theme.fonts.primary};
  overflow-x: hidden;
`,Hz=()=>{const{t:e}=De();Ce.useEffect(()=>(document.body.classList.add("banya-page"),window.scrollTo(0,0),()=>{document.body.classList.remove("banya-page")}),[]);const i={initial:{opacity:0},animate:{opacity:1},exit:{opacity:0}};return h.jsxs(_z,{initial:"initial",animate:"animate",exit:"exit",variants:i,transition:{duration:.2},children:[h.jsx(wB,{}),h.jsx(_B,{}),h.jsx(nz,{}),h.jsx(pz,{}),h.jsx(Lz,{}),h.jsx(Az,{})]})},Vz=w(O.div)`
  background-color: ${e=>e.theme.colors.background};
  color: ${e=>e.theme.colors.text.primary};
  min-height: 100vh;
  font-family: ${e=>e.theme.fonts.primary};
  overflow-x: hidden;
`,L2=w(O.section)`
  position: relative;
  padding: 6rem 1.5rem;
  overflow: hidden;
  
  @media (min-width: 768px) {
    padding: 8rem 2rem;
  }
  
  @media (min-width: 1024px) {
    padding: 10rem 0;
  }
`,_2=w.div`
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 1.5rem;
  position: relative;
  z-index: 2;
  
  @media (min-width: 768px) {
    padding: 0 2rem;
  }
  
  @media (min-width: 1024px) {
    padding: 0 3rem;
  }
`,H2=w(O.h2)`
  font-size: clamp(2rem, 5vw, 3.5rem);
  font-weight: 700;
  line-height: 1.1;
  margin-bottom: 1.5rem;
  font-family: ${e=>e.theme.fonts.heading};
  text-align: center;
  
  @media (min-width: 768px) {
    margin-bottom: 2rem;
  }
`,V2=w(O.p)`
  font-size: clamp(1rem, 2vw, 1.2rem);
  line-height: 1.8;
  color: ${e=>e.theme.colors.text.secondary};
  margin-bottom: 2.5rem;
  text-align: center;
  max-width: 600px;
  margin-left: auto;
  margin-right: auto;
  font-weight: 300;
`;w(O.div)`
  display: inline-block;
  padding: 0.5rem 1.2rem;
  background: ${e=>e.theme.colors.gradients.primary};
  color: white;
  font-size: 0.8rem;
  font-weight: 600;
  letter-spacing: 1px;
  text-transform: uppercase;
  border-radius: 50px;
  margin-bottom: 1.5rem;
  text-align: center;
  
  @media (min-width: 768px) {
    margin-bottom: 2rem;
  }
`;const Pz=w(O.div)`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.05);
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-10px);
    box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
  }
  
  @media (max-width: 768px) {
    padding: 1.5rem;
    border-radius: 12px;
  }
`;w(Pz)`
  text-align: center;
  height: 100%;
  display: flex;
  flex-direction: column;
  
  &:hover {
    transform: translateY(-5px) scale(1.02);
  }
`;const P2=w(O.button)`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  padding: 0.9rem 2.2rem;
  font-size: 0.85rem;
  font-weight: 600;
  letter-spacing: 1px;
  text-transform: uppercase;
  text-decoration: none;
  border: none;
  border-radius: 50px;
  cursor: pointer;
  transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  position: relative;
  overflow: hidden;
  min-width: 220px;
  text-align: center;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.15), transparent);
    transition: left 0.6s ease;
  }
  
  &:hover::before {
    left: 100%;
  }
  
  &:hover {
    transform: translateY(-2px);
  }
  
  &:active {
    transform: translateY(-1px);
  }
  
  &:focus {
    outline: none;
    box-shadow: 0 0 0 3px rgba(144, 179, 167, 0.3);
  }
  
  svg {
    width: 16px;
    height: 16px;
    transition: transform 0.3s ease;
  }
  
  &:hover svg {
    transform: translateX(3px);
  }
  
  @media (max-width: 768px) {
    width: 100%;
    max-width: 320px;
    padding: 1rem 2rem;
    font-size: 0.8rem;
    min-width: unset;
    border-radius: 14px;
    
    &:hover {
      transform: translateY(-3px) scale(1.01);
    }
  }
`,Fz=w(P2)`
  background: linear-gradient(135deg, #90B3A7 0%, #A8C5B8 100%);
  color: white;
  border: 2px solid transparent;
  box-shadow: 0 6px 20px rgba(144, 179, 167, 0.3);
  
  &:hover {
    box-shadow: 0 8px 25px rgba(144, 179, 167, 0.5);
    background: linear-gradient(135deg, #A8C5B8 0%, #B8CFC2 100%);
  }
`;w(P2)`
  background: transparent;
  color: ${e=>e.theme.colors.primary};
  border: 2px solid ${e=>e.theme.colors.primary};
  
  &:hover {
    background: ${e=>e.theme.colors.primary};
    color: white;
  }
`;const Uz=w.div`
  display: grid;
  gap: 2rem;
  
  @media (min-width: 640px) {
    grid-template-columns: repeat(2, 1fr);
  }
  
  @media (min-width: 1024px) {
    grid-template-columns: repeat(3, 1fr);
  }
`;w.div`
  display: grid;
  gap: 3rem;
  align-items: center;
  
  @media (min-width: 1024px) {
    grid-template-columns: 1fr 1fr;
  }
`;w(O.div)`
  position: absolute;
  border-radius: 50%;
  background: ${e=>e.background||"linear-gradient(135deg, rgba(144, 179, 167, 0.1) 0%, rgba(168, 197, 184, 0.05) 100%)"};
  pointer-events: none;
  z-index: 1;
`;w(O.div)`
  position: absolute;
  top: ${e=>e.top||"10%"};
  right: ${e=>e.right||"10%"};
  width: ${e=>e.width||"200px"};
  height: ${e=>e.height||"200px"};
  border-radius: 50%;
  background: ${e=>e.background||"linear-gradient(135deg, rgba(144, 179, 167, 0.1) 0%, rgba(168, 197, 184, 0.05) 100%)"};
  pointer-events: none;
  z-index: 1;
  
  @media (max-width: 768px) {
    width: ${e=>e.mobileWidth||"100px"};
    height: ${e=>e.mobileHeight||"100px"};
  }
`;w(O.div)`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.7);
  z-index: 100;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 1rem;
  overflow-y: auto;
`;w(O.div)`
  background-color: white;
  border-radius: 16px;
  width: 100%;
  max-width: 600px;
  max-height: 90vh;
  overflow-y: auto;
  position: relative;
  padding: 2rem;
  
  @media (max-width: 768px) {
    padding: 1.5rem;
    margin: 1rem;
  }
`;w(O.div)`
  font-size: 0.8rem;
  font-weight: 600;
  letter-spacing: 2px;
  text-transform: uppercase;
  color: ${e=>e.theme.colors.primary};
  margin-bottom: 1rem;
  text-align: center;
`;w(O.p)`
  font-size: 1.1rem;
  line-height: 1.6;
  color: ${e=>e.theme.colors.text.secondary};
  margin-bottom: 2rem;
  text-align: center;
`;w.div`
  margin-bottom: 1.5rem;
`;w.label`
  display: block;
  font-size: 0.9rem;
  font-weight: 500;
  color: ${e=>e.theme.colors.text.primary};
  margin-bottom: 0.5rem;
`;w.input`
  width: 100%;
  padding: 0.75rem 1rem;
  border: 2px solid #e5e7eb;
  border-radius: 8px;
  font-size: 1rem;
  transition: border-color 0.3s ease;
  
  &:focus {
    outline: none;
    border-color: ${e=>e.theme.colors.primary};
  }
`;w.textarea`
  width: 100%;
  padding: 0.75rem 1rem;
  border: 2px solid #e5e7eb;
  border-radius: 8px;
  font-size: 1rem;
  min-height: 120px;
  resize: vertical;
  transition: border-color 0.3s ease;
  
  &:focus {
    outline: none;
    border-color: ${e=>e.theme.colors.primary};
  }
`;const ch={hidden:{y:50,opacity:0},visible:{y:0,opacity:1,transition:{type:"spring",stiffness:300,damping:30,duration:.6}},exit:{y:30,opacity:0,transition:{duration:.5,ease:"easeOut"}}},qz={hidden:{},visible:{transition:{delayChildren:.2,staggerChildren:.15}}},Iz={hidden:{scale:.9,opacity:0},visible:{scale:1,opacity:1,transition:{type:"spring",stiffness:400,damping:10,delay:.5}},hover:{scale:1.05,transition:{type:"spring",stiffness:400,damping:10}},tap:{scale:.95}},uh={hidden:{y:50,opacity:0},visible:{y:0,opacity:1,transition:{type:"spring",stiffness:150,damping:20,delay:.2}}},Yz=w.section`
  position: relative;
  min-height: 50vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, 
    rgba(144, 179, 167, 0.95) 0%, 
    rgba(168, 197, 184, 0.9) 50%, 
    rgba(184, 207, 194, 0.85) 100%
  );
  color: white;
  text-align: center;
  padding: 6rem 1.5rem;
  overflow: hidden;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: 
      radial-gradient(circle at 20% 30%, rgba(255, 255, 255, 0.1) 0%, transparent 50%),
      radial-gradient(circle at 80% 70%, rgba(255, 255, 255, 0.08) 0%, transparent 50%);
    pointer-events: none;
  }
`,Gz=w(O.div)`
  position: relative;
  z-index: 2;
  max-width: 800px;
  margin: 0 auto;
`,Kz=w(O.h1)`
  font-size: clamp(2.5rem, 6vw, 4rem);
  font-weight: 700;
  margin-bottom: 1.5rem;
  font-family: ${e=>e.theme.fonts.heading};
  text-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
`,Xz=w(O.p)`
  font-size: clamp(1.1rem, 2.5vw, 1.3rem);
  line-height: 1.6;
  margin-bottom: 3rem;
  opacity: 0.95;
  font-weight: 300;
`,Zz=w(O.div)`
  position: absolute;
  bottom: 2rem;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
  cursor: pointer;
  opacity: 0.8;
  transition: opacity 0.3s ease;
  
  &:hover {
    opacity: 1;
  }
  
  span {
    font-size: 0.8rem;
    font-weight: 500;
    letter-spacing: 1px;
    text-transform: uppercase;
  }
  
  svg {
    width: 24px;
    height: 24px;
    animation: bounce 2s infinite;
  }
  
  @keyframes bounce {
    0%, 20%, 50%, 80%, 100% {
      transform: translateY(0);
    }
    40% {
      transform: translateY(-10px);
    }
    60% {
      transform: translateY(-5px);
    }
  }
`,Qz=({onScrollToContent:e})=>{const{t:i}=De();return h.jsxs(Yz,{children:[h.jsxs(Gz,{variants:uh,initial:"hidden",animate:"visible",children:[h.jsx(Kz,{variants:uh,initial:"hidden",animate:"visible",children:i("contacts.hero.title")}),h.jsx(Xz,{variants:uh,initial:"hidden",animate:"visible",transition:{delay:.3},children:i("contacts.hero.subtitle")})]}),h.jsxs(Zz,{variants:Iz,initial:"hidden",animate:"visible",onClick:e,whileHover:{scale:1.1},whileTap:{scale:.9},children:[h.jsx("span",{children:i("common.scroll_down")}),h.jsx("svg",{xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:2,stroke:"currentColor",children:h.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M19.5 8.25l-7.5 7.5-7.5-7.5"})})]})]})},Jz=w(O.div)`
  background: white;
  border-radius: 20px;
  padding: 2.5rem;
  box-shadow: 0 15px 35px rgba(0, 0, 0, 0.08);
  text-align: center;
  transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  border: 1px solid rgba(144, 179, 167, 0.1);
  
  &:hover {
    transform: translateY(-8px) scale(1.02);
    box-shadow: 0 25px 50px rgba(0, 0, 0, 0.15);
    border-color: rgba(144, 179, 167, 0.3);
  }
  
  @media (max-width: 768px) {
    padding: 2rem;
    border-radius: 16px;
  }
`,Wz=w.div`
  width: 70px;
  height: 70px;
  border-radius: 50%;
  background: linear-gradient(135deg, #90B3A7 0%, #A8C5B8 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 1.5rem;
  box-shadow: 0 8px 20px rgba(144, 179, 167, 0.3);
  
  svg {
    width: 30px;
    height: 30px;
    color: white;
  }
`,e$=w.h3`
  font-size: 1.3rem;
  font-weight: 600;
  margin-bottom: 1rem;
  color: ${e=>e.theme.colors.text.primary};
  font-family: ${e=>e.theme.fonts.heading};
`,t$=w.div`
  color: ${e=>e.theme.colors.text.secondary};
  line-height: 1.8;
  font-size: 1rem;
  
  a {
    color: ${e=>e.theme.colors.primary};
    text-decoration: none;
    transition: color 0.3s ease;
    
    &:hover {
      color: ${e=>e.theme.colors.zones.spa};
      text-decoration: underline;
    }
  }
`,dh=w.a`
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  color: ${e=>e.theme.colors.primary};
  text-decoration: none;
  font-weight: 500;
  margin-top: 1rem;
  padding: 0.5rem 1rem;
  border-radius: 25px;
  background: rgba(144, 179, 167, 0.1);
  transition: all 0.3s ease;
  
  &:hover {
    background: rgba(144, 179, 167, 0.2);
    transform: translateX(5px);
  }
  
  svg {
    width: 16px;
    height: 16px;
  }
`,i$=()=>{const{t:e}=De(),i=[{icon:WO,title:e("contacts.info.address.title"),details:h.jsxs("div",{children:[h.jsx("div",{children:e("common.address")}),h.jsx("div",{children:"Phuket, Thailand"}),h.jsxs(dh,{href:"https://maps.google.com/?q=73+Baan+Chalekiri+Village+Kathu+Phuket",target:"_blank",rel:"noopener noreferrer",children:[e("contacts.info.address.directions"),h.jsx(If,{})]})]})},{icon:tR,title:e("contacts.info.phone.title"),details:h.jsxs("div",{children:[h.jsx("div",{children:h.jsx("a",{href:"tel:+66624805877",children:e("common.phone_number")})}),h.jsx("div",{style:{fontSize:"0.9rem",marginTop:"0.5rem"},children:e("contacts.info.phone.hours")})]})},{icon:GO,title:e("contacts.info.email.title"),details:h.jsxs("div",{children:[h.jsx("div",{children:h.jsx("a",{href:"mailto:info@kaif-phuket.com",children:"info@kaif-phuket.com"})}),h.jsx("div",{style:{fontSize:"0.9rem",marginTop:"0.5rem"},children:e("contacts.info.email.response")})]})},{icon:sc,title:e("contacts.info.hours.title"),details:h.jsxs("div",{children:[h.jsx("div",{children:e("contacts.info.hours.weekdays")}),h.jsx("div",{children:e("contacts.info.hours.weekends")})]})},{icon:XO,title:e("contacts.info.social.title"),details:h.jsxs("div",{children:[h.jsxs(dh,{href:"https://instagram.com/kaif_phuket",target:"_blank",rel:"noopener noreferrer",children:["Instagram",h.jsx(If,{})]}),h.jsxs(dh,{href:"https://facebook.com/kaif.phuket",target:"_blank",rel:"noopener noreferrer",style:{marginLeft:"1rem"},children:["Facebook",h.jsx(If,{})]})]})}];return h.jsx(L2,{children:h.jsx(_2,{children:h.jsxs(O.div,{variants:qz,initial:"hidden",whileInView:"visible",viewport:{once:!0},children:[h.jsx(H2,{variants:ch,initial:"hidden",whileInView:"visible",viewport:{once:!0},children:e("contacts.info.title")}),h.jsx(V2,{variants:ch,initial:"hidden",whileInView:"visible",viewport:{once:!0},transition:{delay:.2},children:e("contacts.info.subtitle")}),h.jsx(Uz,{style:{marginTop:"4rem"},children:i.map((a,r)=>h.jsxs(Jz,{variants:ch,initial:"hidden",whileInView:"visible",viewport:{once:!0},transition:{delay:r*.1},whileHover:{scale:1.02},whileTap:{scale:.98},children:[h.jsx(Wz,{children:h.jsx(a.icon,{})}),h.jsx(e$,{children:a.title}),h.jsx(t$,{children:a.details})]},r))})]})})})};var fh={exports:{}},Re={};/** @license React v16.13.1
 * react-is.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Pb;function n$(){if(Pb)return Re;Pb=1;var e=typeof Symbol=="function"&&Symbol.for,i=e?Symbol.for("react.element"):60103,a=e?Symbol.for("react.portal"):60106,r=e?Symbol.for("react.fragment"):60107,s=e?Symbol.for("react.strict_mode"):60108,c=e?Symbol.for("react.profiler"):60114,u=e?Symbol.for("react.provider"):60109,f=e?Symbol.for("react.context"):60110,p=e?Symbol.for("react.async_mode"):60111,m=e?Symbol.for("react.concurrent_mode"):60111,y=e?Symbol.for("react.forward_ref"):60112,x=e?Symbol.for("react.suspense"):60113,b=e?Symbol.for("react.suspense_list"):60120,T=e?Symbol.for("react.memo"):60115,A=e?Symbol.for("react.lazy"):60116,C=e?Symbol.for("react.block"):60121,B=e?Symbol.for("react.fundamental"):60117,E=e?Symbol.for("react.responder"):60118,k=e?Symbol.for("react.scope"):60119;function M(D){if(typeof D=="object"&&D!==null){var U=D.$$typeof;switch(U){case i:switch(D=D.type,D){case p:case m:case r:case c:case s:case x:return D;default:switch(D=D&&D.$$typeof,D){case f:case y:case A:case T:case u:return D;default:return U}}case a:return U}}}function F(D){return M(D)===m}return Re.AsyncMode=p,Re.ConcurrentMode=m,Re.ContextConsumer=f,Re.ContextProvider=u,Re.Element=i,Re.ForwardRef=y,Re.Fragment=r,Re.Lazy=A,Re.Memo=T,Re.Portal=a,Re.Profiler=c,Re.StrictMode=s,Re.Suspense=x,Re.isAsyncMode=function(D){return F(D)||M(D)===p},Re.isConcurrentMode=F,Re.isContextConsumer=function(D){return M(D)===f},Re.isContextProvider=function(D){return M(D)===u},Re.isElement=function(D){return typeof D=="object"&&D!==null&&D.$$typeof===i},Re.isForwardRef=function(D){return M(D)===y},Re.isFragment=function(D){return M(D)===r},Re.isLazy=function(D){return M(D)===A},Re.isMemo=function(D){return M(D)===T},Re.isPortal=function(D){return M(D)===a},Re.isProfiler=function(D){return M(D)===c},Re.isStrictMode=function(D){return M(D)===s},Re.isSuspense=function(D){return M(D)===x},Re.isValidElementType=function(D){return typeof D=="string"||typeof D=="function"||D===r||D===m||D===c||D===s||D===x||D===b||typeof D=="object"&&D!==null&&(D.$$typeof===A||D.$$typeof===T||D.$$typeof===u||D.$$typeof===f||D.$$typeof===y||D.$$typeof===B||D.$$typeof===E||D.$$typeof===k||D.$$typeof===C)},Re.typeOf=M,Re}var Fb;function a$(){return Fb||(Fb=1,fh.exports=n$()),fh.exports}var hh,Ub;function r$(){if(Ub)return hh;Ub=1;var e=a$(),i={childContextTypes:!0,contextType:!0,contextTypes:!0,defaultProps:!0,displayName:!0,getDefaultProps:!0,getDerivedStateFromError:!0,getDerivedStateFromProps:!0,mixins:!0,propTypes:!0,type:!0},a={name:!0,length:!0,prototype:!0,caller:!0,callee:!0,arguments:!0,arity:!0},r={$$typeof:!0,render:!0,defaultProps:!0,displayName:!0,propTypes:!0},s={$$typeof:!0,compare:!0,defaultProps:!0,displayName:!0,propTypes:!0,type:!0},c={};c[e.ForwardRef]=r,c[e.Memo]=s;function u(A){return e.isMemo(A)?s:c[A.$$typeof]||i}var f=Object.defineProperty,p=Object.getOwnPropertyNames,m=Object.getOwnPropertySymbols,y=Object.getOwnPropertyDescriptor,x=Object.getPrototypeOf,b=Object.prototype;function T(A,C,B){if(typeof C!="string"){if(b){var E=x(C);E&&E!==b&&T(A,E,B)}var k=p(C);m&&(k=k.concat(m(C)));for(var M=u(A),F=u(C),D=0;D<k.length;++D){var U=k[D];if(!a[U]&&!(B&&B[U])&&!(F&&F[U])&&!(M&&M[U])){var G=y(C,U);try{f(A,U,G)}catch{}}}}return A}return hh=T,hh}r$();function Si(){return Si=Object.assign||function(e){for(var i=1;i<arguments.length;i++){var a=arguments[i];for(var r in a)Object.prototype.hasOwnProperty.call(a,r)&&(e[r]=a[r])}return e},Si.apply(this,arguments)}function Yo(e,i){if(e==null)return{};var a={},r=Object.keys(e),s,c;for(c=0;c<r.length;c++)s=r[c],!(i.indexOf(s)>=0)&&(a[s]=e[s]);return a}var qc=S.createContext(void 0);qc.displayName="FormikContext";qc.Provider;qc.Consumer;function F2(){var e=S.useContext(qc);return e}var o$=function(i){return typeof i=="function"};function U2(e){var i=e.validate,a=e.name,r=e.render,s=e.children,c=e.as,u=e.component,f=e.className,p=Yo(e,["validate","name","render","children","as","component","className"]),m=F2(),y=Yo(m,["validate","validationSchema"]),x=y.registerField,b=y.unregisterField;S.useEffect(function(){return x(a,{validate:i}),function(){b(a)}},[x,b,a,i]);var T=y.getFieldProps(Si({name:a},p)),A=y.getFieldMeta(a),C={field:T,form:y};if(r)return r(Si({},C,{meta:A}));if(o$(s))return s(Si({},C,{meta:A}));if(u){if(typeof u=="string"){var B=p.innerRef,E=Yo(p,["innerRef"]);return S.createElement(u,Si({ref:B},T,E,{className:f}),s)}return S.createElement(u,Si({field:T,form:y},p,{className:f}),s)}var k=c||"input";if(typeof k=="string"){var M=p.innerRef,F=Yo(p,["innerRef"]);return S.createElement(k,Si({ref:M},T,F,{className:f}),s)}return S.createElement(k,Si({},T,p,{className:f}),s)}var s$=S.forwardRef(function(e,i){var a=e.action,r=Yo(e,["action"]),s=a??"#",c=F2(),u=c.handleReset,f=c.handleSubmit;return S.createElement("form",Si({onSubmit:f,ref:i,onReset:u,action:s},r))});s$.displayName="Form";var ph,qb;function l$(){if(qb)return ph;qb=1;function e(E){this._maxSize=E,this.clear()}e.prototype.clear=function(){this._size=0,this._values=Object.create(null)},e.prototype.get=function(E){return this._values[E]},e.prototype.set=function(E,k){return this._size>=this._maxSize&&this.clear(),E in this._values||this._size++,this._values[E]=k};var i=/[^.^\]^[]+|(?=\[\]|\.\.)/g,a=/^\d+$/,r=/^\d/,s=/[~`!#$%\^&*+=\-\[\]\\';,/{}|\\":<>\?]/g,c=/^\s*(['"]?)(.*?)(\1)\s*$/,u=512,f=new e(u),p=new e(u),m=new e(u);ph={Cache:e,split:x,normalizePath:y,setter:function(E){var k=y(E);return p.get(E)||p.set(E,function(F,D){for(var U=0,G=k.length,Z=F;U<G-1;){var J=k[U];if(J==="__proto__"||J==="constructor"||J==="prototype")return F;Z=Z[k[U++]]}Z[k[U]]=D})},getter:function(E,k){var M=y(E);return m.get(E)||m.set(E,function(D){for(var U=0,G=M.length;U<G;)if(D!=null||!k)D=D[M[U++]];else return;return D})},join:function(E){return E.reduce(function(k,M){return k+(T(M)||a.test(M)?"["+M+"]":(k?".":"")+M)},"")},forEach:function(E,k,M){b(Array.isArray(E)?E:x(E),k,M)}};function y(E){return f.get(E)||f.set(E,x(E).map(function(k){return k.replace(c,"$2")}))}function x(E){return E.match(i)||[""]}function b(E,k,M){var F=E.length,D,U,G,Z;for(U=0;U<F;U++)D=E[U],D&&(B(D)&&(D='"'+D+'"'),Z=T(D),G=!Z&&/^\d+$/.test(D),k.call(M,D,Z,G,U,E))}function T(E){return typeof E=="string"&&E&&["'",'"'].indexOf(E.charAt(0))!==-1}function A(E){return E.match(r)&&!E.match(a)}function C(E){return s.test(E)}function B(E){return!T(E)&&(A(E)||C(E))}return ph}var q2=l$(),Kl={exports:{}},Ib;function c$(){if(Ib)return Kl.exports;Ib=1,Kl.exports=function(s){return e(i(s),s)},Kl.exports.array=e;function e(s,c){var u=s.length,f=new Array(u),p={},m=u,y=a(c),x=r(s);for(c.forEach(function(T){if(!x.has(T[0])||!x.has(T[1]))throw new Error("Unknown node. There is an unknown node in the supplied edges.")});m--;)p[m]||b(s[m],m,new Set);return f;function b(T,A,C){if(C.has(T)){var B;try{B=", node was:"+JSON.stringify(T)}catch{B=""}throw new Error("Cyclic dependency"+B)}if(!x.has(T))throw new Error("Found unknown node. Make sure to provided all involved nodes. Unknown node: "+JSON.stringify(T));if(!p[A]){p[A]=!0;var E=y.get(T)||new Set;if(E=Array.from(E),A=E.length){C.add(T);do{var k=E[--A];b(k,x.get(k),C)}while(A);C.delete(T)}f[--u]=T}}}function i(s){for(var c=new Set,u=0,f=s.length;u<f;u++){var p=s[u];c.add(p[0]),c.add(p[1])}return Array.from(c)}function a(s){for(var c=new Map,u=0,f=s.length;u<f;u++){var p=s[u];c.has(p[0])||c.set(p[0],new Set),c.has(p[1])||c.set(p[1],new Set),c.get(p[0]).add(p[1])}return c}function r(s){for(var c=new Map,u=0,f=s.length;u<f;u++)c.set(s[u],u);return c}return Kl.exports}c$();const u$=Object.prototype.toString,d$=Error.prototype.toString,f$=RegExp.prototype.toString,h$=typeof Symbol<"u"?Symbol.prototype.toString:()=>"",p$=/^Symbol\((.*)\)(.*)$/;function m$(e){return e!=+e?"NaN":e===0&&1/e<0?"-0":""+e}function Yb(e,i=!1){if(e==null||e===!0||e===!1)return""+e;const a=typeof e;if(a==="number")return m$(e);if(a==="string")return i?`"${e}"`:e;if(a==="function")return"[Function "+(e.name||"anonymous")+"]";if(a==="symbol")return h$.call(e).replace(p$,"Symbol($1)");const r=u$.call(e).slice(8,-1);return r==="Date"?isNaN(e.getTime())?""+e:e.toISOString(e):r==="Error"||e instanceof Error?"["+d$.call(e)+"]":r==="RegExp"?f$.call(e):null}function Rn(e,i){let a=Yb(e,i);return a!==null?a:JSON.stringify(e,function(r,s){let c=Yb(this[r],i);return c!==null?c:s},2)}function I2(e){return e==null?[]:[].concat(e)}let Y2,G2,K2,g$=/\$\{\s*(\w+)\s*\}/g;Y2=Symbol.toStringTag;class Gb{constructor(i,a,r,s){this.name=void 0,this.message=void 0,this.value=void 0,this.path=void 0,this.type=void 0,this.params=void 0,this.errors=void 0,this.inner=void 0,this[Y2]="Error",this.name="ValidationError",this.value=a,this.path=r,this.type=s,this.errors=[],this.inner=[],I2(i).forEach(c=>{if(Dt.isError(c)){this.errors.push(...c.errors);const u=c.inner.length?c.inner:[c];this.inner.push(...u)}else this.errors.push(c)}),this.message=this.errors.length>1?`${this.errors.length} errors occurred`:this.errors[0]}}G2=Symbol.hasInstance;K2=Symbol.toStringTag;class Dt extends Error{static formatError(i,a){const r=a.label||a.path||"this";return a=Object.assign({},a,{path:r,originalPath:a.path}),typeof i=="string"?i.replace(g$,(s,c)=>Rn(a[c])):typeof i=="function"?i(a):i}static isError(i){return i&&i.name==="ValidationError"}constructor(i,a,r,s,c){const u=new Gb(i,a,r,s);if(c)return u;super(),this.value=void 0,this.path=void 0,this.type=void 0,this.params=void 0,this.errors=[],this.inner=[],this[K2]="Error",this.name=u.name,this.message=u.message,this.type=u.type,this.value=u.value,this.path=u.path,this.errors=u.errors,this.inner=u.inner,Error.captureStackTrace&&Error.captureStackTrace(this,Dt)}static[G2](i){return Gb[Symbol.hasInstance](i)||super[Symbol.hasInstance](i)}}let Ki={default:"${path} is invalid",required:"${path} is a required field",defined:"${path} must be defined",notNull:"${path} cannot be null",oneOf:"${path} must be one of the following values: ${values}",notOneOf:"${path} must not be one of the following values: ${values}",notType:({path:e,type:i,value:a,originalValue:r})=>{const s=r!=null&&r!==a?` (cast from the value \`${Rn(r,!0)}\`).`:".";return i!=="mixed"?`${e} must be a \`${i}\` type, but the final value was: \`${Rn(a,!0)}\``+s:`${e} must match the configured type. The validated value was: \`${Rn(a,!0)}\``+s}},y$={length:"${path} must be exactly ${length} characters",min:"${path} must be at least ${min} characters",max:"${path} must be at most ${max} characters",matches:'${path} must match the following: "${regex}"',email:"${path} must be a valid email",url:"${path} must be a valid URL",uuid:"${path} must be a valid UUID",datetime:"${path} must be a valid ISO date-time",datetime_precision:"${path} must be a valid ISO date-time with a sub-second precision of exactly ${precision} digits",datetime_offset:'${path} must be a valid ISO date-time with UTC "Z" timezone',trim:"${path} must be a trimmed string",lowercase:"${path} must be a lowercase string",uppercase:"${path} must be a upper case string"},x$={min:"${path} must be greater than or equal to ${min}",max:"${path} must be less than or equal to ${max}",lessThan:"${path} must be less than ${less}",moreThan:"${path} must be greater than ${more}",positive:"${path} must be a positive number",negative:"${path} must be a negative number",integer:"${path} must be an integer"},ep={min:"${path} field must be later than ${min}",max:"${path} field must be at earlier than ${max}"},b$={isValue:"${path} field must be ${value}"},v$={noUnknown:"${path} field has unspecified keys: ${unknown}",exact:"${path} object contains unknown properties: ${properties}"},w$={min:"${path} field must have at least ${min} items",max:"${path} field must have less than or equal to ${max} items",length:"${path} must have ${length} items"},S$={notType:e=>{const{path:i,value:a,spec:r}=e,s=r.types.length;if(Array.isArray(a)){if(a.length<s)return`${i} tuple value has too few items, expected a length of ${s} but got ${a.length} for value: \`${Rn(a,!0)}\``;if(a.length>s)return`${i} tuple value has too many items, expected a length of ${s} but got ${a.length} for value: \`${Rn(a,!0)}\``}return Dt.formatError(Ki.notType,e)}};Object.assign(Object.create(null),{mixed:Ki,string:y$,number:x$,date:ep,object:v$,array:w$,boolean:b$,tuple:S$});const X2=e=>e&&e.__isYupSchema__;class Cc{static fromOptions(i,a){if(!a.then&&!a.otherwise)throw new TypeError("either `then:` or `otherwise:` is required for `when()` conditions");let{is:r,then:s,otherwise:c}=a,u=typeof r=="function"?r:(...f)=>f.every(p=>p===r);return new Cc(i,(f,p)=>{var m;let y=u(...f)?s:c;return(m=y==null?void 0:y(p))!=null?m:p})}constructor(i,a){this.fn=void 0,this.refs=i,this.refs=i,this.fn=a}resolve(i,a){let r=this.refs.map(c=>c.getValue(a==null?void 0:a.value,a==null?void 0:a.parent,a==null?void 0:a.context)),s=this.fn(r,i,a);if(s===void 0||s===i)return i;if(!X2(s))throw new TypeError("conditions must return a schema object");return s.resolve(a)}}const Xl={context:"$",value:"."};class Ss{constructor(i,a={}){if(this.key=void 0,this.isContext=void 0,this.isValue=void 0,this.isSibling=void 0,this.path=void 0,this.getter=void 0,this.map=void 0,typeof i!="string")throw new TypeError("ref must be a string, got: "+i);if(this.key=i.trim(),i==="")throw new TypeError("ref must be a non-empty string");this.isContext=this.key[0]===Xl.context,this.isValue=this.key[0]===Xl.value,this.isSibling=!this.isContext&&!this.isValue;let r=this.isContext?Xl.context:this.isValue?Xl.value:"";this.path=this.key.slice(r.length),this.getter=this.path&&q2.getter(this.path,!0),this.map=a.map}getValue(i,a,r){let s=this.isContext?r:this.isValue?i:a;return this.getter&&(s=this.getter(s||{})),this.map&&(s=this.map(s)),s}cast(i,a){return this.getValue(i,a==null?void 0:a.parent,a==null?void 0:a.context)}resolve(){return this}describe(){return{type:"ref",key:this.key}}toString(){return`Ref(${this.key})`}static isRef(i){return i&&i.__isYupRef}}Ss.prototype.__isYupRef=!0;const Z2=e=>e==null;function or(e){function i({value:a,path:r="",options:s,originalValue:c,schema:u},f,p){const{name:m,test:y,params:x,message:b,skipAbsent:T}=e;let{parent:A,context:C,abortEarly:B=u.spec.abortEarly,disableStackTrace:E=u.spec.disableStackTrace}=s;function k(oe){return Ss.isRef(oe)?oe.getValue(a,A,C):oe}function M(oe={}){const xe=Object.assign({value:a,originalValue:c,label:u.spec.label,path:oe.path||r,spec:u.spec,disableStackTrace:oe.disableStackTrace||E},x,oe.params);for(const ne of Object.keys(xe))xe[ne]=k(xe[ne]);const Le=new Dt(Dt.formatError(oe.message||b,xe),a,xe.path,oe.type||m,xe.disableStackTrace);return Le.params=xe,Le}const F=B?f:p;let D={path:r,parent:A,type:m,from:s.from,createError:M,resolve:k,options:s,originalValue:c,schema:u};const U=oe=>{Dt.isError(oe)?F(oe):oe?p(null):F(M())},G=oe=>{Dt.isError(oe)?F(oe):f(oe)};if(T&&Z2(a))return U(!0);let J;try{var ie;if(J=y.call(D,a,D),typeof((ie=J)==null?void 0:ie.then)=="function"){if(s.sync)throw new Error(`Validation test of type: "${D.type}" returned a Promise during a synchronous validate. This test will finish after the validate call has returned`);return Promise.resolve(J).then(U,G)}}catch(oe){G(oe);return}U(J)}return i.OPTIONS=e,i}function T$(e,i,a,r=a){let s,c,u;return i?(q2.forEach(i,(f,p,m)=>{let y=p?f.slice(1,f.length-1):f;e=e.resolve({context:r,parent:s,value:a});let x=e.type==="tuple",b=m?parseInt(y,10):0;if(e.innerType||x){if(x&&!m)throw new Error(`Yup.reach cannot implicitly index into a tuple type. the path part "${u}" must contain an index to the tuple element, e.g. "${u}[0]"`);if(a&&b>=a.length)throw new Error(`Yup.reach cannot resolve an array item at index: ${f}, in the path: ${i}. because there is no value at that index. `);s=a,a=a&&a[b],e=x?e.spec.types[b]:e.innerType}if(!m){if(!e.fields||!e.fields[y])throw new Error(`The schema does not contain the path: ${i}. (failed at: ${u} which is a type: "${e.type}")`);s=a,a=a&&a[y],e=e.fields[y]}c=y,u=p?"["+f+"]":"."+f}),{schema:e,parent:s,parentPath:c}):{parent:s,parentPath:i,schema:e}}class Oc extends Set{describe(){const i=[];for(const a of this.values())i.push(Ss.isRef(a)?a.describe():a);return i}resolveAll(i){let a=[];for(const r of this.values())a.push(i(r));return a}clone(){return new Oc(this.values())}merge(i,a){const r=this.clone();return i.forEach(s=>r.add(s)),a.forEach(s=>r.delete(s)),r}}function hr(e,i=new Map){if(X2(e)||!e||typeof e!="object")return e;if(i.has(e))return i.get(e);let a;if(e instanceof Date)a=new Date(e.getTime()),i.set(e,a);else if(e instanceof RegExp)a=new RegExp(e),i.set(e,a);else if(Array.isArray(e)){a=new Array(e.length),i.set(e,a);for(let r=0;r<e.length;r++)a[r]=hr(e[r],i)}else if(e instanceof Map){a=new Map,i.set(e,a);for(const[r,s]of e.entries())a.set(r,hr(s,i))}else if(e instanceof Set){a=new Set,i.set(e,a);for(const r of e)a.add(hr(r,i))}else if(e instanceof Object){a={},i.set(e,a);for(const[r,s]of Object.entries(e))a[r]=hr(s,i)}else throw Error(`Unable to clone ${e}`);return a}class da{constructor(i){this.type=void 0,this.deps=[],this.tests=void 0,this.transforms=void 0,this.conditions=[],this._mutate=void 0,this.internalTests={},this._whitelist=new Oc,this._blacklist=new Oc,this.exclusiveTests=Object.create(null),this._typeCheck=void 0,this.spec=void 0,this.tests=[],this.transforms=[],this.withMutation(()=>{this.typeError(Ki.notType)}),this.type=i.type,this._typeCheck=i.check,this.spec=Object.assign({strip:!1,strict:!1,abortEarly:!0,recursive:!0,disableStackTrace:!1,nullable:!1,optional:!0,coerce:!0},i==null?void 0:i.spec),this.withMutation(a=>{a.nonNullable()})}get _type(){return this.type}clone(i){if(this._mutate)return i&&Object.assign(this.spec,i),this;const a=Object.create(Object.getPrototypeOf(this));return a.type=this.type,a._typeCheck=this._typeCheck,a._whitelist=this._whitelist.clone(),a._blacklist=this._blacklist.clone(),a.internalTests=Object.assign({},this.internalTests),a.exclusiveTests=Object.assign({},this.exclusiveTests),a.deps=[...this.deps],a.conditions=[...this.conditions],a.tests=[...this.tests],a.transforms=[...this.transforms],a.spec=hr(Object.assign({},this.spec,i)),a}label(i){let a=this.clone();return a.spec.label=i,a}meta(...i){if(i.length===0)return this.spec.meta;let a=this.clone();return a.spec.meta=Object.assign(a.spec.meta||{},i[0]),a}withMutation(i){let a=this._mutate;this._mutate=!0;let r=i(this);return this._mutate=a,r}concat(i){if(!i||i===this)return this;if(i.type!==this.type&&this.type!=="mixed")throw new TypeError(`You cannot \`concat()\` schema's of different types: ${this.type} and ${i.type}`);let a=this,r=i.clone();const s=Object.assign({},a.spec,r.spec);return r.spec=s,r.internalTests=Object.assign({},a.internalTests,r.internalTests),r._whitelist=a._whitelist.merge(i._whitelist,i._blacklist),r._blacklist=a._blacklist.merge(i._blacklist,i._whitelist),r.tests=a.tests,r.exclusiveTests=a.exclusiveTests,r.withMutation(c=>{i.tests.forEach(u=>{c.test(u.OPTIONS)})}),r.transforms=[...a.transforms,...r.transforms],r}isType(i){return i==null?!!(this.spec.nullable&&i===null||this.spec.optional&&i===void 0):this._typeCheck(i)}resolve(i){let a=this;if(a.conditions.length){let r=a.conditions;a=a.clone(),a.conditions=[],a=r.reduce((s,c)=>c.resolve(s,i),a),a=a.resolve(i)}return a}resolveOptions(i){var a,r,s,c;return Object.assign({},i,{from:i.from||[],strict:(a=i.strict)!=null?a:this.spec.strict,abortEarly:(r=i.abortEarly)!=null?r:this.spec.abortEarly,recursive:(s=i.recursive)!=null?s:this.spec.recursive,disableStackTrace:(c=i.disableStackTrace)!=null?c:this.spec.disableStackTrace})}cast(i,a={}){let r=this.resolve(Object.assign({value:i},a)),s=a.assert==="ignore-optionality",c=r._cast(i,a);if(a.assert!==!1&&!r.isType(c)){if(s&&Z2(c))return c;let u=Rn(i),f=Rn(c);throw new TypeError(`The value of ${a.path||"field"} could not be cast to a value that satisfies the schema type: "${r.type}". 

attempted value: ${u} 
`+(f!==u?`result of cast: ${f}`:""))}return c}_cast(i,a){let r=i===void 0?i:this.transforms.reduce((s,c)=>c.call(this,s,i,this),i);return r===void 0&&(r=this.getDefault(a)),r}_validate(i,a={},r,s){let{path:c,originalValue:u=i,strict:f=this.spec.strict}=a,p=i;f||(p=this._cast(p,Object.assign({assert:!1},a)));let m=[];for(let y of Object.values(this.internalTests))y&&m.push(y);this.runTests({path:c,value:p,originalValue:u,options:a,tests:m},r,y=>{if(y.length)return s(y,p);this.runTests({path:c,value:p,originalValue:u,options:a,tests:this.tests},r,s)})}runTests(i,a,r){let s=!1,{tests:c,value:u,originalValue:f,path:p,options:m}=i,y=C=>{s||(s=!0,a(C,u))},x=C=>{s||(s=!0,r(C,u))},b=c.length,T=[];if(!b)return x([]);let A={value:u,originalValue:f,path:p,options:m,schema:this};for(let C=0;C<c.length;C++){const B=c[C];B(A,y,function(k){k&&(Array.isArray(k)?T.push(...k):T.push(k)),--b<=0&&x(T)})}}asNestedTest({key:i,index:a,parent:r,parentPath:s,originalParent:c,options:u}){const f=i??a;if(f==null)throw TypeError("Must include `key` or `index` for nested validations");const p=typeof f=="number";let m=r[f];const y=Object.assign({},u,{strict:!0,parent:r,value:m,originalValue:c[f],key:void 0,[p?"index":"key"]:f,path:p||f.includes(".")?`${s||""}[${p?f:`"${f}"`}]`:(s?`${s}.`:"")+i});return(x,b,T)=>this.resolve(y)._validate(m,y,b,T)}validate(i,a){var r;let s=this.resolve(Object.assign({},a,{value:i})),c=(r=a==null?void 0:a.disableStackTrace)!=null?r:s.spec.disableStackTrace;return new Promise((u,f)=>s._validate(i,a,(p,m)=>{Dt.isError(p)&&(p.value=m),f(p)},(p,m)=>{p.length?f(new Dt(p,m,void 0,void 0,c)):u(m)}))}validateSync(i,a){var r;let s=this.resolve(Object.assign({},a,{value:i})),c,u=(r=a==null?void 0:a.disableStackTrace)!=null?r:s.spec.disableStackTrace;return s._validate(i,Object.assign({},a,{sync:!0}),(f,p)=>{throw Dt.isError(f)&&(f.value=p),f},(f,p)=>{if(f.length)throw new Dt(f,i,void 0,void 0,u);c=p}),c}isValid(i,a){return this.validate(i,a).then(()=>!0,r=>{if(Dt.isError(r))return!1;throw r})}isValidSync(i,a){try{return this.validateSync(i,a),!0}catch(r){if(Dt.isError(r))return!1;throw r}}_getDefault(i){let a=this.spec.default;return a==null?a:typeof a=="function"?a.call(this,i):hr(a)}getDefault(i){return this.resolve(i||{})._getDefault(i)}default(i){return arguments.length===0?this._getDefault():this.clone({default:i})}strict(i=!0){return this.clone({strict:i})}nullability(i,a){const r=this.clone({nullable:i});return r.internalTests.nullable=or({message:a,name:"nullable",test(s){return s===null?this.schema.spec.nullable:!0}}),r}optionality(i,a){const r=this.clone({optional:i});return r.internalTests.optionality=or({message:a,name:"optionality",test(s){return s===void 0?this.schema.spec.optional:!0}}),r}optional(){return this.optionality(!0)}defined(i=Ki.defined){return this.optionality(!1,i)}nullable(){return this.nullability(!0)}nonNullable(i=Ki.notNull){return this.nullability(!1,i)}required(i=Ki.required){return this.clone().withMutation(a=>a.nonNullable(i).defined(i))}notRequired(){return this.clone().withMutation(i=>i.nullable().optional())}transform(i){let a=this.clone();return a.transforms.push(i),a}test(...i){let a;if(i.length===1?typeof i[0]=="function"?a={test:i[0]}:a=i[0]:i.length===2?a={name:i[0],test:i[1]}:a={name:i[0],message:i[1],test:i[2]},a.message===void 0&&(a.message=Ki.default),typeof a.test!="function")throw new TypeError("`test` is a required parameters");let r=this.clone(),s=or(a),c=a.exclusive||a.name&&r.exclusiveTests[a.name]===!0;if(a.exclusive&&!a.name)throw new TypeError("Exclusive tests must provide a unique `name` identifying the test");return a.name&&(r.exclusiveTests[a.name]=!!a.exclusive),r.tests=r.tests.filter(u=>!(u.OPTIONS.name===a.name&&(c||u.OPTIONS.test===s.OPTIONS.test))),r.tests.push(s),r}when(i,a){!Array.isArray(i)&&typeof i!="string"&&(a=i,i=".");let r=this.clone(),s=I2(i).map(c=>new Ss(c));return s.forEach(c=>{c.isSibling&&r.deps.push(c.key)}),r.conditions.push(typeof a=="function"?new Cc(s,a):Cc.fromOptions(s,a)),r}typeError(i){let a=this.clone();return a.internalTests.typeError=or({message:i,name:"typeError",skipAbsent:!0,test(r){return this.schema._typeCheck(r)?!0:this.createError({params:{type:this.schema.type}})}}),a}oneOf(i,a=Ki.oneOf){let r=this.clone();return i.forEach(s=>{r._whitelist.add(s),r._blacklist.delete(s)}),r.internalTests.whiteList=or({message:a,name:"oneOf",skipAbsent:!0,test(s){let c=this.schema._whitelist,u=c.resolveAll(this.resolve);return u.includes(s)?!0:this.createError({params:{values:Array.from(c).join(", "),resolved:u}})}}),r}notOneOf(i,a=Ki.notOneOf){let r=this.clone();return i.forEach(s=>{r._blacklist.add(s),r._whitelist.delete(s)}),r.internalTests.blacklist=or({message:a,name:"notOneOf",test(s){let c=this.schema._blacklist,u=c.resolveAll(this.resolve);return u.includes(s)?this.createError({params:{values:Array.from(c).join(", "),resolved:u}}):!0}}),r}strip(i=!0){let a=this.clone();return a.spec.strip=i,a}describe(i){const a=(i?this.resolve(i):this).clone(),{label:r,meta:s,optional:c,nullable:u}=a.spec;return{meta:s,label:r,optional:c,nullable:u,default:a.getDefault(i),type:a.type,oneOf:a._whitelist.describe(),notOneOf:a._blacklist.describe(),tests:a.tests.map(p=>({name:p.OPTIONS.name,params:p.OPTIONS.params})).filter((p,m,y)=>y.findIndex(x=>x.name===p.name)===m)}}}da.prototype.__isYupSchema__=!0;for(const e of["validate","validateSync"])da.prototype[`${e}At`]=function(i,a,r={}){const{parent:s,parentPath:c,schema:u}=T$(this,i,a,r.context);return u[e](s&&s[c],Object.assign({},r,{parent:s,path:i}))};for(const e of["equals","is"])da.prototype[e]=da.prototype.oneOf;for(const e of["not","nope"])da.prototype[e]=da.prototype.notOneOf;const j$=/^(\d{4}|[+-]\d{6})(?:-?(\d{2})(?:-?(\d{2}))?)?(?:[ T]?(\d{2}):?(\d{2})(?::?(\d{2})(?:[,.](\d{1,}))?)?(?:(Z)|([+-])(\d{2})(?::?(\d{2}))?)?)?$/;function A$(e){const i=E$(e);if(!i)return Date.parse?Date.parse(e):Number.NaN;if(i.z===void 0&&i.plusMinus===void 0)return new Date(i.year,i.month,i.day,i.hour,i.minute,i.second,i.millisecond).valueOf();let a=0;return i.z!=="Z"&&i.plusMinus!==void 0&&(a=i.hourOffset*60+i.minuteOffset,i.plusMinus==="+"&&(a=0-a)),Date.UTC(i.year,i.month,i.day,i.hour,i.minute+a,i.second,i.millisecond)}function E$(e){var i,a;const r=j$.exec(e);return r?{year:Yi(r[1]),month:Yi(r[2],1)-1,day:Yi(r[3],1),hour:Yi(r[4]),minute:Yi(r[5]),second:Yi(r[6]),millisecond:r[7]?Yi(r[7].substring(0,3)):0,precision:(i=(a=r[7])==null?void 0:a.length)!=null?i:void 0,z:r[8]||void 0,plusMinus:r[9]||void 0,hourOffset:Yi(r[10]),minuteOffset:Yi(r[11])}:null}function Yi(e,i=0){return Number(e)||i}let C$=new Date(""),O$=e=>Object.prototype.toString.call(e)==="[object Date]";class n0 extends da{constructor(){super({type:"date",check(i){return O$(i)&&!isNaN(i.getTime())}}),this.withMutation(()=>{this.transform((i,a,r)=>!r.spec.coerce||r.isType(i)||i===null?i:(i=A$(i),isNaN(i)?n0.INVALID_DATE:new Date(i)))})}prepareParam(i,a){let r;if(Ss.isRef(i))r=i;else{let s=this.cast(i);if(!this._typeCheck(s))throw new TypeError(`\`${a}\` must be a Date or a value that can be \`cast()\` to a Date`);r=s}return r}min(i,a=ep.min){let r=this.prepareParam(i,"min");return this.test({message:a,name:"min",exclusive:!0,params:{min:i},skipAbsent:!0,test(s){return s>=this.resolve(r)}})}max(i,a=ep.max){let r=this.prepareParam(i,"max");return this.test({message:a,name:"max",exclusive:!0,params:{max:i},skipAbsent:!0,test(s){return s<=this.resolve(r)}})}}n0.INVALID_DATE=C$;const R$=w(O.div)`
  background: white;
  border-radius: 20px;
  padding: 3rem;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(144, 179, 167, 0.1);
  
  @media (max-width: 768px) {
    padding: 2rem;
    border-radius: 16px;
  }
`;w.div`
  margin-bottom: 1.5rem;
`;w.label`
  display: block;
  font-size: 0.9rem;
  font-weight: 600;
  color: ${e=>e.theme.colors.text.primary};
  margin-bottom: 0.5rem;
  letter-spacing: 0.5px;
`;w(U2)`
  width: 100%;
  padding: 1rem 1.25rem;
  border: 2px solid #e5e7eb;
  border-radius: 12px;
  font-size: 1rem;
  transition: all 0.3s ease;
  background: #fafafa;
  
  &:focus {
    outline: none;
    border-color: ${e=>e.theme.colors.primary};
    background: white;
    box-shadow: 0 0 0 3px rgba(144, 179, 167, 0.1);
  }
  
  &::placeholder {
    color: #9ca3af;
  }
`;w(U2)`
  width: 100%;
  padding: 1rem 1.25rem;
  border: 2px solid #e5e7eb;
  border-radius: 12px;
  font-size: 1rem;
  min-height: 140px;
  resize: vertical;
  transition: all 0.3s ease;
  background: #fafafa;
  font-family: inherit;
  
  &:focus {
    outline: none;
    border-color: ${e=>e.theme.colors.primary};
    background: white;
    box-shadow: 0 0 0 3px rgba(144, 179, 167, 0.1);
  }
  
  &::placeholder {
    color: #9ca3af;
  }
`;w(O.div)`
  color: ${e=>e.theme.colors.error};
  font-size: 0.85rem;
  margin-top: 0.5rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  
  svg {
    width: 16px;
    height: 16px;
  }
`;w(O.div)`
  background: linear-gradient(135deg, #10b981 0%, #34d399 100%);
  color: white;
  padding: 1.5rem;
  border-radius: 12px;
  text-align: center;
  font-weight: 500;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.75rem;
  
  svg {
    width: 24px;
    height: 24px;
  }
`;w(Fz)`
  width: 100%;
  margin-top: 1rem;
  font-size: 1rem;
  padding: 1.25rem 2rem;
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none !important;
  }
  
  svg {
    width: 18px;
    height: 18px;
  }
`;const k$=()=>{const{t:e}=De();return h.jsx(L2,{children:h.jsxs(_2,{children:[h.jsx(H2,{children:e("contacts.form.title")}),h.jsx(V2,{children:e("contacts.form.subtitle")}),h.jsx(R$,{children:h.jsx("p",{children:"Форма контактов будет здесь"})})]})})},D$=()=>{const{t:e}=De(),i=S.useRef(null),a=()=>{i.current&&i.current.scrollIntoView({behavior:"smooth",block:"start"})};return h.jsxs(Vz,{initial:{opacity:0},animate:{opacity:1},transition:{duration:.6},children:[h.jsx(Qz,{onScrollToContent:a}),h.jsxs("div",{ref:i,children:[h.jsx(i$,{}),h.jsx(k$,{})]})]})},M$=()=>{const e=fi();return h.jsxs(wS,{location:e,children:[h.jsx(An,{path:"/",element:h.jsx(kk,{})}),h.jsx(An,{path:"/restaurant",element:h.jsx($k,{})}),h.jsx(An,{path:"/spa",element:h.jsx(hM,{})}),h.jsx(An,{path:"/sports",element:h.jsx(iB,{})}),h.jsx(An,{path:"/banya",element:h.jsx(Hz,{})}),h.jsx(An,{path:"/contacts",element:h.jsx(D$,{})}),h.jsx(An,{path:"*",element:h.jsx(bS,{to:"/",replace:!0})})]})},B$=()=>{const{isLoading:e,isContentReady:i}=Hv();return h.jsxs(h.Fragment,{children:[h.jsx(hA,{isVisible:e}),i&&h.jsx("div",{className:"App",children:h.jsx(vO,{children:h.jsx(M$,{})})})]})};function z$(){const{i18n:e}=De();return S.useEffect(()=>{document.documentElement.dir=e.dir(),document.documentElement.lang=e.language},[e.language]),h.jsxs(J7,{theme:jE,children:[h.jsx(y8,{}),h.jsx(b8,{}),h.jsx(v8,{children:h.jsx(IS,{basename:"/",children:h.jsx(B$,{})})})]})}R4.createRoot(document.getElementById("root")).render(h.jsx(Ce.StrictMode,{children:h.jsx(z$,{})}));
